package com.harman.dmat.common.config;

import javax.inject.Inject;
import javax.sql.DataSource;
import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.TransactionManagementConfigurer;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;
import com.harman.dmat.common.interceptor.AuthorizationInterceptor;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.utils.SecuirtyUtils;

/**
 * The Class AppConfig.
 *
 * @author prakash.bisht@harman.com
 */
@Configuration
@EnableWebMvc
@ComponentScan(basePackages = "com.harman")
@PropertySource(value = { "file:${conf.dir}/config.properties" })
@EnableTransactionManagement
public class AppConfig extends WebMvcConfigurerAdapter implements TransactionManagementConfigurer {

	/**
	 * Injected properties file.
	 */
	@Inject
	private transient Environment environment;

	/**
	 * Providing MVC mechanism.
	 *
	 * @return the view resolver
	 */
	@Bean
	public ViewResolver viewResolver() {
		final InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
		viewResolver.setViewClass(JstlView.class);
		viewResolver.setPrefix("/WEB-INF/views/");
		viewResolver.setSuffix(".jsp");
		return viewResolver;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter
	 * #configureDefaultServletHandling(org.springframework.web.servlet.config.
	 * annotation.DefaultServletHandlerConfigurer)
	 */
	@Override
	public void configureDefaultServletHandling(final DefaultServletHandlerConfigurer configurer) {
		configurer.enable();
	}

	/**
	 * Configuration for database.
	 *
	 * @return the data source
	 */
	@Bean
	public DataSource dataSource() {
		final BasicDataSource dataSource = new BasicDataSource();
		dataSource.setDriverClassName(environment.getRequiredProperty("jdbc.driverClassName"));
		dataSource.setUrl(environment.getRequiredProperty("jdbc.url"));
		dataSource.setUsername(environment.getRequiredProperty("jdbc.username"));
		dataSource.setPassword(SecuirtyUtils.decrypt(environment.getRequiredProperty("jdbc.password")));
		dataSource.setMaxTotal(Integer.parseInt(environment.getRequiredProperty("jdbc.pool.maxTotal")));
		dataSource.setMaxIdle(Integer.parseInt(environment.getRequiredProperty("jdbc.pool.maxIdle")));
		dataSource.setMinIdle(Integer.parseInt(environment.getRequiredProperty("jdbc.pool.minIdle")));
		dataSource.setInitialSize(Integer.parseInt(environment.getRequiredProperty("jdbc.pool.initialSize")));
		dataSource.setMaxWaitMillis(Long.parseLong(environment.getRequiredProperty("jdbc.pool.maxWaitMillis")));
		dataSource.setAccessToUnderlyingConnectionAllowed(true);
		return dataSource;
	}

	/**
	 * Configuration for database.
	 *
	 * @return the data source
	 */
	@Bean
	public DataSource mapDataSource() {
		final BasicDataSource dataSource = new BasicDataSource();
		dataSource.setDriverClassName(environment.getRequiredProperty("jdbc.driverClassName"));
		dataSource.setUrl(environment.getRequiredProperty("jdbc.dburl"));
		dataSource.setUsername(environment.getRequiredProperty("jdbc.dbuname"));
		dataSource.setPassword(SecuirtyUtils.decrypt(environment.getRequiredProperty("jdbc.dbpwd")));
		dataSource.setMaxTotal(Integer.parseInt(environment.getRequiredProperty("jdbc.pool.maxTotal")));
		dataSource.setMaxIdle(Integer.parseInt(environment.getRequiredProperty("jdbc.pool.maxIdle")));
		dataSource.setMinIdle(Integer.parseInt(environment.getRequiredProperty("jdbc.pool.minIdle")));
		dataSource.setInitialSize(Integer.parseInt(environment.getRequiredProperty("jdbc.pool.initialSize")));
		dataSource.setMaxWaitMillis(Long.parseLong(environment.getRequiredProperty("jdbc.pool.maxWaitMillis")));
		dataSource.setAccessToUnderlyingConnectionAllowed(true);
		return dataSource;
	}

	/**
	 * Configuration for the live database.
	 *
	 * @return the data source
	 */
	@Bean
	public DataSource liveDataSource() {
		final org.apache.commons.dbcp2.BasicDataSource dataSource = new BasicDataSource();
		dataSource.setDriverClassName(environment.getRequiredProperty("jdbc.driverClassName"));
		dataSource.setUrl(environment.getRequiredProperty("jdbc.dburl"));
		dataSource.setUsername(environment.getRequiredProperty("jdbc.livedbuname"));
		dataSource.setPassword(SecuirtyUtils.decrypt(environment.getRequiredProperty("jdbc.livedbpwd")));
		dataSource.setMaxTotal(Integer.parseInt(environment.getRequiredProperty("jdbc.pool.maxTotal")));
		dataSource.setMaxIdle(Integer.parseInt(environment.getRequiredProperty("jdbc.pool.maxIdle")));
		dataSource.setMinIdle(Integer.parseInt(environment.getRequiredProperty("jdbc.pool.minIdle")));
		dataSource.setInitialSize(Integer.parseInt(environment.getRequiredProperty("jdbc.pool.initialSize")));
		dataSource.setMaxWaitMillis(Long.parseLong(environment.getRequiredProperty("jdbc.pool.maxWaitMillis")));
		dataSource.setAccessToUnderlyingConnectionAllowed(true);
		return dataSource;
	}

	/**
	 * Transaction Management for Database.
	 *
	 * @return the platform transaction manager
	 */
	@Bean
	public PlatformTransactionManager transactionManager() {
		return new DataSourceTransactionManager(dataSource());
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.springframework.transaction.annotation.
	 * TransactionManagementConfigurer#annotationDrivenTransactionManager()
	 */
	@Override
	public PlatformTransactionManager annotationDrivenTransactionManager() {
		return transactionManager();
	}

	/**
	 * ThreadPool for Email and other synchronized service of system.
	 *
	 * @return the thread pool task executor
	 */
	@Bean
	public ThreadPoolTaskExecutor taskExecutor() {
		final ThreadPoolTaskExecutor pool = new ThreadPoolTaskExecutor();
		pool.setCorePoolSize(5);
		pool.setMaxPoolSize(10);
		pool.setWaitForTasksToCompleteOnShutdown(true);
		return pool;
	}

	/**
	 * Multipart resolver.
	 *
	 * @return the standard servlet multipart resolver
	 */

	@Bean
	public CommonsMultipartResolver multipartResolver() {
		final CommonsMultipartResolver resolver = new CommonsMultipartResolver();
		resolver.setDefaultEncoding("utf-8");
		resolver.setMaxUploadSize(1024 * 1024 * 1024 * 3);
		return resolver;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter
	 * #addInterceptors(org.springframework.web.servlet.config.annotation.
	 * InterceptorRegistry)
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new AuthorizationInterceptor()).addPathPatterns(
				Constant.FULL_PATH + ControllerUrl.GROUP, Constant.FULL_PATH + ControllerUrl.IMPORT_EXCEL_FILE,
				Constant.FULL_PATH + ControllerUrl.DEVICE, Constant.FULL_PATH + ControllerUrl.DELETE_USER,
				Constant.FULL_PATH + ControllerUrl.UPDATE_USER_PROFILE_DATA,
				Constant.FULL_PATH + ControllerUrl.USER_NOTIFICATION, Constant.FULL_PATH + ControllerUrl.DELETE_USERS,
				Constant.FULL_PATH + ControllerUrl.STATUS_CHANGE, Constant.FULL_PATH + ControllerUrl.ACCORDION,
				Constant.FULL_PATH + ControllerUrl.EXPORT, Constant.FULL_PATH + ControllerUrl.LOGMGR_DELETELOGS);
	}

	/*
	 * @Bean public EsClient addEsClient() { return new EsClient(environment); }
	 */

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
}
