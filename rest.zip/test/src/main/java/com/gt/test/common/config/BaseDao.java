package com.harman.dmat.common.config;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

/**
 * @author prakash.bisht@harman.com
 *
 */
public abstract class BaseDao {

	/**
	 * Base JdbcTemplate for query.
	 */
	private JdbcTemplate jdbcTemplate;

	/**
	 * Base JdbcTemplate for query.
	 */
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	/**
	 * Base JdbcTemplate for query.
	 */
	private JdbcTemplate mapJdbcTemplate;

	/**
	 * SimpleJdbcInsert for map client API.
	 */
	private SimpleJdbcInsert clientApiMapSimpleJdbcInsert;

	/**
	 * SimpleJdbcInsert for DeviceTestSummary client API.
	 */
	private SimpleJdbcInsert clientApiDeviceSimpleJdbcInsert;

	/**
	 * SimpleJdbcInsert for InbuildingImage client API.
	 */
	private SimpleJdbcInsert clientApiInbuildingSimpleJdbcInsert;

	/**
	 * SimpleJdbcInsert for PostProcLogs.
	 */
	private SimpleJdbcInsert postProcSimpleJdbcInsert;

	/**
	 * Base JdbcTemplate for live API.
	 */
	private JdbcTemplate liveJdbcTemplate;

	/**
	 * @param dataSource
	 */
	@Autowired
	public void setDataSource(final DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * @param mapDataSource
	 */
	@Autowired
	public void setClientApiMapSimpleJdbcInsert(final DataSource mapDataSource) {
		clientApiMapSimpleJdbcInsert = new SimpleJdbcInsert(mapDataSource);
	}

	/**
	 * @param dataSource
	 */
	@Autowired
	public void setClientApiDeviceSimpleJdbcInsert(final DataSource dataSource) {
		clientApiDeviceSimpleJdbcInsert = new SimpleJdbcInsert(dataSource);
	}

	/**
	 * @param dataSource
	 */
	@Autowired
	public void setClientApiInbuildingSimpleJdbcInsert(final DataSource dataSource) {
		clientApiInbuildingSimpleJdbcInsert = new SimpleJdbcInsert(dataSource);
	}

	@Autowired
	public void setPostProcSimpleJdbcInsert(final DataSource dataSource) {
		postProcSimpleJdbcInsert = new SimpleJdbcInsert(dataSource);
	}

	/**
	 * @param mapDataSource
	 */
	@Autowired
	public void setMapDataSource(final DataSource mapDataSource) {
		mapJdbcTemplate = new JdbcTemplate(mapDataSource);
	}

	/**
	 * @param liveDataSource
	 */
	@Autowired
	public void setLiveDataSource(final DataSource liveDataSource) {
		liveJdbcTemplate = new JdbcTemplate(liveDataSource);
	}

	/**
	 * @param NamedParameterJdbcTemplate
	 */
	@Autowired
	public void setNamedParameterJdbcTemplate(final DataSource dataSource) {
		namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	/**
	 * @return JdbcTemplate
	 */
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	/**
	 * @return JdbcTemplate
	 */
	public JdbcTemplate getMapJdbcTemplate() {
		return mapJdbcTemplate;
	}


	/**
	 * @return SimpleJdbcInsert
	 */
	public SimpleJdbcInsert getClientApiMapSimpleJdbcInsert() {
		return clientApiMapSimpleJdbcInsert;
	}

	/**
	 * @return SimpleJdbcInsert
	 */
	public SimpleJdbcInsert getClientApiDeviceSimpleJdbcInsert() {
		return clientApiDeviceSimpleJdbcInsert;
	}

	/**
	 * @return SimpleJdbcInsert
	 */
	public SimpleJdbcInsert getClientApiInbuildingSimpleJdbcInsert() {
		return clientApiInbuildingSimpleJdbcInsert;
	}

	/**
	 * @return liveJdbcTemplate
	 */
	public JdbcTemplate getLiveJdbcTemplate() {
		return liveJdbcTemplate;
	}

	/**
	 *
	 * @return SimpleJdbcInsert
	 */
	public SimpleJdbcInsert getPostProcSimpleJdbcInsert() { return postProcSimpleJdbcInsert; }

	/**
	 * @return JdbcTemplate
	 */
	public NamedParameterJdbcTemplate getNamedParameterJdbcTemplate() {
		return namedParameterJdbcTemplate;
	}

}
