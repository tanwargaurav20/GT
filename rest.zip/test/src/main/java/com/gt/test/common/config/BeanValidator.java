package com.harman.dmat.common.config;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.springframework.validation.Errors;



/**
 * @author prakash.bisht@harman.com
 * The Class BeanValidator.
 */
public class BeanValidator {

  /** The validator. */
  private Validator validator;


  /**
   * After properties set.
   *
   * @throws Exception the exception
   */
  public void afterPropertiesSet() throws Exception {
    final ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
    validator = validatorFactory.usingContext().getValidator();
  }


  /**
   * Supports.
   *
   * @param clazz the clazz
   * @return true, if successful
   */
  public boolean supports(final Class clazz) {
    return true;
  }


  /**
   * Validate.
   *
   * @param target the target
   * @param errors the errors
   */
  public void validate(final Object target, final Errors errors) {
    final Set<ConstraintViolation<Object>> constraintViolations = validator.validate(target);
    for (final ConstraintViolation<Object> constraintViolation : constraintViolations) {
      final String propertyPath = constraintViolation.getPropertyPath().toString();
      final String message = constraintViolation.getMessage();
      errors.rejectValue(propertyPath, "", message);
    }
  }
}
