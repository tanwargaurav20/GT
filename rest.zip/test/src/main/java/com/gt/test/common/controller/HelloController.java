package com.harman.dmat.common.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


/**
 * @author prakash.bisht@harman.com
 * 
 * The Class HelloController.
 * Sample controller for mvc
 * 
 */
@Controller

public class HelloController {

  /**
   * Hello.
   *
   * @param model the model
   * @return the string
   */
  @GetMapping("/hello")
  public String hello(final Model model) {

    model.addAttribute("name", "John Doe");

    return "welcome";
  }
}
