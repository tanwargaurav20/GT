package com.harman.dmat.common.cron.job;

import java.io.File;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.harman.dmat.dao.LegendsDao;
import com.harman.dmat.service.StorageService;
import com.harman.dmat.service.UserService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author prakash.bisht@harman.com The Class CronJobs contain jobs for send
 *         notification
 */
@Slf4j
@Service
@EnableScheduling
public class CronJobs {

	/** The user service. */
	@Autowired
	UserService userService;
	@Autowired
	LegendsDao legendsDao;
	@Inject
	StorageService storageService;

	/**
	 * Send email notification to inactive users.
	 */
	@Scheduled(cron = "0 1 1 * * *")
	public void sendEmailNotificationToInactiveUsers() {
		log.info("Running sendEmailNotificationToInactiveUsers job");
		userService.sendEmailNotificationToInactiveUsers();
	}

	@Scheduled(fixedDelay = 900000)
	public void maintainDefaultLegendTemplate() {
		log.info("Running default template manager job");
		legendsDao.validateAndUpdateDefaultTemplate();
		log.info("default template update done");
	}

	@Scheduled(fixedDelay = 72000000)
	public void deleteLogFiles() {
		log.info("Running past day log files deletion");
		File[] listFiles = storageService.getRootLocation().toFile().listFiles();
		long purgeTime = System.currentTimeMillis() - (1 * 24 * 60 * 60 * 1000);
		for (File listFile : listFiles) {
			if (listFile.lastModified() < purgeTime) {
				if (listFile.isFile()) {
					listFile.delete();
					log.debug("File deleted from temp location: " + listFile);
					log.debug("File last modified" + listFile.lastModified());
				} else {
					log.debug("Not a file: " + listFile);
				}
			}
		}
	}

}
