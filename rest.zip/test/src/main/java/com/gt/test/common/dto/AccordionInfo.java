package com.harman.dmat.common.dto;

import java.util.HashMap;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccordionInfo {
	private Map<String, AccordionStats> accordionStats;
}
