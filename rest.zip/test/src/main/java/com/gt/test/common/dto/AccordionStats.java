package com.harman.dmat.common.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class AccordionStats {
	int activeCount;
	int inactiveCount;
	int totalCount;
	String name;

	public AccordionStats() {

	}

	public AccordionStats(int totalCount) {
		this.totalCount = totalCount;
	}
}
