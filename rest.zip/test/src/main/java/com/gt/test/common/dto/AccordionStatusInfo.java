package com.harman.dmat.common.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Setter
@Getter
@ToString
public class AccordionStatusInfo {		
	private Boolean isAll=false;
	private List<Integer> includedUserIds;
	private List<Integer> excludedUserdIds;
	public void setIsAll(Boolean all){
		this.isAll=all;
	}
	public Boolean isAll(){
		return isAll;
	}
}
