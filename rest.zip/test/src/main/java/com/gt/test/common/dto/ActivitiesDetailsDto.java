package com.harman.dmat.common.dto;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class CreatedActivitiesDto.
 *
 * @author insgupta06
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)

@Setter
public class ActivitiesDetailsDto {

/** The user id. */
@Getter
private Integer userId;

/** The activity name */
@Getter
private String activityName; 

/** The user name. */
@Getter
private String userName;

/** The activity id. */
@Getter
private Integer activityId;
@Getter
private Integer shareActivityId;


/** The definition expression. */
@Getter
private String definitionExpresion;

/** The zoom level. */
@Getter
private Integer zoomLevel;

/** The xy points. */
@Getter
private String xyPoints;

/** The log id. */
@Getter
private List<Integer> logId;

/**The status of activity**/
@Getter
private String status;
@Getter
private String geoPolygon;
@Getter
private List<String> fileNames;

/**The creation timestamp**/
private Date createdTimestamp;

public String getCreateTimestamp(){
	return createdTimestamp.toString();
}

}
