package com.harman.dmat.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class ActivityCommentDto.
 *
 * @author prakash.bisht@harman.com
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)

/**
 * Gets the log share activity id.
 *
 * @return the log share activity id
 */
@Getter

/**
 * Sets the log share activity id.
 *
 * @param logShareActivityId the new log share activity id
 */
@Setter
public class ActivityCommentDto {

/** The comment. */
private String comment;

/** The user id. */
private Integer userId;

/** The log share activity id. */
private Integer logShareActivityId;

/** The activity id. */
private Integer activityId;

/** The user name. */
private String userName;
/** The Created timestamp. */
private String CreatedTimestamp;
}
