/**
 * 
 */
package com.harman.dmat.common.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author insgupta06
 *
 */
@ToString

/**
 * Gets the group request.
 *
 * @return the group request
 */
@Getter

/**
 * Sets the group request.
 *
 * @param groupRequest the new group request
 */
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ActivityDTO {
	
	/** The user id. */
	private Integer userId;
	
	/** The activity name */
	private String activityName; 
	
	/** The definition expression. **/
	private String definitionExpression;
	
	/** The zoom level. **/
	private Integer zoomLevel;
	
	/** The xy points. **/
	private String xyPoints;
	
	/** The logs ids. */
	private List<Integer> logIds;
	
	/** The geo polygon. */
	private String geoPolygon;
	
	/** The test ids */
	private String testIds; 
	
	/** The file names */
	private String fileNames; 
	
}
