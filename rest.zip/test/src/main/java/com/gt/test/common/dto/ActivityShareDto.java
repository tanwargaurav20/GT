package com.harman.dmat.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class ActivityShareDto.
 *
 * @author prakash.bisht@harman.com
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)

/**
 * Gets the user ids.
 *
 * @return the user ids
 */
@Getter

/**
 * Sets the user ids.
 *
 * @param userIds the new user ids
 */
@Setter
public class ActivityShareDto {

/** The activity id. */
private Integer activityId;

/** The user ids. */
private String email;
}
