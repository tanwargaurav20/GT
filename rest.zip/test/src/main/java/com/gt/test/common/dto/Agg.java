package com.harman.dmat.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class Agg {
	/*
	* Agg.java
	* insnayak20
	**/
	private String sum_other_doc_count;
	private Buckets[] buckets;
	private String doc_count_error_upper_bound;

}
