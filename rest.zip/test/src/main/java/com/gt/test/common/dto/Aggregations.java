package com.harman.dmat.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class Aggregations {
	private Agg agg;
	private AggAvg avg_rsrp;
	private AggAvg avg_rsrq;
	private AggAvg avg_rssi;
	
	/*
	* Aggregations.javass
	* insnayak20
	**/
}
