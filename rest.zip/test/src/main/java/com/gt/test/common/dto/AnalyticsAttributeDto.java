package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AnalyticsAttributeDto {
    private int i;
    private long mag;
}
