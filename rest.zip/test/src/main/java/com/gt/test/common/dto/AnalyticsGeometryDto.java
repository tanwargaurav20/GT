package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AnalyticsGeometryDto {
    private String type = "point";
    private double x;
    private double y;
    private int spatialReference = 102100;
}
