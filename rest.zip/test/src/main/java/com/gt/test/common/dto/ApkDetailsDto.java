package com.harman.dmat.common.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApkDetailsDto {
	
	private long count;
	private List<ApkDto> apkList;

}
