package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApkDto {

	private String versionNum ;
	private long count;
}