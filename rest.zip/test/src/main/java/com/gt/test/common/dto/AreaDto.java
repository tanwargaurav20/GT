package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by srinivasu on 7/12/2017.
 */
@Getter
@Setter
public class AreaDto {
    private Double minX;
    private Double minY;
    private Double maxX;
    private Double maxY;
    private Integer wkid;
}
