package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AutoTestReportDto {
    private int detailsid;
    private String downloadspeed;
    private String pingduration;
    private String uploadspeed;
    private String losspercentage;
    private String packetreceived;
    private String packetsent;
    private String bandwidth;
    private String interval;
    private String transfer;
    private String actualduration;
    private String configuredduration;
    private String mo;
    private String mt;
    private String smsdelivered;
    private String smssent;
    private String receiver;
    private String sender;
    private String starttime;
    private String endtime;
    private String iteration;
    private String latitude;
    private String longitude;
    private String name;
    private String teststatus;
    private String errormsg;
}
