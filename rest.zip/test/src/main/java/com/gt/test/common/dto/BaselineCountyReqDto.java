package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaselineCountyReqDto {
    private String kpiName;
    private String startDate;
    private String endDate;
    private String domain;
    private String imeiS;
    private String imeiT;
    private String mdnS;
    private String mdnT;
    private String modelS;
    private String modelT;
    private String tlLat;
    private String tlLon;
    private String brLat;
    private String brLon;
    private String magnitude;
    private String userId;
}
