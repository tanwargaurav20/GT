package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.Map;

@Getter
@Setter
public class BaselineCountyResDto {
    private Map<String, Long> counties;
    private Map<String, Long> states;
    private Map<String, Long> regions;
}
