package com.harman.dmat.common.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CellSiteClusterResponseDto {
	private String objectIdFieldName;
	private FieldAliasDto fieldAlias;
	private String geometryType;
	private SpatialReferenceDto spatialReference;
	private List<FieldsDto> fields;
	private List<CellsiteFeaturesDto> features;
}
