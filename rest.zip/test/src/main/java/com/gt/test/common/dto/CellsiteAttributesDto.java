package com.harman.dmat.common.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonAutoDetect;

@Setter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE, getterVisibility = JsonAutoDetect.Visibility.NONE,
setterVisibility = JsonAutoDetect.Visibility.NONE, creatorVisibility = JsonAutoDetect.Visibility.NONE,
isGetterVisibility = JsonAutoDetect.Visibility.NONE)
public class CellsiteAttributesDto {

	@JsonProperty("ID")
	private String ID;	

	@JsonProperty("loc")
	private String loc;
}