package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConnectedDto {
    private String ssid;
    private String bssid;
    private String rssi;
    private String ipAddress;
    private String linkSpeed;
    private String macAddress;
    private String networkId;
    private String hiddenSsid;
    private String gateway;
    private String netmask;
    private String encryption;
    private String dhcpServer;
    private String secondryDns;
    private String channel;
}
