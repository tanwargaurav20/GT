package com.harman.dmat.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
@ToString
public class CustomReportsDownloadPdfRequestDto {
    private Integer reportType;
    private CustomReportsRequestDto timeseriesRequestDto;
    private CustomReportsRequestDto histogramRequestDto;
    private String fileName;
}
