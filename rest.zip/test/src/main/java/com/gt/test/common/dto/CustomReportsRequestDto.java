package com.harman.dmat.common.dto;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
@ToString
public class CustomReportsRequestDto {

	private List<String> userIds;
	private List<String> kpis;
	private List<String> imei;
	private List<String> states;
	private List<String> testId;
	private List<String> fileNames;
	private Integer data;
	private String from;
	private String to;
}