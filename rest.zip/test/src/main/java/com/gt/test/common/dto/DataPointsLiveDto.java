package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * DataPointsLive Data Transfer Object.
 */
@Getter
@Setter
@ToString
public class DataPointsLiveDto {
    private String RecordTime = "";
    private String lat = "";
    private String lng = "" ;
    private String filename = "";
    private String imei = "" ;
    private String imsi = "" ;

    private String servingCell = "" ;
    private String rsrp = "" ;
    private String rsrq = "" ;
    private String rssi = "" ;
    private String sinr = "" ;
    private String puschTx = "" ;
    private String pucchActualTx = "" ;
    private String BandIndicator = "" ;
    private String Rat = "" ;

    private String CdmaSID = "" ;
    private String CdmaNID = "" ;
    private String CdmaECIO = "" ;
    private String CdmaBandClass = "" ;

    private String mdn = "" ;

    private String PDSCH = "" ;
    private String PUSCH = "" ;
    private String MACUL = "" ;
    private String MACDL = "" ;
    private String RLCUL = "" ;
    private String RLCDL = "" ;
    private String PDCPUL = "" ;
    private String PDCPDL = "" ;

    private String statecode = "" ;
    private String county_ns = "" ;
    private String VZ_Regions = "" ;
    private String Country = "" ;

    private double x_mercator = 0.00;
    private double y_mercator = 0.00;
    private String shape = "";
}