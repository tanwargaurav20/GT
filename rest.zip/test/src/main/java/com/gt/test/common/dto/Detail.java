package com.harman.dmat.common.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Detail {
    private int detailsId;
    private double downloadSpeed;
    private int pingDuration;
    private double uploadSpeed;
    private String startTime;
    private String endTime;
    private int iteration;
    private double latitude;
    private double longitude;
    private String name;
    private String testStatus;
    private String errorMsg;
    private long actualDuration;
    private boolean smsDelivered;
    private boolean smsSent;

    @JsonProperty("ConfiguredDuration")
    private long configuredDuration;
    private String mo;
    private String mt;
    private String sender;
    private String receiver;
    private String bandwidth;
    private String interval;
    private String transfer;
    private String lossPercentage;
    private String packetReceived;
    private String packetSent;
}
