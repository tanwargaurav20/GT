package com.harman.dmat.common.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;


/**
 * Gets the os not supported.
 *
 * @return the os not supported
 */
@Getter
/**
 * Sets the os supported.
 *
 * @param osSupported the new os supported
 */

/**
 * Sets the os not supported.
 *
 * @param osNotSupported the new os not supported
 */
@Setter
public class DeviceDto {
	
	/** The id. */
	private Integer id;
	/** The device name. */
	private String deviceName;
	
	/** The device manifacturer. */
	private String deviceManufacturer;
	
	/** The device model. */
	private String deviceModel;
	
	/** The os supported. */
	private List<String> osSupported;
	
	/** The os not supported. */
	private List<String> osNotSupported;

}
