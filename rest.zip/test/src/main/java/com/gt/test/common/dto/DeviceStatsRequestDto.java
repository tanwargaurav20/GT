package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class DeviceStatsRequestDto {
    private String fromDate;
    private String toDate;
    private String tlLat;
    private String tlLon;
    private String brLat;
    private String brLon;
    private String locCode;
    private List<String> events;
    private List<String> devices;
    private List<String> timeFrame;
    private List<String> kpiRanges;
    private String kpi;
    private String domain;
    private String userId;
}
