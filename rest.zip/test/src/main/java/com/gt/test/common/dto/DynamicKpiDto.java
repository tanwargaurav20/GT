package com.harman.dmat.common.dto;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class DynamicKpiDto {
	/*
	 * DynamicKpiDto.java insnayak20
	 **/
	private String timeFrom;
	private String timeTo;
	private String userId;
	private MapExtent mapExtent;
	private Map<String, String> valueColorMap;
	private Map<String, List<Integer>> filter;
	private String kpiName;
}
