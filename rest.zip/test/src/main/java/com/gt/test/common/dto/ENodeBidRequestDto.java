package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ENodeBidRequestDto {
    private String fromDate;
    private String toDate;
    private String tlLat;
    private String tlLon;
    private String brLat;
    private String brLon;
    private String userId;
    private String domain;
}
