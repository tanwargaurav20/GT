package com.harman.dmat.common.dto;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class EditRoleDto {
	@NotEmpty(message = "Please enter valid email.")
	private String email;
	@NotNull(message="old role id can't be null")
	private Integer oldRole;
	@NotNull(message="new role id can't be null")
	private Integer newRole;

}
