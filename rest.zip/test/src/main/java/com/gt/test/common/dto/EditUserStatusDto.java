package com.harman.dmat.common.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

import org.hibernate.validator.constraints.NotEmpty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EditUserStatusDto {
	@Null@NotEmpty(message = "email id is either null or empty")
	private String email;
	@NotNull@NotEmpty(message="role id can't pe null or emplty")
	private Integer roleId;
	@NotNull@NotEmpty(message="please specify either user needs to be active or inactive")
	@Max(1)
	private Integer status;
	

}
