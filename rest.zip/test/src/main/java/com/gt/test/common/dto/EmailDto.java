package com.harman.dmat.common.dto;

import java.io.File;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmailDto {
    private String name;
    private String emailTo;
    private String emailMessage;
    private String emailSubject;
    private File file;

    public EmailDto(String name, String emailTo, String emailMessage, String emailSubject) {
        super();
        this.name = name;
        this.emailTo = emailTo;
        this.emailMessage = emailMessage;
        this.emailSubject = emailSubject;
    }
}
