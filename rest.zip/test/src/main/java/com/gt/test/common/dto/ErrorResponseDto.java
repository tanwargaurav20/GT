package com.harman.dmat.common.dto;

/**
 * The Class ErrorResponseDto.
 *
 * @author <a href="mailto:Prakash.Bisht@harman.com">Prakash Bisht</a>
 */
public class ErrorResponseDto {

  /** The error code. */
  private int errorCode;

  /** The message. */
  private String message;

  /**
   * Gets the error code.
   *
   * @return the error code
   */
  public int getErrorCode() {
    return errorCode;
  }

  /**
   * Sets the error code.
   *
   * @param errorCode the new error code
   */
  public void setErrorCode(final int errorCode) {
    this.errorCode = errorCode;
  }

  /**
   * Gets the message.
   *
   * @return the message
   */
  public String getMessage() {
    return message;
  }

  /**
   * Sets the message.
   *
   * @param message the new message
   */
  public void setMessage(final String message) {
    this.message = message;
  }
}
