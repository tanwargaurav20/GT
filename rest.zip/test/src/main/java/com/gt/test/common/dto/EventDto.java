package com.harman.dmat.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class EventDto.
 *
 * @author prakash.bisht@harman.com
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)

/**
 * Gets the icon path.
 *
 * @return the icon path
 */
@Getter

/**
 * Sets the icon path.
 *
 * @param iconPath
 *            the new icon path
 */
@Setter
public class EventDto {

	/** The id. */
	private Integer id;

	/** The key. */
	private String key;

	/** The description. */
	private String description;

	/** The icon path. */
	private String iconPath;

	/** Color. */
	private String color;

}
