package com.harman.dmat.common.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

/**
 * @author GTanwar
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)

@Getter

@Setter
public class EventDtos {

	/** List of Events Dto. */
	private List<EventDto> eventsInfo;

	/** Total Events. */
	private String totalEvents;

	/** Distinct Events. */
	private String distinctEvents;

}
