package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EventStatusDto {
    private Long newEvents;
    private Long inProgressEvents;
    private Long failureEvents;
    private Long successEvents;
}
