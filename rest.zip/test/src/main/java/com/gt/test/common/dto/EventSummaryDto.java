package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Map;

@Getter
@Setter
public class EventSummaryDto {
    private String eventStartDate;
    private Map<String, String> eventOccurrence;
    private List<EventsDto> events;
}
