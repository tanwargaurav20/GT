package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EventsDto {
    private String name;
    private String time;
    private DataDto data;
}
