package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EventsInfoDto {
    private String eventName;
    private String fileName;
    private String timeStamp;
    private String lon;
    private String lat;
    private String objectId;
    private String firstName;
    private String lastName;
    private String emailId;
    private String userId;
    private String status;
    private String eventESName;
}
