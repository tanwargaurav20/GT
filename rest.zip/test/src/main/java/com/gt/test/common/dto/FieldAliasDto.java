package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FieldAliasDto {
    private String ID;
}
