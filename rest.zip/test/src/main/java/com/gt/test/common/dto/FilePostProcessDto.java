package com.harman.dmat.common.dto;

import com.harman.dmat.utils.Utill;
import lombok.Setter;

@Setter
public class FilePostProcessDto {
    private String processDate;
    private Long filesPicked;
    private Long partDir;
    private Long partFiles;
    private Long filesProcessed;
    private Long partFilesProcessed;
    private Long processFailed;
    private Long totalFilesProcessed;

    public String getProcessDate() {
        return processDate == null ? null : Utill.formatDateToUsDate(processDate);
    }

    public Long getFilesPicked() {
        return filesPicked != null ? filesPicked : 0;
    }

    public Long getPartDir() {
        return partDir != null ? partDir : 0;
    }

    public Long getPartFiles() {
        return partFiles != null ? partFiles : 0;
    }

    public Long getFilesProcessed() {
        return filesProcessed != null ? filesProcessed : 0;
    }

    public Long getPartFilesProcessed() {
        return partFilesProcessed != null ? partFilesProcessed : 0;
    }

    public Long getProcessFailed() {
        return processFailed != null ? processFailed : 0;
    }

    public Long getTotalFilesProcessed() {
        return totalFilesProcessed != null ? totalFilesProcessed : 0;
    }
}
