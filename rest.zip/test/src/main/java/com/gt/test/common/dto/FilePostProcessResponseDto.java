package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class FilePostProcessResponseDto {
    private int count;
    private List<FilePostProcessDto> filePostProcessDtoList;
}
