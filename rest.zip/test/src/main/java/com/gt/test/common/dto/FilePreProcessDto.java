package com.harman.dmat.common.dto;

import com.harman.dmat.utils.Utill;
import lombok.Setter;

@Setter
public class FilePreProcessDto {
    private String processDate;
    private Long filesPicked;
    private Long zipFiles;
    private Long dlfFiles;
    private Long others;
    private Long staged;
    private Long preProcessed;
    private Long failed;
    private Long mvWorkDir;
    private Long mvPartDir;

    public String getProcessDate() {
        return processDate == null ? null : Utill.formatDateToUsDate(processDate);
    }

    public Long getFilesPicked() {
        return filesPicked != null ? filesPicked : 0;
    }

    public Long getZipFiles() {
        return zipFiles != null ? zipFiles : 0;
    }

    public Long getDlfFiles() {
        return dlfFiles != null ? dlfFiles : 0;
    }

    public Long getOthers() {
        return others != null ? others : 0;
    }

    public Long getStaged() {
        return staged != null ? staged : 0;
    }

    public Long getPreProcessed() {
        return preProcessed != null ? preProcessed : 0;
    }

    public Long getFailed() {
        return failed != null ? failed : 0;
    }

    public Long getMvWorkDir() {
        return mvWorkDir != null ? mvWorkDir : 0;
    }

    public Long getMvPartDir() {
        return mvPartDir != null ? mvPartDir : 0;
    }

}
