package com.harman.dmat.common.dto;

import com.harman.dmat.utils.Utill;
import lombok.Setter;

@Setter
public class FileProcessDirComparisonDto {

    private String processDate;
    private Long individualFiles;
    private Long partDirCount;
    private Long totalPartFiles;
    private Long filesFailed;
    private Long total;

    public String getProcessDate() {
        return processDate == null ? null : Utill.formatDateToUsDate(processDate);
    }

    public Long getIndividualFiles() {
        return individualFiles != null ? individualFiles : 0;
    }

    public Long getPartDirCount() {
        return partDirCount != null ? partDirCount : 0;
    }

    public Long getTotalPartFiles() {
        return totalPartFiles != null ? totalPartFiles : 0;
    }

    public Long getFilesFailed() {
        return filesFailed != null ? filesFailed : 0;
    }

    public Long getTotal() {
        return getIndividualFiles() + getTotalPartFiles() + getFilesFailed();
    }

    public String getFormattedProcessDate() {
        return processDate;
    }

}
