package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class FileProcessDirComparisonResponseDto {
    private int count;
    private List<FileProcessDirComparisonDto>  fileProcessDirComparisonDtoList;
}
