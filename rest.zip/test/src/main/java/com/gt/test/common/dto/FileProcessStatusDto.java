package com.harman.dmat.common.dto;

import com.harman.dmat.utils.Utill;
import lombok.Setter;

@Setter
public class FileProcessStatusDto {
    private String processDate;
    private Long ftpFiles;
    private Long preProcessedFiles;
    private Long postProcessedFiles;
    private Long postProcessedRecords;
    private Long postProcessedEvents;
    private Long esFiles;
    private Long esRecords;
    private Long esEvents;
    private Long failedFiles;

    public String getProcessDate() {
        return processDate == null ? null : Utill.formatDateToUsDate(processDate);
    }

    public Long getFtpFiles() {
        return ftpFiles != null ? ftpFiles : 0;
    }

    public Long getPreProcessedFiles() {
        return preProcessedFiles != null ? preProcessedFiles : 0;
    }

    public Long getPostProcessedFiles() {
        return postProcessedFiles != null ? postProcessedFiles : 0;
    }

    public Long getPostProcessedRecords() {
        return postProcessedRecords != null ? postProcessedRecords : 0;
    }

    public Long getPostProcessedEvents() {
        return postProcessedEvents != null ? postProcessedEvents : 0;
    }

    public Long getEsFiles() {
        return esFiles != null ? esFiles : 0;
    }

    public Long getEsRecords() {
        return esRecords != null ? esRecords : 0;
    }

    public Long getEsEvents() {
        return esEvents != null ? esEvents : 0;
    }

    public Long getFailedFiles() {
        return failedFiles != null ? failedFiles : 0;
    }

    public String getFormattedProcessDate() {
        return processDate;
    }
}
