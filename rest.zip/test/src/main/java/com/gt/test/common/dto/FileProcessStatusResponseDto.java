package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class FileProcessStatusResponseDto {
    private int count;
    private List<FileProcessStatusDto> fileProcessStatusDtoList;
}
