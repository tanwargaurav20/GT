package com.harman.dmat.common.dto;

import java.util.Date;
import java.util.Optional;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FileUploadDto {
	/*
	 * FileUploadDto.java insnayak20
	 **/
	private Long id;
	private String type;
	private String version;
	private String fileName;
	private String description;
	private String size;
	private Optional<String> location;
    private Date createdDate;
	private String createdDateTime;
    public FileUploadDto(String type, String version, String fileName, String description, String size,
			Optional<String> location) {
		super();
		this.type =type ;
		this.version = version;
		this.location = location;
		this.fileName = fileName;
		this.description = description;
		this.size = size;

	}

}
