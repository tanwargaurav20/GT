package com.harman.dmat.common.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class FilterDto {
	private List<String> fileName;
	private List<String> imei;
	private List<String> mdn;
	private List<String> stateName;
	private List<String> modelName;

}
