package com.harman.dmat.common.dto;

import org.hibernate.validator.constraints.Email;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ForgetPasswordDto {
	@Email(message = "Please enter valid username.")
	String userName;

}
