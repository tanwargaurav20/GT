package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GeometryDto {
    private double x;
    private double y;
    private double locX;
    private double locY;
}
