package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Map;
import java.util.Set;

@Getter
@Setter
public class GlobalFilterDataDto {
    private List<LogUserDto> logUsers;
    private Map<String, List<UserDto>> userGroups;
    private Set<String> imeis;
    private Set<String> mdns;
    private Set<String> models;
    private Set<String> statCodes;
}
