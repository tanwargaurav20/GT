package com.harman.dmat.common.dto;

import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@ToString
public class GlobalFilterDto {

	private List<String> dm_user;
	private java.sql.Date uploadedDate;
	private java.sql.Date logCapturedDate;
	private String userLastName;
	private List<UserLogFileDto> userLogFiles;
	private String testId;
	private long size;
	private String gps;
	private Set<String> imei;
	private String status;
	private Set<String> mdn;
	private Integer modelId;
	private Boolean autotest;
	private String firstName;
	private String lastName;
	private Set<String> model;
	private Integer userModelId;
	private String email;
	private List<String> statecode;
	private Set<String> vz_regions ;
	private List<String> statename ;
	private List<GroupDto> groupDtos;
	private Integer totalUser;
	private Set<String> logFiles;
	
	

}
