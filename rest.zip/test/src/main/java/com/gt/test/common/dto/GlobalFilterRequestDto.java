package com.harman.dmat.common.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class GlobalFilterRequestDto.
 *
 * @author prakash.bisht@harman.com
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)

/**
 * Gets the logfiles.
 *
 * @return the logfiles
 */
@Getter

/**
 * Sets the logfiles.
 *
 * @param logfiles the new logfiles
 */
@Setter
public class GlobalFilterRequestDto {
	
	/** The mdns. */
	private List<String> mdns;
	
	/** The models. */
	private List<String> models;
	
	/** The imeis. */
	private List<String> imeis;
	
	/** The logfiles. */
	private List<String>logfiles;

}
