package com.harman.dmat.common.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class GroupDto.
 *
 * @author prakash.bisht@harman.com
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)

/**
 * Gets the users.
 *
 * @return the users
 */
@Getter

/**
 * Sets the users.
 *
 * @param users the new users
 */
@Setter
public class GroupDto {
	
	/** The group id. */
	private Integer groupId;
	
	/** The group admin id. */
	private Integer groupAdminId;
	
	/** The group name. */	
	private String groupName;
	
	/** The add user ids. */
	private List<Integer> addUserIds;
	
	/** The remove user ids. */
	private List<Integer> removeUserIds;
	
	/** The users. */
	private List<UserDto> users;
	

}
