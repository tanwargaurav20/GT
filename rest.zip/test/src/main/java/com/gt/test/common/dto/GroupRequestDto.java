package com.harman.dmat.common.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

/**
 * Gets the users.
 *
 * @author prakash.bisht@harman.com
 * @return the users
 */

/**
 * Gets the group name.
 *
 * @return the group name
 */
@Getter

/**
 * Sets the users.
 *
 * @param users
 *            the new users
 */

/**
 * Sets the group name.
 *
 * @param groupName the new group name
 */
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GroupRequestDto {
	
	/** The status. */
	@NotNull
	private Integer status;
	
	/** The group id. */
	@NotNull
	private Integer groupId;
	
	/** The group name. */
	
	private String groupName;
	
	/** The admin name. */
	private String adminName;
}
