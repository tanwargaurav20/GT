package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HeatMapRequestDto {
    private String timeStampFrm;
    private String timeStampTo;
    private String userId;
    private String magnitude;
    private String tlLat;
    private String tlLon;
    private String brLat;
    private String brLon;
    private boolean cdmaless;
    private String locCode;
}
