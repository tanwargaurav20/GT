package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class HeatMapResponseDto {
    private String displayFieldID;
    private FieldAliasDto fieldAlias;
    private String geometryType;
    private SpatialReferenceDto spatialReference;
    private List<FieldsDto> fields;
    private List<FeaturesDto> features;

}
