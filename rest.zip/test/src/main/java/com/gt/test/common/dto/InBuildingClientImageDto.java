package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InBuildingClientImageDto {
    private int id ;
    private byte[] buildingimage ;
    private String name ;
    private String address ;
    private String statecode ;
    private String zip ;
    private String city ;
    private int floorlevel ;
    private int userid ;
}
