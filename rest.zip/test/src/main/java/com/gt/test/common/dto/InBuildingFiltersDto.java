package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InBuildingFiltersDto {
    private String state ;
    private String city ;
    private String zip ;
    private UserFiltersDto userFiltersDto;
}
