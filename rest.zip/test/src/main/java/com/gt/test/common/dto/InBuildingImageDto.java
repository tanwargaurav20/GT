package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InBuildingImageDto {
    private int id ;
    private byte[] image ;
    private String name ;
    private String buildingaddress ;
    private String statecode ;
    private String zipcode ;
    private String city ;
    private int floorlevel ;
    private int userid ;
    private int dmuser;
    private int access;
}
