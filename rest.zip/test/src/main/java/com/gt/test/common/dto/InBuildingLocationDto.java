package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InBuildingLocationDto {
    public String state ;
    public String city ;
    public String zip ;
}
