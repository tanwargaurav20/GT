package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class InBuildingLogViewDto {

    private String fileName;
    private Integer imageIds;
    private Integer testId;
}
