package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InbuildingUploadImageDto {
    private String imei;
    private String imsi;
    private String email;
    private String access;
    private String buildingName;
    private String floorLevel;
    private String buildingAddress;
    private String city;
    private String state;
    private String zipCode;
    private byte[] image;
    private int imageWidth;
    private int imageHeight;
}
