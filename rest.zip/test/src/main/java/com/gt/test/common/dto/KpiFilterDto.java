package com.harman.dmat.common.dto;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class KpiFilterDto {
	/*
	 * KpiFilterDto.java insnayak20
	 **/
	private boolean isKpisEnable;
	private List<FilterKpi> filterKpiList;
	private Map<String, List<String>> ratValues;

	public void setIsKpisEnable(boolean isKpisEnable) {
		this.isKpisEnable = isKpisEnable;
	}

}
