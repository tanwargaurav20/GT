package com.harman.dmat.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.harman.dmat.utils.Utill;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@Getter
@Setter
@ToString
public class LiveInfoPointsDto {

	private String rsrp;
	private String rsrq;
	private String rssi;
	private String sinr;
	private String pushTx;
	private String servingCell;
	private String pucchActualTx;
	private String file_name;
	private String dm_user;
	private String imei;
	private String mdn;
	@Getter(AccessLevel.NONE)
	private String dmtimestamp;
	private String bandIndicator;
	private String rat;
	private String pdschThroughput;
	private String puschThroughput;
	private String macUlTx;
	private String macDlTx;
	private String rlcul;
	private String rlcdl;
	private String pdcpul;
	private String pdcpdl;

	public String getDmtimestamp() {
		return dmtimestamp == null ? null : Utill.liveDbdateToUsFormat(dmtimestamp);
	}

}
