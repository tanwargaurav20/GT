package com.harman.dmat.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@ToString
public class LiveTrendingDto {

	private String rsrp;
	private String rsrq;
	private String rssi;
	private String sinr;
	private String pdsch;
	private String pusch;
	private String time;
	private String dmtimestamp;

}
