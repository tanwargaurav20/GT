package com.harman.dmat.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@ToString
public class LogMgrAnalysisDto {

	@Getter(AccessLevel.NONE)
	private String status;
	private String percentage;
	private Long count;

	public String getStatus() {
		return status == null ? "No Status Available" : status;
	}
}
