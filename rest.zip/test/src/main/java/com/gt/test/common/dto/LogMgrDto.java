package com.harman.dmat.common.dto;

import java.math.BigDecimal;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.harman.dmat.utils.Utill;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@ToString
public class LogMgrDto {

	private List<String> deleteFiles;
	private List<Integer> testIds;
	private int id;
	@Getter(AccessLevel.NONE)
	private String uploadedDate;
	@Getter(AccessLevel.NONE)
	private String logCapturedDate;
	private String fileName;
	private String testId;
	private long size;
	private String gps;
	@Getter(AccessLevel.NONE)
	private String imei;
	private String status;
	private String mdn;
	private String firstName;
	private String lastName;
	private String modelName;
	private String email;
	private String logType;
	private String events;
	private String startDate;
	private String endDate;
	private boolean atrFlag;

	public String getUploadedDate() {
		return uploadedDate == null ? null : Utill.dateToUsFormat(uploadedDate);
	}

	public String getLogCapturedDate() {
		return logCapturedDate == null ? null : Utill.dateToUsFormat(logCapturedDate);
	}

	public String getImei() {
		//return imei == null ? null : new BigDecimal(imei).toPlainString();
		return imei;
	}

}
