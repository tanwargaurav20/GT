package com.harman.dmat.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@ToString
public class LogMgrPrefDto {

	private Integer userId;
	private Boolean uploadedDate;
	private Boolean logCapturedDate;
	private Boolean fileName;
	private Boolean testId;
	private Boolean size;
	private Boolean gps;
	private Boolean imei;
	private Boolean status;
	private Boolean mdn;
	private Boolean userName;
	private Boolean modelName;
	private Boolean email;
	private Boolean logType;
	private Boolean events;

}
