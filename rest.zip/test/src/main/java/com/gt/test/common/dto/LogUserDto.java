package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
public class LogUserDto {
    private int userId;
    private String firstName;
    private String lastName;
    private Set<String> fileNames;
}
