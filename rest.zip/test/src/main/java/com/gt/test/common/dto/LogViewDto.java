package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class LogViewDto {
    private String fileName;
    private int testId;
    private String eventTimeStamp;
    private String status;
    private String filePath;
    private int objectId;
    private int duration;

    @Override
    public String toString(){
        return "{"+this.objectId + ","+this.status+"}";
    }
}
