package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LogViewResponseDto {
    private String fileName;
    private int testid;
    private String evt_timestamp;
    private int lvfid;
}
