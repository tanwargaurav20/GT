package com.harman.dmat.common.dto;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class LoginDto {
	@NotEmpty(message = "Please enter valid username.")
	@Email
	String userName;
	@NotEmpty(message = "Please enter valid password.")
	//@Pattern(regexp = "((?=.*\\d)(?=.*[\\a-z])(?=.*[A-Z])(?=.*[!-@#$%]).{8,20})", message = "Please enter valid password.")
	String password;

	String accessCode;

}
