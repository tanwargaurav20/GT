package com.harman.dmat.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class MapExtent {
	/*
	* MapExtent.java
	* insnayak20
	**/
	private Double corner1;
	private Double corner2;
	private Double corner3;
	private Double corner4;
	
}
