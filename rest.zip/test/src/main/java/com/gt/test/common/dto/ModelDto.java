package com.harman.dmat.common.dto;

import java.math.BigInteger;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Gets the model name.
 *
 * @return the model name
 */
@Getter

/**
 * Sets the model name.
 *
 * @param modelName the new model name
 */
@Setter

/**
 * Instantiates a new model dto.
 */
@NoArgsConstructor
public class ModelDto {
	
	/** The model id. */
	private BigInteger modelId;
	
	/** The model name. */
	private String modelName;

}
