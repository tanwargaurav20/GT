package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NeighborDto {
    private String ssid;
    private String rssi;
    private String bssid;
    private String channel;
    private String securityType;
    private int frequency;
}
