package com.harman.dmat.common.dto;

public class NotificationInfoDto {
String subject;
String body;

}
