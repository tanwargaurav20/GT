package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * OEM Data Transfer Object
 */
@Getter
@Setter
public class OemDto {
    public int id;
    public String name;
    public String emailId;
    public List<String> tacList;
    public List<String> imeiList;
    public List<String> emailIds;
}
