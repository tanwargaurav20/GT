package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OsDto {
	private Integer id;
	private String name;
	private String version;

}
