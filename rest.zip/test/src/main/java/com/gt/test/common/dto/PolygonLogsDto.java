package com.harman.dmat.common.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/* (non-Javadoc)
 * @see java.lang.Object#toString()
 */
@ToString

/**
 * Gets the group request.
 *
 * @return the group request
 */

/**
 * Gets the total.
 *
 * @return the total
 */
@Getter

/**
 * Sets the group request.
 *
 * @param groupRequest the new group request
 */

/**
 * Sets the total.
 *
 * @param total the new total
 */
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PolygonLogsDto {
	
	/** The logs. */
	List<Object> logs;
	
	/** The total. */
	Long total;
}
