package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PostProcLogsDto {
    private int dmUser;
    private String fileName;
    private String mdn;
    private String imei;
    private String emailId;
    private String modelName;
    private String fileLocation;
    private String appVersionCode;
    private String appVersionName;
    private String baseBandVersion;
    private String iccid;
    private String imsFeatureTag;
    private String imsStatus;
    private String imsi;
    private String isLastChunk;
    private String oemName;
    private String osBuildId;
    private String osSdkLevel;
    private String osVersion;
    private int isnondmat;
}
