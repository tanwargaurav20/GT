package com.harman.dmat.common.dto;

import javax.xml.bind.annotation.XmlType;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@XmlType(propOrder = { "status", "message", "data" })
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseDto {

	private String status;
	private String message = "Successfull.";
	private Object data;
	private Integer totalCount;
	private String errorMessage;
	private Integer errorCode;
	private String developerMessage;
	private Integer statusCode;
	
	public ResponseDto(Object data){
		this.data=data;
	}
}
