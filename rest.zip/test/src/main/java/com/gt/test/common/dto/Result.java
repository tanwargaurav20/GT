package com.harman.dmat.common.dto;



import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class Result {
	/*
	* Result.java
	* insnayak20
	**/
	private Hits hits;
	private Shards _shards;
	private String timed_out;
	private String took;
	private Aggregations aggregations;

}
