package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class RoleDto {
	private Integer roleId;
	private String roleName;
	private String desc;

}
