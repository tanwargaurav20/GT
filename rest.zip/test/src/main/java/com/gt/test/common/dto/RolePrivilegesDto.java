package com.harman.dmat.common.dto;

import java.util.Date;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class RolePrivilegesDto {
  private Integer roleId;
  private List<PrivilegeDto> privileges;
  private Integer isAllowed;
  private Date insertTime;
  private String insertLogin;
  private Date updateTime;
  private String updateLogin;



 

}
