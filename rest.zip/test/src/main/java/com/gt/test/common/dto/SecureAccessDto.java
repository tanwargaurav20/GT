package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SecureAccessDto {
    private int id;
    private int userId;
    private String pin;
    private String creationTime;
    private boolean verified;
    private String mdn;
}
