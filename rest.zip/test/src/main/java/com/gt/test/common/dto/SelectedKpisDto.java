package com.harman.dmat.common.dto;

import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

/**
 * @author GTanwar
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class SelectedKpisDto {

	private List<String> selectedKpis;
	private Map<String, List<String>> bandValues;
	private Map<String, List<String>> earfcnValues;

}
