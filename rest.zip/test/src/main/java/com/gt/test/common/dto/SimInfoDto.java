package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SimInfoDto {
private String iccid;
private String simPin;
private String simPuk;
}
