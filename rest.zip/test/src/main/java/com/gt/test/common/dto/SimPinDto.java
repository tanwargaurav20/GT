package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SimPinDto {
    private String imei;
    private String imsi;
    private String mode;
    private String pin;
    private String iccid;
    private String appVersion;
}
