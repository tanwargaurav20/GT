package com.harman.dmat.common.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * Gets the sim infos.
 *
 * @return the sim infos
 */
@Getter

/**
 * Sets the sim infos.
 *
 * @param simInfos the new sim infos
 */
@Setter
public class SimRequestData {

/** The total count. */
private Integer totalCount;

/** The sim infos. */
private List<SimRequestDto> simInfos;
}
