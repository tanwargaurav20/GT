package com.harman.dmat.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class SimRequestDto.
 *
 * @author prakash.bisht@harman.com
 */

/**
 * Gets the first name.
 *
 * @return the first name
 */

/**
 * Gets the last login.
 *
 * @return the last login
 */
@Getter

/**
 * Sets the address.
 *
 * @param address the new address
 */

/**
 * Sets the first name.
 *
 * @param firstName the new first name
 */

/**
 * Sets the last login.
 *
 * @param lastLogin the new last login
 */
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SimRequestDto {

/** The bussines reason. */
private String businessReason;

/** The no of sim. */
private Integer noOfSim;

/** The mdn. */
private String mdn;

/** The address. */
private String address;

/** The email. */
private String email;

/** The first name. */
private String firstName;

/** The last login. */
private String requestTime;
}
