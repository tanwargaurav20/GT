package com.harman.dmat.common.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.harman.dmat.legends.dto.KpiInfo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class SimpleTemplate {
	/*
	 * SimpleTemplate.java insnayak20
	 **/
	private Long teplateId;
	private String name;
	private boolean isActive;
	private List<KpiInfo> list;

}
