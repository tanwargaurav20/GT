package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SoftwareDto {
    private String imei;
    private String imsi;
    private String versionCode;
    private String releaseType;
    private String sdkLevel;
    private String buildFlavor;
    private UserFiltersDto userFiltersDto;
    private String variant;
    private String versionName;
}
