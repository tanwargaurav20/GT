package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SoftwareVersionDto {
    private String versionName;
    private int versionCode;
    private int buildFlavor;
    private int variant;
    private int id;
    private String deviceOs;
    private boolean latest;
    private byte[] apk;
}
