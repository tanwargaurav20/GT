package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SpatialReferenceDto {
    private int wkid;
}
