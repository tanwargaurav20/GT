package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class StatusDto {

	private Integer userId;
	private Integer isActive;
	
}
