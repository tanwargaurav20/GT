package com.harman.dmat.common.dto;

import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.Max;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


/**
 * The Class StatusInfoDto.
 */
/**
 * @author inpbisht20
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)

/**
 * Sets the sme.
 *
 * @param sme the new sme
 */
@Setter

/**
 * Gets the sme.
 *
 * @return the sme
 */
@Getter
@ToString
public class StatusInfoDto {
	
	/** The token. */
	private String token;
	
	/** The status. */
	@Max(value = 3, message = "Please enter valid status")
	private Integer status;
	
	/** The is grand. */
	private Boolean isGrand = false;
	
	/** The is delete. */
	@AssertTrue( message = "Value should true in order to delete users.")
	private Boolean isDelete;
	
	
	/** The pending. */
	private AccordionStatusInfo pending;
	
	/** The super admin. */
	private AccordionStatusInfo superAdmin;
	
	/** The admin. */
	private AccordionStatusInfo admin;
	
	/** The group admin. */
	private AccordionStatusInfo groupAdmin;
	
	/** The user. */
	private AccordionStatusInfo user;
	
	/** The oem. */
	private AccordionStatusInfo oem;
	
	/** The sme. */
	private AccordionStatusInfo sme;
	
	/** The lra. */
	private AccordionStatusInfo lra;

	/**
	 * Sets the checks if is grand.
	 *
	 * @param grand the new checks if is grand
	 */
	public void setIsGrand(Boolean grand) {
		this.isGrand = grand;
	}

	/**
	 * Checks if is grand.
	 *
	 * @return the boolean
	 */
	public Boolean isGrand() {
		return isGrand;
	}
	
	/**
	 * Sets the checks if is delete.
	 *
	 * @param isDelete the new checks if is delete
	 */
	public void setIsDelete(Boolean isDelete) {
		this.isDelete = isDelete;
	}

	/**
	 * Checks if is delete.
	 *
	 * @return the boolean
	 */
	public Boolean isDelete() {
		return isDelete;
	}
	
	
}
