package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class TestResultsDto {
    private String testName;
    private String total;
    private String passed;
    private String failed;
    private String startTime;
    private String endTime;
    List<Detail> details;
    List<String> logFiles;
}
