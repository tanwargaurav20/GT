package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

@Getter
@Setter
public class TestResultsWrapper {
    @JsonProperty("TestResults")
    private List<TestResultsDto> testResults;
}
