package com.harman.dmat.common.dto;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class USRegionDto {
	/*
	 * USRegionDto.java insnayak20
	 **/
	private String field;
	// private String fieldName;
	private String index;
	private String type;
	private String dm_timestampFrom;
	private String dm_timestampTo;
	private String userId;
	private List<String> stateCode;
	private MapExtent mapExtent;
	private KpiFilterDto kpiFilterDto;
	private SelectedKpisDto selectedKpisDto;
	private SubFilterDto subFilterDto;
	/**/}
