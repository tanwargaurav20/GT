package com.harman.dmat.common.dto;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/* (non-Javadoc)
 * @see java.lang.Object#toString()
 */
@ToString

/**
 * Gets the group request.
 *
 * @return the group request
 */
@Getter

/**
 * Sets the group request.
 *
 * @param groupRequest the new group request
 */
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserDto {

	/** The user ids. */
	private List<Integer> userIds;
	
	/** The user id. */
	private Integer userId;
	
	/** The email. */
	@Email(message = "Please enter valid email.")
	@NotEmpty(message = "Please enter valid email.")
	private String email;

	/** The first name. */
	@NotEmpty(message = "Please enter first name.")
	private String firstName;

	/** The last name. */
	@NotEmpty(message = "Please enter last name.")
	private String lastName;
	
	/** The password. */
	@NotEmpty(message = "Please enter valid password.")
	//@Pattern(regexp = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!-@#$%]).{8,20})", message = "Please enter valid password.")
	private String password;
	
	/** The role id. */
	private Integer roleId;
	
	/** The state code. */
	@NotBlank(message = "Please enter state code")
	private String stateCode;

	/** The region. */
	@NotBlank(message = "Please enter region")
	private String region;

	/** The business purpose. */
	@NotBlank(message = "Please enter valid Business Purpose")
	private String businessPurpose;

	/** The company id. */
	@NotNull
	private Integer companyId;
	
	/** The company name. */
	private String companyName;
	
	/** The preference id. */
	private Integer preferenceId;
	
	/** The status. */
	@Max(value=3,message = "Please enter valid status")
	private Integer status;
	
	/** The is group admin. */
	private Integer isGroupAdmin;
	
	/** The is group member. */
	private Integer isGroupMember;
	
	/** The is first login. */
	private Integer isFirstLogin;
	
	/** The is reset password. */
	private Integer isResetPassword;
	
	/** The last login. */
	private Date lastLogin;
	
	/** The insert time. */
	private Date insertTime;
	
	/** The insert by. */
	private String insertBy;
	
	/** The update time. */
	private Date updateTime;
	
	/** The update by. */
	private String updateBy;
	
	/** The access code. */
	private String accessCode;	
	
	/** The privileges dto. */
	private List<PrivilegeDto> privilegesDto;
	
	/** The job title. */
	private String jobTitle;
	
	/** The last activity json. */
	private String lastActivityJson;
	
	/** The group status. */
	private String groupStatus;
	/** The group request. */
	private Boolean isGroupRequest;
	
	/** The is activity shared. */
	private Boolean isActivityShared;
	
	/** The logged in user domain */
	private String userDomain;
}
