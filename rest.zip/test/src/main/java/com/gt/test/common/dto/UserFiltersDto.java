package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserFiltersDto {
    private String imei;
    private String imsi;
    private String version;
    private String osVersion;
}
