package com.harman.dmat.common.dto;

public class UserListDto {

	private Integer userId;

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "UserListDto [userId=" + userId + "]";
	}

}
