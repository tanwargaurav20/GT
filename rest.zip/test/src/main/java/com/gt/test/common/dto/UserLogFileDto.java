package com.harman.dmat.common.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserLogFileDto {
	private Integer userId;
	private String firstName;
	private String lastName;
	List<String> logFiles;

}
