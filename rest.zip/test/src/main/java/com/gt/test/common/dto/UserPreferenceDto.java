package com.harman.dmat.common.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class UserPreferenceDto {
	private Integer userId;
	private Integer preferenceId;
	private List<String> stateCode;
	private AreaDto mapExtent;
	private Integer zoomLevel;
}
