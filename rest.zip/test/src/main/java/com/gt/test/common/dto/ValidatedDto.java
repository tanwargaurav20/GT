package com.harman.dmat.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class ValidatedDto {

	private Integer userId;
	private String type;
	private String token;
	private String firstName;
	private String lastName;
	private String refreshToken;
	private Integer isResetPassword;
}
