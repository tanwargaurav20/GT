package com.harman.dmat.common.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class WifiAttributesDto {

    @JsonProperty("ID")
    private String ID;

    @JsonProperty("count")
    private long count;
}
