package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class WifiClusterInfoRequestDto {
    private String timeStampFrm;
    private String timeStampTo;
    private String scale;
    private String locMx;
    private String locMy;
    private String ssid;
    private String wifiType;
}
