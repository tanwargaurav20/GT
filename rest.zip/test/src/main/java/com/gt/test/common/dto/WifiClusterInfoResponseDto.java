package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WifiClusterInfoResponseDto {
    private String ssid;
    private String rssi;
    private String bssid;
    private String ipAddress;
    private String hiddenSsid;
    private String networkId;
    private String macAddress;
    private String linkSpeed;
    private String gateway;
    private String netMask;
    private String wifiType;
    private String encryption;
    private String frequency;
    private String primaryDns;
    private String secondaryDns;
    private String dhcpServer;
    private String channel;
    private String routerType;
    private String imei;
    private String mdn;
    private String ipassscore;
    private String ipass;
    private String authenticationUsed;
}
