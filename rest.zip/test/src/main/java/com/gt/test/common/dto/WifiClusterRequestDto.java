package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WifiClusterRequestDto {
    private String timeStampFrm;
    private String timeStampTo;
    private String tlLat;
    private String tlLon;
    private String brLat;
    private String brLon;
    private String locCode;
    private boolean wifiRequest;
    private boolean escherRequest;
}
