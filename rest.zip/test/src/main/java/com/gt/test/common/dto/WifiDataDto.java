package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@Getter
@Setter
public class WifiDataDto {
    @JsonProperty("Connected")
    private ConnectedDto connected;

    @JsonProperty("Neighbor")
    private List<NeighborDto> neighbors;
    private double latitude;
    private double longitude;

    @JsonProperty("Count")
    private int count;
    private String timeSpent;
    private String dataSent;
    private String dataReceived;
    private String totalData;
    private String uploadDownloadSpeed;
    private String imei;
    private String imsi;
}
