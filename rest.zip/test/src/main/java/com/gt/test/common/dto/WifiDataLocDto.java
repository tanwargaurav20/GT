package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WifiDataLocDto {
    private double loc_mx;
    private double loc_my;
    private String loc_2;
    private String loc_5;
    private String loc_10;
    private String loc_25;
    private String loc_50;
    private String loc_100;
    private String loc_200;
    private String loc_500;
    private String loc_1000;
    private String loc_2000;
    private String loc_4000;
    private String loc_5000;
    private String loc_10000;
    private String loc_15000;
    private String loc_25000;
    private String loc_50000;
    private String loc_75000;
    private String loc_100000;
    private String statecode;
    private String county_ns;
    private String VZ_Regions;
    private String country;
    private String shape;
}
