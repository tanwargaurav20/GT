package com.harman.dmat.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WifiDto {
	private String createddate;
	private String ssid;
	private String rssi;
	private String brssi;
	private String ipAddress;
	private String hiddenSsId;
	private String networkId;
	private String macAddress;
	private String linkSpeed;
	private String gateway;
	private String netMask;
	private String wifiType;
	private String encryption;
	// frequency not present.
	// primary DSN not present.
	private String secondaryDns;
	private String dhcpserver;
	private String channel;
	// routerType not present.
}