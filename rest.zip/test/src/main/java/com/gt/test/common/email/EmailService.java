package com.harman.dmat.common.email;

import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Singleton;

import com.harman.dmat.common.dto.ResponseDto;
import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

import com.harman.dmat.common.dto.EmailDto;
import com.harman.dmat.common.exception.UserEmailException;
import com.harman.dmat.utils.SecuirtyUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class EmailService is for send email.
 *
 * @author <a href="mailto:Prakash.Bisht@harman.com">Prakash Bisht</a>
 */

@Singleton
@Component
@Slf4j
public class EmailService {

	/** The host name. */
	private String hostName;

	/** The username. */
	private String username;

	/** The password. */
	private String password;

	/** The email from. */
	private String emailFrom;

	/** The sender name. */
	private String senderName;

	/** The smtp port. */
	private int smtpPort;

	/** The is ssl on. */
	private boolean isSslOn;

	private String dmatSupportEmailFrom;

	private String dmatSupportPassword;

	private String dmatSupportUserName;

	/** The environment. */
	@Inject
	private Environment environment;
	@Inject
	ThreadPoolTaskExecutor threadPool;

	/**
	 * Instantiates a new email service.
	 *
	 * @return
	 */
	@PostConstruct
	public void intit() {
		hostName = environment.getRequiredProperty("email.host");
		username = environment.getRequiredProperty("email.username");
		password = SecuirtyUtils.decrypt(environment.getRequiredProperty("email.userpassword"));
		emailFrom = environment.getRequiredProperty("email.from");
		senderName = environment.getRequiredProperty("email.sender.name");
		smtpPort = Integer.parseInt(environment.getRequiredProperty("email.port"));
		isSslOn = Boolean.parseBoolean(environment.getRequiredProperty("email.sslenable"));

		dmatSupportUserName = environment.getRequiredProperty("dmatSupportEmail.username");
		dmatSupportEmailFrom = environment.getRequiredProperty("dmatSupportEmail.from");
		dmatSupportPassword = environment.getRequiredProperty("dmatSupportEmail.userpassword");
	}

	/**
	 * @param emailDto
	 */
	public void sendEmail(final EmailDto emailDto) {
		threadPool.execute(() -> {
			final HtmlEmail email = new HtmlEmail();
			email.setHostName(hostName);
			email.setSmtpPort(smtpPort);
			email.setAuthenticator(new DefaultAuthenticator(username, password));

			email.setSSLOnConnect(isSslOn);
			try {
				email.addTo(emailDto.getEmailTo(), emailDto.getName());
				email.setFrom(emailFrom, senderName);
				email.setSubject(emailDto.getEmailSubject());
				email.setHtmlMsg(emailDto.getEmailMessage());
				if (emailDto.getFile() != null) {
					final EmailAttachment attachment = new EmailAttachment();
					attachment.setPath(emailDto.getFile().getAbsolutePath());
					attachment.setDisposition(EmailAttachment.ATTACHMENT);
					email.attach(attachment);
				}
				// email.setTextMsg("Your email client does not support HTML
				// messages");
				email.send();
				log.info("Sending email to,{}", emailDto.getEmailTo());
			}catch (final EmailException ex) {
				throw new UserEmailException("Unbale to send email to added users "+ex);
			}catch (final Exception e) {
				log.error("Error occred during sending email to " + emailDto.getEmailTo() + " :" + e);
			}
		});
	}

	/**
	 * Feedback sendEmail
	 *
	 * @param emailDto
	 */
	public void sendFeedbackEmail(final EmailDto emailDto) throws UserEmailException {
		final HtmlEmail email = new HtmlEmail();
		email.setHostName(hostName);
		email.setSmtpPort(smtpPort);
		email.setAuthenticator(new DefaultAuthenticator(username, password));

		email.setSSLOnConnect(isSslOn);
		try {
			//email.addTo(emailDto.getEmailTo(), emailDto.getName());
			String[] multipleEmails = emailDto.getEmailTo().split(Pattern.quote(","));
			if(multipleEmails!=null && multipleEmails.length>0){
				email.addTo(multipleEmails);
			}
			email.setFrom(emailDto.getName(), emailDto.getName());
			email.setSubject(emailDto.getEmailSubject());
			email.setHtmlMsg(emailDto.getEmailMessage());
			if (emailDto.getFile() != null) {
				final EmailAttachment attachment = new EmailAttachment();
				attachment.setPath(emailDto.getFile().getAbsolutePath());
				attachment.setDisposition(EmailAttachment.ATTACHMENT);
				email.attach(attachment);
			}
			// email.setTextMsg("Your email client does not support HTML
			// messages");
			email.send();
			log.info("Sending email to,{}", emailDto.getEmailTo());
		}catch (final EmailException ex) {
			throw new UserEmailException("Unable to send email to added users "+ex);
		}catch (final Exception e) {
			log.error("Error occured during sending email to " + emailDto.getEmailTo() + " :" + e);
		}
	}

	/**
	 * sends mail to all administrators
	 *
	 * @param adminEmails
	 * @param subject
	 * @param message
	 * @param firstName
	 */
	public String sendEventSummaryEmailList(List<String> adminEmails, String subject, String message, String firstName, final boolean isClientApi) {
		String response = "success";
		final HtmlEmail email = new HtmlEmail();
		email.setHostName(hostName);
		email.setSmtpPort(smtpPort);
		email.setAuthenticator(new DefaultAuthenticator(username, password));
		email.setSSLOnConnect(isSslOn);
		String[] emailData = adminEmails.stream().toArray(String[]::new);
		try {
			email.setFrom(emailFrom, senderName);
			email.setSubject(subject);
			email.setHtmlMsg(message);
			email.addTo(emailData);
			email.send();
			log.info("Sending email to,{}" + adminEmails);
		} catch (final EmailException ex) {
			response = "failure";
			log.error("Unable to send email to added users " + ex.getMessage());
		} catch (final Exception e) {
			log.error("Error occured during sending email:" + e.getMessage());
		}

		return response;
	}

	/**
	 * sends mail to all administrators
	 * 
	 * @param adminEmails
	 * @param subject
	 * @param message
	 * @param firstName
	 */
	public void sendEmailList(List<String> adminEmails, String subject, String message, String firstName, final boolean isClientApi) {
		threadPool.execute(() -> {
			final HtmlEmail email = new HtmlEmail();
			email.setHostName(hostName);
			email.setSmtpPort(smtpPort);
            email.setAuthenticator(new DefaultAuthenticator(username, password));


			email.setSSLOnConnect(isSslOn);
			String[] emailData = adminEmails.stream().toArray(String[]::new);
			try {
				email.setFrom(emailFrom, senderName);
				email.setSubject(subject);
				email.setHtmlMsg(message);
				email.addTo(emailData);
				email.send();
				log.info("Sending email to,{}" + adminEmails);
			} catch (final Exception e) {
				log.error("Error occured during sending email:" + e.getMessage());
			}
		});
	}

}
