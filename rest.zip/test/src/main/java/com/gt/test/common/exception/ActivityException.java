/**
 * 
 */
package com.harman.dmat.common.exception;

/**
 * @author insgupta06
 *
 */
public class ActivityException extends Exception {

	/**
	 *
	 */
	private static final long serialVersionUID = 7356158433235263154L;

	/** The message. */
	private String message;

	/** The error code. */
	private Integer erroreCode;

	/**
	 * @param message
	 * @param throwable
	 */
	public ActivityException(final String message, final Throwable throwable) {
		super(message, throwable);
		this.message = message;
	}

	/**
	 * @param throwable
	 */
	public ActivityException(final Throwable throwable) {
		super(throwable);
	}

	/**
	 * @param message
	 */
	public ActivityException(final String message) {
		super();
		this.message = message;
	}

	/**
	 * @param message
	 * @param errorCode
	 */
	public ActivityException(final String message, final Integer errorCode) {
		super();
		this.message = message;
		this.erroreCode = errorCode;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Throwable#getMessage()
	 */
	@Override
	public String getMessage() {
		return message;
	}

	/**
	 * @param message
	 */
	public void setMessage(final String message) {
		this.message = message;
	}

	/**
	 * @return Integer
	 */
	public Integer getErroreCode() {
		return erroreCode;
	}

	/**
	 * @param erroreCode
	 */
	public void setErroreCode(final Integer erroreCode) {
		this.erroreCode = erroreCode;
	}

}
