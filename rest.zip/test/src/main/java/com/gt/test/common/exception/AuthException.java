package com.harman.dmat.common.exception;

import org.springframework.security.core.AuthenticationException;

/**
 * The Class AuthException.
 */
/**
 * @author prakash.bisht@harman.com
 *
 */
public class AuthException extends AuthenticationException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8539384644461610643L;

	/** The message. */
	private String message;

	/** The error code. */
	private String errorCode;

	/**
	 * Instantiates a new auth exception.
	 *
	 * @param msg
	 *            the msg
	 * @param errorCode
	 *            the error code
	 * @param t
	 *            the t
	 */
	public AuthException(final String msg, final String errorCode, final Throwable t) {
		super(msg, t);
		this.errorCode = errorCode;
		message = msg;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Throwable#getMessage()
	 */
	@Override
	public String getMessage() {
		return message;
	}

	/**
	 * Sets the message.
	 *
	 * @param message
	 *            the new message
	 */
	public void setMessage(final String message) {
		this.message = message;
	}

	/**
	 * Gets the error code.
	 *
	 * @return the error code
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * Sets the error code.
	 *
	 * @param errorCode
	 *            the new error code
	 */
	public void setErrorCode(final String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * Gets the serialversionuid.
	 *
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
