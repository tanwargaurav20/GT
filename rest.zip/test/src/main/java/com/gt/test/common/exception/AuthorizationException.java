package com.harman.dmat.common.exception;


/**
 * The Class AuthorizationException.
 */
/**
 * @author inpbisht20
 *
 */
public class AuthorizationException extends RuntimeException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7356258433235263154L;

	/** The message. */
	private String message;

	/** The errore code. */
	private Integer erroreCode;

	/**
	 * Instantiates a new authorization exception.
	 *
	 * @param message the message
	 * @param throwable the throwable
	 */
	public AuthorizationException(final String message, final Throwable throwable) {
		super(message, throwable);
		this.message = message;
	}

	/**
	 * Instantiates a new authorization exception.
	 *
	 * @param throwable the throwable
	 */
	public AuthorizationException(final Throwable throwable) {
		super(throwable);
	}

	/**
	 * Instantiates a new authorization exception.
	 *
	 * @param message the message
	 */
	public AuthorizationException(final String message) {
		super();
		this.message = message;
	}

	/**
	 * Instantiates a new authorization exception.
	 *
	 * @param message the message
	 * @param errorCode the error code
	 */
	public AuthorizationException(final String message, final Integer errorCode) {
		super();
		this.message = message;
		erroreCode = errorCode;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Throwable#getMessage()
	 */
	@Override
	public String getMessage() {
		return message;
	}

	/**
	 * Sets the message.
	 *
	 * @param message the new message
	 */
	public void setMessage(final String message) {
		this.message = message;
	}

	/**
	 * Gets the errore code.
	 *
	 * @return Integer
	 */
	public Integer getErroreCode() {
		return erroreCode;
	}

	/**
	 * Sets the errore code.
	 *
	 * @param erroreCode the new errore code
	 */
	public void setErroreCode(final Integer erroreCode) {
		this.erroreCode = erroreCode;
	}

}
