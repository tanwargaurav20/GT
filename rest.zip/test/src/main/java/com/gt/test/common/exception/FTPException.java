package com.harman.dmat.common.exception;

public class FTPException extends RuntimeException {

	/**
	 * long
	 * FTPException.java
	 */
	private static final long serialVersionUID = 6501449712825753019L;
	/*
	* FTPException.java
	* insnayak20
	**/
	
	public FTPException() {
	}

	public FTPException(String message) {
		super(message);
	}

	public FTPException(Throwable cause) {
		super(cause);
	}

	public FTPException(String message, Throwable cause) {
		super(message, cause);
	}

	public FTPException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}	
}
