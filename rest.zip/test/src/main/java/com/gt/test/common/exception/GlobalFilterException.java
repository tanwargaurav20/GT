package com.harman.dmat.common.exception;

/**
 * The Class GlobalFilterException.
 *
 * @author prakash.bisht@harman.com
 */
public class GlobalFilterException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7356258433235263154L;

	/** The message. */
	private String message;

	/** The errore code. */
	private Integer erroreCode;

	/**
	 * Instantiates a new global filter exception.
	 *
	 * @param message the message
	 * @param throwable the throwable
	 */
	public GlobalFilterException(final String message, final Throwable throwable) {
		super(message, throwable);
		this.message = message;
	}

	/**
	 * Instantiates a new global filter exception.
	 *
	 * @param throwable the throwable
	 */
	public GlobalFilterException(final Throwable throwable) {
		super(throwable);
	}

	/**
	 * Instantiates a new global filter exception.
	 *
	 * @param message the message
	 */
	public GlobalFilterException(final String message) {
		super();
		this.message = message;
	}

	/**
	 * Instantiates a new global filter exception.
	 *
	 * @param message the message
	 * @param errorCode the error code
	 */
	public GlobalFilterException(final String message, final Integer errorCode) {
		super();
		this.message = message;
		erroreCode = errorCode;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Throwable#getMessage()
	 */
	@Override
	public String getMessage() {
		return message;
	}

	/**
	 * Sets the message.
	 *
	 * @param message the new message
	 */
	public void setMessage(final String message) {
		this.message = message;
	}

	/**
	 * Gets the errore code.
	 *
	 * @return Integer
	 */
	public Integer getErroreCode() {
		return erroreCode;
	}

	/**
	 * Sets the errore code.
	 *
	 * @param erroreCode the new errore code
	 */
	public void setErroreCode(final Integer erroreCode) {
		this.erroreCode = erroreCode;
	}

}
