package com.harman.dmat.common.exception;

public class InfoPointsException extends RuntimeException {

	private static final long serialVersionUID = -7883256433123962173L;

	public InfoPointsException() {
	}

	public InfoPointsException(String message) {
		super(message);
	}

	public InfoPointsException(Throwable cause) {
		super(cause);
	}

	public InfoPointsException(String message, Throwable cause) {
		super(message, cause);
	}

	public InfoPointsException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
