package com.harman.dmat.common.exception;

public class InvalidActivityExcption extends RuntimeException {
	/**
	 * long
	 * InvalidActivityExcption.java
	 */
	private static final long serialVersionUID = 7716486718541997896L;

	/**
	 * long
	 * InvalidActivityExcption.java
	 */

	/*
	* InvalidActivityExcption.java
	* insnayak20
	**/
	public InvalidActivityExcption() {
	}

	public InvalidActivityExcption(String message) {
		super(message);
	}

	public InvalidActivityExcption(Throwable cause) {
		super(cause);
	}

	public InvalidActivityExcption(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidActivityExcption(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}	

}
