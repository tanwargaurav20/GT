package com.harman.dmat.common.exception;

public class InvalidFileFormatException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3957784208610956478L;
	public InvalidFileFormatException() {
	}

	public InvalidFileFormatException(String message) {
		super(message);
	}

	public InvalidFileFormatException(Throwable cause) {
		super(cause);
	}

	public InvalidFileFormatException(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidFileFormatException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	
	
}
