package com.harman.dmat.common.exception;

public class InvalidRoleException extends RuntimeException {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 3764498079884530001L;

	/**
	 * 
	 */


	public InvalidRoleException() {
	}

	public InvalidRoleException(String message) {
		super(message);
	}

	public InvalidRoleException(Throwable cause) {
		super(cause);
	}

	public InvalidRoleException(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidRoleException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
