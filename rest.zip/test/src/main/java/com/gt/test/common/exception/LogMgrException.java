package com.harman.dmat.common.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public class LogMgrException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7693600705630382848L;

	String message;
	int erroreCode;

	public LogMgrException(final Throwable throwable) {
		super(throwable);
	}
	
	public LogMgrException(final String message) {
		super();
		this.message = message;
	}
}
