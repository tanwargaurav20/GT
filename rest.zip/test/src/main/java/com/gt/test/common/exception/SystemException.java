package com.harman.dmat.common.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Sets the errore code.
 *
 * @param erroreCode the new errore code
 */
@Setter

/**
 * Gets the errore code.
 *
 * @return the errore code
 */
@Getter

/**
 * Instantiates a new system exception.
 *
 * @param message the message
 * @param erroreCode the errore code
 */
@AllArgsConstructor
public class SystemException extends Exception {
  
  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 7292568586513545387L;
  
  /** The message. */
  String message;
  
  /** The errore code. */
  int erroreCode;

  /**
   * Instantiates a new system exception.
   *
   * @param throwable the throwable
   */
  public SystemException(final Throwable throwable) {
    super(throwable);
  }
}
