package com.harman.dmat.common.exception;

/**
 * Created by VRanjan2 on 5/1/2017.
 */
public class TokenGenerationException extends Exception {

    public TokenGenerationException(String message, Exception e){
        super(message, e);
    }
}
