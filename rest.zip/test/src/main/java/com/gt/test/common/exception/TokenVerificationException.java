package com.harman.dmat.common.exception;

/**
 * Created by VRanjan2 on 5/1/2017.
 */
public class TokenVerificationException extends Exception {

	public TokenVerificationException(final String message, final Exception e) {
		super(message, e);
	}
}
