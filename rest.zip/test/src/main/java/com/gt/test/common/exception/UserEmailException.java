package com.harman.dmat.common.exception;

public class UserEmailException extends RuntimeException {

	/**
	 * long
	 * UserEmailException.java
	 */
	private static final long serialVersionUID = 49113313761108974L;
	/*
	* UserEmailException.java
	* insnayak20
	**/
	public UserEmailException() {
	}

	public UserEmailException(String message) {
		super(message);
	}

	public UserEmailException(Throwable cause) {
		super(cause);
	}

	public UserEmailException(String message, Throwable cause) {
		super(message, cause);
	}

	public UserEmailException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
}
