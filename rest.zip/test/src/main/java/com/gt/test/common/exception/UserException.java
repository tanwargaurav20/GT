package com.harman.dmat.common.exception;

/**
 * @author prakash.bisht@harman.com
 * The Class UserException.
 */
public class UserException extends Exception {

	/**
	 *
	 */
	private static final long serialVersionUID = 7356258433235263154L;

	/** The message. */
	private String message;

	/** The errore code. */
	private Integer erroreCode;

	/**
	 * @param message
	 * @param throwable
	 */
	public UserException(final String message, final Throwable throwable) {
		super(message, throwable);
		this.message = message;
	}

	/**
	 * @param throwable
	 */
	public UserException(final Throwable throwable) {
		super(throwable);
	}

	/**
	 * @param message
	 */
	public UserException(final String message) {
		super();
		this.message = message;
	}

	/**
	 * @param message
	 * @param errorCode
	 */
	public UserException(final String message, final Integer errorCode) {
		super();
		this.message = message;
		erroreCode = errorCode;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Throwable#getMessage()
	 */
	@Override
	public String getMessage() {
		return message;
	}

	/**
	 * @param message
	 */
	public void setMessage(final String message) {
		this.message = message;
	}

	/**
	 * @return Integer
	 */
	public Integer getErroreCode() {
		return erroreCode;
	}

	/**
	 * @param erroreCode
	 */
	public void setErroreCode(final Integer erroreCode) {
		this.erroreCode = erroreCode;
	}

}
