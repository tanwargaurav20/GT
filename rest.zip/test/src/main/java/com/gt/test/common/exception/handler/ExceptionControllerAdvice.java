package com.harman.dmat.common.exception.handler;

import static com.harman.dmat.constant.ControllerUrl.CONCAT;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.harman.dmat.common.dto.ErrorResponseDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.common.exception.ActivityException;
import com.harman.dmat.common.exception.AuthorizationException;
import com.harman.dmat.common.exception.DataAccessException;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.EsException;
import com.harman.dmat.common.exception.GlobalFilterException;
import com.harman.dmat.common.exception.InActiveStatusException;
import com.harman.dmat.common.exception.InfoPointsException;
import com.harman.dmat.common.exception.InvalidActivityExcption;
import com.harman.dmat.common.exception.InvalidFileFormatException;
import com.harman.dmat.common.exception.InvalidRequestPayloadException;
import com.harman.dmat.common.exception.InvalidRoleException;
import com.harman.dmat.common.exception.LogMgrException;
import com.harman.dmat.common.exception.UserEmailException;
import com.harman.dmat.common.exception.UserException;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.legends.exception.InvalidPayloadException;
import com.harman.dmat.legends.exception.RegionException;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class ExceptionControllerAdvice having all exception end point to make
 * json response in case of exception occurrence.
 *
 * @author <a href="mailto:Prakash.Bisht@harman.com">Prakash Bisht</a>
 */
@Slf4j
@ControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class ExceptionControllerAdvice {

	@Order(Ordered.HIGHEST_PRECEDENCE)
	@ExceptionHandler(InvalidFileFormatException.class)
	public ResponseEntity<String> InvalidFileFormatExceptionHandler(final Exception ex) {
		log.error("logging the error in Invalid File format Exception  ", ex);
		return new ResponseEntity<>(getJsonErrorMessage(ex.getMessage()), HttpStatus.BAD_REQUEST);
	}

	@Order(Ordered.HIGHEST_PRECEDENCE)
	@ExceptionHandler(RegionException.class)
	public ResponseEntity<String> RegionExceptionExceptionHandler(final Exception ex) {
		log.error("logging the error in Region  Exception  ", ex);
		return new ResponseEntity<>(getJsonErrorMessage(ex.getMessage()), HttpStatus.FAILED_DEPENDENCY);
	}

	/**
	 * Exception handler.
	 *
	 * @param ex
	 *            the ex
	 * @return the response entity
	 */
	@Order(Ordered.LOWEST_PRECEDENCE)
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ResponseDto> exceptionHandler(final Exception ex) {
		log.error("logging the error in default  Exception  ", ex);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.CONTACT_TO_ADMIN);
		responseDto.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value() + CONCAT);
		ex.printStackTrace();
		return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
	}

	/**
	 * User exception handler.
	 *
	 * @param ex
	 *            the ex
	 * @return the response entity
	 */
	@ExceptionHandler(org.springframework.web.bind.MethodArgumentNotValidException.class)
	public ResponseEntity<ResponseDto> userExceptionHandler(
			final org.springframework.web.bind.MethodArgumentNotValidException ex) {
		log.error("logging the error in user Exception {}  ", ex);
		final String errorMessage = ex.getMessage();
		final String finalmessage = errorMessage.substring(errorMessage.lastIndexOf("[") + 1,
				errorMessage.lastIndexOf("]]"));
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(finalmessage);
		responseDto.setStatus(HttpStatus.PRECONDITION_FAILED.value() + CONCAT);
		return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
	}

	/**
	 * User exception handler.
	 *
	 * @param ex
	 *            the ex
	 * @return the response entity
	 */
	@ExceptionHandler(UserException.class)
	public ResponseEntity<ResponseDto> userExceptionHandler(final UserException ex) {
		log.error("logging the error in UserException {}  ", ex);
		final String errorCode = ex.getErroreCode() == null ? HttpStatus.INTERNAL_SERVER_ERROR.value() + CONCAT
				: ex.getErroreCode() + CONCAT;
		final String errorMessage = ex.getMessage() == null ? Constant.CONTACT_TO_ADMIN : ex.getMessage();
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(errorMessage);
		responseDto.setStatus(errorCode);
		return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
	}

	/**
	 * Handle in valid role exception.
	 *
	 * @param e
	 *            the e
	 * @return the response entity
	 */
	@ExceptionHandler(value = InvalidRoleException.class)
	public ResponseEntity<ErrorResponseDto> handleInValidRoleException(final InvalidRoleException e) {
		log.error("logging the error in InvalidRoleException {}  ", e);
		final ErrorResponseDto error = new ErrorResponseDto();
		error.setErrorCode(HttpStatus.UNAUTHORIZED.value());
		error.setMessage("Role is Invalid for doing modification");
		return new ResponseEntity<ErrorResponseDto>(error, HttpStatus.OK);
	}

	/**
	 * Handle data not found exception.
	 *
	 * @param e
	 *            the e
	 * @return the response entity
	 */
	@ExceptionHandler(value = DataNotFoundException.class)
	public ResponseEntity<ErrorResponseDto> handleDataNotFoundException(final DataNotFoundException e) {
		log.error("logging the error in DataNotFoundException {}  ", e);
		final ErrorResponseDto error = new ErrorResponseDto();
		error.setErrorCode(HttpStatus.NOT_FOUND.value());
		error.setMessage("Data not found");
		return new ResponseEntity<ErrorResponseDto>(error, HttpStatus.OK);
	}

	/**
	 * Handle in active status exception.
	 *
	 * @param e
	 *            the e
	 * @return the response entity
	 */
	@ExceptionHandler(value = InActiveStatusException.class)
	public ResponseEntity<ErrorResponseDto> handleInActiveStatusException(final InActiveStatusException e) {
		log.error("logging the error in InActiveStatusException {}  ", e);
		final ErrorResponseDto error = new ErrorResponseDto();
		error.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		error.setMessage("User is either inactive state or not present");
		return new ResponseEntity<ErrorResponseDto>(error, HttpStatus.OK);
	}

	/**
	 * Handle invalid request payload exception.
	 *
	 * @param e
	 *            the e
	 * @return the response entity
	 */
	@ExceptionHandler(value = InvalidRequestPayloadException.class)
	public ResponseEntity<ResponseDto> handleInvalidRequestPayloadException(final InvalidRequestPayloadException e) {
		log.error("logging the error in InvalidRequestPayloadException {}  ", e);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.PAYLOAD_REQUEST_ERROR);
		responseDto.setStatus(HttpStatus.BAD_REQUEST.value() + CONCAT);
		return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
	}

	/**
	 * Handle db opration exception.
	 *
	 * @param e
	 *            the e
	 * @return the response entity
	 */
	@ExceptionHandler(value = LogMgrException.class)
	public ResponseEntity<ResponseDto> handleDbOprationException(final LogMgrException e) {
		log.error("logging the error in LogMgrException {}  ", e);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.DB_ERROR);
		responseDto.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value() + CONCAT);
		return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
	}

	/**
	 * Handle data access exception.
	 *
	 * @param e
	 *            the e
	 * @return the response entity
	 */
	@ExceptionHandler(value = DataAccessException.class)
	public ResponseEntity<ResponseDto> handleDataAccessException(final DataAccessException e) {
		log.error("logging the error in DataAccessException {}  ", e);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.DB_FETCH_ERROR);
		responseDto.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value() + CONCAT);
		return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
	}

	/**
	 * Handle info points exception.
	 *
	 * @param e
	 *            the e
	 * @return the response entity
	 */
	@ExceptionHandler(value = InfoPointsException.class)
	public ResponseEntity<ErrorResponseDto> handleInfoPointsException(final InfoPointsException e) {
		log.error("logging the error in InfoPointsException {}  ", e);
		final ErrorResponseDto error = new ErrorResponseDto();
		error.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		error.setMessage("Error connecting to Elastic search cluster");
		return new ResponseEntity<ErrorResponseDto>(error, HttpStatus.OK);
	}

	/**
	 * Handel authorization exception.
	 *
	 * @param e
	 *            the e
	 * @return the response entity
	 */
	@ExceptionHandler(value = AuthorizationException.class)
	public ResponseEntity<ErrorResponseDto> handelAuthorizationException(final AuthorizationException e) {
		log.error("logging the error in AuthorizationException {}  ", e);
		final ErrorResponseDto error = new ErrorResponseDto();
		error.setErrorCode(e.getErroreCode());
		error.setMessage(e.getMessage());
		return new ResponseEntity<ErrorResponseDto>(error, HttpStatus.OK);
	}

	@ExceptionHandler(GlobalFilterException.class)
	public ResponseEntity<ResponseDto> globalFilterExceptionHandler(final GlobalFilterException ex) {
		log.error("logging the error in GlobalFilterException {}  ", ex);
		final String errorCode = ex.getErroreCode() == null ? HttpStatus.INTERNAL_SERVER_ERROR.value() + CONCAT
				: ex.getErroreCode() + CONCAT;
		final String errorMessage = ex.getMessage() == null ? Constant.CONTACT_TO_ADMIN : ex.getMessage();
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(errorMessage);
		responseDto.setStatus(errorCode);
		return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
	}

	@ExceptionHandler(InvalidPayloadException.class)
	public ResponseEntity<String> globalFilterExceptionHandler(final InvalidPayloadException ex) {
		log.error("logging the error in InvalidPayloadException {}  ", ex);
		return new ResponseEntity<>(getJsonErrorMessage(ex.getMessage()), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(InvalidActivityExcption.class)
	public ResponseEntity<String> invalidExceptionHandler(final InvalidActivityExcption ex) {
		log.error("logging the error in InvalidActivityExcption {}  ", ex);
		return new ResponseEntity<>(getJsonErrorMessage(ex.getMessage()), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(ActivityException.class)
	public ResponseEntity<ErrorResponseDto> activityExceptionHandler(final ActivityException ex) {
		log.error("logging the error in ActivityException {}  ", ex);
		final ErrorResponseDto error = new ErrorResponseDto();
		error.setErrorCode(ex.getErroreCode());
		error.setMessage(ex.getMessage());
		return new ResponseEntity<ErrorResponseDto>(error, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(UserEmailException.class)
	public ResponseEntity<String> UserEmailExceptionHandler(final UserEmailException ex) {
		log.error("logging the error in ActivityException {}  ", ex);
		return new ResponseEntity<>(getJsonErrorMessage(ex.getMessage()), HttpStatus.BAD_REQUEST);
	}

	@Order(Ordered.HIGHEST_PRECEDENCE)
	@ExceptionHandler(EsException.class)
	public ResponseEntity<String> EsExceptionExceptionHandler(final EsException ex) {
		log.error("logging the error in ActivityException {}  ", ex);
		return new ResponseEntity<>(getJsonErrorMessage(ex.getMessage()), HttpStatus.BAD_REQUEST);
	}

	public String getJsonErrorMessage(final String message) {
		return "{ \"error\": \"" + message + "\"}";
	}

}
