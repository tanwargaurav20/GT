package com.harman.dmat.common.security;

import java.util.ArrayList;
import java.util.Collection;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

/**
 * The Class AuthentiationToken.
 *
 * @author prakash.bisht@harman.com
 */
public class AuthentiationToken implements Authentication {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7758451389069618720L;

	/** The token. */
	private final String token;

	/** The is authenticated. */
	private boolean isAuthenticated;
	
	private User userDetails;

	/**
	 * Instantiates a new authentiation token.
	 *
	 * @param token
	 *            the token
	 */
	public AuthentiationToken(final String token) {
		this.token = token;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.security.core.Authentication#getAuthorities()
	 */
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return new ArrayList<GrantedAuthority>(0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.security.core.Authentication#getCredentials()
	 */
	@Override
	public Object getCredentials() {
		return token;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.security.core.Authentication#getDetails()
	 */
	@Override
	public Object getDetails() {
		return userDetails;
	}
	public void setDetails(User user) {
		this.userDetails=user;
		
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.security.core.Authentication#getPrincipal()
	 */
	@Override
	public Object getPrincipal() {
		return userDetails;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.security.core.Authentication#isAuthenticated()
	 */
	@Override
	public boolean isAuthenticated() {
		return isAuthenticated;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.security.core.Authentication#setAuthenticated(
	 * boolean)
	 */
	@Override
	public void setAuthenticated(final boolean isAuthenticated) throws IllegalArgumentException {
		this.isAuthenticated = isAuthenticated;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.security.Principal#getName()
	 */
	@Override
	public String getName() {
		return null;
	}
}