package com.harman.dmat.common.security;

import org.springframework.core.annotation.Order;
import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 * The Class SecurityInitializer.
 */
/**
 * @author prakash.bisht@harman.com
 *
 */
@Order(value = 1)
public class SecurityInitializer extends AbstractSecurityWebApplicationInitializer {
}