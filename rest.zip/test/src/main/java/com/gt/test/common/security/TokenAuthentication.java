package com.harman.dmat.common.security;

import java.io.UnsupportedEncodingException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Singleton;

import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.harman.dmat.common.exception.AuthException;
import com.harman.dmat.common.exception.TokenGenerationException;
import com.harman.dmat.common.exception.TokenVerificationException;
import com.harman.dmat.enums.ErrorCode;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by VRanjan2 on 5/1/2017.
 */
@Component
@Singleton
@Slf4j
public class TokenAuthentication {

	private static String secret = "secret-dmat-vz";

	public TokenAuthentication() {
	}

	public Map<String, String> getToken(final User user) throws TokenGenerationException {
		Map<String, String> tokensMap = new HashMap<>();
		final Calendar tokenExpiryTime = Calendar.getInstance();
		tokenExpiryTime.setTime(new Date());
		tokenExpiryTime.add(Calendar.MINUTE, 15);

		final Calendar refreshtokenExpiryTime = Calendar.getInstance();
		refreshtokenExpiryTime.setTime(new Date());
		refreshtokenExpiryTime.add(Calendar.HOUR, 24);
		try {
			final Algorithm algorithm = Algorithm.HMAC256(secret);
			final String token = JWT.create().withIssuer("auth0").withClaim("userName", user.getUserName())
					.withClaim("userId", user.getUserId()).withClaim("scope", user.getScope())
					.withClaim("isActive", user.getIsActive()).withClaim("isGroupAdmin", user.getIsGroupAdmin())
					.withClaim("userDomain", user.getUserDomain())
					.withClaim("expiry", tokenExpiryTime.getTimeInMillis() + "").sign(algorithm);
			if (log.isDebugEnabled())
				log.debug("Token generated at: {} for user {} expires at: {}", new Date(), user.getUserName(),
						tokenExpiryTime.getTime());
			final String refreshToken = JWT.create().withIssuer("auth0").withClaim("userName", user.getUserName())
					.withClaim("userId", user.getUserId()).withClaim("scope", user.getScope())
					.withClaim("isActive", user.getIsActive()).withClaim("isGroupAdmin", user.getIsGroupAdmin())
					.withClaim("userDomain", user.getUserDomain())
					.withClaim("expiry", refreshtokenExpiryTime.getTimeInMillis() + "").withSubject("refresh")
					.sign(algorithm);
			tokensMap.put("accessToken", token);
			tokensMap.put("refreshToken", refreshToken);
			return tokensMap;
		} catch (final UnsupportedEncodingException exception) {
			throw new TokenGenerationException("UTF-8 encoding not supported", exception);
		} catch (final JWTCreationException exception) {
			throw new TokenGenerationException("Token could not be generated", exception);
		}
	}

	public DecodedJWT validateToken(final String token) throws Exception {

		try {
			final Algorithm algorithm = Algorithm.HMAC256(secret);
			final JWTVerifier verifier = JWT.require(algorithm).withIssuer("auth0").build();
			final DecodedJWT jwt = verifier.verify(token);
			return jwt;
		} catch (final UnsupportedEncodingException exception) {
			throw new TokenVerificationException("UTF-8 encoding not supported", exception);
		} catch (final JWTVerificationException exception) {
			throw new TokenGenerationException("Invalid user", exception);
		}
	}

	/**
	 * @param refreshToken
	 * @return
	 * @throws Exception
	 */
	public String getAccessTokenFromRefreshToken(String refreshToken) throws Exception {
		final DecodedJWT jwt = validateToken(refreshToken);
		final Integer userId = jwt.getClaim("userId").asInt();
		final Integer roleId = jwt.getClaim("scope").asInt();
		final String userName = jwt.getClaim("userName").asString();
		final Integer isActive = jwt.getClaim("isActive").asInt();
		final Integer isGroupAdmin = jwt.getClaim("isGroupAdmin").asInt();
		final String userDomain = jwt.getClaim("userDomain").asString();
		final Long expiry = Long.parseLong(jwt.getClaim("expiry").asString());
		final Long currentTimeMillis = System.currentTimeMillis();
		final String subject = jwt.getSubject();
		String accessToken = "";
		try {
			if (!"refresh".equalsIgnoreCase(subject)) {
				throw new TokenGenerationException("Token could not be generated from refresh token", null);
			}
			if (currentTimeMillis > expiry) {
				throw new AuthException(ErrorCode.REFRESH_TOKEN_EXPIRED.getErrorMessage(),
						ErrorCode.REFRESH_TOKEN_EXPIRED.getErrorCode() + "", null);
			}
			final User user = new User();
			user.setUserName(userName);
			user.setUserDomain(userDomain);
			user.setUserId(userId);
			user.setIsActive(isActive);
			user.setIsGroupAdmin(isGroupAdmin);
			user.setScope(roleId);
			accessToken = getToken(user).get("accessToken");
		} catch (final JWTCreationException exception) {
			throw new TokenGenerationException("Token could not be generated", exception);
		}
		return accessToken;

	}

	public static void main(final String[] args) {
		final TokenAuthentication gToken = new TokenAuthentication();

		try {
			final DecodedJWT jwt = gToken.validateToken(
					"eyJhbGciOiJIUzI1NiJ9.eyJpc0dyb3VwQWRtaW4iOjk5OSwic2NvcGUiOjIsImlzcyI6ImF1dGgwIiwidXNlckRvbWFpbiI6InZlcml6b253aXJlbGVzcy5jb20iLCJleHBpcnkiOiIxNTEwMjI2MDIyMDcxIiwidXNlck5hbWUiOiJzdW5ueS5yb2RyaWd1ZXNAdmVyaXpvbndpcmVsZXNzLmNvbSIsImlzQWN0aXZlIjoxLCJ1c2VySWQiOjEyfQ.Sx6Pd1tr_Kkv9j32Hl0dzB0Tz84UrCFlTx6TNL17o04");
			final Integer userId = jwt.getClaim("userId").asInt();
			final Integer roleId = jwt.getClaim("scope").asInt();
			final String userName = jwt.getClaim("userName").asString();
			final Integer isActive = jwt.getClaim("isActive").asInt();
			final Integer isGroupAdmin = jwt.getClaim("isGroupAdmin").asInt();
			final String userDomain = jwt.getClaim("userDomain").asString();
			final String expiry = jwt.getClaim("expiry").asString();
			System.out.println(expiry);
			final User user = new User();
			// user.setUserId("s3rfw4gh545-gert55ef");
			user.setUserName("Jogendra.Yaramchitti@VerizonWireless.com");
			user.setUserDomain("VerizonWireless.com");
			user.setUserId(79);
			user.setIsActive(1);
			user.setIsGroupAdmin(1);
			final String token = gToken.getToken(user).get("accessToken");
			System.out.println("Token - " + token);
			System.out.println("Refresh Token - " + gToken.getToken(user).get("refreshToken"));
			gToken.validateToken(token);
		} catch (final Exception e) {
			e.printStackTrace();
		}

	}
}
