package com.harman.dmat.common.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.harman.dmat.common.exception.AuthException;
import com.harman.dmat.enums.ErrorCode;

/**
 * @author prakash.bisht@harman.com
 *
 */
@Component
public class TokenAuthenticationProvider implements AuthenticationProvider {

	@Autowired
	TokenAuthentication tokenAuthentication;

	/*
	 * (non-Javadoc)
	 *
	 * @see org.springframework.security.authentication.AuthenticationProvider#
	 * authenticate(org.springframework.security.core.Authentication)
	 */
	@Override
	public Authentication authenticate(final Authentication authentication) throws AuthenticationException {

		authentication.getName();
		final String token = (String) authentication.getCredentials();
		Long expiry = 0L;
		try {
			final DecodedJWT jwt = tokenAuthentication.validateToken(token);
			final Integer userId = jwt.getClaim("userId").asInt();
			final Integer roleId = jwt.getClaim("scope").asInt();
			final String userName = jwt.getClaim("userName").asString();
			final Integer isActive = jwt.getClaim("isActive").asInt();
			final Integer isGroupAdmin = jwt.getClaim("isGroupAdmin").asInt();
			final String userDomain = jwt.getClaim("userDomain").asString();
			final User user = new User(userId, userName, roleId, isActive, isGroupAdmin, userDomain);
			((AuthentiationToken) authentication).setDetails(user);
			expiry = Long.parseLong(jwt.getClaim("expiry").asString());
		} catch (final Exception e) {
			throw new AuthException("Invalid token", "508", e);
		}
		Long currentTime = Long.valueOf(System.currentTimeMillis());
		if (expiry == 0 || currentTime.compareTo(expiry) > 0) {
			throw new AuthException(ErrorCode.TOKEN_EXPIRED.getErrorMessage(),
					ErrorCode.TOKEN_EXPIRED.getErrorCode() + "", null);
		}
		authentication.setAuthenticated(true);
		return authentication;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.security.authentication.AuthenticationProvider#
	 * supports(java.lang.Class)
	 */
	@Override
	public boolean supports(final Class<?> authentication) {
		return true;
	}

}