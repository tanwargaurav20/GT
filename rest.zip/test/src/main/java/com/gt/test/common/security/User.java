package com.harman.dmat.common.security;

/**
 * 
 *
 * @author prakash.bisht@harman.com
 */

public class User {

	/** The user id. */
	private Integer userId;

	/** The user name. */
	private String userName;

	/** The scope. */
	private Integer scope;

	/** The active. */
	private Integer isActive;

	/** The is group admin. */
	private Integer isGroupAdmin;

	/** The domain of the user. */
	private String userDomain;

	/**
	 * Instantiates a new user.
	 */
	public User() {
	}

	/**
	 * Instantiates a new user.
	 *
	 * @param userId
	 *            the user id
	 * @param userName
	 *            the user name
	 * @param scope
	 *            the scope
	 * @param active
	 *            the active
	 * @param isGroupAdmin
	 *            the is group admin
	 */
	public User(final Integer userId, final String userName, final Integer scope, final Integer active,
			Integer isGroupAdmin, String userDomain) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.scope = scope;
		this.isActive = active;
		this.isGroupAdmin = isGroupAdmin;
		this.setUserDomain(userDomain);
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public Integer getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId
	 *            the new user id
	 */
	public void setUserId(final Integer userId) {
		this.userId = userId;
	}

	/**
	 * Gets the user name.
	 *
	 * @return the user name
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * Sets the user name.
	 *
	 * @param userName
	 *            the new user name
	 */
	public void setUserName(final String userName) {
		this.userName = userName;
	}

	/**
	 * Gets the scope.
	 *
	 * @return the scope
	 */
	public Integer getScope() {
		return scope;
	}

	/**
	 * Sets the scope.
	 *
	 * @param scope
	 *            the new scope
	 */
	public void setScope(final Integer scope) {
		this.scope = scope;
	}

	/**
	 * gets the isActive.
	 *
	 * @return the checks if is active
	 */
	public Integer getIsActive() {
		return isActive;
	}

	/**
	 * Sets the isActive.
	 *
	 * @param isActive
	 *            the Active Status
	 */
	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}

	/**
	 * Gets the checks if is group admin.
	 *
	 * @return the checks if is group admin
	 */
	public Integer getIsGroupAdmin() {
		return isGroupAdmin;
	}

	/**
	 * Sets the checks if is group admin.
	 *
	 * @param isGroupAdmin
	 *            the new checks if is group admin
	 */
	public void setIsGroupAdmin(Integer isGroupAdmin) {
		this.isGroupAdmin = isGroupAdmin;
	}

	/**
	 * @return the userDomain
	 */
	public String getUserDomain() {
		return userDomain;
	}

	/**
	 * @param userDomain the userDomain to set
	 */
	public void setUserDomain(String userDomain) {
		this.userDomain = userDomain;
	}

}
