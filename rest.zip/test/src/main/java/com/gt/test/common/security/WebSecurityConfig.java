package com.harman.dmat.common.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

/**
 * The Class WebSecurityConfig.
 *
 * @author prakash.bisht@harman.com
 */
@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	/** The Constant TOKEN_REFRESH_ENTRY_POINT. */
	public static final String TOKEN_REFRESH_ENTRY_POINT = "/usermang/v1/login";
	public static final String GET_STATES = "/usermang/v1/states";
	public static final String GET_REGION = "/usermang/v1/regions";
	public static final String GET_COMPANY = "/usermang/v1/companies";
	public static final String REGISTER_USER = "/usermang/v1/register";
	public static final String FORGET_PASSWORD = "/usermang/v1/users/forgetpwd";
	public static final String CONTACT_US = "/usermang/v1/contact";
	public static final String EVENT_IMAGE_URLS = "/resources/images/**";

	// Client API calls
	public static final String CRASHREPORT_CLIENTRESTAPI = "/client/api/v1/crashreport";
	public static final String SIMPINREQUEST_CLIENTRESTAPI = "/client/api/v1/simpin";
	public static final String DMATLIVE_CLIENTRESTAPI = "/client/api/v1/livedatapoints";
	public static final String INBUILDING_CLIENTRESTAPI = "/client/api/v1/InBuilding/filteredimages";
	public static final String INBUILDING_IMAGEDATA = "/client/api/v1/InBuilding/images/{\\d+}";
	public static final String INBUILDING_LOCATIONS = "/client/api/v1/InBuilding/locations";
	public static final String SOFTWARE_VERSION = "/client/api/v1/appUpdate";
	public static final String APKDATA = "/client/api/v1/apks/{\\d+}";
	public static final String DEVICE_TEST = "/client/api/v1/autotest/report";
	public static final String ADD_IMAGE = "/client/api/v1/InBuilding/images";
	public static final String WIFI_DATA = "/client/api/v1/wifidata";
	public static final String EVENTSSUMMARY_EMAIL = "/client/api/v1/eventsSummary";
	public static final String POST_PROC_LOGS = "/postProc/v1/logs";
	public static final String LV_STATUS = "/loganalysis/v1/lvstatus";
	public static final String LV_EVENTS = "/loganalysis/v1/lvevents";
	public static final String LV_EVENTS_STATUS_REPORT = "/loganalysis/v1/estatusreport";
	public static final String REFRESH = "/usermang/v1/auth/refresh";

	/* public static final String ALL = "/**"; */

	/** The authentication provider. */
	@Autowired
	AuthenticationProvider authenticationProvider;

	/**
	 * Configure global.
	 *
	 * @param auth
	 *            the auth
	 * @throws Exception
	 *             the exception
	 */
	@Autowired
	public void configureGlobal(final AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(authenticationProvider);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.springframework.security.config.annotation.web.configuration.
	 * WebSecurityConfigurerAdapter#configure(org.springframework.security.
	 * config.annotation.web.builders.HttpSecurity)
	 */
	@Override
	protected void configure(final HttpSecurity http) throws Exception {
		http.csrf().disable().sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
				.authorizeRequests()
				.antMatchers(EVENT_IMAGE_URLS, CONTACT_US, FORGET_PASSWORD, TOKEN_REFRESH_ENTRY_POINT, GET_STATES,
						GET_COMPANY, GET_REGION, REGISTER_USER, CRASHREPORT_CLIENTRESTAPI, SIMPINREQUEST_CLIENTRESTAPI,
						DMATLIVE_CLIENTRESTAPI, INBUILDING_CLIENTRESTAPI, INBUILDING_IMAGEDATA, INBUILDING_LOCATIONS,
						SOFTWARE_VERSION, APKDATA, DEVICE_TEST, ADD_IMAGE, WIFI_DATA, POST_PROC_LOGS, LV_STATUS,
						LV_EVENTS, REFRESH,LV_EVENTS_STATUS_REPORT, EVENTSSUMMARY_EMAIL)
				.permitAll().and().authorizeRequests().anyRequest().authenticated();
		http.exceptionHandling().authenticationEntryPoint(new RestAuthenticationEntryPoint());
		http.addFilterBefore(new AuthenticationTokenFilter(), BasicAuthenticationFilter.class);
	}

}