package com.harman.dmat.common.sftp;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Singleton;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import com.harman.dmat.utils.SecuirtyUtils;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import lombok.extern.slf4j.Slf4j;

/**
 * Creates Connection to the SFTP server
 *
 * @author GTanwar
 */

@Singleton
@Component
@Slf4j
public class SftpService {

	private String host;
	private String username;
	private String password;
	private Integer port;
	private String workingDir;

	private Session session;
	private Channel channel;
	private ChannelSftp channelSftp;

	@Inject
	private Environment environment;

	/**
	 * Instantiates a new SFTP service.
	 *
	 * @return
	 */
	@PostConstruct
	public void intit() {
		host = environment.getRequiredProperty("sftp.host");
		username = environment.getRequiredProperty("sftp.user");
		password = SecuirtyUtils.decrypt(environment.getRequiredProperty("sftp.pwd"));
		port = Integer.parseInt(environment.getRequiredProperty("sftp.port"));
		workingDir = environment.getRequiredProperty("sftp.wrkngdir");

	}

	/**
	 * Connects to SFTP channel
	 */
	public ChannelSftp connectChannel() {
		JSch jsch = new JSch();
		try {
			session = jsch.getSession(username, host, port);

			session.setPassword(password);
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);
			session.connect();
			log.debug("Host connected.");
			channel = session.openChannel("sftp");
			channel.connect();

			log.debug("sftp channel opened and connected.");
			channelSftp = (ChannelSftp) channel;
			channelSftp.cd(workingDir);
		} catch (JSchException e) {
			log.error("Couldnt create JSCH session");
		} catch (SftpException e) {
			log.error("Couldnt create SFTP channel");
		}
		return channelSftp;
	}

}
