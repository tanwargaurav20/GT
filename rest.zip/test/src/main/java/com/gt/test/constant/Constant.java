package com.harman.dmat.constant;

// TODO: Auto-generated Javadoc
/**
 * The Interface Constant.
 */
public interface Constant {

	/** The Constant OK. */
	/**/
	public static final String OK = "200";

	/** The Constant NOT_FOUND. */
	public static final String NOT_FOUND = "404";

	/** The Constant USER_DELETED_SUCCESSFULLY. */
	public static final String USER_DELETED_SUCCESSFULLY = "User is deleted successfully.";

	/** The Constant ADMIN_ROLE_ID. */
	public static final Integer ADMIN_ROLE_ID = 2;

	/** The Constant ACTIVE_USER. */
	public static final Integer ACTIVE_USER = 1;

	/** The Constant IN_ACTIVE_USER. */
	public static final Integer IN_ACTIVE_USER = 0;

	/** The Constant USER_NOT_DELETED. */
	public static final String USER_NOT_DELETED = "No user is for deletion";

	/** The Constant FORBIDDEN. */
	public static final String FORBIDDEN = "403";

	/** The Constant USER_ID_EMPTY_OR_NULL. */
	public static final String USER_ID_EMPTY_OR_NULL = "User id is empty or null";

	/** The Constant PAYLOAD_REQUEST_ERROR. */
	public static final String PAYLOAD_REQUEST_ERROR = "payload given is wrong";

	/** The Constant USER_REGISTERED_SUCCESSFULLY. */
	public static final String USER_REGISTERED_SUCCESSFULLY = "user registered successfully";

	/** The Constant USER_NOT_REGISTERED_SUCCESSFULLY. */
	public static final String USER_NOT_REGISTERED_SUCCESSFULLY = "user not registered ";

	/** The Constant FIRST_OR_LAST_NAME_UPDATED_SUCCESSFULLY. */
	public static final String FIRST_OR_LAST_NAME_UPDATED_SUCCESSFULLY = "first or last name updated successfully";

	/** The Constant FIRST_OR_LAST_NAME_HAS_NOT_CHANGED. */
	public static final String FIRST_OR_LAST_NAME_HAS_NOT_CHANGED = "first or last name has not changed";

	/** The Constant ROLE_UPDATED_SUCCESSFULLY. */
	public static final String ROLE_UPDATED_SUCCESSFULLY = "Role updated Successfully";

	/** The Constant ROLE_NOT_UPDATED. */
	public static final String ROLE_NOT_UPDATED = "Role Not Updated";

	/** The Constant DEFAULT_PREFERENCE_ID. */
	public static final Integer DEFAULT_PREFERENCE_ID = 1;

	/** The Constant USER_ACTIVATED. */
	public static final String USER_STATUS_CHANGE = "User status change successfully.";

	/** The Constant USER_DELETED. */
	public static final String USER_DELETED = "User deleted successfully.";

	/** The Constant USER_LOGIN. */
	public static final String USER_LOGIN = "User login successfully";

	/** The Constant FORGET_PASSWORD. */
	public static final String FORGET_PASSWORD = "Password has been sent successfully to registered email ID.";

	/** The Constant FEEDBACK. */
	public static final String FEEDBACK = "Feedback has been recorded successfully.";

	public static final String FEEDBACK_ERROR = "Error while sending email.";

	/** The Constant CHANGE_PASSWORD. */
	public static final String CHANGE_PASSWORD = "Password changed successfully.";

	/** The Constant USER_REGISTER. */
	public static final String USER_REGISTER = "User register successfully.";

	/** The Constant COMPANIES. */
	public static final String COMPANIES = "Get all companies successfully";

	/** The Constant REGIONS. */
	public static final String REGIONS = "Get all regions successfully.";

	/** The Constant STATES. */
	public static final String STATES = "Get all states successfully.";

	/** The Constant ROLES. */
	public static final String ROLES = "Get all roles successfully";

	/** The Constant CONTACT_TO_ADMIN. */
	public static final String CONTACT_TO_ADMIN = "Please contact your administrator.";

	/** The Constant USER_PREFERENCE_SAVED_SUCCESSFULLY. */
	public static final String USER_PREFERENCE_SAVED_SUCCESSFULLY = "User preference saved successfully";

	/** The Constant GET_ALL_PRIVILEGES_FOR_THIS_ROLE. */
	public static final String GET_ALL_PRIVILEGES_FOR_THIS_ROLE = "Get all privileges for this role";

	/** The Constant GET_USER_PREFERENCE. */
	public static final String GET_USER_PREFERENCE = "Get user preference";

	/** The Constant GET_PREFERENCES_LIST. */
	public static final String GET_PREFERENCES_LIST = "List of preferences";

	/** The Constant STATUS_CHANGED_BY_ADMIN. */
	public static final String STATUS_CHANGED_BY_ADMIN = "Admin make the changes successfully";

	/** The Constant GET_LIST_OF_STATES. */
	public static final String GET_LIST_OF_STATES = "Get list of status on the basis of region";

	/** The Constant GET_SEARCHED_LIST_ON_BASIS_OF_INPUT. */
	public static final String GET_SEARCHED_LIST_ON_BASIS_OF_INPUT = "Get List of users on the basis of search param";

	/** The Constant EMAIL_DOES_NOT_EXIST. */
	public static final String EMAIL_DOES_NOT_EXIST = "Email not exist in the records";

	/** The Constant INTERNAL_SERVER_ERROR. */
	public static final String INTERNAL_SERVER_ERROR = "500";

	/** The Constant STATUS_NOT_SUCCESSFULLY_CHANGED_BY_ADMIN. */
	public static final String STATUS_NOT_SUCCESSFULLY_CHANGED_BY_ADMIN = "Status not successfully changed by admin";

	/** The Constant GET_ALL_USER_LIST. */
	public static final String GET_ALL_USER_LIST = "Get all users list";

	/** The Constant GET_ALL_USER_LIST_WITH_STATUS. */
	public static final String GET_ALL_USER_LIST_WITH_STATUS = "Get all users.";

	/** The Constant NOT_CHANGED. */
	public static final String NOT_CHANGED = "304";

	/** The Constant UNABLE_TO_GET_USERS_DATA. */
	public static final String UNABLE_TO_GET_USERS_DATA = "Unable to get User Data contact to administrator";

	/** The Constant DATA_NOT_ACCESSIBLE. */
	public static final String DATA_NOT_ACCESSIBLE = "Unable to get User Data";

	/** The Constant DB_ERROR. */
	public static final String DB_ERROR = "Error persisting data. Please contact your administrator.";

	/** The Constant GET_USER_DATA. */
	public static final String GET_USER_DATA = "Get user data";

	/** The Constant VALUE_CHECK. */
	public static final Integer VALUE_CHECK = 0;

	/** The Constant PREFERENCE_VALUE_CHECK_DEEP. */
	public static final Integer PREFERENCE_VALUE_CHECK_DEEP = 1;

	/** The Constant PREFERENCE_VALUE_CHECK_HIGH. */
	public static final Integer PREFERENCE_VALUE_CHECK_HIGH = 2;

	/** The Constant USER_IMEIS. */
	public static final String USER_IMEIS = "Get user imeis successfully";

	/** The Constant IMEIS. */
	public static final String IMEIS = "Get all imeis successfully";

	/** The Constant MODELS. */
	public static final String MODELS = "Get all models successfully";

	/** The Constant USER_MODELS. */
	public static final String USER_MODELS = "Get user models successfully";

	/** The Constant MDNS. */
	public static final String MDNS = "Get all mdns successfully";

	/** The Constant USER_MDNS. */
	public static final String USER_MDNS = "Get user mdns successfully";

	/** The Constant LOGS. */
	public static final String LOGS = "Get all logs successfully";

	/** The Constant USER_LOGS. */
	public static final String USER_LOGS = "Get user logs successfully";

	/** The Constant IMEI. */
	public static final String IMEI = "Get Imei successfully";

	/** The Constant DB_FETCH_ERROR. */
	public static final String DB_FETCH_ERROR = "Error Fetching data.Please contact your administrator";

	/** The Constant USER_PREFERENCE__NOT_SAVED_SUCCESSFULLY. */
	public static final String USER_PREFERENCE__NOT_SAVED_SUCCESSFULLY = "User preference not saved successfully";

	/** The Constant SUCCESS. */
	public static final String SUCCESS = "SUCCESS";

	/** The Constant FAILED. */
	public static final String FAILED = "FAILED";

	/** The Constant ALL. */
	public static final String ALL = "All";

	/** The Constant DAY. */
	public static final String DAY = "DAY";

	/** The Constant WEEK. */
	public static final String WEEK = "WEEK";

	/** The Constant MONTH. */
	public static final String MONTH = "MONTH";

	/** The Constant USER_STATE_DATA. */
	public static final String USER_STATE_DATA = "Get user State Data";

	/** The Constant AUTH_TYPE. */
	public static final String AUTH_TYPE = "Bearer";

	/** The Constant FAILURE. */
	public static final String FAILURE = "Failure";

	/** The Constant USER_ID. */
	public static final String USER_ID = "user_id";

	/** The Constant IS_SUSPENDED. */
	public static final String IS_SUSPENDED = "is_suspended";

	/** The Constant IS_ACTIVE. */
	public static final String IS_ACTIVE = "is_active";

	/** The Constant FIRST_NAME. */
	public static final String FIRST_NAME = "first_name";

	/** The Constant LAST_NAME. */
	public static final String LAST_NAME = "last_name";

	/** The Constant IS_GROUP_ADMIN. */
	public static final String IS_GROUP_ADMIN = "is_group_admin";

	/** The Constant COMPANY_ID. */
	public static final Object COMPANY_ID = "company_id";

	/** The Constant ROLE_ID. */
	public static final Object ROLE_ID = "role_id";

	/** Log file Uploaded Successfully. */
	public static final String UPLOADED_SUCCESS = "Uploaded successfully";

	/** Log file Registered for reprocess Successfully. */
	public static final String REPROCESS_SUCCESS = "Log file Registered for Re-process Successfully.";

	/** The Constant UPLOADED_FAILED. */
	public static final String UPLOADED_FAILED = "Upload failed due to empty file  or invalid file extension.";

	/** The Constant NOFILE. */
	public static final String NOFILE = "No File Selected.";

	/** The Constant ACCORDION. */
	public static final String ACCORDION = "Get all accordion info successfully";

	/** The Constant PENDING. */
	public static final String PENDING = "PENDING";

	/** The Constant ALL_ROLE_ID. */
	public static final String ALL_ROLE_ID = "(0,2,3,4,5,99)";

	/** The Constant STATUS. */
	public static final String STATUS = "status";

	/** The Constant NOTIFICATION. */
	public static final String NOTIFICATION = "Notification has been send to user.";

	/** The Constant ADMIN. */
	public static final String ADMIN = "ADMIN";

	/** The Constant SUPER_ADMIN. */
	public static final String SUPER_ADMIN = "SUPER_ADMIN";

	/** The Constant GROUP_ADMIN. */
	public static final String GROUP_ADMIN = "GROUP_ADMIN";

	/** The Constant OEM. */
	public static final String OEM = "OEM";

	/** The Constant FULL_PATH. */
	public static final String FULL_PATH = "/**";

	public static final String CONTACT = "Get contact details successfully.";

	public static final String INFOPOINT_OPERATOR = "Operator:Verizon Wireless";

	public static final String LAST_ACTIVITY = "Last activity.";

	public static final String DEVICE_ADDED = "Device added successfully";

	public static final String DEVICE_EDIT = "Device edited successfully";
	/** The Constant FAILED. */
	public static final String LOGMGR_DELETE_FAILED = "Insufficient permissions to delete log file.";

	/** State constant for Drive route. */
	public static final String STATE = "state";

	/** The Constant COLON. */
	public static final String COLON = ":";

	/** The Constant USER_SELECTION. */
	public static final String USER_SELECTION = "Wrong user selection,you have not enough privileges to perform operation on selected users.";

	/** The Constant ROLE_CHANGED. */
	public static final String ROLE_CHANGED = "You can not assign this role to user.";

	/** The Constant SAVE_ACTIVITY. */
	public static final String SAVE_ACTIVITY = "Activity Saved Successfully.";

	/** Failed saving reports template. */
	public static final String REPORTS_SAVE_FAILED = "Failed saving reports template.";

	/** Failed deleting reports template. */
	public static final String REPORTS_DELETE_FAILED = "Failed deleting reports template.";

	public static final String RESOURSE_EXISTS = "422";
	public static final String RESOURSE_EXISTS_MESSAGE = "File already exists.";
	public static final String DOT = ".";
	public static final String LOG_SCAPE_CHAR = "[\r\n]";
	public static final String EMPTY_STRING = "";

	String CUSTOM_REPORT_TIME_SERIES_HEADER = "Timeseries Chart for";
	String CUSTOM_REPORT_HISTOGRAM_HEADER = "Histogram Chart for";
	String CUSTOM_REPORT_TIME_SERIES_XLABEL = "Date Time";
	String CUSTOM_REPORT_HISTOGRAM_XLABEL = "";
	String CUSTOM_REPORT_TIME_SERIES_YLABEL = "KPI Value";
	String CUSTOM_REPORT_HISTOGRAM_YLABEL = "Percentage(%)";

	/** SME constant. */
	public static final String SME = "SME";
	public static final String LRA = "LRA";
	public static final String USER = "USER";
	public static final String OPERATOR = "Operator:";
	public static final String CUSTOMREPORT = "CUSTOMREPORT";

	public static final String LM_SUCCESS = "000";
	public static final String LM_INVALID_CREDENTIALS = "005";
	public static final String LM_INACTIVE_USER = "007";
	public static final String LM_LICENSE_EXPIRED = "006";
	public static final String LM_UNAUTHORIZED_USER = "003";
	public static final String TRUE = "true";
	public static final String FALSE = "false";

	public static final String REMOVE_INBUILDING_FILES = " AND filename NOT LIKE 'InBuilding%' ";
	public static final String DASHBOARDREPORT = "dashboardReport";
	/** Constant Refresh token. */
	public static final String REFRESH_TOKEN = "Token generated successfully";

	public static final String SOFTWARE_DELETED_SUCCESSFULLY = "Software is deleted successfully.";
	public static final String SOFTWARE_NOT_DELETED = "Software is not deleted.";
}
