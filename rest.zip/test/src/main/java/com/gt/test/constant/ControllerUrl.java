package com.harman.dmat.constant;

/**
 * The Interface ControllerUrl.
 *
 * @author prakash.bisht@harman.com
 */
public interface ControllerUrl {

	/** The concat. */
	String CONCAT = "";

	/** The version. */
	String VERSION = "/v1";

	/** The users. */
	String USERS = "/users";

	/** The users register. */
	String USERS_REGISTER = "/register";

	/** The user. */
	String USER = "/user";

	/** The user mang. */
	String USER_MANG = "/usermang" + VERSION;

	/** The validat user. */
	String VALIDAT_USER = "/login";

	/** The activate. */
	String ACTIVATE = "/activate";

	/** The forget password. */
	String FORGET_PASSWORD = USERS + "/forgetpwd";

	/** User Feedback url */
	String FEEDBACK = USERS + "/feedback";

	/** The get user details. */
	String GET_USER_DETAILS = USERS + "/{userId}";

	/** The change password. */
	String CHANGE_PASSWORD = USERS + "/changepwd";

	/** The home. */
	String HOME = "/home" + VERSION;

	/** The companies. */
	String COMPANIES = "/companies";

	/** The regions. */
	String REGIONS = "/regions";

	/** The states. */
	String STATES = "/states";

	/** The roles. */
	String ROLES = "/roles";

	/** The delete user. */
	String DELETE_USER = "/users";

	/** The update user profile data. */
	String UPDATE_USER_PROFILE_DATA = USERS;

	/** The get users with status. */
	String GET_USERS_WITH_STATUS = USERS;

	/** The user search. */
	String USER_SEARCH = "/users/search";

	/** The approve user. */
	String APPROVE_USER = "/users/status";

	/** The role privileges. */
	String ROLE_PRIVILEGES = "user/getrolepriviledge";

	/** The edit role. */
	String EDIT_ROLE = "/users/role";

	/** The user preference. */
	String USER_PREFERENCE = USERS + "/preferences";

	/** The user preference with extent. */
	String USER_PREFERENCE_MAP_EXTENT = USERS + "/preferences/extent";

	/** The get user preference. */
	String GET_USER_PREFERENCE = "/users/{userId}/preferences";

	/** The get privileges. */
	String GET_PRIVILEGES = "/getallprivileges";

	/** The get states. */
	String GET_STATES = "/region/states";

	/** The save user. */
	String SAVE_USER = "/register";

	/** The get preferences. */
	String GET_PREFERENCES = "/preferences";

	/** The logmgr rootpath. */
	String LOGMGR_ROOTPATH = "/logmgr" + VERSION;

	/** The logmgr reports. */
	String LOGMGR_REPORTS = "/reports/{user}";

	/** The logmgr report. */
	String LOGMGR_REPORT = "/log/reports";

	/** The logmgr search. */
	String LOGMGR_SEARCH = "/reports/search/{user}";

	/** The logmgr userpref. */
	String LOGMGR_USERPREF = USERS + "/preferences";

	/** The logmgr deletelogs. */
	String LOGMGR_DELETELOGS = "/logs";

	/** The logmgr getpref. */
	String LOGMGR_GETPREF = "/users/{userId}/preferences";

	/** The logmgr analysis. */
	String LOGMGR_ANALYSIS = "/log/analysis/{userId}";

	/** The models. */
	String MODELS = "/global/models";

	/** The imei. */
	String IMEI = "/global/imeis";

	/** The user imei. */
	String USER_IMEI = "/users/{userId}/imeis";

	/** The user mdn. */
	String USER_MDN = "/users/{userId}/mdns";

	/** The mdn. */
	String MDN = "/global/mdns";

	/** The all. */
	String ALL = "/All";

	/** The filters. */
	String FILTERS = "/filters/v1";

	/** The user models. */
	String USER_MODELS = "/users/{userId}/models";

	/** The user filtter states. */
	String USER_FILTTER_STATES = "/users/{userId}/states";

	/** The user logs. */
	String USER_LOGS = "/users/{userId}/logs";

	/** The logs. */
	String LOGS = "/logs";

	/** The global filters. */
	String GLOBAL_FILTERS = "/global/{user}";

	/** The global filters. */
	String GLOBAL_FILTERS_ES = "/globalEs/{user}";

	/** The filtter states. */
	String FILTTER_STATES = "/states";

	/** The user info. */
	String USER_INFO = USERS + "/info";

	/** The events. */
	String EVENTS = "/events";

	/** The legends. */
	String LEGENDS = "/legends/v1";

	/** The infopoints rootpath. */
	String INFOPOINTS_ROOTPATH = "/infopoints" + VERSION;

	/** The infopoints info. */
	String INFOPOINTS_INFO = "/point";

	/** The infopoints live info. */
	String INFOPOINTS_LIVE = "/live";

	/** Events List info **/
	String EVENTS_LIST = "/events";

	/** The event infopoints info. */
	String EVENT_INFOPOINTS_INFO = "/event/point";

	/** The accordion. */
	String ACCORDION = "/accordion/info";

	/** The status change. */
	String STATUS_CHANGE = "/status/change";

	/** The delete users. */
	String DELETE_USERS = USER + "/delete";

	/** The user notification. */
	String USER_NOTIFICATION = USER + "/notification";

	/** The region. */
	String REGION = "/region";
	/** The contact us. */
	String CONTACT_US = "/contact";

	/** The global logfiles. */
	String GLOBAL_LOGFILES = "/global/files";

	/** The view more files. */
	String VIEW_MORE_FILES = "/more/files";

	/** The user last activity. */
	String USER_LAST_ACTIVITY = USER + "/activity";

	/** The sim card request. */
	String SIM_CARD_REQUEST = USER + "/sim/request";

	/** The device. */
	String DEVICE = USER + "/device";

	/** The import excel file. */
	String IMPORT_EXCEL_FILE = USER + "/import";

	/** The sim info. */
	String SIM_INFO = USER + "/sim/info";

	/** The os. */
	String OS = USER + "/os";

	/** DLF Upload. */
	String UPLOAD = "/upload";
	/** DLF Re-process. */
	String REPROCESS = "/reProcess";
	/** DLF Export. */
	String EXPORT = "/export";
	/** The DriveRoute rootpath. */
	String DRIVEROUTE_ROOTPATH = "/driveroute" + VERSION;
	/** The route info. */
	String ROUTE = "/route";

	/** The group. */
	String GROUP = USERS + "/group";

	/** The group requrest. */
	String GROUP_REQUREST = USERS + "/group/request";

	/** The group request accepe. */
	String GROUP_REQUEST_STATUS = USERS + "/group/request/status";

	/** The user breif info. */
	String USER_BREIF_INFO = USERS + "/user/info";

	/** The sim request data. */
	String SIM_REQUEST_DATA = USERS + "/sim/info";

	/** The user groups. */
	String USER_GROUPS = USER + "/groups";

	/** The client api services. */
	String CLIENT_API_SERVICES = "/client/api/v1";

	/** The client api services. */
	String BASELINE_SERVICE = "/county_state_region_baseline";

	/** The crashreport. */
	String CRASHREPORT = "/crashreport";

	/** The simpin request. */
	String SIMPIN_REQUEST = "/simpin";

	/** events summary email request */
	String EVENTSSUMMARY_EMAIL = "/eventsSummary";

	/** The activity management. */
	String ACTIVITY_MNG = "/activitymgr" + VERSION;

	/** The save activity. */
	String ACTIVITY = "/activity";

	/** The save activity. */
	String ASSIGNED_ACTIVITY = ACTIVITY + "/assigned";

	/** The activity status. */
	String ACTIVITY_STATUS = ACTIVITY + "/status/{activityId}";

	/** The activity share. */
	String ACTIVITY_SHARE = ACTIVITY + "/share";

	/** The activity comment. */
	String ACTIVITY_COMMENT = ACTIVITY + "/comment";

	/** The live rootpath. */
	String LIVE_ROOTPATH = "/live" + VERSION;

	/** The live imei. */
	String LISTIMEI = "/imei";

	String DMATLIVE_REQUEST = "/livedatapoints";

	String FILTEREDDATA = "/InBuilding/filteredimages";

	/** The live trend. */
	String LIVETREND = "/trend/{imei}";

	String INBUILDING_IMAGE = "/InBuilding/images/{imageId}";

	String INBUILDING_LOCATION = "/InBuilding/locations";

	/** Inbuilding Images */
	String INBUILDING_ROOT = "/inbuilding" + VERSION;

	String INBUILDINGIMG = "/InbuildingImage";

	String INBUILDINGIMG_LOGFILES = "/inbuildinglogfiles";

	String INBUILDING_INFOPOINT = "/infopoint";

	String INBUILDING_REGISTER = "/register";

	String INBUILDING_REGISTER_V1 = "/registerib";

	String SOFTWARE_APK_UPLOAD = "/swApkUpload";

	String REGISTER_SOFTWARE = "/registerSw";

	String INBUILDING_LIST = "/list";

	String INBUILDING_REMOVE = "/remove";

	String INBUILDING_UPDATE_IMAGE = "/updateimage";

	String INBUILDING_UPDATE = "/updateinfo";

	/** The Custom reports files search. */
	String CUSTOMREPORTS_SEARCH = "/customreport";

	/** The Custome reports histogram. */
	String CUSTOMREPORTS_HISTOGRAM = "/customreport/histogram";

	String SOFTWARE_VERSION = "/appUpdate";

	String APKDATA = "/apks/{version:.+}";

	String DEVICE_TEST = "/autotest/report";

	/** The Custom reports devices. */
	String CUSTOMREPORTS_DEVICES = "/customreport/devices";

	/** The Custom reports template. */
	String CUSTOMREPORTS_TEMPLATES = "/customreport/template";

	String LVLOGANALYSIS = "/loganalysis/v1";

	String LVFILEID = "/lvfile";

	String LVSTATUS = "/lvstatus";

	String LVEVENTS = "/lvevents";

	String EVENTS_STATUS_REPORT = "/estatusreport";

	String LV_AUTO_TEST_REPORT = "/atreport";

	/** The Custom reports timeseries. */
	String CUSTOMREPORTS_TIMESERIES = "/customreport/timeseries";

	String ADD_IMAGE = "/InBuilding/images";

	/** The user gruid. */
	String USER_GRUID = USERS + "/file";

	String WIFI_DATA = "/wifidata";

	String CUSTOMREPORTS_DOWNLOAD_PDF = "/customreport/downloadpdf";

	String CREATE_PDF = "/customreport/createpdf";

	String SHOW_PDF = "/customreport/showpdf";

	String HEATMAP = "/heatMap/v1";

	String HEATMAP_LOCATION = "/location";

	String POST_PROC = "/postProc/v1";

	String POST_PROC_LOGS = "/logs";

	/** The wifi rootpath. */
	String WIFI_ROOTPATH = "/wifi" + VERSION;

	String WIFI_INFO = "/wifiinfo";

	String WIFI_CLUSTER = "/wificluster";

	String WIFI_CLUSTER_INFO = "/wificlusterinfo";
	
	/** The cellsite rootpath. */
	String CELLSITE_ROOTPATH = "/cellsite" + VERSION;
	
	String CELLSITE_CLUSTER = "/cellsitecluster";

	
	

	/** The Dashboard root */
	String DASHBOARD_ROOT = "/dashboard" + VERSION;

	String DASHBOARD_USERS_COUNT = "/usercount";

	String USER_LIST = "/userlist";

	String APK_VERSION = "/apkversion";

	String DASHBOARD_FILE_PROCESS_REPORT = "/fileprocessreport";

	String DASHBOARD_PRE_PROCESS_REPORT = "/filepreprocessreport";

	String DASHBOARD_POST_PROCESS_REPORT = "/filepostprocessreport";

	String DASHBOARD_DIR_COMPARISON_REPORT = "/dircomparisonreport";

	String DOWNLOAD_DASHBOARD_FILE_PROCESS_REPORT = "/downloadfileprocessreport";

	String DOWNLOAD_DASHBOARD_PRE_PROCESS_REPORT = "/downloadfilepreprocessreport";

	String DOWNLOAD_DASHBOARD_POST_PROCESS_REPORT = "/downloadfilepostprocessreport";

	String DOWNLOAD_DASHBOARD_DIR_COMPARISON_REPORT = "/downloaddircomparisonreport";

	/** Refresh Token. */
	String REFRESHTOKEN = "/auth/refresh";

	String ANALYTICS = "/analytics/v1";

	String UNIQUE_MODEL = "/models";

	String DEVICE_ANALYTICS = "/devicePerf";

	String ENBID = "/kpi/v1";

	String RETRIEVE_ENBID = "/enbid";
	
	/** Events. */
	String EVENTS_LEGENDS = "/events/legends";
	
	/** Events. */
	String EVENTS_COUNT = "/events/count";
	
}
