package com.harman.dmat.constant;

public class LegendsConstant {
	private LegendsConstant() {
		super();
	}

	// type of legends
	public static final String TYPE_NO_LEGEND = "no_legend";
	public static final String TYPE_FIXED_RANGE = "fixed_range_with_color";
	public static final String TYPE_VARIABLE_RANGE = "variable_range_with_color";
	// Type Table
	public static final String TYPE_FIXED_RANGE_TABLE = "LEGEND_FIXED_RANGE_DEF";
	public static final String TYPE_VARIABLE_RANGE_TABLE = "LEGEND_VARIABLE_RANGE_DEF";

	public static final String TYPE_FIXED_RANGE_TABLE_USER = "LEGEND_FIXED_RANGE_USER";
	public static final String TYPE_VARIABLE_RANGE_TABLE_USER = "LEGEND_VARIABLE_RANGE_USER";

	public static final String KPI_NO_UNIT = "no_unit";

	public static final String VARIABLE = "<=x<";

	// db constants
	public static final String MIN = "Min";
	public static final String MAX="Max";
	public static final String NAME = "Name";
	public static final String KPI_ID = "KpiId";
	public static final String LEGEND_Id = "LegendId";
	public static final String ES_KPI_KEY = "KpiKey";
	public static final String COLOR = "Color";
	public static final String VALUE="Value";
	public static final String UNIT="Unit";
	public static final String EDITABLE="Editable";
	public static final String GROUP_ID= "GroupId"; 
	public static final String LEGEND_TYPE= "LegendType";
	public static final String ID="Id";
	
	
	//db query
	public static final String REMOVE_ALL_VARIABLE_LEGEND_FOR_USER="delete from LEGEND_VARIABLE_RANGE_USER where UserId=?";
	public static final String REMOVE_ALL_FIXED_LEGEND_FOR_USER="delete from LEGEND_FIXED_RANGE_USER where UserId=?";
	public static final String GET_KPI_USING_GROUP_ID="select KpiId,Name,GroupId,Editable,LegendType,ESKpiKey from KPI_DEFINITIONS where GroupId=?";
	
	
	
}
