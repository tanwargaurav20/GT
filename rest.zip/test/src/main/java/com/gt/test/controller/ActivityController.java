/**
 * 
 */
package com.harman.dmat.controller;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.validation.Valid;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.harman.dmat.common.dto.ActivitiesDetailsDto;
import com.harman.dmat.common.dto.ActivityCommentDto;
import com.harman.dmat.common.dto.ActivityDTO;
import com.harman.dmat.common.dto.ActivityShareDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.common.exception.ActivityException;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.manager.ActivityManager;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class ActivityController.
 *
 * @author insgupta06
 */
@RestController
@RequestMapping(ControllerUrl.ACTIVITY_MNG)
		
		/** The Constant log. */
		@ Slf4j
public class ActivityController {

	/**
	 * Inject activityManager implementation.
	 */
	@Inject
	private transient ActivityManager activityManager;

	/**
	 * Save activity in system.
	 *
	 * @param activityDto
	 *            the activity dto
	 * @return the response dto
	 * @throws ActivityException
	 *             the activity exception
	 */
	@PostMapping(ControllerUrl.ACTIVITY)
	public ResponseDto saveActivity(@Valid @RequestBody final ActivityDTO activityDto) throws ActivityException {
		activityManager.saveActivity(activityDto);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SAVE_ACTIVITY);
		responseDto.setStatus(Constant.OK);
		return responseDto;

	}
	
	/**
	 * Get logged in user's created activity list.
	 *
	 * @param
	 * @return the response dto
	 * @throws ActivityException
	 *             the activity exception
	 */
	@GetMapping(ControllerUrl.ACTIVITY)
	public ResponseDto getCreatedActivities() throws ActivityException {
		final List<ActivitiesDetailsDto> createdActivities = activityManager.getCreatedActivities();
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(createdActivities);
		return responseDto;

	}
	
	/**
	 * Get assigned activities for logged in user.
	 *
	 * @param 
	 * @return the response dto
	 * @throws ActivityException
	 *             the activity exception
	 */
	@GetMapping(ControllerUrl.ASSIGNED_ACTIVITY)
	public ResponseDto getAssignedActivities() throws ActivityException {
		final List<ActivitiesDetailsDto> assignedActivities = activityManager.getAssignedActivities();
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(assignedActivities);
		return responseDto;

	}
	
	/**
	 * Delete activity.
	 *
	 * @param activityId the activity id
	 * @return the response dto
	 * @throws ActivityException the activity exception
	 */
	@DeleteMapping(ControllerUrl.ACTIVITY)
	public ResponseDto deleteActivity(@RequestParam("activityId") final Integer activityId) throws ActivityException {
		activityManager.deleteActivity(activityId);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		return responseDto;

	}
	
	/**
	 * Creates the activity status.
	 *
	 * @param activityId the share activity id
	 * @param status the status
	 * @return the response dto
	 * @throws ActivityException the activity exception
	 */
	@PutMapping(ControllerUrl.ACTIVITY_STATUS)
	public ResponseDto createActivityStatus(@PathVariable("activityId") final Integer activityId,
			@RequestBody final Map<String,String> dataMap) throws ActivityException {
		activityManager.createActivityStatus(activityId,dataMap.get("status"));
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		return responseDto;

	}
	
	/**
	 * Share activity.
	 *
	 * @param activityShareDto the activity share dto
	 * @return the response dto
	 * @throws ActivityException the activity exception
	 */
	@PostMapping(ControllerUrl.ACTIVITY_SHARE)
	public ResponseDto shareActivity( @RequestBody final ActivityShareDto activityShareDto) throws ActivityException {
		activityManager.shareActivity(activityShareDto);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		return responseDto;

	}
	
	/**
	 * Creates the comment.
	 *
	 * @param activityCommentDto the activity comment dto
	 * @return the response dto
	 * @throws ActivityException the activity exception
	 */
	@PostMapping(ControllerUrl.ACTIVITY_COMMENT)
	public ResponseDto createComment( @RequestBody final ActivityCommentDto activityCommentDto) throws ActivityException {
		activityManager.createComment(activityCommentDto);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		return responseDto;

	}
	
	/**
	 * Gets the comments.
	 *
	 * @param activityId the activity id
	 * @return the comments
	 * @throws ActivityException the activity exception
	 */
	@GetMapping(ControllerUrl.ACTIVITY_COMMENT)
	public ResponseDto getComments( @RequestParam("activityId")Integer activityId) throws ActivityException {
		final List<ActivityCommentDto> comments=activityManager.getComments(activityId);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(comments);
		return responseDto;

	}
	@GetMapping(ControllerUrl.ACTIVITY_SHARE)
	public ResponseDto getShareActivity() throws ActivityException {
		final List<ActivitiesDetailsDto> shareActivity=activityManager.getShareActivity();
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(shareActivity);
		return responseDto;

	}
}
