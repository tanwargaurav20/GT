package com.harman.dmat.controller;

import com.harman.dmat.common.dto.*;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.service.AnalyticsService;
import com.harman.dmat.utils.SecuirtyUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.util.List;

/**
 * Analytics based on model, kpi, events, kpi ranges and timeframes.
 */

@RestController
@Slf4j
@RequestMapping(ControllerUrl.ANALYTICS)
public class AnalyticsController {
    @Inject
    AnalyticsService analyticsService;

    @GetMapping(ControllerUrl.UNIQUE_MODEL)
    public ResponseEntity<AnalyticsResponseDto> getUniqueModels(@RequestParam(value = "from", required = true) final String from,
                                                       @RequestParam(value = "to", required = true) final String to,
                                                       @RequestParam(value = "tlLat", required = true) final String tlLat,
                                                       @RequestParam(value = "tlLon", required = true) final String tlLon,
                                                       @RequestParam(value = "brLat", required = true) final String brLat,
                                                       @RequestParam(value = "brLon", required = true) final String brLon,
                                                       @RequestParam(value = "domain", required = true) final String domain,
                                                       @RequestParam(value = "userId", required = true) final String userId) {
        AnalyticsResponseDto responseDto = new AnalyticsResponseDto();

        if (log.isDebugEnabled()) {
            log.debug(SecuirtyUtils
                    .removeCFLRChar("getUniqueModels() request params: " + " fromDate= " + from + " toDate= "
                            + to + " tl_lat= " + tlLat + " tl_lon= " + tlLon + " br_lat= " + brLat + " br_lon= " + brLon + " domain= "+ domain + " userId= " + userId));
        }

        AnalyticsRequestDto requestDto = new AnalyticsRequestDto();
        requestDto.setFromDate(from);
        requestDto.setToDate(to);
        requestDto.setTlLat(tlLat);
        requestDto.setTlLon(tlLon);
        requestDto.setBrLat(brLat);
        requestDto.setBrLon(brLon);
        requestDto.setDomain(domain);
        requestDto.setUserId(userId);

        AnalyticsResponseDto analyticsResponseDto = analyticsService.getModels(requestDto);

        return new ResponseEntity<AnalyticsResponseDto>(analyticsResponseDto, HttpStatus.OK);
    }

    @PostMapping(ControllerUrl.DEVICE_ANALYTICS)
    public ResponseEntity<List<DeviceStatsResponseDto>> getDeviceStats(@RequestBody DeviceStatsRequestDto deviceStatsRequestDto) {
        ResponseDto responseDto = new ResponseDto();

        if (log.isDebugEnabled()) {
            log.debug(SecuirtyUtils
                    .removeCFLRChar("getDeviceStats() request params: " + " fromDate= " + deviceStatsRequestDto.getFromDate() +
                            " toDate= " + deviceStatsRequestDto.getToDate() + " tl_lat= " + deviceStatsRequestDto.getTlLat() +
                            " tl_lon= " + deviceStatsRequestDto.getTlLon() + " br_lat= " + deviceStatsRequestDto.getBrLat() +
                            " br_lon= " + deviceStatsRequestDto.getBrLon() + " locCode= "+ deviceStatsRequestDto.getLocCode() +
                            " events= "+ deviceStatsRequestDto.getEvents() + " devices= "+ deviceStatsRequestDto.getDevices() +
                            " timeFrame= "+ deviceStatsRequestDto.getTimeFrame() + " kpiRanges= "+ deviceStatsRequestDto.getKpiRanges() +
                            " kpi= "+ deviceStatsRequestDto.getKpi() + " domain= "+ deviceStatsRequestDto.getDomain()
                            + " userId= "+ deviceStatsRequestDto.getUserId()));
        }

        List<DeviceStatsResponseDto> deviceStatsResponseDto = analyticsService.getDeviceStats(deviceStatsRequestDto);

        return new ResponseEntity<List<DeviceStatsResponseDto>>(deviceStatsResponseDto, HttpStatus.OK);
    }

}
