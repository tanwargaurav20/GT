package com.harman.dmat.controller;

import com.harman.dmat.common.dto.BaselineCountyReqDto;
import com.harman.dmat.common.dto.BaselineCountyResDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.service.BaselineCountyService;
import com.harman.dmat.utils.SecuirtyUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;

@RestController
@RequestMapping(ControllerUrl.BASELINE_SERVICE)
@Slf4j
public class BaselineCountyController {
    @Inject
    BaselineCountyService baselineCountyService;

    @PostMapping(value = "/", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseDto> getBaselineCounty(@RequestBody final BaselineCountyReqDto baselineCountyReqDto) {
        log.debug("Baseline County userId as received: " + SecuirtyUtils.removeCFLRChar(baselineCountyReqDto.getUserId()));
        log.debug("Baseline County brLat as received: " + SecuirtyUtils.removeCFLRChar(baselineCountyReqDto.getBrLat()));
        log.debug("Baseline County brLon as received: " + SecuirtyUtils.removeCFLRChar(baselineCountyReqDto.getBrLon()));
        log.debug("Baseline County tlLat as received: " + SecuirtyUtils.removeCFLRChar(baselineCountyReqDto.getTlLat()));
        log.debug("Baseline County tlLon as received: " + SecuirtyUtils.removeCFLRChar(baselineCountyReqDto.getTlLon()));
        log.debug("Baseline County domain as received: " + SecuirtyUtils.removeCFLRChar(baselineCountyReqDto.getDomain()));
        log.debug("Baseline County endDate as received: " + SecuirtyUtils.removeCFLRChar(baselineCountyReqDto.getEndDate()));
        log.debug("Baseline County startDate as received: " + SecuirtyUtils.removeCFLRChar(baselineCountyReqDto.getStartDate()));
        log.debug("Baseline County imeiS as received: " + (StringUtils.isNotBlank(baselineCountyReqDto.getImeiS()) ? SecuirtyUtils.removeCFLRChar(baselineCountyReqDto.getImeiS()) : baselineCountyReqDto.getImeiS()));
        log.debug("Baseline County imeiT as received: " + (StringUtils.isNotBlank(baselineCountyReqDto.getImeiT()) ? SecuirtyUtils.removeCFLRChar(baselineCountyReqDto.getImeiT()) : baselineCountyReqDto.getImeiT()));
        log.debug("Baseline County mdnS as received: " + (StringUtils.isNotBlank(baselineCountyReqDto.getMdnS()) ? SecuirtyUtils.removeCFLRChar(baselineCountyReqDto.getMdnS()) : baselineCountyReqDto.getMdnS()));
        log.debug("Baseline County mdnT as received: " + (StringUtils.isNotBlank(baselineCountyReqDto.getMdnT()) ? SecuirtyUtils.removeCFLRChar(baselineCountyReqDto.getMdnT()) : baselineCountyReqDto.getMdnT()));
        log.debug("Baseline County modelS as received: " + (StringUtils.isNotBlank(baselineCountyReqDto.getModelS()) ? SecuirtyUtils.removeCFLRChar(baselineCountyReqDto.getModelS()) : baselineCountyReqDto.getModelS()));
        log.debug("Baseline County modelT as received: " + (StringUtils.isNotBlank(baselineCountyReqDto.getModelT()) ? SecuirtyUtils.removeCFLRChar(baselineCountyReqDto.getModelT()) : baselineCountyReqDto.getModelT()));
        log.debug("Baseline County kpiName as received: " + SecuirtyUtils.removeCFLRChar(baselineCountyReqDto.getKpiName()));

        final ResponseDto filter = new ResponseDto();
        final BaselineCountyResDto globalFilters = baselineCountyService.getBaselineCounty(baselineCountyReqDto, baselineCountyReqDto.getUserId());

        filter.setStatus(Constant.OK);
        filter.setMessage(Constant.SUCCESS);
        filter.setData(globalFilters);

        return new ResponseEntity<ResponseDto>(filter, HttpStatus.OK);
    }

}
