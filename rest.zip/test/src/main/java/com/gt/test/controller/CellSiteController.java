package com.harman.dmat.controller;

import static com.harman.dmat.constant.ControllerUrl.CELLSITE_ROOTPATH;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.harman.dmat.common.dto.CellSiteClusterRequestDto;
import com.harman.dmat.common.dto.CellSiteClusterResponseDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.manager.CellSiteManager;

@RestController
@RequestMapping(CELLSITE_ROOTPATH)

public class CellSiteController {

	@Inject
	CellSiteManager cellSiteManager;

	@GetMapping(value = ControllerUrl.CELLSITE_CLUSTER, produces = MediaType.APPLICATION_JSON_VALUE)

	public ResponseEntity<ResponseDto> getWifiDataClusters(
			@RequestParam(value = "timeStampFrm", required = true) final String timeStampFrm,
			@RequestParam(value = "timeStampTo", required = true) final String timeStampTo,
			@RequestParam(value = "tl_lat", required = true) final String tl_lat,
			@RequestParam(value = "tl_lon", required = true) final String tl_lon,
			@RequestParam(value = "br_lat", required = true) final String br_lat,
			@RequestParam(value = "br_lon", required = true) final String br_lon,
			@RequestParam(value = "locCode", required = true) final String locCode) throws DataNotFoundException {

		ResponseDto responseDto = new ResponseDto();

		CellSiteClusterRequestDto cellSiteClusterRequestDto = new CellSiteClusterRequestDto();

		cellSiteClusterRequestDto.setTimeStampFrom(timeStampFrm);
		cellSiteClusterRequestDto.setTimeStampTo(timeStampTo);
		cellSiteClusterRequestDto.setTlLat(tl_lat);
		cellSiteClusterRequestDto.setTlLon(tl_lon);
		cellSiteClusterRequestDto.setBrLat(br_lat);
		cellSiteClusterRequestDto.setBrLon(br_lon);
		cellSiteClusterRequestDto.setLocCode(locCode);

		CellSiteClusterResponseDto cellSiteManagerClusterResponseDto = cellSiteManager
				.getCellSiteClusterData(cellSiteClusterRequestDto);

		responseDto.setStatus(Constant.OK);
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setData(cellSiteManagerClusterResponseDto);

		return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
	}
}