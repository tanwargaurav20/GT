package com.harman.dmat.controller;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.harman.dmat.common.clientApi.WebMercator;
import com.harman.dmat.common.dto.*;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.dao.ClientAPIDao;
import com.harman.dmat.service.ClientAPIService;
import com.harman.dmat.utils.SecuirtyUtils;
import com.harman.dmat.utils.Utill;
import lombok.extern.slf4j.Slf4j;
import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.imageio.ImageIO;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import java.awt.image.BufferedImage;
import java.io.*;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.*;

/**
 * All the client api rest service starts here.
 */
@RestController
@RequestMapping(ControllerUrl.CLIENT_API_SERVICES)
@Slf4j
public class ClientAPIController {
	@Inject
	ClientAPIService clientAPIService;

	@Inject
	ClientAPIDao clientAPIDao;

	@Inject
	private transient Environment environment;

	private static final String ALGO = "AES";
	private byte[] IV = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

	/**
	 * Records crash report details from mobile client and sends the crash
	 * exception mail to the admins.
	 * 
	 * @param imei
	 * @param imsi
	 * @param appVersionName
	 * @param osVersion
	 * @param crashExceptionString
	 * @return
	 */
	@PostMapping(value = ControllerUrl.CRASHREPORT)
	public ResponseEntity<ResponseDto> createCrashReport(
			@RequestHeader(value = "imei", required = false) final String imei,
			@RequestHeader(value = "imsi", required = false) final String imsi,
			@RequestHeader(value = "appVersionName", required = false) final String appVersionName,
			@RequestHeader(value = "osVersion", required = false) final String osVersion,
			@RequestBody final String crashExceptionString) {
		log.debug("CrashReport imei as received:{} ", imei != null ? SecuirtyUtils.removeCFLRChar(imei) : imei);
		log.debug("CrashReport imsi as received:{} ", imsi != null ? SecuirtyUtils.removeCFLRChar(imsi) : imsi);
		log.debug("CrashReport appVersionName as received:{} ", appVersionName != null ? SecuirtyUtils.removeCFLRChar(appVersionName) : appVersionName);
		log.debug("CrashReport osVersion as received:{} ", osVersion != null ? SecuirtyUtils.removeCFLRChar(osVersion) : osVersion);
		log.debug("CrashReport request param:{} ", SecuirtyUtils.removeCFLRChar(crashExceptionString));

		ResponseDto responseDto = new ResponseDto();

		UserFiltersDto userFiltersDto = new UserFiltersDto();

		userFiltersDto.setImei(imei);
		userFiltersDto.setImsi(imsi);
		userFiltersDto.setVersion(appVersionName);
		userFiltersDto.setOsVersion(osVersion);

		responseDto = clientAPIService.createCrashReport(crashExceptionString, userFiltersDto);

		return getResponse(responseDto);
	}

	/**
	 * Updates/Gets the simpin data into/from table depends on the strMode in
	 * the request.
	 * 
	 * @param imei
	 * @param imsi
	 * @param appVersionName
	 * @param osVersion
	 * @param dmatLiveDataPoints
	 * @return
	 */
	@PostMapping(value = ControllerUrl.DMATLIVE_REQUEST)
	public ResponseEntity<ResponseDto> addDmatLiveDataPoints(
			@RequestHeader(value = "imei", required = true) final String imei,
			@RequestHeader(value = "imsi", required = true) final String imsi,
			@RequestHeader(value = "appVersionName", required = false) final String appVersionName,
			@RequestHeader(value = "osVersion", required = false) final String osVersion,
			@RequestBody final String dmatLiveDataPoints) {
		log.debug("DmatLive Data points imei as received: {}", SecuirtyUtils.removeCFLRChar(imei));
		log.debug("DmatLive Data points imsi as received: {}", SecuirtyUtils.removeCFLRChar(imsi));
		log.debug("DmatLive Data points appVersionName as received: {}", appVersionName != null ? SecuirtyUtils.removeCFLRChar(appVersionName) : appVersionName);
		log.debug("DmatLive Data points osVersion as received: {}", osVersion != null ? SecuirtyUtils.removeCFLRChar(osVersion) : osVersion);
		log.debug("DmatLive Data points input as received: {}", SecuirtyUtils.removeCFLRChar(dmatLiveDataPoints));
		ResponseDto responseDto = new ResponseDto();

		UserFiltersDto userFiltersDto = new UserFiltersDto();

		userFiltersDto.setImei(imei);
		userFiltersDto.setImsi(imsi);
		userFiltersDto.setVersion(appVersionName);
		userFiltersDto.setOsVersion(osVersion);

		List<DataPointsLiveDto> dataPointsList = new ArrayList<>();
		Gson gson = new Gson();

		JsonReader reader = new JsonReader(new StringReader(dmatLiveDataPoints.trim()));
		reader.setLenient(true);

		dataPointsList = gson.fromJson(reader, new TypeToken<List<DataPointsLiveDto>>() {
		}.getType());

		dataPointsList.forEach(x -> {
			x.setX_mercator((x.getLng() != null && x.getLng().trim() != "" && !x.getLng().trim().equals("-"))
					? WebMercator.longitudeToX(Double.parseDouble(x.getLng())) : 0.00);
			x.setY_mercator((x.getLat() != null && x.getLat().trim() != "" && !x.getLat().trim().equals("-"))
					? WebMercator.latitudeToY(Double.parseDouble(x.getLat())) : 0.00);
		});

		responseDto = clientAPIService.addDmatLiveDatapoints(dmatLiveDataPoints, dataPointsList, userFiltersDto);

		return getResponse(responseDto);
	}

	/**
	 * Get Filtered Data – to get the floor plan address list.
	 * 
	 * @param imei
	 * @param imsi
	 * @param state
	 * @param city
	 * @param zip
	 * @return address list
	 */
	@GetMapping(value = ControllerUrl.FILTEREDDATA, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getFilteredData(
			@RequestHeader(value = "imei", required = true) final String imei,
			@RequestHeader(value = "imsi", required = true) final String imsi,
			@RequestHeader(value = "appVersionName", required = false) final String appVersionName,
			@RequestHeader(value = "osVersion", required = false) final String osVersion,
			@RequestParam(value = "state", required = false) final String state,
			@RequestParam(value = "city", required = false) final String city,
			@RequestParam(value = "zip", required = false) final String zip) {
		log.debug("Filtered Data imei as received: {}", SecuirtyUtils.removeCFLRChar(imei));
		log.debug("Filtered Data imsi as received:{} ", SecuirtyUtils.removeCFLRChar(imsi));
		log.debug("Filtered Data appVersionName as received: {}", appVersionName != null ? SecuirtyUtils.removeCFLRChar(appVersionName) : appVersionName);
		log.debug("Filtered Data osVersion as received: {}", osVersion != null ? SecuirtyUtils.removeCFLRChar(osVersion) : osVersion);
		log.debug("Filtered Data state as received: {}", state != null ? SecuirtyUtils.removeCFLRChar(state) : state);
		log.debug("Filtered Data city as received:{} ", city != null ? SecuirtyUtils.removeCFLRChar(city) : city);
		log.debug("Filtered Data zip as received: {}", zip != null ? SecuirtyUtils.removeCFLRChar(zip) : zip);

		ResponseDto responseDto = new ResponseDto();
		InBuildingFiltersDto inBuildingFiltersDto = new InBuildingFiltersDto();
		UserFiltersDto userFiltersDto = new UserFiltersDto();

		userFiltersDto.setImei(imei);
		userFiltersDto.setImsi(imsi);
		userFiltersDto.setVersion(appVersionName);
		userFiltersDto.setOsVersion(osVersion);

		inBuildingFiltersDto.setUserFiltersDto(userFiltersDto);
		inBuildingFiltersDto.setState(state);
		inBuildingFiltersDto.setCity(city);
		inBuildingFiltersDto.setZip(zip);

		responseDto = clientAPIService.getFilteredData(inBuildingFiltersDto);

		return getResponse(responseDto);
	}

	/**
	 * Get Image – To retrieve image by sending image ID’s
	 * 
	 * @param imageId
	 * @param imei
	 * @param imsi
	 * @param appVersionName
	 * @param osVersion
	 * @return Image
	 */
	@ResponseBody
	@GetMapping(value = ControllerUrl.INBUILDING_IMAGE, produces = MediaType.IMAGE_JPEG_VALUE)
	public byte[] getInbuildingImage(@PathVariable("imageId") int imageId,
			@RequestHeader(value = "imei", required = true) final String imei,
			@RequestHeader(value = "imsi", required = true) final String imsi,
			@RequestHeader(value = "appVersionName", required = false) final String appVersionName,
			@RequestHeader(value = "osVersion", required = false) final String osVersion) {
		// We are not doing authentication for this API now since this requires
		// images to be wrapped in ResponseEntity
		// need to co-ordinate with Mukesh in Client team for this enhancement.
		log.debug("Image Data imei as received: {}", SecuirtyUtils.removeCFLRChar(imei));
		log.debug("Image Data imsi as received: {}", SecuirtyUtils.removeCFLRChar(imsi));
		log.debug("Image Data appVersionName as received: {} ", appVersionName != null ? SecuirtyUtils.removeCFLRChar(appVersionName) : appVersionName);
		log.debug("Image Data osVersion as received: {}", osVersion != null ? SecuirtyUtils.removeCFLRChar(osVersion) : osVersion);
		log.debug("Image Data imageId as received: {}", SecuirtyUtils.removeCFLRChar(imageId));

		return clientAPIService.getInbuildingImage(imageId);
	}

	/**
	 * Gets the inbuilding locations for the mobile client user.
	 * 
	 * @param imei
	 * @param imsi
	 * @param appVersionName
	 * @param osVersion
	 * @return Inbuilding locations in response.
	 */
	@GetMapping(value = ControllerUrl.INBUILDING_LOCATION, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getInbuildingLocations(
			@RequestHeader(value = "imei", required = true) final String imei,
			@RequestHeader(value = "imsi", required = true) final String imsi,
			@RequestHeader(value = "appVersionName", required = false) final String appVersionName,
			@RequestHeader(value = "osVersion", required = false) final String osVersion) {
		log.debug("Filtered Data imei as received:{} ", SecuirtyUtils.removeCFLRChar(imei));
		log.debug("Filtered Data imsi as received:{} ", SecuirtyUtils.removeCFLRChar(imsi));
		log.debug("Filtered Data appVersionName as received:{} ", appVersionName != null ? SecuirtyUtils.removeCFLRChar(appVersionName): appVersionName);
		log.debug("Filtered Data osVersion as received: {}", osVersion != null ? SecuirtyUtils.removeCFLRChar(osVersion) : osVersion);
		ResponseDto responseDto = new ResponseDto();

		UserFiltersDto userFiltersDto = new UserFiltersDto();
		userFiltersDto.setImei(imei);
		userFiltersDto.setImsi(imsi);
		userFiltersDto.setVersion(appVersionName);
		userFiltersDto.setOsVersion(osVersion);

		responseDto = clientAPIService.getInbuildingLocations(userFiltersDto);

		return getResponse(responseDto);
	}

	/**
	 * Gets the latest software version for the mobile client.
	 * 
	 * @param imei
	 * @param imsi
	 * @param appVersionName
	 * @param osVersion
	 * @param versionCode
	 * @param releaseType
	 * @param sdkLevel
	 * @param buildFlavor
	 * @param variant
	 * @param versionName
	 * @return Response with the latest software version details.
	 */
	@PostMapping(value = ControllerUrl.SOFTWARE_VERSION, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<ResponseDto> getSoftwareVersion(
			@RequestHeader(value = "imei", required = true) final String imei,
			@RequestHeader(value = "imsi", required = true) final String imsi,
			@RequestHeader(value = "appVersionName", required = false) final String appVersionName,
			@RequestHeader(value = "osVersion", required = false) final String osVersion,
			@RequestParam(value = "versionCode", required = true) final String versionCode,
			@RequestParam(value = "releaseType", required = true) final String releaseType,
			@RequestParam(value = "sdkLevel", required = true) final String sdkLevel,
			@RequestParam(value = "buildFlavor", required = true) final String buildFlavor,
			@RequestParam(value = "variant", required = true) final String variant,
			@RequestParam(value = "versionName", required = true) final String versionName) {
		log.debug("Software Data imei as received:{} ", SecuirtyUtils.removeCFLRChar(imei));
		log.debug("Software Data imsi as received:{} ", SecuirtyUtils.removeCFLRChar(imsi));
		log.debug("Software Data appVersionName as received: {}", appVersionName != null ? SecuirtyUtils.removeCFLRChar(appVersionName) : appVersionName);
		log.debug("Software Data osVersion as received: {}", osVersion != null ? SecuirtyUtils.removeCFLRChar(osVersion) : osVersion);
		log.debug("Software Data versioncode as received: {}", SecuirtyUtils.removeCFLRChar(versionCode));
		log.debug("Software Data releasetype as received: {}", SecuirtyUtils.removeCFLRChar(releaseType));
		log.debug("Software Data sdklevel as received: {}", SecuirtyUtils.removeCFLRChar(sdkLevel));
		log.debug("Software Data buildflavor as received: {}", SecuirtyUtils.removeCFLRChar(buildFlavor));
		log.debug("Software Data variant as received: {}", SecuirtyUtils.removeCFLRChar(variant));
		log.debug("Software Data versionName as received: {}", SecuirtyUtils.removeCFLRChar(versionName));

		SoftwareDto softwareDto = new SoftwareDto();
		softwareDto.setImei(imei);
		softwareDto.setImsi(imsi);
		softwareDto.setVersionCode(versionCode);
		softwareDto.setReleaseType(releaseType);
		softwareDto.setSdkLevel(sdkLevel);
		softwareDto.setBuildFlavor(buildFlavor);
		softwareDto.setVariant(variant);
		softwareDto.setVersionName(versionName);

		ResponseDto responseDto = new ResponseDto();

		UserFiltersDto userFiltersDto = new UserFiltersDto();
		userFiltersDto.setImei(imei);
		userFiltersDto.setImsi(imsi);
		userFiltersDto.setVersion(appVersionName);
		userFiltersDto.setOsVersion(osVersion);

		softwareDto.setUserFiltersDto(userFiltersDto);

		responseDto = clientAPIService.getSoftwareVersion(softwareDto);

		return getResponse(responseDto);
	}

	/**
	 * Gets apk for the mobile client.
	 * 
	 * @param version
	 * @param imei
	 * @param imsi
	 * @param appVersionName
	 * @param osVersion
	 * @return returns apk to the client
	 */
	@ResponseBody
	@GetMapping(value = ControllerUrl.APKDATA, produces = "application/apk")
	public byte[] getApkData(@PathVariable("version") String version,
			@RequestHeader(value = "imei", required = true) final String imei,
			@RequestHeader(value = "imsi", required = true) final String imsi,
			@RequestHeader(value = "appVersionName", required = false) final String appVersionName,
			@RequestHeader(value = "osVersion", required = false) final String osVersion) {
		// We are not doing authentication for this API now since this requires
		// apk to be wrapped in ResponseEntity
		// need to co-ordinate with Mukesh in Client team for this enhancement.
		log.debug("Image Data imei as received: {}", SecuirtyUtils.removeCFLRChar(imei));
		log.debug("Image Data imsi as received: {}", SecuirtyUtils.removeCFLRChar(imsi));
		log.debug("Image Data appVersionName as received: {}", appVersionName != null ? SecuirtyUtils.removeCFLRChar(appVersionName) : appVersionName);
		log.debug("Image Data osVersion as received: {} ", osVersion != null ? SecuirtyUtils.removeCFLRChar(osVersion) : osVersion);

		return clientAPIService.getApkData(version);
	}

	/**
	 * Adds device test summary details to postgres.
	 * 
	 * @param imei
	 * @param imsi
	 * @param appVersionName
	 * @param osVersion
	 * @param testResultsWrapper
	 * @return ResponseEntity with the success/failure status of adding
	 *         DeviceTestSummary.
	 */
	@PostMapping(value = ControllerUrl.DEVICE_TEST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> addDeviceTestSummary(
			@RequestHeader(value = "imei", required = true) final String imei,
			@RequestHeader(value = "imsi", required = true) final String imsi,
			@RequestHeader(value = "appVersionName", required = false) final String appVersionName,
			@RequestHeader(value = "osVersion", required = false) final String osVersion,
			@RequestBody final TestResultsWrapper testResultsWrapper) {
		log.debug("Device Data TestResults imei as received: " + SecuirtyUtils.removeCFLRChar(imei));
		log.debug("Device Data TestResults imsi as received: " + SecuirtyUtils.removeCFLRChar(imsi));
		log.debug("Device Data TestResults appVersionName as received: " + appVersionName != null ? SecuirtyUtils.removeCFLRChar(appVersionName) : appVersionName);
		log.debug("Device Data TestResults osVersion as received: " + osVersion != null ? SecuirtyUtils.removeCFLRChar(osVersion) : osVersion);

		ResponseDto responseDto = new ResponseDto();

		UserFiltersDto userFiltersDto = new UserFiltersDto();
		userFiltersDto.setImei(imei);
		userFiltersDto.setImsi(imsi);
		userFiltersDto.setVersion(appVersionName);
		userFiltersDto.setOsVersion(osVersion);

		responseDto = clientAPIService.addDeviceTestSummary(testResultsWrapper, userFiltersDto);

		return getResponse(responseDto);
	}

	/**
	 * Adds Inbuilding Images to the postgres table.
	 * 
	 * @param imei
	 * @param imsi
	 * @param appVersionName
	 * @param osVersion
	 * @param email
	 * @param access
	 * @param buildingName
	 * @param floorLevel
	 * @param buildingAddress
	 * @param city
	 * @param state
	 * @param zipCode
	 * @param image
	 * @return ResponseEntity with the success/failure status of adding
	 *         Inbuilding Images.
	 */
	@ResponseBody
	@PostMapping(value = ControllerUrl.ADD_IMAGE)
	public ResponseEntity<ResponseDto> addInbuildingImage(
			@RequestHeader(value = "imei", required = true) final String imei,
			@RequestHeader(value = "imsi", required = true) final String imsi,
			@RequestHeader(value = "appVersionName", required = false) final String appVersionName,
			@RequestHeader(value = "osVersion", required = false) final String osVersion,
			@RequestParam(value = "email", required = true) final String email,
			@RequestParam(value = "access", required = true) final String access,
			@RequestParam(value = "buildingName", required = true) final String buildingName,
			@RequestParam(value = "floorLevel", required = true) final String floorLevel,
			@RequestParam(value = "buildingAddress", required = true) final String buildingAddress,
			@RequestParam(value = "city", required = true) final String city,
			@RequestParam(value = "state", required = true) final String state,
			@RequestParam(value = "zipCode", required = true) final String zipCode,
			@RequestParam(value = "image", required = true) final MultipartFile image, @Context HttpServletRequest request) {
		log.debug("Inbuilding Image Data imei as received:{} ",  SecuirtyUtils.removeCFLRChar(imei));
		log.debug("Inbuilding Image Data imsi as received: " + SecuirtyUtils.removeCFLRChar(imsi));
		log.debug("Inbuilding Image Data appVersionName as received: " + appVersionName != null ? SecuirtyUtils.removeCFLRChar(appVersionName) : appVersionName);
		log.debug("Inbuilding Image Data osVersion as received: " + osVersion != null ? SecuirtyUtils.removeCFLRChar(osVersion) : osVersion);
		log.debug("Inbuilding Image Data email as received: " + SecuirtyUtils.removeCFLRChar(email));
		log.debug("Inbuilding Image Data access as received: " + SecuirtyUtils.removeCFLRChar(access));
		log.debug("Inbuilding Image Data buildingName as received: " + SecuirtyUtils.removeCFLRChar(buildingName));
		log.debug("Inbuilding Image Data floorLevel as received: " + SecuirtyUtils.removeCFLRChar(floorLevel));
		log.debug("Inbuilding Image Data buildingAddress as received: " + SecuirtyUtils.removeCFLRChar(buildingAddress));
		log.debug("Inbuilding Image Data city as received: " + SecuirtyUtils.removeCFLRChar(city));
		log.debug("Inbuilding Image Data state as received: " + SecuirtyUtils.removeCFLRChar(state));
		log.debug("Inbuilding Image Data zipCode as received: " + SecuirtyUtils.removeCFLRChar(zipCode));

		ResponseDto responseDto = new ResponseDto();

		try {
			InbuildingUploadImageDto imageDto = new InbuildingUploadImageDto();

			setCachedDirectory(request);
			BufferedImage bufferedImage = ImageIO.read(new ByteArrayInputStream(image.getBytes()));

			imageDto.setImageHeight(bufferedImage.getHeight());
			imageDto.setImageWidth(bufferedImage.getWidth());
			imageDto.setImei(imei);
			imageDto.setImsi(imsi);
			imageDto.setEmail(email);
			imageDto.setAccess(access);
			imageDto.setBuildingName(buildingName);
			imageDto.setFloorLevel(floorLevel);
			imageDto.setBuildingAddress(buildingAddress);
			imageDto.setCity(city);
			imageDto.setState(state);
			imageDto.setZipCode(zipCode);
			imageDto.setImage(image.getBytes());

			UserFiltersDto userFiltersDto = new UserFiltersDto();
			userFiltersDto.setImei(imei);
			userFiltersDto.setImsi(imsi);
			userFiltersDto.setVersion(appVersionName);
			userFiltersDto.setOsVersion(osVersion);

			responseDto = clientAPIService.addInbuildingImage(imageDto, userFiltersDto);
		} catch (IOException ex) {
			log.error("Exception in adding Inbuilding Image" + ex.getMessage());
			responseDto.setErrorCode(1);
			responseDto.setMessage("Error in adding Inbuilding Image");
			responseDto.setDeveloperMessage("Error in Inbuilding Image");
		}

		return getResponse(responseDto);
	}

	private void setCachedDirectory(HttpServletRequest request) {
		File tempDirectory = new File(request.getSession().getServletContext().getRealPath("temp"));
		if (!tempDirectory.exists()) {
			tempDirectory.mkdir();
		}
		ImageIO.setCacheDirectory(tempDirectory);
	}

	/**
	 * Adds wifi cluster data to Elastic Search.
	 * 
	 * @param imei
	 * @param imsi
	 * @param appVersionName
	 * @param osVersion
	 * @param wifiData
	 * @return ResponseEntity with the success/failure status of adding
	 *         wifidata.
	 */
	@ResponseBody
	@PostMapping(value = ControllerUrl.WIFI_DATA, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> addWifiData(@RequestHeader(value = "imei", required = true) final String imei,
			@RequestHeader(value = "imsi", required = true) final String imsi,
			@RequestHeader(value = "appVersionName", required = false) final String appVersionName,
			@RequestHeader(value = "osVersion", required = false) final String osVersion,
			@RequestBody final WifiDataDto wifiData) {
		log.debug("Wifi Data imei as received: {}", SecuirtyUtils.removeCFLRChar(imei));
		log.debug("Wifi Data imsi as received: {}", SecuirtyUtils.removeCFLRChar(imsi));
		log.debug("Wifi Data appVersionName as received: {}", appVersionName != null ? SecuirtyUtils.removeCFLRChar(appVersionName) : appVersionName);
		log.debug("Wifi Data osVersion as received: {} ", osVersion != null ? SecuirtyUtils.removeCFLRChar(osVersion) : osVersion);
		ResponseDto responseDto = new ResponseDto();

		UserFiltersDto userFiltersDto = new UserFiltersDto();
		userFiltersDto.setImei(imei);
		userFiltersDto.setImsi(imsi);
		userFiltersDto.setVersion(appVersionName);
		userFiltersDto.setOsVersion(osVersion);

		WifiDataLocDto wifiDataLocDto = new WifiDataLocDto();

		Double loc_mx = (wifiData.getLongitude() != 0.00) ? WebMercator.longitudeToX(wifiData.getLongitude()) : 0.00;
		Double loc_my = (wifiData.getLatitude() != 0.00) ? WebMercator.latitudeToY(wifiData.getLatitude()) : 0.00;

		wifiDataLocDto.setLoc_mx(loc_mx);
		wifiDataLocDto.setLoc_my(loc_my);

		wifiDataLocDto.setLoc_2(Utill.getMxMyToRowCol(2, loc_mx, loc_my));
		wifiDataLocDto.setLoc_5(Utill.getMxMyToRowCol(5, loc_mx, loc_my));
		wifiDataLocDto.setLoc_10(Utill.getMxMyToRowCol(10, loc_mx, loc_my));
		wifiDataLocDto.setLoc_25(Utill.getMxMyToRowCol(25, loc_mx, loc_my));
		wifiDataLocDto.setLoc_50(Utill.getMxMyToRowCol(50, loc_mx, loc_my));
		wifiDataLocDto.setLoc_100(Utill.getMxMyToRowCol(100, loc_mx, loc_my));
		wifiDataLocDto.setLoc_200(Utill.getMxMyToRowCol(200, loc_mx, loc_my));
		wifiDataLocDto.setLoc_500(Utill.getMxMyToRowCol(500, loc_mx, loc_my));
		wifiDataLocDto.setLoc_1000(Utill.getMxMyToRowCol(1000, loc_mx, loc_my));
		wifiDataLocDto.setLoc_2000(Utill.getMxMyToRowCol(2000, loc_mx, loc_my));
		wifiDataLocDto.setLoc_4000(Utill.getMxMyToRowCol(4000, loc_mx, loc_my));
		wifiDataLocDto.setLoc_5000(Utill.getMxMyToRowCol(5000, loc_mx, loc_my));
		wifiDataLocDto.setLoc_10000(Utill.getMxMyToRowCol(10000, loc_mx, loc_my));
		wifiDataLocDto.setLoc_15000(Utill.getMxMyToRowCol(15000, loc_mx, loc_my));
		wifiDataLocDto.setLoc_25000(Utill.getMxMyToRowCol(25000, loc_mx, loc_my));
		wifiDataLocDto.setLoc_50000(Utill.getMxMyToRowCol(50000, loc_mx, loc_my));
		wifiDataLocDto.setLoc_75000(Utill.getMxMyToRowCol(75000, loc_mx, loc_my));
		wifiDataLocDto.setLoc_100000(Utill.getMxMyToRowCol(100000, loc_mx, loc_my));

		responseDto = clientAPIService.addWifiData(wifiData, userFiltersDto, wifiDataLocDto);

		return getResponse(responseDto);
	}

	/**
	 * Updates/Gets the simpin data into/from table depends on the strMode in
	 * the request.
	 *
	 * @param imei
	 * @param imsi
	 * @param pin
	 * @param mode
	 * @param iccid
	 * @return ResponseEntity with the simpin information for get pin.
	 */
	@PostMapping(value = ControllerUrl.SIMPIN_REQUEST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<ResponseDto> updateOrGetPin(@RequestHeader(value = "imei", required = true) final String imei,
			@RequestHeader(value = "imsi", required = true) final String imsi,
			@RequestHeader(value = "appVersionName", required = false) final String appVersionName,
			@RequestHeader(value = "osVersion", required = false) final String osVersion,
			@RequestParam(value = "pin", required = true) final String pin,
			@RequestParam(value = "mode", required = true) final String mode,
			@RequestParam(value = "iccid", required = true) final String iccid) {
		byte[] cryptkeybyte = Base64.getDecoder().decode(environment.getProperty("cryptkeybyte"));
		String encryptedICCID = "";
		log.debug("Sim pin Imei as recieved:{} ", SecuirtyUtils.removeCFLRChar(imei));
		log.debug("Sim pin Imsi as recieved:{} ", SecuirtyUtils.removeCFLRChar(imsi));
		log.debug("Sim pin appVersionName as received:{} ", appVersionName != null ? SecuirtyUtils.removeCFLRChar(appVersionName) : appVersionName);
		log.debug("Sim pin osVersion as received:{} ", osVersion != null ? SecuirtyUtils.removeCFLRChar(osVersion) : osVersion);
		log.debug("Sim pin Mode as recieved:{} ", SecuirtyUtils.removeCFLRChar(mode));
		log.debug("Sim pin Pin as recieved: {}", SecuirtyUtils.removeCFLRChar(pin));
		log.debug("Sim pin Iccid as recieved: " + SecuirtyUtils.removeCFLRChar(iccid));

		SimPinDto simPinDto = new SimPinDto();
		simPinDto.setImei(imei);
		simPinDto.setImsi(imsi);
		simPinDto.setPin(pin);
		simPinDto.setMode(mode);
		simPinDto.setIccid(iccid);

		UserFiltersDto userFiltersDto = new UserFiltersDto();
		userFiltersDto.setImei(imei);
		userFiltersDto.setImsi(imsi);
		userFiltersDto.setVersion(appVersionName);
		userFiltersDto.setOsVersion(osVersion);

		ResponseDto responseDto = new ResponseDto();
		try {
			if (simPinDto.getIccid() != null && simPinDto.getIccid().trim() != "") {
				encryptedICCID = encrypt(simPinDto.getIccid(), cryptkeybyte);
			}

			if (simPinDto.getMode().equalsIgnoreCase("new")) {
				responseDto = clientAPIService.updatePin(encryptedICCID, simPinDto.getPin(), userFiltersDto);
			} else {
				responseDto = clientAPIService.getPin(encryptedICCID, userFiltersDto);
			}
		} catch (UnsupportedEncodingException ex) {
			log.error("Exception in encryption " + ex);
			responseDto.setErrorCode(1);
			responseDto.setMessage("Exception in encryption");
			responseDto.setDeveloperMessage("Exception in encryption");
		} catch (Exception ex) {
			log.error("Exception in encryption or getting data from db." + ex);
			responseDto.setErrorCode(1);
			responseDto.setMessage("Exception in encryption or getting data from db.");
			responseDto.setDeveloperMessage("Exception in encryption or getting data from db.");
		}

		return getResponse(responseDto);
	}

	/**
	 * Sends email to the client based upon the request.
	 * @param imei
	 * @param imsi
	 * @param appVersionName
	 * @param osVersion
	 * @param eventsSummaryRequest
	 * @return
	 */
	@PostMapping(value = ControllerUrl.EVENTSSUMMARY_EMAIL)
	public ResponseEntity<ResponseDto> sendEventsSummaryId(@RequestHeader(value = "imei", required = true) final String imei,
														   @RequestHeader(value = "imsi", required = true) final String imsi,
														   @RequestHeader(value = "appVersionName", required = false) final String appVersionName,
														   @RequestHeader(value = "osVersion", required = false) final String osVersion,
														   @RequestBody final String eventsSummaryRequest) throws IOException {
		ResponseDto responseDto = new ResponseDto();

		if (log.isDebugEnabled()) {
			log.debug("EventSummary imei as received: {}", SecuirtyUtils.removeCFLRChar(imei));
			log.debug("EventSummary imsi as received: {}", SecuirtyUtils.removeCFLRChar(imsi));
			log.debug("EventSummary appVersionName as received: {}", appVersionName != null ? SecuirtyUtils.removeCFLRChar(appVersionName) : appVersionName);
			log.debug("EventSummary osVersion as received: {} ", osVersion != null ? SecuirtyUtils.removeCFLRChar(osVersion) : osVersion);
			log.debug("EventSummary Request as received: {}", SecuirtyUtils.removeCFLRChar(imei));
			log.debug(SecuirtyUtils.removeCFLRChar("EventSummary Request as received: {}: " + eventsSummaryRequest));
		}

		EventsSummaryRequestDto eventsSummaryRequestDto = new EventsSummaryRequestDto();
		EventSummaryDto eventSummaryDto = new EventSummaryDto();
		List<EventsDto> events = new ArrayList<>();

		JsonFactory factory = new JsonFactory();
		ObjectMapper mapper = new ObjectMapper(factory);
		JsonNode rootNode = mapper.readTree(eventsSummaryRequest);

		Iterator<Map.Entry<String,JsonNode>> fieldsIterator = rootNode.getFields();
		while (fieldsIterator.hasNext()) {
			Map.Entry<String,JsonNode> field = fieldsIterator.next();

			if(field.getKey().equalsIgnoreCase("recipientEmail")) {
				List<String> dataResult = mapper.convertValue(field.getValue(), List.class);
				eventsSummaryRequestDto.setRecipientEmail(dataResult);
			}

			if(field.getKey().equalsIgnoreCase("eventSummary")) {
				eventSummaryDto.setEventStartDate(field.getValue().get("eventStartDate").toString());

				Map<String, String> evtOccurrence = mapper.convertValue(field.getValue().get("eventOccurrence"), Map.class);
				eventSummaryDto.setEventOccurrence(evtOccurrence);

				if (field.getValue().get("events").isArray()) {
					for (final JsonNode objNode : field.getValue().get("events")) {
						EventsDto eventsDto = new EventsDto();
						DataDto dataDto = new DataDto();
						eventsDto.setName(objNode.get("name").toString());
						eventsDto.setTime(objNode.get("time").toString());

						Map<String, String> dataResult = mapper.convertValue(objNode.get("data"), Map.class);

						dataDto.setEventCause(dataResult);
						eventsDto.setData(dataDto);

						events.add(eventsDto);
					}
				}
				eventSummaryDto.setEvents(events);
			}
			eventsSummaryRequestDto.setEventSummary(eventSummaryDto);
		}

		responseDto = clientAPIService.sendEventsSummaryEmail(eventsSummaryRequestDto);

		return getResponse(responseDto);
	}

	/**
	 * Encrypts the given the string with the cryptkey.
	 * 
	 * @param encryptedStr
	 * @param cryptKey
	 * @return EncryptedString
	 * @throws UnsupportedEncodingException
	 */
	public String encrypt(String encryptedStr, byte[] cryptKey) throws UnsupportedEncodingException {
		String encryptedText = "";
		byte[] plainTextByte = encryptedStr.getBytes("UTF-8");
		try {
			Cipher c = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			cryptKey = Arrays.copyOf(cryptKey, 16);
			Key SecretKey = new SecretKeySpec(cryptKey, ALGO);
			IvParameterSpec ivspec = new IvParameterSpec(IV);
			c.init(Cipher.ENCRYPT_MODE, SecretKey, ivspec);
			byte[] encrypted = c.doFinal(plainTextByte);

			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			outputStream.write(encrypted);
			outputStream.flush();
			encryptedText = Base64.getEncoder().encodeToString(outputStream.toByteArray());

		} catch (Exception e) {
			e.printStackTrace();
		}
		return encryptedText;
	}

	/**
	 * Decrypts the string with the cryptkey.
	 * 
	 * @param encryptedText
	 * @param cryptkeybyte
	 * @return DecryptedString
	 * @throws NoSuchPaddingException
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidAlgorithmParameterException
	 * @throws InvalidKeyException
	 * @throws BadPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws UnsupportedEncodingException
	 */
	public String decrypt(String encryptedText, byte[] cryptkeybyte)
			throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException,
			InvalidKeyException, BadPaddingException, IllegalBlockSizeException, UnsupportedEncodingException {

		byte[] cryptKey = java.util.Base64.getDecoder().decode(cryptkeybyte);
		cryptKey = Arrays.copyOf(cryptKey, 16);
		Key secretKey = new SecretKeySpec(cryptKey, ALGO);

		IvParameterSpec ivspec = new IvParameterSpec(IV);
		byte[] encryptedTextByte = java.util.Base64.getDecoder().decode(encryptedText);
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
		cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
		byte[] decryptedByte = cipher.doFinal(encryptedTextByte);
		String decryptedText = new String(decryptedByte);

		return decryptedText;
	}

	private ResponseEntity<ResponseDto> getResponse(ResponseDto responseDto) {
		if (responseDto.getStatusCode() != null && responseDto.getStatusCode().equals(0)) {
			return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
		} else {
			return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.NOT_FOUND);
		}
	}

}
