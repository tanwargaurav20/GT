package com.harman.dmat.controller;

import java.io.IOException;
import java.util.List;

import javax.inject.Inject;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.harman.dmat.common.dto.ApkDetailsDto;
import com.harman.dmat.common.dto.FilePostProcessResponseDto;
import com.harman.dmat.common.dto.FilePreProcessResponseDto;
import com.harman.dmat.common.dto.FileProcessDirComparisonResponseDto;
import com.harman.dmat.common.dto.FileProcessStatusResponseDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.common.dto.UserCountDto;
import com.harman.dmat.common.dto.UserDto;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.manager.DashboardManager;
import com.harman.dmat.utils.FileProcessingUtil;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(ControllerUrl.DASHBOARD_ROOT)
@Slf4j
public class DashboardController {

	@Inject
	DashboardManager dashboardManager;

	/**
	 * This method returns no. of users (active, inactive, deactive)in the
	 * application.
	 *
	 * @return
	 */
	@ResponseBody
	@GetMapping(value = ControllerUrl.DASHBOARD_USERS_COUNT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getUserCount() {
		UserCountDto userCountDto = dashboardManager.getUserCount();
		ResponseDto responseDto = new ResponseDto();
		responseDto.setStatus(Constant.OK);
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setData(userCountDto);
		return new ResponseEntity<>(responseDto, HttpStatus.OK);
	}

	/**
	 * This method returns user details of different users (active, inactive,
	 * deactive)in the application.
	 *
	 * @param userType,
	 *            (active, inactive, deactive)
	 * @param offset,
	 *            starting index
	 * @param limit,
	 *            no. of user need to display
	 * @return
	 */
	@ResponseBody
	@GetMapping(value = ControllerUrl.USER_LIST, produces = MediaType.APPLICATION_JSON_VALUE)

	public ResponseEntity<ResponseDto> getUserList(@RequestParam(value = "userType") final String userType,
			@RequestParam(value = "offset") final int offset, @RequestParam(value = "limit") final int limit) {
		log.debug("getUserList input params:- {}", "userType:" + userType + " offset:" + offset + ", limit:" + limit);

		List<UserDto> userDtoList = dashboardManager.getUserList(userType, offset, limit);
		ResponseDto responseDto = new ResponseDto();
		responseDto.setStatus(Constant.OK);
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setData(userDtoList);

		return new ResponseEntity<>(responseDto, HttpStatus.OK);
	}

	/**
	 * @param offset,
	 *            starting index
	 * @return
	 */
	@ResponseBody
	@GetMapping(value = ControllerUrl.APK_VERSION, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getApkVersionDetails(@RequestParam(value = "offset") final int offset,
			@RequestParam(value = "limit") final int limit) {
		log.debug("getApkVersionDetails input params:- {}", "offset:" + offset + ", limit:" + limit);

		ApkDetailsDto apkDetailsDto = dashboardManager.getApkVersionDetails(offset, limit);
		ResponseDto responseDto = new ResponseDto();
		responseDto.setStatus(Constant.OK);
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setData(apkDetailsDto);

		return new ResponseEntity<>(responseDto, HttpStatus.OK);
	}

	@ResponseBody
	@GetMapping(value = ControllerUrl.DASHBOARD_FILE_PROCESS_REPORT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getFileProcessStatusReport(
			@RequestParam(value = "startDate") final String startDate,
			@RequestParam(value = "endDate") final String endDate, @RequestParam(value = "offset") final Integer offset,
			@RequestParam(value = "limit") final Integer limit) {
		FileProcessStatusResponseDto fileProcessedList = dashboardManager.getFileProcessStatusReport(startDate, endDate,
				offset, limit);

		final ResponseDto info = new ResponseDto();
		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(fileProcessedList);
		return new ResponseEntity<>(info, HttpStatus.OK);
	}

	@ResponseBody
	@GetMapping(value = ControllerUrl.DASHBOARD_PRE_PROCESS_REPORT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getFilePreProcessReport(
			@RequestParam(value = "startDate") final String startDate,
			@RequestParam(value = "endDate") final String endDate, @RequestParam(value = "offset") final Integer offset,
			@RequestParam(value = "limit") final Integer limit) {
		FilePreProcessResponseDto fileProcessedList = dashboardManager.getFilePreProcessList(startDate, endDate, offset,
				limit);

		final ResponseDto info = new ResponseDto();
		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(fileProcessedList);
		return new ResponseEntity<>(info, HttpStatus.OK);
	}

	@ResponseBody
	@GetMapping(value = ControllerUrl.DASHBOARD_POST_PROCESS_REPORT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getFilePostProcessReport(
			@RequestParam(value = "startDate") final String startDate,
			@RequestParam(value = "endDate") final String endDate, @RequestParam(value = "offset") final Integer offset,
			@RequestParam(value = "limit") final Integer limit) {
		FilePostProcessResponseDto fileProcessedList = dashboardManager.getFilePostProcessList(startDate, endDate,
				offset, limit);

		final ResponseDto info = new ResponseDto();
		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(fileProcessedList);
		return new ResponseEntity<>(info, HttpStatus.OK);
	}

	@ResponseBody
	@GetMapping(value = ControllerUrl.DASHBOARD_DIR_COMPARISON_REPORT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getPhysicalDirComparisonReport(
			@RequestParam(value = "startDate") final String startDate,
			@RequestParam(value = "endDate") final String endDate, @RequestParam(value = "offset") final Integer offset,
			@RequestParam(value = "limit") final Integer limit) {
		FileProcessDirComparisonResponseDto fileProcessedList = dashboardManager
				.getPhysicalDirComparisonReport(startDate, endDate, offset, limit);

		final ResponseDto info = new ResponseDto();
		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(fileProcessedList);
		return new ResponseEntity<>(info, HttpStatus.OK);
	}

	@GetMapping(value = ControllerUrl.DOWNLOAD_DASHBOARD_FILE_PROCESS_REPORT)
	public ResponseEntity<Resource> fileProcessReportDownloadToExcel(
			@RequestParam(value = "startDate") final String startDate,
			@RequestParam(value = "endDate") final String endDate,
			@RequestParam(value = "fileName") final String fileName,
			@RequestParam(value = "userId") final String userId) throws DataNotFoundException, IOException {
		FileProcessStatusResponseDto fileProcessedList = dashboardManager.getFileProcessStatusReport(startDate, endDate,
				1, 60);

		FileProcessingUtil fileProcessingUtil = new FileProcessingUtil();
		String fullFileLocation = fileProcessingUtil.createReportFile(fileName, userId);
		HSSFWorkbook workbook = fileProcessingUtil
				.buildFileProcessingExcel(fileProcessedList.getFileProcessStatusDtoList());
		return fileProcessingUtil.downloadExcelSheet(fullFileLocation, workbook);
	}

	@GetMapping(value = ControllerUrl.DOWNLOAD_DASHBOARD_PRE_PROCESS_REPORT)
	public ResponseEntity<Resource> filePreProcessReportDownloadToExcel(
			@RequestParam(value = "startDate") final String startDate,
			@RequestParam(value = "endDate") final String endDate,
			@RequestParam(value = "fileName") final String fileName,
			@RequestParam(value = "userId") final String userId) throws DataNotFoundException, IOException {
		FilePreProcessResponseDto fileProcessedList = dashboardManager.getFilePreProcessList(startDate, endDate, 1, 60);

		FileProcessingUtil fileProcessingUtil = new FileProcessingUtil();
		String fullFileLocation = fileProcessingUtil.createReportFile(fileName, userId);
		HSSFWorkbook workbook = fileProcessingUtil
				.buildPreProcessingExcel(fileProcessedList.getFilePreProcessDtoList());
		return fileProcessingUtil.downloadExcelSheet(fullFileLocation, workbook);
	}

	@GetMapping(value = ControllerUrl.DOWNLOAD_DASHBOARD_POST_PROCESS_REPORT)
	public ResponseEntity<Resource> filePostProcessReportDownloadToExcel(
			@RequestParam(value = "startDate") final String startDate,
			@RequestParam(value = "endDate") final String endDate,
			@RequestParam(value = "fileName") final String fileName,
			@RequestParam(value = "userId") final String userId) throws DataNotFoundException, IOException {
		FilePostProcessResponseDto fileProcessedList = dashboardManager.getFilePostProcessList(startDate, endDate, 1,
				60);

		FileProcessingUtil fileProcessingUtil = new FileProcessingUtil();
		String fullFileLocation = fileProcessingUtil.createReportFile(fileName, userId);
		HSSFWorkbook workbook = fileProcessingUtil.buildPostProcessExcel(fileProcessedList.getFilePostProcessDtoList());
		return fileProcessingUtil.downloadExcelSheet(fullFileLocation, workbook);
	}

	@GetMapping(value = ControllerUrl.DOWNLOAD_DASHBOARD_DIR_COMPARISON_REPORT)
	public ResponseEntity<Resource> dirComparisonReportDownloadToExcel(
			@RequestParam(value = "startDate") final String startDate,
			@RequestParam(value = "endDate") final String endDate,
			@RequestParam(value = "fileName") final String fileName,
			@RequestParam(value = "userId") final String userId) throws DataNotFoundException, IOException {
		FileProcessDirComparisonResponseDto fileProcessedList = dashboardManager
				.getPhysicalDirComparisonReport(startDate, endDate, 1, 60);

		FileProcessingUtil fileProcessingUtil = new FileProcessingUtil();
		String fullFileLocation = fileProcessingUtil.createReportFile(fileName, userId);
		HSSFWorkbook workbook = fileProcessingUtil
				.buildPhysicalDirectoryExcel(fileProcessedList.getFileProcessDirComparisonDtoList());
		return fileProcessingUtil.downloadExcelSheet(fullFileLocation, workbook);
	}
}