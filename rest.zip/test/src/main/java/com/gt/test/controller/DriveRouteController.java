package com.harman.dmat.controller;

import java.util.List;
import javax.inject.Inject;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.manager.DriveRouteManager;
import com.harman.dmat.utils.SecuirtyUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * @author GTanwar Info Points Controller contains REST services to get the info
 *         points on the map
 */
@RestController
@RequestMapping(ControllerUrl.DRIVEROUTE_ROOTPATH)
@Slf4j
public class DriveRouteController {

	@Inject
	DriveRouteManager driveRouteManager;

	/**
	 * Fetches the Lat Lng from file names
	 * 
	 * @param lat
	 * @param lon
	 * @param dm_user
	 * @param fileName
	 * @return
	 * @throws DataNotFoundException
	 */
	@GetMapping(value = ControllerUrl.ROUTE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getLatLng(@RequestParam(value = "fileNames", required = true) final String fileName,
			@RequestParam(value = "startDate", required = true) final String startDate,
			@RequestParam(value = "endDate", required = true) final String endDate) throws DataNotFoundException {

		if (log.isDebugEnabled()) {
			log.debug("getLatLng() request params: " + " testIds= " + SecuirtyUtils.removeCFLRChar(fileName)
					+ "startDate::endDate" + SecuirtyUtils.removeCFLRChar(startDate) + "::"
					+ SecuirtyUtils.removeCFLRChar(endDate));
		}
		final ResponseDto info = new ResponseDto();
		List<String> list = driveRouteManager.getLatLng(fileName, startDate, endDate);

		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(list);

		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

}
