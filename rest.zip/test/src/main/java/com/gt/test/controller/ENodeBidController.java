package com.harman.dmat.controller;

import com.harman.dmat.common.dto.ENodeBidRequestDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.service.ENodeBidService;
import com.harman.dmat.utils.SecuirtyUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;
import java.util.List;

/**
 * Controller related to eNBID api's.
 */
@RestController
@RequestMapping(ControllerUrl.ENBID)
@Slf4j
public class ENodeBidController {
    @Inject
    ENodeBidService eNodeBidService;

    @GetMapping(ControllerUrl.RETRIEVE_ENBID)
    public ResponseEntity<ResponseDto> getEnodeBIDs(@RequestParam(value = "fromDate", required = true) String fromDate,
                                                    @RequestParam(value = "toDate", required = true) String toDate,
                                                    @RequestParam(value = "tlLat", required = true) String tlLat,
                                                    @RequestParam(value = "tlLon", required = true) String tlLon,
                                                    @RequestParam(value = "brLat", required = true) String brLat,
                                                    @RequestParam(value = "brLon", required = true) String brLon,
                                                    @RequestParam(value = "userId", required = true) String userId,
                                                    @RequestParam(value = "domain", required = true) String domain){
        ResponseDto responseDto = new ResponseDto();
        if (log.isDebugEnabled()) {
            log.debug(SecuirtyUtils.removeCFLRChar ("getEnodeBIDs() request params: " + " fromDate= " + fromDate +
                    ", toDate= " + toDate +
                    ", tlLat= "+ tlLat + ", tlLon= "+ tlLon + ", brLat= "+ brLat + ", brLon= "+ brLon+ ", userId= "+ userId+ ", domain= "+ domain));
        }
        ENodeBidRequestDto requestDto = new ENodeBidRequestDto();
        requestDto.setFromDate(fromDate);
        requestDto.setToDate(toDate);
        requestDto.setTlLat(tlLat);
        requestDto.setTlLon(tlLon);
        requestDto.setBrLat(brLat);
        requestDto.setBrLon(brLon);
        requestDto.setUserId(userId);
        requestDto.setDomain(domain);

        List<String> eNBIDs = eNodeBidService.getENodeBids(requestDto);
        responseDto.setStatus(Constant.OK);
        responseDto.setMessage(Constant.SUCCESS);
        responseDto.setData(eNBIDs);

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

}
