package com.harman.dmat.controller;

import java.util.List;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.harman.dmat.common.dto.GlobalFilterDto;
import com.harman.dmat.common.dto.GlobalFilterRequestDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.common.dto.UserLogFileDto;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.GlobalFilterException;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.manager.GlobalFilterManager;
import com.harman.dmat.utils.SecuirtyUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class GlobalFilterController.
 *
 * @author prakash.bisht@harman.com
 */
@RestController
@RequestMapping(ControllerUrl.FILTERS)

/** The Constant log. */
@Slf4j
public class GlobalFilterController {

	/** The global filter manager. */
	@Inject
	private GlobalFilterManager globalFilterManager;

	/**
	 * Get the model on the basis of user Id.
	 *
	 * @param user the user
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param mdn the mdn
	 * @param model the model
	 * @param fileName the file name
	 * @param imei the imei
	 * @return the filter data
	 * @throws DataNotFoundException the data not found exception
	 *//*
	@GetMapping(ControllerUrl.USER_MODELS)
	public ResponseDto getModelData(@PathVariable("userId") final Integer userId)
			throws DataNotFoundException, DataAccessException {
		final List<ModelDto> models = globalFilterManager.getModelData(userId);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.USER_MODELS);
		responseDto.setStatus(Constant.OK);

		responseDto.setData(models);
		return responseDto;
	}

	*//**
	 * Get all the models
	 * 
	 * @param offset
	 * @param limit
	 * @return
	 * @throws DataAccessException
	 *//*
	@GetMapping(ControllerUrl.MODELS)
	public ResponseDto getModelData(@RequestParam(value = "offset", required = true) final Integer offset,
			@RequestParam(value = "limit", required = true) final Integer limit) throws DataAccessException {
		final List<ModelDto> models = globalFilterManager.getallModels(offset, limit);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.MODELS);
		responseDto.setStatus(Constant.OK);

		responseDto.setData(models);
		return responseDto;
	}

	*//**
	 * Get the imei on the basis of user Id
	 * 
	 * @param userId
	 * @return
	 * @throws DataNotFoundException
	 * @throws DataAccessException
	 *//*
	@GetMapping(ControllerUrl.USER_IMEI)
	public ResponseDto getImeiData(@PathVariable("userId") final Integer userId)
			throws DataNotFoundException, DataAccessException {
		final List<ImeiDto> imeis = globalFilterManager.getImeiData(userId);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.USER_IMEIS);
		responseDto.setStatus(Constant.OK);

		responseDto.setData(imeis);
		return responseDto;
	}

	*//**
	 * Get all the imei
	 * 
	 * @param offset
	 * @param limit
	 * @return
	 * @throws DataAccessException
	 *//*
	@GetMapping(ControllerUrl.IMEI)
	public ResponseDto getAllImeiData(@RequestParam(value = "offset", required = true) final Integer offset,
			@RequestParam(value = "limit", required = true) final Integer limit) throws DataAccessException {
		final List<ImeiDto> imeis = globalFilterManager.getAllImeiData(offset, limit);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.IMEIS);
		responseDto.setStatus(Constant.OK);

		responseDto.setData(imeis);
		return responseDto;
	}

	*//**
	 * Get the mdn on the basis of user Id
	 * 
	 * @param userId
	 * @return
	 * @throws DataNotFoundException
	 * @throws DataAccessException
	 *//*
	@GetMapping(ControllerUrl.USER_MDN)
	public ResponseDto getUserMdnData(@PathVariable("userId") final Integer userId)
			throws DataNotFoundException, DataAccessException {
		final List<ImeiDto> mdns = globalFilterManager.getUserMdnData(userId);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.USER_MDNS);
		responseDto.setStatus(Constant.OK);

		responseDto.setData(mdns);
		return responseDto;
	}

	*//**
	 * Get all the mdn
	 * 
	 * @param offset
	 * @param limit
	 * @return
	 * @throws DataAccessException
	 *//*
	@GetMapping(ControllerUrl.MDN)
	public ResponseDto getAllMdnData(@RequestParam(value = "offset", required = true) final Integer offset,
			@RequestParam(value = "limit", required = true) final Integer limit) throws DataAccessException {
		final List<ImeiDto> mdns = globalFilterManager.getAllMdnData(offset, limit);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.MDNS);
		responseDto.setStatus(Constant.OK);

		responseDto.setData(mdns);
		return responseDto;
	}
*/
/*	*//**
	 * Get the logs on the basis of user Id
	 * 
	 * @param userId
	 * @param offset
	 * @param limit
	 * @return
	 * @throws DataNotFoundException
	 * @throws DataAccessException
	 *//*
	@GetMapping(ControllerUrl.USER_LOGS)
	public ResponseDto getUserLogData(@PathVariable("userId") final Integer userId,
			@RequestParam(value = "offset", required = true) final Integer offset,
			@RequestParam(value = "limit", required = true) final Integer limit)
			throws DataNotFoundException, DataAccessException {
		final List<LogMgrDto> userLog = globalFilterManager.getUserLogData(userId, offset, limit);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.USER_LOGS);
		responseDto.setStatus(Constant.OK);

		responseDto.setData(userLog);
		return responseDto;
	}

	*//**
	 * Get all the logs
	 * 
	 * @param offset
	 * @param limit
	 * @return
	 * @throws DataAccessException
	 *//*
	@GetMapping(ControllerUrl.LOGS)
	public ResponseDto getAllLogData(@RequestParam(value = "offset", required = true) final Integer offset,
			@RequestParam(value = "limit", required = true) final Integer limit) throws DataAccessException {
		final List<LogMgrDto> logs = globalFilterManager.getAllLogData(offset, limit);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.LOGS);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(logs);
		return responseDto;
	}

	*//**
	 * 
	 * Get the user state
	 * 
	 * @param userId
	 * @return
	 * @throws DataNotFoundException
	 * @throws DataAccessException
	 *//*
	@GetMapping(ControllerUrl.USER_FILTTER_STATES)
	public ResponseDto getUserStateData(@PathVariable("userId") final Integer userId)
			throws DataNotFoundException, DataAccessException {
		final List<StateDto> userLog = globalFilterManager.getUserStateData(userId);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.USER_STATE_DATA);
		responseDto.setStatus(Constant.OK);

		responseDto.setData(userLog);
		return responseDto;
	}
*/
	/**
	 * Get the global Filter data on the basis of data and other param
	 * 
	 * @param user
	 * @param calFilterType
	 * @param date
	 * @param offset
	 * @param limit
	 * @param mdn
	 * @param model
	 * @param fileName
	 * @param imei
	 * @param status
	 * @return
	 * @throws DataNotFoundException
	 * @throws GlobalFilterException 
	 */
	@GetMapping(value = ControllerUrl.GLOBAL_FILTERS, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getFilterData(@PathVariable(value = "user", required = true) final String user,
			@RequestParam(value = "startDate", required = true) final String startDate,
			@RequestParam(value = "endDate", required = true) final String endDate,
			@RequestParam(value = "mdn", required = false) final String mdn,
			@RequestParam(value = "model", required = false) final Integer model,
			@RequestParam(value = "fileName", required = false) final String fileName,
			@RequestParam(value = "imei", required = false) final String imei) throws  GlobalFilterException {

		log.debug(SecuirtyUtils.removeCFLRChar ("getFilterData() request params: " + " user= " + user + " startDate= " + startDate + " toDate= "
				+ endDate + " mdn= " + mdn + " model= " + model + "fileName= " + fileName + " imei= " + imei));
		final ResponseDto info = new ResponseDto();
		final List<GlobalFilterDto> globalFilterResDto = globalFilterManager.getFilterData(user, startDate, endDate,
				mdn, model, fileName, imei);

		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(globalFilterResDto);
		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	/**
	 * Gets the user log files.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param token the token
	 * @param userLimit the user limit
	 * @param fileLimit the file limit
	 * @param ofset the ofset
	 * @param userId the user id
	 * @param mdn the mdn
	 * @param model the model
	 * @param imei the imei
	 * @return the user log files
	 * @throws DataNotFoundException the data not found exception
	 * @throws GlobalFilterException 
	 */
	@GetMapping(value = ControllerUrl.GLOBAL_LOGFILES, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getUserLogFiles(
			@RequestParam(value = "startDate", required = true) final String startDate,
			@RequestParam(value = "endDate", required = true) final String endDate,
			@RequestParam(value = "token", required = false) final String token,
			@RequestParam(value = "limit", required = false) Integer userLimit,
			@RequestParam(value = "fileLimit", required = false) Integer fileLimit,
			@RequestParam(value = "offset", required = true) final Integer ofset,
			@RequestParam(value = "userId", required = false) final Integer userId,
			@RequestParam(value = "mdn", required = false) final String mdn,
			@RequestParam(value = "model", required = false) final Integer model,			
			@RequestParam(value = "imei", required = false) final String imei
			) throws DataNotFoundException, GlobalFilterException {
		if (userLimit == null) {
			userLimit = 10;
		} else if (fileLimit == null) {
			fileLimit = 10;
		}
		final List<UserLogFileDto> globalFilterResDto = globalFilterManager.getUserLogFiles(userId, startDate, endDate,
				token, userLimit, fileLimit, ofset,mdn, model, imei);
		final ResponseDto info = new ResponseDto();
		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(globalFilterResDto);
		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}
	
	/**
	 * Gets the mdns.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param userId the user id
	 * @param globalFilterDtos the global filter dtos
	 * @return the mdns
	 * @throws DataNotFoundException the data not found exception
	 * @throws GlobalFilterException 
	 */
	@PostMapping(ControllerUrl.MDN)
	public ResponseDto getMdns(
			@RequestParam(value = "startDate", required = true) final String startDate,
			@RequestParam(value = "endDate", required = true) final String endDate,			
			@RequestParam(value = "userId", required = false) final Integer userId,
			@RequestBody GlobalFilterRequestDto globalFilterDtos) throws GlobalFilterException {
		
		final List<String> mdns = globalFilterManager.getMdns(userId, startDate, endDate,globalFilterDtos);
		final ResponseDto info = new ResponseDto();
		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(mdns);
		return info;

	}
	
	/**
	 * Gets the imeis.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param userId the user id
	 * @param globalFilterDtos the global filter dtos
	 * @return the imeis
	 * @throws GlobalFilterException 
	 * @throws DataNotFoundException the data not found exception
	 */
	@PostMapping(ControllerUrl.IMEI)
	public ResponseDto getImeis(
			@RequestParam(value = "startDate", required = true) final String startDate,
			@RequestParam(value = "endDate", required = true) final String endDate,			
			@RequestParam(value = "userId", required = false) final Integer userId,
			@RequestBody GlobalFilterRequestDto globalFilterDtos) throws GlobalFilterException  {
		
		final List<String> imes = globalFilterManager.getImeis(userId, startDate, endDate,globalFilterDtos);
		final ResponseDto info = new ResponseDto();
		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(imes);
		return info;

	}
	
	/**
	 * Gets the models.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param userId the user id
	 * @param globalFilterDtos the global filter dtos
	 * @return the models
	 * @throws DataNotFoundException the data not found exception
	 * @throws GlobalFilterException 
	 */
	@PostMapping(ControllerUrl.MODELS)
	public ResponseDto getModels(
			@RequestParam(value = "startDate", required = true) final String startDate,
			@RequestParam(value = "endDate", required = true) final String endDate,			
			@RequestParam(value = "userId", required = false) final Integer userId,
			@RequestBody GlobalFilterRequestDto globalFilterDtos) throws DataNotFoundException, GlobalFilterException {
		
		final List<String> models = globalFilterManager.getModels(userId, startDate, endDate, globalFilterDtos);
		final ResponseDto info = new ResponseDto();
		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(models);
		return info;

	}
}
