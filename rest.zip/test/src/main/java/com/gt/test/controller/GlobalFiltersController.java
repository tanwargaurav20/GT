package com.harman.dmat.controller;

import com.harman.dmat.common.dto.GlobalFilterDataDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.common.exception.GlobalFilterException;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.manager.GlobalFilterManager;
import com.harman.dmat.utils.SecuirtyUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;

@RestController
@RequestMapping(ControllerUrl.FILTERS)
@Slf4j
public class GlobalFiltersController {
    @Inject
    GlobalFilterManager globalFilterManager;

    @GetMapping(value = ControllerUrl.GLOBAL_FILTERS_ES, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseDto> getFilterData(@PathVariable(value = "user", required = true) final String user,
                                                     @RequestParam(value = "startDate", required = true) final String startDate,
                                                     @RequestParam(value = "endDate", required = true) final String endDate,
                                                     @RequestParam(value = "domain", required = true) final String domain,
                                                     @RequestParam(value = "loc_tl_lat", required = true) final String tl_lat,
                                                     @RequestParam(value = "loc_tl_lon", required = true) final String tl_lon,
                                                     @RequestParam(value = "loc_br_lat", required = true) final String br_lat,
                                                     @RequestParam(value = "loc_br_lon", required = true) final String br_lon,
                                                     @RequestParam(value = "fileOffset", required = false, defaultValue = "10") final int fileOffset,
                                                     @RequestParam(value = "userOffset", required = false, defaultValue = "10") final int userOffset
                                                     ) throws GlobalFilterException {
        log.debug(SecuirtyUtils.removeCFLRChar ("getFilterData() request params: " + " user= " + user + " startDate= " + startDate + " toDate= "
                + endDate + " domain= " + domain + " loc_tl_lat= " + tl_lat + "loc_tl_lon= " + tl_lon + " loc_br_lat= " + br_lat +  " loc_br_lon= " + br_lon) + " fileOffset= "+ fileOffset+" userOffset= "+userOffset);
        final ResponseDto filter = new ResponseDto();
        final GlobalFilterDataDto globalFilters = globalFilterManager.getFilterDataFromES(user, startDate, endDate, domain, tl_lat, tl_lon, br_lat, br_lon, fileOffset, userOffset);

        filter.setStatus(Constant.OK);
        filter.setMessage(Constant.SUCCESS);
        filter.setData(globalFilters);

        return new ResponseEntity<ResponseDto>(filter, HttpStatus.OK);
    }

}
