package com.harman.dmat.controller;

import com.harman.dmat.common.dto.HeatMapRequestDto;
import com.harman.dmat.common.dto.HeatMapResponseDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.service.HeatMapService;
import com.harman.dmat.utils.SecuirtyUtils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;

/**
 * HeatMapController to retrieve data from ElasticSearch
 */
@RestController
@RequestMapping(ControllerUrl.HEATMAP)
@Slf4j
public class HeatMapController {
    @Inject
    HeatMapService heatMapsService;

    @GetMapping(value = ControllerUrl.HEATMAP_LOCATION, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseDto> getInfoPoints(@RequestParam(value = "timeStampFrm", required = true) final String timeStampFrm,
                                                     @RequestParam(value = "timeStampTo", required = true) final String timeStampTo,
                                                     @RequestParam(value = "tl_lat", required = true) final String tl_lat,
                                                     @RequestParam(value = "tl_lon", required = true) final String tl_lon,
                                                     @RequestParam(value = "br_lat", required = true) final String br_lat,
                                                     @RequestParam(value = "br_lon", required = true) final String br_lon,
                                                     @RequestParam(value = "cdmaless", required = true) final boolean cdmaless,
                                                     @RequestParam(value = "locCode", required = true) final String locCode) throws DataNotFoundException {
        final ResponseDto info = new ResponseDto();

        if (log.isDebugEnabled()) {
            log.debug(SecuirtyUtils.removeCFLRChar ("getHeatMapInfoPoints() request params: " + " timeStampFrm= " + timeStampFrm +
                    ", timeStampTo= " + timeStampTo + ", cdmaless= "+ cdmaless +
                    ", tl_lat= "+ tl_lat + ", tl_lon= "+ tl_lon + ", br_lat= "+ br_lat + ", br_lon= "+ br_lon + ", locCode= "+ locCode));
        }

        HeatMapRequestDto heatMapRequestDto = new HeatMapRequestDto();

        heatMapRequestDto.setTimeStampFrm(timeStampFrm);
        heatMapRequestDto.setTimeStampTo(timeStampTo);
        heatMapRequestDto.setTlLat(tl_lat);
        heatMapRequestDto.setTlLon(tl_lon);
        heatMapRequestDto.setBrLat(br_lat);
        heatMapRequestDto.setBrLon(br_lon);
        heatMapRequestDto.setCdmaless(cdmaless);
        heatMapRequestDto.setLocCode(locCode);

        HeatMapResponseDto heatMapResponseDto = heatMapsService.getHeatMapLocations(heatMapRequestDto);

        info.setStatus(Constant.OK);
        info.setMessage(Constant.SUCCESS);
        info.setData(heatMapResponseDto);

        return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);
    }

}
