package com.harman.dmat.controller;

import com.harman.dmat.common.dto.*;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.manager.InBuildingManager;
import com.harman.dmat.utils.SecuirtyUtils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(ControllerUrl.INBUILDING_ROOT)
@Slf4j
public class InBuildingController {

	@Inject
	InBuildingManager inBuildingManager;

	/**
	 * Get Image – To retrieve image by sending image ID’s
	 *
	 * @param imageId
	 * @return image in the response
	 */
	@ResponseBody
	@GetMapping(value = ControllerUrl.INBUILDINGIMG, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getInbuildingImage(@RequestParam(value = "imageId") final int imageId) {
		Map<String, Object> imageByteArray = inBuildingManager.getInbuildingImage(imageId);

		ResponseDto responseDto = new ResponseDto();
		responseDto.setStatus(Constant.OK);
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setData(imageByteArray);
		return new ResponseEntity<>(responseDto, HttpStatus.OK);
	}

	@ResponseBody
	@GetMapping(value = ControllerUrl.INBUILDINGIMG_LOGFILES, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getLogFiles(@RequestParam(value = "startDate") final String startDate,
			@RequestParam(value = "endDate") final String endDate,
			@RequestParam(value = "userId") final Integer userId,
			@RequestParam(value = "userType") final Integer userType) {
		final ResponseDto info = new ResponseDto();
		List<InBuildingLogViewDto> logViewDtos = inBuildingManager.getLogsByDate(startDate, endDate, userId, userType);

		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(logViewDtos);
		return new ResponseEntity<>(info, HttpStatus.OK);
	}

	@ResponseBody
	@GetMapping(value = ControllerUrl.INBUILDING_INFOPOINT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getInfoPoints(@RequestParam(value = "inbuildingx") final String inbuildingx,
			@RequestParam(value = "inbuildingy") final String inbuildingy,
			@RequestParam(value = "filename") final String fileName,
			@RequestParam(value = "startDate") final String startDate,
			@RequestParam(value = "endDate") final String endDate) throws DataNotFoundException {

		log.debug("getInfoPoints() request params: xcoord = {} ycoord = {} fileName = {} ",
				SecuirtyUtils.removeCFLRChar(inbuildingx), SecuirtyUtils.removeCFLRChar(inbuildingy),
				SecuirtyUtils.removeCFLRChar(fileName));
		final ResponseDto info = new ResponseDto();
		try {
			double inBuildingXValue = Double.parseDouble(inbuildingx);
			double inBuildingYValue = Double.parseDouble(inbuildingy);
			Map<String, String> map = inBuildingManager.getInfoPoints(inBuildingXValue, inBuildingYValue, fileName,
					startDate, endDate);

			info.setStatus(Constant.OK);
			info.setMessage(Constant.SUCCESS);
			info.setData(map);

			return new ResponseEntity<>(info, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			info.setStatus(Constant.FAILURE);
			info.setMessage(Constant.FAILURE);
			return new ResponseEntity<>(info, HttpStatus.BAD_REQUEST);
		}
	}

	@PostMapping(value = ControllerUrl.INBUILDING_REGISTER_V1, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> register(@RequestBody final InBuildingImageDto inBuildingImageDto,
			@Context HttpServletRequest request) {
		ResponseDto responseDto;
		setCachedDirectory(request);
		responseDto = inBuildingManager.registerInBuildingWithoutImage(inBuildingImageDto);
		return new ResponseEntity<>(responseDto, HttpStatus.OK);
	}

	@PostMapping(value = ControllerUrl.INBUILDING_REGISTER, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> register(@RequestParam(value = "access", required = false) final String access,
			@RequestParam(value = "name") final String name,
			@RequestParam(value = "buildingaddress") final String buildingAddress,
			@RequestParam(value = "dm_user") final Integer dmUser,
			@RequestParam(value = "floorlevel") final String floorLevel,
			@RequestParam(value = "statecode") final String state,
			@RequestParam(value = "zipcode") final String zipCode, @RequestParam(value = "city") final String city,
			@RequestParam(value = "buildingimage") final MultipartFile image, @Context HttpServletRequest request) {
		ResponseDto responseDto;
		try {
			setCachedDirectory(request);
			BufferedImage buf = ImageIO.read(new ByteArrayInputStream(image.getBytes()));
			Map<String, Object> inBuildingParameters = new HashMap<>();
			inBuildingParameters.put("buildingimage", image.getBytes());
			inBuildingParameters.put("name", name);
			inBuildingParameters.put("buildingaddress", buildingAddress);
			inBuildingParameters.put("dm_user", dmUser);
			inBuildingParameters.put("access", access);
			inBuildingParameters.put("floorlevel", floorLevel);
			inBuildingParameters.put("statecode", state);
			inBuildingParameters.put("zipcode", zipCode);
			inBuildingParameters.put("city", city);
			inBuildingParameters.put("image_width", buf.getWidth());
			inBuildingParameters.put("image_height", buf.getHeight());

			log.debug("Calculated Image Height: " + buf.getHeight() + " Width: " + buf.getWidth());

			responseDto = inBuildingManager.registerInBuilding(inBuildingParameters);

			return new ResponseEntity<>(responseDto, HttpStatus.OK);
		} catch (IOException e) {
			log.error(e.getMessage(), e);
			log.error("Failed to add dmat Inbuilding Image");
			responseDto = new ResponseDto();
			responseDto.setErrorCode(1);
			responseDto.setMessage("Failed to register Inbuilding");
			responseDto.setDeveloperMessage("Failed to registered Inbuilding");
			return new ResponseEntity<>(responseDto, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = ControllerUrl.INBUILDING_UPDATE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> update(@RequestBody final InBuildingImageDto inBuildingImageDto) {
		ResponseDto responseDto;
		responseDto = inBuildingManager.updateInBuildingInfo(inBuildingImageDto);
		return new ResponseEntity<>(responseDto, HttpStatus.OK);
	}

	@ResponseBody
	@GetMapping(value = ControllerUrl.INBUILDING_LIST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getInBuildingList(
			@RequestParam(value = "user_id", required = true) final Integer userId,
			@RequestParam(value = "access", required = false, defaultValue = "-1") final Integer access,
			@RequestParam(value = "offset", required = false) final Integer offset,
			@RequestParam(value = "limit", required = false) final Integer limit) {

		InBuildingImageListDto inBuildingImageListDto = inBuildingManager.getInBuildingList(offset, limit, userId,access);

		ResponseDto responseDto = new ResponseDto();
		responseDto.setStatus(Constant.OK);
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setData(inBuildingImageListDto);
		return new ResponseEntity<>(responseDto, HttpStatus.OK);

	}

	@DeleteMapping(value = ControllerUrl.INBUILDING_REMOVE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> removeInBuilding(@RequestParam(value = "id") final String id) {

		ResponseDto responseDto = inBuildingManager.removeInBuilding(id);

		return new ResponseEntity<>(responseDto, HttpStatus.OK);

	}

	@PostMapping(value = ControllerUrl.INBUILDING_UPDATE_IMAGE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> updateInBuildingImage(@RequestParam(value = "id") final Integer imageId,
			@RequestParam(value = "buildingimage") final MultipartFile image, @Context HttpServletRequest request)
			throws IOException {

		setCachedDirectory(request);
		BufferedImage buf = ImageIO.read(new ByteArrayInputStream(image.getBytes()));
		ResponseDto responseDto = inBuildingManager.updateInBuildingImage(imageId, image.getBytes(), buf.getWidth(),
				buf.getHeight());
		return new ResponseEntity<>(responseDto, HttpStatus.OK);
	}

	private void setCachedDirectory(HttpServletRequest request) {
		File tempDirectory = new File(request.getSession().getServletContext().getRealPath("temp"));
		if (!tempDirectory.exists()) {
			tempDirectory.mkdir();
		}
		ImageIO.setCacheDirectory(tempDirectory);
	}

}
