package com.harman.dmat.controller;

import java.util.List;
import java.util.Map;
import javax.inject.Inject;

import com.harman.dmat.common.dto.EventsInfoDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.harman.dmat.common.dto.LiveInfoPointsDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.manager.InfoPointsManager;
import com.harman.dmat.utils.SecuirtyUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * @author GTanwar Info Points Controller contains REST services to get the info
 *         points on the map
 */
@RestController
@RequestMapping(ControllerUrl.INFOPOINTS_ROOTPATH)
@Slf4j
public class InfoPointsController {

	@Inject
	InfoPointsManager infoPointsManager;

	/**
	 * Fetches the Info Points from the lat & lng
	 * 
	 * @param lat
	 * @param lon
	 * @param dm_user
	 * @param fileName
	 * @return
	 * @throws DataNotFoundException
	 */
	@GetMapping(value = ControllerUrl.INFOPOINTS_INFO, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getInfoPoints(@RequestParam(value = "lat", required = true) final String lat,
			@RequestParam(value = "lon", required = true) final String lon,
			@RequestParam(value = "user", required = false) final String dm_user,
			@RequestParam(value = "fileName", required = false) final String fileName,
			@RequestParam(value = "scale", required = false) final String scale,
			@RequestParam(value = "kpiName", required = false) final String kpiName,
			@RequestParam(value = "startDate", required = true) final String startDate,
			@RequestParam(value = "endDate", required = true) final String endDate,
			@RequestParam(value = "kpiType", required = false) final String kpiType,
			@RequestParam(value = "mdn", required = false) final String mdn,
			@RequestParam(value = "showEvent", required = true) final String showEvent,
			@RequestParam(value = "events", required = false) final String events,
			@RequestParam(value = "bandfilter", required = false, defaultValue = "") final String[] bandFilterArr,
			@RequestParam(value = "voicerat", required = false) final String voiceratFilterArr,
			@RequestParam(value = "earfcn", required = false) final String earfcnFilterArr,
			@RequestParam(value = "rsrpfltr", required = false) final String rsrpFilter,
			@RequestParam(value = "sinrfltr", required = false) final String sinrFilter,
			@RequestParam(value = "rsrqfltr", required = false) final String rsrqFilter,
			@RequestParam(value = "rssifltr", required = false) final String rssiFilter,
			@RequestParam(value = "enbIdfltr", required = false) final String enbIdFilter) throws DataNotFoundException {

		if (log.isDebugEnabled()) {
			log.debug(SecuirtyUtils.removeCFLRChar("getInfoPoints() request params: " + " lat= " + lat + " lon= " + lon
					+ " user= " + dm_user + "scale: " + scale + "KPI name: " + kpiName + "startDate: " + startDate
					+ "End Date: " + endDate + "kpiType" + kpiType + "MDN : " + mdn + "showEvent: " + showEvent
					+ " events: " + events + "bandFilterArr: " + bandFilterArr + "voiceratFilterArr: "
					+ voiceratFilterArr + "earfcnFilterArr: " + earfcnFilterArr));
		}
		final ResponseDto info = new ResponseDto();
		int[] bandFilterInt = (bandFilterArr != null) ? new int[bandFilterArr.length] : new int[1];
		if (bandFilterArr != null) {
			for (int i = 0; i < bandFilterArr.length; i++) {
				bandFilterInt[i] = Integer.parseInt(bandFilterArr[i]);
			}
		}
		List<String> list = infoPointsManager.getInfoPoints(lat, lon, dm_user, fileName, scale, kpiName, startDate,
				endDate, mdn, kpiType, showEvent, events, bandFilterInt, voiceratFilterArr, earfcnFilterArr, rsrpFilter,
				sinrFilter, rsrqFilter, rssiFilter,enbIdFilter);

		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(list);

		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	@GetMapping(value = ControllerUrl.EVENT_INFOPOINTS_INFO, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getEventInfoPoints(
			@RequestParam(value = "lat", required = true) final String lat,
			@RequestParam(value = "lon", required = true) final String lon,
			@RequestParam(value = "user", required = false) final String dm_user,
			@RequestParam(value = "scale", required = false) final String scale,
			@RequestParam(value = "fileName", required = false) final String fileName,
			@RequestParam(value = "scaleLoc", required = false) final String scaleLoc) throws DataNotFoundException {

		if (log.isDebugEnabled()) {
			log.debug(SecuirtyUtils.removeCFLRChar(
					"getEventInfoPoints() request params: " + " lat= " + lat + " lon= " + lon + " user= " + dm_user));
		}
		final ResponseDto info = new ResponseDto();
		Map<String, Object> dataMap = infoPointsManager.getEventInfoPoints(lat, lon, dm_user, scale, fileName,
				scaleLoc);

		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(dataMap);

		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	/**
	 * Fetches the live Info Points from the lat & lng
	 * 
	 * @param lat
	 * @param lon
	 * @return
	 * @throws DataNotFoundException
	 */
	@GetMapping(value = ControllerUrl.INFOPOINTS_LIVE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getLiveInfoPoints(@RequestParam(value = "lat", required = true) final String lat,
			@RequestParam(value = "lon", required = true) final String lon,
			@RequestParam(value = "imei", required = false) final String imei) {

		if (log.isDebugEnabled()) {
			log.debug(SecuirtyUtils.removeCFLRChar(
					"getInfoPoints() request params: " + " lat= " + lat + " lon= " + lon + " imei= " + imei));
		}
		final ResponseDto info = new ResponseDto();
		LiveInfoPointsDto liveInfoPointsDto = infoPointsManager.getLiveInfoPoints(lat, lon, imei);

		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(liveInfoPointsDto);

		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	/**
	 * Gets the Events Info List from ES for the given parameters.
	 * 
	 * @param startDate
	 * @param endDate
	 * @param userId
	 * @param domain
	 * @param tl_lat
	 * @param tl_lon
	 * @param br_lat
	 * @param br_lon
	 * @param eventsName
	 * @param fileNames
	 * @return
	 */
	@GetMapping(value = ControllerUrl.EVENTS_LIST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getEventsInfoList(
			@RequestParam(value = "startDate", required = true) final String startDate,
			@RequestParam(value = "endDate", required = true) final String endDate,
			@RequestParam(value = "userId", required = true) final String userId,
			@RequestParam(value = "domain", required = true) final String domain,
			@RequestParam(value = "loc_tl_lat", required = true) final String tl_lat,
			@RequestParam(value = "loc_tl_lon", required = true) final String tl_lon,
			@RequestParam(value = "loc_br_lat", required = true) final String br_lat,
			@RequestParam(value = "loc_br_lon", required = true) final String br_lon,
			@RequestParam(value = "eventsName", required = true) final String[] eventsName,
			@RequestParam(value = "fileNames", required = false, defaultValue = "") final String[] fileNames) {
		final ResponseDto info = new ResponseDto();

		if (log.isDebugEnabled()) {
			log.debug(SecuirtyUtils
					.removeCFLRChar("getEventsInfoList() request params: " + " startDate= " + startDate + " endDate= "
							+ endDate + " userId= " + userId + " domain= " + domain + " eventsList= " + eventsName
							+ " tl_lat= " + tl_lat + " tl_lon= " + tl_lon + " br_lat= " + br_lat + " br_lon= " + br_lon)
					+ "fileNames= " + fileNames);
		}

		List<EventsInfoDto> eventsInfoList = infoPointsManager.getEventsList(startDate, endDate, userId, domain, tl_lat,
				tl_lon, br_lat, br_lon, eventsName, fileNames);

		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(eventsInfoList);

		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);
	}

}
