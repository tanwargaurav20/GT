package com.harman.dmat.controller;

import java.io.FileInputStream;
import java.io.OutputStream;
import java.nio.file.Path;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.harman.dmat.common.dto.DynamicKpiDto;
import com.harman.dmat.common.dto.ResetTeplate;
import com.harman.dmat.common.dto.UniqueKpiDto;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.legends.dto.Kpi;
import com.harman.dmat.legends.dto.Template;
import com.harman.dmat.manager.LegendsManager;
import com.harman.dmat.service.StorageService;
import com.harman.dmat.utils.SecuirtyUtils;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(ControllerUrl.LEGENDS)
@Slf4j
public class LegendsController {

	@Inject
	LegendsManager legendsManager;
	@Inject
	StorageService storageService;

	@PostMapping("/kpi/templet")
	public ResponseEntity<Template> createNewTemplate(@RequestBody Template template) {
		log.info("create a new template for the user");
		return new ResponseEntity<>(legendsManager.createNewTemplate(template), HttpStatus.CREATED);
	}

	@PutMapping("/kpi/templet/default/{teplateId}/{kpi}")
	public ResponseEntity<Object> getDefaultKpiLegends(@PathVariable Long teplateId, @PathVariable Long kpi) {
		log.info("getting setting the default legends for kpi " + SecuirtyUtils.removeCFLRChar(kpi));
		return new ResponseEntity<>(legendsManager.getDefaultKpiLegends(teplateId, kpi), HttpStatus.OK);
	}

	@GetMapping("/kpi/templet/{userId}/{templateid}")
	public ResponseEntity<Template> getTemplate(@PathVariable Long userId, @PathVariable Long templateid) {
		log.info("getting the template {} for the user {}", SecuirtyUtils.removeCFLRChar(templateid),
				SecuirtyUtils.removeCFLRChar(userId));
		return new ResponseEntity<>(legendsManager.getTemplate(userId, templateid), HttpStatus.OK);
	}

	@GetMapping("/kpi/templet/{userId}")
	public ResponseEntity<List<Template>> getTemplate(@PathVariable Long userId) {
		log.info("getting the list of templates for the user {}", SecuirtyUtils.removeCFLRChar(userId));
		return new ResponseEntity<>(legendsManager.getUserTemplates(userId), HttpStatus.OK);
	}

	@DeleteMapping("/kpi/templet/{userId}/{templateid}")
	public ResponseEntity<String> deleteTemplate(@PathVariable Long userId, @PathVariable Long templateid) {
		log.info("deleting the template {} for the user {}", SecuirtyUtils.removeCFLRChar(templateid),
				SecuirtyUtils.removeCFLRChar(userId));
		return new ResponseEntity<>("{ \"message\": \"" + legendsManager.deleteTemplate(userId, templateid) + "\"}",
				HttpStatus.OK);
	}

	@PutMapping("/teplate/replace")
	public ResponseEntity<Template> resetTeplate(@RequestBody ResetTeplate resetTeplate) {
		log.info("replace the template from for the user {} ", resetTeplate.getUserId());
		return new ResponseEntity<>(legendsManager.resetTeplate(resetTeplate), HttpStatus.OK);
	}

	@PutMapping("/kpi/templet")
	public ResponseEntity<Template> updateTeplate(@RequestBody Template teplate) {
		log.info("updating  the user template {} from for the user {} ", teplate.getTemplateId(), teplate.getUserId());
		return new ResponseEntity<>(legendsManager.updateTeplate(teplate), HttpStatus.OK);
	}

	@PutMapping("/kpi/templet/apply")
	public ResponseEntity<Template> applyTeplate(@RequestBody Template teplate) {
		log.info("applying the the template for the user");
		return new ResponseEntity<>(legendsManager.applyTeplate(teplate), HttpStatus.OK);
	}

	@GetMapping("/kpis")
	public ResponseEntity<List<Kpi>> getKpiLegendsForUser(@RequestParam("userId") Long userId,
			@RequestParam("Group") int groupId) {
		log.info("Getting the user kpis and legends for useId: {} for group {} ",
				SecuirtyUtils.removeCFLRChar(userId.toString()), SecuirtyUtils.removeCFLRChar(groupId));
		return new ResponseEntity<>(legendsManager.getUserLegends(userId, groupId), HttpStatus.OK);
	}

	@GetMapping("/kpi")
	public ResponseEntity<Kpi> getKpiLegendForUser(@RequestParam("kpiId") Long kpiId,
			@RequestParam("userId") Long userId) {
		log.info("Getting the kpi: {} for the user : {}", SecuirtyUtils.removeCFLRChar(kpiId),
				SecuirtyUtils.removeCFLRChar(userId));
		return new ResponseEntity<>(legendsManager.getLegendForKpi(userId, kpiId), HttpStatus.OK);
	}

	@PostMapping("/kpi/templet/import")
	public ResponseEntity<Template> importUserLegends(@RequestParam("fileName") MultipartFile file,
			@RequestParam("userId") Long userId) {
		log.info("Importing the template for  userid {} legends from the file {} ",
				SecuirtyUtils.removeCFLRChar(userId), SecuirtyUtils.removeCFLRChar(file.getOriginalFilename()));
		return new ResponseEntity<>(legendsManager.saveUserFile(file, userId), HttpStatus.OK);
	}

	/*
	 * @GetMapping("/reset/{userId}") public ResponseEntity<ResponseDto>
	 * resetUserLegends(@PathVariable Long userId) { log.info(
	 * "Resetting the  legends for the user userId :{}",
	 * SecuirtyUtils.removeCFLRChar(userId)); return new
	 * ResponseEntity<>(legendsManager.resetUserLegends(userId), HttpStatus.OK);
	 * }
	 */

	@RequestMapping(value = "/kpi/templet/export/{userId}/{teplateId}", method = RequestMethod.GET)
	public void exportLegend(HttpServletRequest request, HttpServletResponse response,
			@PathVariable("userId") Long userId, @PathVariable("teplateId") Long teplateId) throws Exception {
		log.info("Expotring the legends for the  user :{}", SecuirtyUtils.removeCFLRChar(userId));
		ServletContext context = request.getServletContext();
		Path path = legendsManager.createWorkShett(userId, teplateId);
		try (FileInputStream inputStream = new FileInputStream(path.toFile())) {
			Enumeration<String> test = request.getHeaderNames();
			while (test.hasMoreElements()) {
				String val = test.nextElement();
				log.info("Name: {} : value :{}", SecuirtyUtils.removeCFLRChar(val),
						SecuirtyUtils.removeCFLRChar(request.getHeader(val)));

			}
			String mimeType = context.getMimeType(path.toString());
			if (mimeType == null) {
				mimeType = "application/octet-stream";
			}
			response.setContentType(mimeType);
			response.setContentLength((int) path.toFile().length());
			String headerKey = "Content-Disposition";
			String headerValue = String.format("attachment; filename=\"%s\"", path.toFile().getName());
			response.setHeader(headerKey, headerValue);
			try (OutputStream outStream = response.getOutputStream();) {
				byte[] buffer = new byte[4096];
				int bytesRead = -1;
				while ((bytesRead = inputStream.read(buffer)) != -1) {
					outStream.write(buffer, 0, bytesRead);
				}
			}
		}

		storageService.deleteFile(path);
	}

	@PostMapping("/kpi/templet/ESKpiValues")
	public ResponseEntity<Map<String, List<Integer>>> getUniqueKpiBasedOnMapExtent(
			@RequestBody UniqueKpiDto uniqueKpiDto) {
		return new ResponseEntity<>(legendsManager.getKpiValuesFromEs(uniqueKpiDto), HttpStatus.OK);
	}

	@PostMapping("/kpi/templet/DynamicKpiValues")
	public ResponseEntity<Map<String, String>> getDynamicKpiLegendsOnMapExtent(
			@RequestBody DynamicKpiDto dynamicKpiDto) {
		return new ResponseEntity<>(legendsManager.getDynamicKpiLegendsOnMapExtent(dynamicKpiDto), HttpStatus.OK);
	}

}