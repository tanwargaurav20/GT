package com.harman.dmat.controller;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.harman.dmat.common.dto.LiveAPIDto;
import com.harman.dmat.common.dto.LivePciDto;
import com.harman.dmat.common.dto.LiveTrendingDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.manager.LiveAPIManager;
import com.harman.dmat.utils.SecuirtyUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * @author GTanwar Live API Controller contains REST services for various
 *         operations for Live Data
 */
@RestController
@RequestMapping(ControllerUrl.LIVE_ROOTPATH)
@Slf4j
public class LiveAPIController {

	@Inject
	LiveAPIManager liveAPIManager;

	/**
	 * Retrieves the all IMEIs there in live DB
	 * 
	 * @return ResponseDto
	 * @throws DataNotFoundException
	 */
	@GetMapping(value = ControllerUrl.LISTIMEI, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getLiveImei() throws DataNotFoundException {

		log.debug("entered getLiveImei()");
		final ResponseDto info = new ResponseDto();
		final LiveAPIDto liveAPIDto = liveAPIManager.getLiveImei();

		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(liveAPIDto);
		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	@GetMapping(value = ControllerUrl.LIVETREND, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getLiveTrend(@PathVariable("imei") final String imei,
			@RequestParam(value = "currtimestamp", required = false) String timestamp) throws DataNotFoundException {

		log.debug("entered getLiveTrend() imei: " + SecuirtyUtils.removeCFLRChar(imei) + "timestamp: " + timestamp);
		final ResponseDto info = new ResponseDto();
		final List<LiveTrendingDto> liveTrendingDto = liveAPIManager.getLiveTrend(imei, timestamp);

		
		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(liveTrendingDto);
		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	@PostMapping("/PSKpiValues")
	public ResponseEntity<Map<String, List<Integer>>> getUniqueKpiBasedOnMapExtent(@RequestBody LivePciDto livePciDto) {
		return new ResponseEntity<>(liveAPIManager.getKpiValuesFromPs(livePciDto), HttpStatus.OK);
	}

}
