package com.harman.dmat.controller;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.harman.dmat.annotation.AUTHORIZED;
import com.harman.dmat.common.dto.CustomReportsDownloadPdfRequestDto;
import com.harman.dmat.common.dto.CustomReportsHistogramDto;
import com.harman.dmat.common.dto.CustomReportsLogDto;
import com.harman.dmat.common.dto.CustomReportsRequestDto;
import com.harman.dmat.common.dto.CustomReportsTemplateDto;
import com.harman.dmat.common.dto.LogMgrAnalysisDto;
import com.harman.dmat.common.dto.LogMgrDto;
import com.harman.dmat.common.dto.LogMgrPrefDto;
import com.harman.dmat.common.dto.LogMgrRespDto;
import com.harman.dmat.common.dto.PolygonLogsDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.InvalidRequestPayloadException;
import com.harman.dmat.common.exception.LogMgrException;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.manager.LogMgrManager;
import com.harman.dmat.service.StorageService;
import com.harman.dmat.utils.SecuirtyUtils;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;

import lombok.extern.slf4j.Slf4j;

/**
 * @author GTanwar Log Manager Controller contains REST services for various
 *         operations for Log Manager module
 */
@RestController
@RequestMapping(ControllerUrl.LOGMGR_ROOTPATH)
@Slf4j
public class LogMgrController {

	@Inject
	LogMgrManager logMgrManager;
	@Inject
	StorageService storageService;

	/**
	 * Retrieves the all log records against the requested parameters
	 *
	 * @param user
	 * @param calFilterType
	 * @param date
	 * @param page
	 * @param limit
	 * @param mdn
	 * @param model
	 * @param uploadedDate
	 * @param logCapturedDate
	 * @param userLastName
	 * @param fileName
	 * @param testId
	 * @param size
	 * @param gps
	 * @param imei
	 * @param status
	 * @param autotest
	 * @return ResponseDto
	 * @throws DataNotFoundException
	 */
	@GetMapping(value = ControllerUrl.LOGMGR_REPORTS, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getLogReport(@PathVariable("user") final String user,
			@RequestParam(value = "currusr", required = true) final Integer currUser,
			@RequestParam(value = "startDate", required = true) final String startDate,
			@RequestParam(value = "endDate", required = true) final String endDate,
			@RequestParam(value = "offset", required = false) final Integer offset,
			@RequestParam(value = "limit", required = false) final Integer limit,
			@RequestParam(value = "mdn", required = false) final String mdn,
			@RequestParam(value = "model", required = false) final String model,
			@RequestParam(value = "fileName", required = false) final String fileName,
			@RequestParam(value = "imei", required = false) final String imei,
			@RequestParam(value = "sortby", required = false) final String sortby,
			@RequestParam(value = "sortCol", required = false) final String sortCol) throws DataNotFoundException {

		log.debug(SecuirtyUtils.removeCFLRChar("getLogReport() request params: " + " userId= " + user + " endDate= "
				+ endDate + " startdate= " + startDate + " offset= " + offset + " limit= " + limit + " mdn= " + mdn
				+ " model= " + model + " imei= " + imei + " currUser: " + currUser));
		final ResponseDto info = new ResponseDto();
		final LogMgrRespDto logMgrRespDto = logMgrManager.getLogReport(user, startDate, endDate, mdn, model, fileName,
				imei, offset, limit, sortby, currUser, sortCol);

		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(logMgrRespDto.getLogMgrDto());
		info.setTotalCount(logMgrRespDto.getTotalCount());
		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	/**
	 * Saves the log manager user preferences
	 *
	 * @param logMgrUserPrefDto
	 * @return ResponseDto
	 * @throws LogMgrException
	 */
	@PostMapping(value = ControllerUrl.LOGMGR_USERPREF, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> saveUserPref(@RequestBody final LogMgrPrefDto logMgrUserPrefDto)
			throws LogMgrException {
		log.debug("saveUserPref request params: {} ", SecuirtyUtils.removeCFLRChar(logMgrUserPrefDto.toString()));
		final ResponseDto info = new ResponseDto();
		final Boolean result = logMgrManager.saveUserPref(logMgrUserPrefDto);
		if (result) {
			info.setStatus(Constant.OK);
			info.setMessage(Constant.SUCCESS);
		} else {
			info.setStatus(Constant.INTERNAL_SERVER_ERROR);
			info.setMessage(Constant.FAILED);
		}

		info.setData(result);

		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	/**
	 * Deletes the selected/passed log records as delimited String id's
	 *
	 * @param ids
	 * @return ResponseDto
	 * @throws InvalidRequestPayloadException
	 */
	@DeleteMapping(value = ControllerUrl.LOGMGR_DELETELOGS, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> deleteLog(@RequestBody final LogMgrDto logMgrDto)
			throws InvalidRequestPayloadException {
		log.debug(SecuirtyUtils.removeCFLRChar("deleteLog request params: " + "ids= " + logMgrDto.toString()));
		final ResponseDto info = new ResponseDto();
		Boolean result = false;
		try {
			result = logMgrManager.deleteLogs(logMgrDto.getDeleteFiles(), logMgrDto.getStartDate(), logMgrDto.getEndDate());
			if (result) {
				info.setStatus(Constant.OK);
				info.setMessage(Constant.SUCCESS);
			} else {
				info.setStatus(Constant.INTERNAL_SERVER_ERROR);
				info.setMessage(Constant.LOGMGR_DELETE_FAILED);
			}
		} catch (final LogMgrException e) {
			info.setStatus(Constant.INTERNAL_SERVER_ERROR);
			info.setMessage(e.getLocalizedMessage());
		}
		info.setData(result);
		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	/**
	 * Retrieves the saved user preferences for a particular user
	 *
	 * @param user
	 * @return ResponseDto
	 * @throws DataNotFoundException
	 */
	@GetMapping(value = ControllerUrl.LOGMGR_GETPREF, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getUserPref(@PathVariable("userId") final Integer userId)
			throws DataNotFoundException {
		log.debug("getUserPref request params: " + "user= " + SecuirtyUtils.removeCFLRChar(userId));
		final ResponseDto info = new ResponseDto();
		final List<LogMgrPrefDto> listLogMgrPrefDto = logMgrManager.getUserPref(userId);

		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(listLogMgrPrefDto);
		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	/**
	 * Retrieves the log analysis data as percentage of status's
	 *
	 * @return ResponseDto
	 * @throws DataNotFoundException
	 */
	@GetMapping(value = ControllerUrl.LOGMGR_ANALYSIS, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getLogAnalysisData(@PathVariable("userId") String userId,
			@RequestParam(value = "currusr", required = true) final Integer currUser,
			@RequestParam(value = "startDate", required = true) final String startDate,
			@RequestParam(value = "endDate", required = true) final String endDate,
			@RequestParam(value = "dateType", required = false) final String dateType) throws DataNotFoundException {

		log.debug("getLogAnalysisData() invoked");
		final ResponseDto info = new ResponseDto();
		final Map<String, List<LogMgrAnalysisDto>> dataMap = logMgrManager.getLogAnalysisData(userId, currUser,
				startDate, endDate, dateType);
		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(dataMap);
		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	/**
	 * Returns search results
	 * 
	 * @param user
	 * @param startDate
	 * @param endDate
	 * @param param
	 * @param sortby
	 * @param offset
	 * @param limit
	 * @return
	 * @throws DataNotFoundException
	 */
	@GetMapping(value = ControllerUrl.LOGMGR_SEARCH, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> searchLogs(@PathVariable("user") final String user,
			@RequestParam(value = "currusr", required = true) final Integer currUser,
			@RequestParam(value = "startDate", required = true) final String startDate,
			@RequestParam(value = "endDate", required = true) final String endDate,
			@RequestParam(value = "param", required = true) final String param,
			@RequestParam(value = "sortby", required = false) final String sortby,
			@RequestParam(value = "offset", required = true) final Integer offset,
			@RequestParam(value = "limit", required = false) final Integer limit,
			@RequestParam(value = "sortCol", required = false) final String sortCol) throws DataNotFoundException {

		log.debug(SecuirtyUtils
				.removeCFLRChar("searchLogs() request params: " + " userId= " + user + " param= " + param + " sortby= "
						+ sortby + " startDate= " + startDate + " endDate= " + endDate + " currUser: " + currUser));
		final ResponseDto info = new ResponseDto();
		final LogMgrRespDto logMgrRespDto = logMgrManager.searchLogs(user, startDate, endDate, param, sortby, offset,
				limit, currUser, sortCol);

		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(logMgrRespDto.getLogMgrDto());
		info.setTotalCount(logMgrRespDto.getTotalCount());
		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	@GetMapping(value = ControllerUrl.EXPORT)
	public ResponseEntity<Resource> fileDownloadHandler(@RequestParam(value = "file", required = true) String file)
			throws IOException, JSchException, SftpException {
		File f = null;
		Resource resource1 = null;
		HttpHeaders headers = null;
		headers = new HttpHeaders();

		f = logMgrManager.fileDownloadHandler(file);
		if (f == null) {
			return ResponseEntity.noContent().build();
		}
		resource1 = new InputStreamResource(new FileInputStream(f));
		headers.add(HttpHeaders.CONTENT_LENGTH, Long.toString(f.length()));
		headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
		headers.add("Pragma", "no-cache");
		headers.add("Expires", "0");
		headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + file.trim());
		headers.set(HttpHeaders.CONTENT_LENGTH, Long.toString(f.length())); 
		return ResponseEntity.ok().headers(headers).contentLength(f.length()).body(resource1);
	}

	@PostMapping(value = ControllerUrl.UPLOAD)
	public ResponseEntity<ResponseDto> fileUploadHandler(@RequestParam(value = "file") MultipartFile file)
			throws IOException {
		Integer isUploaded = 2;
		final ResponseDto info = new ResponseDto();

		isUploaded = logMgrManager.fileUploadHandler(file);

		if (isUploaded == 0) {
			info.setStatus(Constant.OK);
			info.setMessage(Constant.SUCCESS);
			info.setData(Constant.UPLOADED_SUCCESS);
			return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);
		} else if (isUploaded == 1) {
			info.setStatus(Constant.RESOURSE_EXISTS);
			info.setMessage(Constant.RESOURSE_EXISTS_MESSAGE);
			info.setData(Constant.RESOURSE_EXISTS_MESSAGE);
			return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);
		} else {

			info.setStatus(Constant.INTERNAL_SERVER_ERROR);
			info.setMessage(Constant.FAILED);
			info.setData(Constant.UPLOADED_FAILED);
			return new ResponseEntity<ResponseDto>(info, HttpStatus.INTERNAL_SERVER_ERROR);

		}

	}

	//Marked it as deprecated and didn't update it based on log file names
	//as this feature is removed from application.
	@Deprecated
	@AUTHORIZED(value = { Constant.ADMIN, Constant.SUPER_ADMIN }, notAllowed = { Constant.OEM, Constant.LRA,
			Constant.USER })
	@PostMapping(value = ControllerUrl.REPROCESS, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> reprocessLogFile(@RequestBody final LogMgrDto logMgrDto) throws IOException {
		Integer isUploaded = 2;
		final ResponseDto info = new ResponseDto();
		isUploaded = logMgrManager.reprocessLogFile(logMgrDto.getTestIds());

		if (isUploaded == 0) {
			info.setStatus(Constant.OK);
			info.setMessage(Constant.SUCCESS);
			info.setData(Constant.REPROCESS_SUCCESS);
			return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);
		} else if (isUploaded == 1) {
			info.setStatus(Constant.RESOURSE_EXISTS);
			info.setMessage(Constant.RESOURSE_EXISTS_MESSAGE);
			info.setData(Constant.RESOURSE_EXISTS_MESSAGE);
			return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);
		} else {
			info.setStatus(Constant.INTERNAL_SERVER_ERROR);
			info.setMessage(Constant.FAILED);
			info.setData(Constant.UPLOADED_FAILED);
			return new ResponseEntity<ResponseDto>(info, HttpStatus.INTERNAL_SERVER_ERROR);

		}

	}

	@GetMapping(value = ControllerUrl.LOGMGR_REPORT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getLogSixMonthLogs(
			@RequestParam(value = "userId", required = false) final Integer userId,
			@RequestParam(value = "geoPoints", required = true) final String geoPoints,
			@RequestParam(value = "mdn", required = false) final String mdn,
			@RequestParam(value = "imei", required = false) final String imei,
			@RequestParam(value = "stateCode", required = false) final String stateCode,
			@RequestParam(value = "regions", required = false) final String regions,
			@RequestParam(value = "modelId", required = false) final String modelId,
			@RequestParam(value = "deviceId", required = false) final String deviceId,
			@RequestParam(value = "limit", required = false) final Integer limit,
			@RequestParam(value = "offset", required = false) final Integer offset,
			@RequestParam(value = "startDate", required = true) final String startDate,
			@RequestParam(value = "endDate", required = true) final String endDate,
			@RequestParam(value = "fileName", required = false) final String fileName) throws LogMgrException {
		final PolygonLogsDto polygonLogsDto = logMgrManager.getLogSixMonthLogs(userId, geoPoints, mdn, imei, stateCode,
				regions, modelId, deviceId, limit, offset, startDate, endDate, fileName);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(polygonLogsDto);
		return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
	}

	/**
	 * Returns search results
	 * 
	 * @param user
	 * @param startDate
	 * @param endDate
	 * @param param
	 * @param sortby
	 * @param offset
	 * @param limit
	 * @return
	 * @throws DataNotFoundException
	 */
	@GetMapping(value = ControllerUrl.CUSTOMREPORTS_SEARCH, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> searchLogFiles(@RequestParam(value = "data", required = true) final Integer data,
			@RequestParam(value = "from", required = true) final String from,
			@RequestParam(value = "to", required = true) final String to,
			@RequestParam(value = "part", required = true) final String param,
			@RequestParam(value = "offset", required = true) final Integer offset,
			@RequestParam(value = "limit", required = false) final Integer limit) throws DataNotFoundException {

		log.debug(SecuirtyUtils.removeCFLRChar("custom searchLogFiles() request params: part= " + param + " from= "
				+ from + " to= " + to + " data: " + data + " offset= " + offset + " limit= " + limit));
		final ResponseDto info = new ResponseDto();
		// final List<CustomReportsDto> customReportsDto =
		// logMgrManager.searchLogFiles(data, from, to, param);
		final CustomReportsLogDto customReportsDto = logMgrManager.searchLogFiles(data, from, to, param, offset, limit);
		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		// info.setData(customReportsDto);
		info.setData(customReportsDto.getCustomReportsDto());
		info.setTotalCount(customReportsDto.getTotalCount());

		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	/**
	 * Returns Histogram results
	 * 
	 * @param user
	 * @param startDate
	 * @param endDate
	 * @param files
	 * @param kpis
	 * @param offset
	 * @param limit
	 * @return
	 * @throws DataNotFoundException
	 */
	@PostMapping(value = ControllerUrl.CUSTOMREPORTS_HISTOGRAM, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getHistogram(@RequestBody CustomReportsRequestDto customReportsRequestDto)
			throws DataNotFoundException {

		log.debug(
				SecuirtyUtils.removeCFLRChar("custom histogram() request body:" + customReportsRequestDto.toString()));
		final ResponseDto info = new ResponseDto();
		final Map<String, List<CustomReportsHistogramDto>> customReportsDtos = logMgrManager
				.getHistogram(customReportsRequestDto);

		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(customReportsDtos);
		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	/**
	 * Fetches model+imei's from ES
	 * 
	 * @return
	 * @throws DataNotFoundException
	 */
	@GetMapping(value = ControllerUrl.CUSTOMREPORTS_DEVICES, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getDevices(
			@RequestParam(value = "startDate", required = false) final String startDate,
			@RequestParam(value = "endDate", required = false) final String endDate) throws DataNotFoundException {

		log.debug(
				SecuirtyUtils.removeCFLRChar("custom reports() devices" + "startDate::endDate" + startDate + endDate));
		final ResponseDto info = new ResponseDto();
		final List<String> devices = logMgrManager.getDevices(startDate, endDate);

		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(devices);
		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	@PostMapping(value = ControllerUrl.CUSTOMREPORTS_TEMPLATES)
	public ResponseEntity<ResponseDto> saveTemplate(@RequestBody CustomReportsTemplateDto reportsTemplateDto)
			throws InvalidRequestPayloadException {
		final ResponseDto info = new ResponseDto();

		Integer isPersisted = logMgrManager.saveTemplate(reportsTemplateDto);
		if (isPersisted > 0) {
			info.setStatus(Constant.OK);
			info.setMessage(Constant.SUCCESS);
			info.setData(true);
		} else {
			info.setStatus(Constant.OK);
			info.setMessage(Constant.REPORTS_SAVE_FAILED);
			info.setData(false);
		}
		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	/**
	 * @param userId
	 * @return
	 * @throws DataNotFoundException
	 */
	@GetMapping(value = ControllerUrl.CUSTOMREPORTS_TEMPLATES)
	public ResponseEntity<ResponseDto> getAllTemplates(
			@RequestParam(value = "userId", required = true) final String userId) throws DataNotFoundException {
		final ResponseDto info = new ResponseDto();

		List<CustomReportsTemplateDto> list = logMgrManager.getAllTemplates(userId);

		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(list);

		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	/**
	 * @param reportsTemplateDto
	 * @return
	 * @throws InvalidRequestPayloadException
	 */
	@DeleteMapping(value = ControllerUrl.CUSTOMREPORTS_TEMPLATES)
	public ResponseEntity<ResponseDto> deleteTemplate(@RequestBody CustomReportsTemplateDto reportsTemplateDto)
			throws InvalidRequestPayloadException {
		final ResponseDto info = new ResponseDto();

		Integer isPersisted = logMgrManager.deleteTemplate(reportsTemplateDto);
		if (isPersisted > 0) {
			info.setStatus(Constant.OK);
			info.setMessage(Constant.SUCCESS);
			info.setData(true);
		} else {
			info.setStatus(Constant.OK);
			info.setMessage(Constant.REPORTS_DELETE_FAILED);
			info.setData(false);
		}
		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	/**
	 * @param reportsTemplateDto
	 * @return
	 * @throws InvalidRequestPayloadException
	 */
	@PutMapping(value = ControllerUrl.CUSTOMREPORTS_TEMPLATES)
	public ResponseEntity<ResponseDto> editTemplate(@RequestBody CustomReportsTemplateDto reportsTemplateDto)
			throws InvalidRequestPayloadException {
		final ResponseDto info = new ResponseDto();

		log.debug("DTO: " + SecuirtyUtils.removeCFLRChar(reportsTemplateDto.toString()));
		Integer isPersisted = logMgrManager.editTemplate(reportsTemplateDto);
		if (isPersisted > 0) {
			info.setStatus(Constant.OK);
			info.setMessage(Constant.SUCCESS);
			info.setData(true);
		} else {
			info.setStatus(Constant.OK);
			info.setMessage(Constant.REPORTS_DELETE_FAILED);
			info.setData(false);
		}
		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	@PostMapping(value = ControllerUrl.CUSTOMREPORTS_TIMESERIES, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getTimeseries(@RequestBody CustomReportsRequestDto customReportsRequestDto)
			throws DataNotFoundException {

		log.debug(
				"custom histogram() request body:" + SecuirtyUtils.removeCFLRChar(customReportsRequestDto.toString()));
		final ResponseDto info = new ResponseDto();
		final Map<String, List<CustomReportsHistogramDto>> customReportsDtos = logMgrManager
				.getTimeseries(customReportsRequestDto);

		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(customReportsDtos);
		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);

	}

	@PostMapping(value = ControllerUrl.CREATE_PDF, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> createPDF(HttpServletRequest request,
			@RequestBody CustomReportsDownloadPdfRequestDto customReportsRequestDto) throws DataNotFoundException {

		String pat = this.getClass().getClassLoader().getResource("").getPath();
		log.debug("Context path create:" + pat);
		String fullPath = null;
		try {
			fullPath = URLDecoder.decode(pat, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
		}
		String pathArr[] = fullPath.split("/WEB-INF/classes/");
		log.debug("Tomcat install path create:" + pathArr[0]);
		fullPath = pathArr[0];
		File orbitDirectory = new File(fullPath);
		String parentDirectory = orbitDirectory.getParent();
		String pdfPath = parentDirectory + "\\" + Constant.CUSTOMREPORT;
		log.debug("Custom Report folder location create:" + pdfPath);
		Path path = Paths.get(pdfPath);
		File f = new File(pdfPath);
		if (!f.exists()) {
			f.mkdirs();
		}
		String fullLocation = path.toString() + "\\" + customReportsRequestDto.getFileName();
		System.out.println("FullLocation:" + fullLocation);
		logMgrManager.customReportSavePDF(customReportsRequestDto, fullLocation);

		final ResponseDto info = new ResponseDto();
		info.setStatus(Constant.OK);
		info.setMessage(Constant.SUCCESS);
		info.setData(customReportsRequestDto.getFileName());
		return new ResponseEntity<ResponseDto>(info, HttpStatus.OK);
	}

	@GetMapping(value = ControllerUrl.SHOW_PDF)
	public ResponseEntity<Resource> showPDF(HttpServletRequest request,
			@RequestParam(value = "fileName", required = true) String file) throws DataNotFoundException, IOException {

		String pat = this.getClass().getClassLoader().getResource("").getPath();
		log.debug("Context path show:" + pat);
		String fullPath = null;
		try {
			fullPath = URLDecoder.decode(pat, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
		}
		String pathArr[] = fullPath.split("/WEB-INF/classes/");
		log.debug("Tomcat install path show:" + pathArr[0]);
		fullPath = pathArr[0];
		File orbitDirectory = new File(fullPath);
		String parentDirectory = orbitDirectory.getParent();
		String pdfPath = parentDirectory + "\\" + Constant.CUSTOMREPORT;
		log.debug("Custom Report folder location show:" + pdfPath);
		String fullLocation = pdfPath.toString() + "\\" + file;
		log.debug("File Location show:" + SecuirtyUtils.removeCFLRChar(fullLocation));
		final File downloadFile = new File(fullLocation);
		log.debug("DownloadFile:" + downloadFile.getAbsolutePath());
		FileInputStream fis = new FileInputStream(fullLocation);
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		byte[] buf = new byte[1024];
		try {
			for (int readNum; (readNum = fis.read(buf)) != -1;) {
				bos.write(buf, 0, readNum);
				System.out.println("read " + readNum + " bytes,");
			}
		} catch (IOException ex) {
		}
		ByteArrayResource resource = new ByteArrayResource(bos.toByteArray());
		HttpHeaders headers = null;
		headers = new HttpHeaders();
		headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
		headers.add("Pragma", "no-cache");
		headers.add("Expires", "0");
		headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		bos.close();
		fis.close();
		boolean isDeleted = false;
		if (downloadFile.exists()) {
			isDeleted = downloadFile.delete();
		}
		System.out.println("Is file deleted:- " + isDeleted);
		return ResponseEntity.ok().headers(headers).contentLength(resource.contentLength()).body(resource);
	}

}
