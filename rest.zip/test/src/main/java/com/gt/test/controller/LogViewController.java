package com.harman.dmat.controller;

import com.harman.dmat.common.dto.EventStatusDto;
import com.harman.dmat.common.dto.LogViewDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.service.LogViewService;
import com.harman.dmat.utils.SecuirtyUtils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

@RestController
@RequestMapping(ControllerUrl.LVLOGANALYSIS)
@Slf4j
public class LogViewController {
	@Inject
	LogViewService logViewService;

	@GetMapping(value = ControllerUrl.LVFILEID)
	public ResponseEntity<ResponseDto> getFileId(
			@RequestParam(value = "filename", required = true) final String fileName,
			@RequestParam(value = "testid", required = true) final int testId,
			@RequestParam(value = "evttimestamp", required = true) final String evtTimestamp) {
		log.debug("Log Viewer fileName as received:{} ", SecuirtyUtils.removeCFLRChar(fileName));
		log.debug("Log Viewer testid as received: {}", SecuirtyUtils.removeCFLRChar(testId));
		log.debug("Log Viewer evtTimestamp as received: {}", SecuirtyUtils.removeCFLRChar(evtTimestamp));

		// ResponseDto responseDto = new ResponseDto();
		LogViewDto logViewDto = new LogViewDto();

		logViewDto.setFileName(fileName);
		logViewDto.setTestId(testId);
		logViewDto.setEventTimeStamp(evtTimestamp);

		ResponseDto responseDto = logViewService.getFileId(logViewDto);
		return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
	}

	@PostMapping(value = ControllerUrl.LVSTATUS)
	public ResponseEntity<ResponseDto> updateEventStatus(@RequestBody List<LogViewDto> logViewDtoList){//@RequestParam(value="status", required = true) final String[] statusArr ){
		log.debug("Request received to Update Event Status from lvab...");
		log.debug("Total List Size for Event Status from lvab :{} ", SecuirtyUtils.removeCFLRChar(logViewDtoList.size()));
		log.debug("Object Id and Status from lvab :{} ", SecuirtyUtils.removeCFLRChar(logViewDtoList.toString()));
		/*List<LogViewDto> logViewDtos = new ArrayList<>();
		for(String str : statusArr){
			LogViewDto lvd = new LogViewDto();
			String[] tempArr = str.split(Pattern.quote("-"));
			if(tempArr.length>1) {
				lvd.setObjectId(new Integer(tempArr[0]).intValue());
				lvd.setStatus(tempArr[1].toUpperCase());
				logViewDtos.add(lvd);
			}
		}*/
		ResponseDto responseDto = logViewService.updateEvtStatus(logViewDtoList);
		return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
	}

	@ResponseBody
	@GetMapping(value = ControllerUrl.LVEVENTS, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getEvents() {
		log.debug("Request received for Polling Events from lvab..");
		List<LogViewDto> logViewDtoList = logViewService.getEventsList();
		log.debug("List of events sending to lvab:{}",SecuirtyUtils.removeCFLRChar(logViewDtoList.size()));
		ResponseDto responseDto = new ResponseDto();
		responseDto.setStatus(Constant.OK);
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setData(logViewDtoList);
		return new ResponseEntity<>(responseDto, HttpStatus.OK);
	}

	@ResponseBody
	@GetMapping(value = ControllerUrl.EVENTS_STATUS_REPORT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getEventsReportCount(
			@RequestParam(value = "startDate", required = true) final String startDate,
			@RequestParam(value = "endDate", required = true) final String endDate) {
		log.debug("Request received for Events Status Report with startDate {} and endDate {}",startDate,endDate);
		EventStatusDto evtDto = logViewService.getStatusReportCount(startDate, endDate);
		ResponseDto responseDto = new ResponseDto();
		responseDto.setStatus(Constant.OK);
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setData(evtDto);
		return new ResponseEntity<>(responseDto, HttpStatus.OK);
	}

	@GetMapping(value = ControllerUrl.LV_AUTO_TEST_REPORT)
	public ResponseEntity<ResponseDto> getAutoTestReport(
			@RequestParam(value = "filename", required = true) final String fileName) {
		log.debug("Log Viewer AUTO Test Report fileName as received:{} ", SecuirtyUtils.removeCFLRChar(fileName));
		ResponseDto responseDto = logViewService.getAutoTestReport(fileName);
		return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
	}
}
