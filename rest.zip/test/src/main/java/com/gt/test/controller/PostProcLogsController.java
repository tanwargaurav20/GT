package com.harman.dmat.controller;

import com.harman.dmat.common.dto.PostProcLogsDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.service.PostProcLogsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.util.List;

@RestController
@RequestMapping(ControllerUrl.POST_PROC)
@Slf4j
public class PostProcLogsController {
    @Inject
    PostProcLogsService postProcLogsService;

    @ResponseBody
    @PostMapping(value = ControllerUrl.POST_PROC_LOGS, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseDto> addPostProcLogs(@RequestBody final List<PostProcLogsDto> postProcLogsDtoList) {
        log.debug("Recieved data in PostProcLogs Controller");
        ResponseDto responseDto = new ResponseDto();

        responseDto = postProcLogsService.addPostProcLogs(postProcLogsDtoList);

        if(responseDto.getStatusCode() != null && responseDto.getStatusCode().equals(0)) {
            return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
        } else {
            return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.NOT_FOUND);
        }
    }

}
