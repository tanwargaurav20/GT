package com.harman.dmat.controller;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.harman.dmat.common.dto.Result;
import com.harman.dmat.common.dto.USRegionDto;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.manager.RegionManager;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(ControllerUrl.REGION)
@Slf4j
public class RegionController {
	@Inject
	RegionManager regionManager;
	
	/*
	* RegionController.java
	* insnayak20
	**/

	@PostMapping(value = "/")
	@ResponseBody
	public ResponseEntity<Result> getRegionData(@RequestBody USRegionDto usRegionDto) {
		return new ResponseEntity<>(regionManager.getRegionData(usRegionDto), HttpStatus.OK);

	}


}
