package com.harman.dmat.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.inject.Inject;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.harman.dmat.annotation.AUTHORIZED;
import com.harman.dmat.common.dto.AccordionInfo;
import com.harman.dmat.common.dto.AreaDto;
import com.harman.dmat.common.dto.ChangePasswordDto;
import com.harman.dmat.common.dto.CompanyDto;
import com.harman.dmat.common.dto.ContactDto;
import com.harman.dmat.common.dto.DeviceDto;
import com.harman.dmat.common.dto.EditRoleDto;
import com.harman.dmat.common.dto.EditUserStatusDto;
import com.harman.dmat.common.dto.EventDto;
import com.harman.dmat.common.dto.EventDtos;
import com.harman.dmat.common.dto.EventsBodyDto;
import com.harman.dmat.common.dto.EventsCountDto;
import com.harman.dmat.common.dto.FeedBackDto;
import com.harman.dmat.common.dto.FileUploadDto;
import com.harman.dmat.common.dto.ForgetPwdDto;
import com.harman.dmat.common.dto.GroupDto;
import com.harman.dmat.common.dto.GroupRequestDto;
import com.harman.dmat.common.dto.LastActivitiyDto;
import com.harman.dmat.common.dto.LoginDto;
import com.harman.dmat.common.dto.OsDto;
import com.harman.dmat.common.dto.PreferenceDto;
import com.harman.dmat.common.dto.RegionDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.common.dto.RoleDto;
import com.harman.dmat.common.dto.SimRequestData;
import com.harman.dmat.common.dto.SimRequestDto;
import com.harman.dmat.common.dto.SoftwareVersionDto;
import com.harman.dmat.common.dto.StateDto;
import com.harman.dmat.common.dto.StatusInfoDto;
import com.harman.dmat.common.dto.UserDto;
import com.harman.dmat.common.dto.UserPreferenceDto;
import com.harman.dmat.common.dto.ValidatedDto;
import com.harman.dmat.common.exception.DataAccessException;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.InvalidRequestPayloadException;
import com.harman.dmat.common.exception.SystemException;
import com.harman.dmat.common.exception.UserException;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.enums.ErrorCode;
import com.harman.dmat.manager.UserManager;
import com.harman.dmat.utils.SecuirtyUtils;
import com.harman.dmat.utils.Utill;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class UserController.
 *
 * @author prakash.bisht@harman.com
 */

@RestController

/** The Constant log. */

/** The Constant log. */
@Slf4j
@RequestMapping(ControllerUrl.USER_MANG)
public class UserController {

	/**
	 * Inject userManager implementation.
	 */
	@Inject
	private transient UserManager userManager;

	/**
	 * Login user.
	 *
	 * @param loginDto
	 *            the login dto
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 */
	@PutMapping(ControllerUrl.VALIDAT_USER)
	public ResponseDto loginUser(@Valid @RequestBody final LoginDto loginDto) throws UserException {
		final ValidatedDto validateDto = userManager.validateUser(loginDto.getUserName(), loginDto.getPassword(),
				loginDto.getAccessCode());
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.USER_LOGIN);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(validateDto);
		return responseDto;
	}

	/**
	 * Forget password.
	 *
	 * @param forgetPwd
	 *            the forget pwd
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 */
	@PutMapping(ControllerUrl.FORGET_PASSWORD)
	public ResponseDto forgetPassword(@Valid @RequestBody final ForgetPwdDto forgetPwd) throws UserException {
		userManager.forgetPassword(forgetPwd.getEmail());
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.FORGET_PASSWORD);
		responseDto.setStatus(Constant.OK);
		return responseDto;
	}

	/**
	 * Records the feedback.
	 *
	 * @param feedback
	 * @return
	 * @throws UserException
	 */
	@PostMapping(ControllerUrl.FEEDBACK)
	public ResponseDto userFeedback(@RequestBody final FeedBackDto feedback) throws UserException {
		ResponseDto responseDto = new ResponseDto();
		if (log.isDebugEnabled()) {
			log.debug(SecuirtyUtils.removeCFLRChar("userFeedback() request params: " + " email= " + feedback.getEmail()
					+ " feedback= " + feedback.getFeedback()));
		}
		responseDto = userManager.userFeedback(feedback);
		return responseDto;
	}

	/**
	 * Change password.
	 *
	 * @param changePasswordDto
	 *            the change password dto
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 */
	@PutMapping(ControllerUrl.CHANGE_PASSWORD)
	public ResponseDto changePassword(@Valid @RequestBody final ChangePasswordDto changePasswordDto)
			throws UserException {
		userManager.changePassword(changePasswordDto.getUserId(), changePasswordDto.getOldPassword(),
				changePasswordDto.getNewPassword());
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.CHANGE_PASSWORD);
		responseDto.setStatus(Constant.OK);
		return responseDto;
	}

	/**
	 * Register user in system.
	 *
	 * @param userDto
	 *            the user dto
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 */
	@PostMapping(ControllerUrl.USERS_REGISTER)
	public ResponseDto registerUser(@Valid @RequestBody final UserDto userDto) throws UserException {
		userManager.registerUser(userDto);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.USER_REGISTER);
		responseDto.setStatus(Constant.OK);
		return responseDto;

	}

	/**
	 * get the user preference on the basis of user id.
	 *
	 * @param userId
	 *            the user id
	 * @return the user preference
	 * @throws UserException
	 *             the user exception
	 */
	@GetMapping(value = ControllerUrl.GET_USER_PREFERENCE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseDto getUserPreference(@PathVariable("userId") final Integer userId) throws UserException {
		UserPreferenceDto userPreferenceDto;
		userPreferenceDto = userManager.getUserPreference(userId);
		final ResponseDto responseDto = new ResponseDto();
		if (userPreferenceDto != null && userPreferenceDto.getMapExtent() != null) {
			final int min = BigDecimal.ZERO.compareTo(BigDecimal.valueOf(userPreferenceDto.getMapExtent().getMinX()));
			final int max = BigDecimal.ZERO.compareTo(BigDecimal.valueOf(userPreferenceDto.getMapExtent().getMaxY()));
			if (userPreferenceDto.getStateCode() != null && min == 0 && max == 0) {
				final AreaDto areaDto = userManager.getUserPreferredArea(userPreferenceDto.getStateCode().get(0));
				userPreferenceDto.setMapExtent(areaDto);
			}
			responseDto.setData(userPreferenceDto);
			responseDto.setStatus(Constant.OK);
			responseDto.setMessage(Constant.GET_USER_PREFERENCE);
		} else {
			responseDto.setData(userPreferenceDto);
			responseDto.setStatus(Constant.INTERNAL_SERVER_ERROR);
			responseDto.setMessage(Constant.GET_USER_PREFERENCE);

		}
		return responseDto;
	}

	/**
	 * Delete the users on the basis of userIds.
	 *
	 * @param userDto
	 *            the user dto
	 * @return the response dto
	 * @throws InvalidRequestPayloadException
	 *             the invalid request payload exception
	 */
	@AUTHORIZED(value = { Constant.ADMIN, Constant.SUPER_ADMIN })
	@DeleteMapping(value = ControllerUrl.DELETE_USER)
	public ResponseDto deleteUser(@RequestBody final UserDto userDto) throws InvalidRequestPayloadException {
		final Boolean result = userManager.deleteUser(userDto.getUserIds());
		final ResponseDto responseDto = new ResponseDto();
		if (result) {
			responseDto.setData(result);
			responseDto.setStatus(Constant.OK);
			responseDto.setMessage(Constant.USER_DELETED_SUCCESSFULLY);
			return responseDto;
		} else {
			responseDto.setData(result);
			responseDto.setStatus(Constant.OK);
			responseDto.setMessage(Constant.USER_NOT_DELETED);
			return responseDto;
		}

	}

	/**
	 * Edit user first name and last name.
	 *
	 * @param userInfo
	 *            the user info
	 * @return the response dto
	 * @throws InvalidRequestPayloadException
	 *             the invalid request payload exception
	 * @throws DataAccessException
	 *             the data access exception
	 * @throws UserException
	 */
	@AUTHORIZED(value = { Constant.ADMIN, Constant.SUPER_ADMIN })
	@PatchMapping(value = ControllerUrl.UPDATE_USER_PROFILE_DATA)
	public ResponseDto editUserByAdmin(@RequestBody final Map<String, String> userInfo)
			throws InvalidRequestPayloadException, DataAccessException, UserException {

		final int row = userManager.updateByAdminData(userInfo);
		final ResponseDto responseDto = new ResponseDto();
		if (row > 0) {
			responseDto.setData(row);
			responseDto.setMessage(Constant.SUCCESS);
			responseDto.setStatus(Constant.OK);
		} else {
			responseDto.setData(row);
			responseDto.setMessage(Constant.FAILURE);
			responseDto.setStatus(Constant.NOT_CHANGED);
		}
		return responseDto;

	}

	/**
	 * Edits the user.
	 *
	 * @param userInfo
	 *            the user info
	 * @return the response dto
	 * @throws InvalidRequestPayloadException
	 *             the invalid request payload exception
	 * @throws DataAccessException
	 *             the data access exception
	 */
	@PatchMapping(value = ControllerUrl.USER_INFO)
	public ResponseDto editUser(@RequestBody final Map<String, String> userInfo)
			throws InvalidRequestPayloadException, DataAccessException {
		final int row = userManager.updateUserData(userInfo);
		final ResponseDto responseDto = new ResponseDto();
		if (row > 0) {
			responseDto.setData(row);
			responseDto.setMessage(Constant.SUCCESS);
			responseDto.setStatus(Constant.OK);
		} else {
			responseDto.setData(row);
			responseDto.setMessage(Constant.FAILURE);
			responseDto.setStatus(Constant.NOT_CHANGED);
		}
		return responseDto;

	}

	/**
	 * Get user with status of inactive and active.
	 *
	 * @param offset
	 *            the offset
	 * @param limit
	 *            the limit
	 * @param status
	 *            the status
	 * @param userType
	 *            the user type
	 * @param token
	 *            the token
	 * @return the user status
	 * @throws DataNotFoundException
	 *             the data not found exception
	 * @throws UserException
	 *             the user exception
	 */
	@GetMapping(value = ControllerUrl.GET_USERS_WITH_STATUS)
	public ResponseDto getUserStatus(@RequestParam(value = "offset", required = true) final Integer offset,
			@RequestParam(value = "limit", required = true) final Integer limit,
			@RequestParam(value = "status", required = false) final Integer status,
			@RequestParam(value = "userType", required = true) final String userType,
			@RequestParam(value = "token", required = false) final String token,
			@RequestParam(value = "sortBy", required = true) final String sortBy)
			throws DataNotFoundException, UserException {
		final List<UserDto> userlist = userManager.getDetailsWithStatus(offset, limit, status, userType, token, sortBy);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setData(userlist);
		responseDto.setStatus(Constant.OK);
		responseDto.setMessage(Constant.GET_ALL_USER_LIST_WITH_STATUS);
		return responseDto;

	}

	/**
	 * Get the user details.
	 *
	 * @param userId
	 *            the user id
	 * @return the user details
	 * @throws UserException
	 *             the user exception
	 */

	@GetMapping(value = ControllerUrl.GET_USER_DETAILS, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseDto getUserDetails(@PathVariable("userId") final Integer userId) throws UserException {
		final UserDto userdata = userManager.getUserDetail(userId);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setData(userdata);
		responseDto.setStatus(Constant.OK);
		responseDto.setMessage(Constant.GET_USER_DATA);
		return responseDto;
	}

	/**
	 * get the Users data on the basis of search param.
	 *
	 * @param email
	 *            the email
	 * @return the response dto
	 * @throws InvalidRequestPayloadException
	 *             the invalid request payload exception
	 */
	@GetMapping(value = ControllerUrl.USER_SEARCH, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseDto searchUser(@RequestParam(value = "email", required = true) final String email)
			throws InvalidRequestPayloadException {
		final List<UserDto> userdata = userManager.getSearchuser(email);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setData(userdata);
		responseDto.setStatus(Constant.OK);
		responseDto.setMessage(Constant.GET_SEARCHED_LIST_ON_BASIS_OF_INPUT);
		return responseDto;
	}

	/**
	 * Edit the user with new role and active status.
	 *
	 * @param editUserStatusDto
	 *            the edit user status dto
	 * @return the response dto
	 * @throws DataNotFoundException
	 *             the data not found exception
	 */
	@PutMapping(value = ControllerUrl.APPROVE_USER, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseDto editActiveStatus(@RequestBody final EditUserStatusDto editUserStatusDto)
			throws DataNotFoundException {
		int status;
		status = userManager.editUserStatus(editUserStatusDto);
		final ResponseDto responseDto = new ResponseDto();
		if (status > 0) {
			responseDto.setData(status);
			responseDto.setStatus(Constant.OK);
			responseDto.setMessage(Constant.STATUS_CHANGED_BY_ADMIN);
		} else {
			responseDto.setData(status);
			responseDto.setStatus(Constant.INTERNAL_SERVER_ERROR);
			responseDto.setMessage(Constant.STATUS_NOT_SUCCESSFULLY_CHANGED_BY_ADMIN);

		}
		return responseDto;

	}

	/**
	 * Edit the role for the user.
	 *
	 * @param editRoleDto
	 *            the edit role dto
	 * @return the response dto
	 * @throws DataNotFoundException
	 *             the data not found exception
	 */
	@PutMapping(value = ControllerUrl.EDIT_ROLE, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseDto editRole(@Valid @RequestBody final EditRoleDto editRoleDto) throws DataNotFoundException {
		final int roleupdated = userManager.editRoleforUser(editRoleDto);
		final ResponseDto responseDto = new ResponseDto();
		if (roleupdated > 0) {
			responseDto.setData(roleupdated);
			responseDto.setStatus(Constant.OK);
			responseDto.setMessage(Constant.ROLE_UPDATED_SUCCESSFULLY);
		} else {
			responseDto.setData(roleupdated);
			responseDto.setStatus(Constant.NOT_CHANGED);
			responseDto.setMessage(Constant.ROLE_NOT_UPDATED);
		}
		return responseDto;
	}

	/**
	 * Edit the user preference.
	 *
	 * @param userPreferenceDto
	 *            the user preference dto
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 * @throws DataNotFoundException
	 *             the data not found exception
	 */
	@PutMapping(value = ControllerUrl.USER_PREFERENCE, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseDto editUserPreferences(@RequestBody final UserPreferenceDto userPreferenceDto)
			throws UserException {
		boolean result;
		result = userManager.saveUserPreferences(userPreferenceDto);
		final ResponseDto responseDto = new ResponseDto();
		if (result) {
			responseDto.setData(result);
			responseDto.setStatus(Constant.OK);
			responseDto.setMessage(Constant.USER_PREFERENCE_SAVED_SUCCESSFULLY);
		} else {
			responseDto.setData(result);
			responseDto.setStatus(Constant.INTERNAL_SERVER_ERROR);
			responseDto.setMessage(Constant.USER_PREFERENCE__NOT_SAVED_SUCCESSFULLY);
		}
		return responseDto;

	}

	/**
	 * Edit the user preference.
	 *
	 * @param userPreferenceDto
	 *            the user preference dto
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 * @throws DataNotFoundException
	 *             the data not found exception
	 */
	@PutMapping(value = ControllerUrl.USER_PREFERENCE_MAP_EXTENT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseDto saveUserPreferenceExtent(@RequestBody final UserPreferenceDto userPreferenceDto)
			throws UserException {
		boolean result;
		result = userManager.saveUserPreferenceExtent(userPreferenceDto);
		final ResponseDto responseDto = new ResponseDto();
		if (result) {
			responseDto.setData(result);
			responseDto.setStatus(Constant.OK);
			responseDto.setMessage(Constant.USER_PREFERENCE_SAVED_SUCCESSFULLY);
		} else {
			responseDto.setData(result);
			responseDto.setStatus(Constant.INTERNAL_SERVER_ERROR);
			responseDto.setMessage(Constant.USER_PREFERENCE__NOT_SAVED_SUCCESSFULLY);
		}
		return responseDto;

	}

	/**
	 * Activate users.
	 *
	 * @param userIds
	 *            the user ids
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 */
	@PostMapping(value = ControllerUrl.ACTIVATE)
	public ResponseDto activateUsers(final @RequestBody List<Integer> userIds) throws UserException {
		userManager.activateUsers(userIds);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.USER_STATUS_CHANGE);
		responseDto.setStatus(Constant.OK);
		return responseDto;

	}

	/**
	 * Get all roles.
	 *
	 * @return the all roles
	 * @throws UserException
	 *             the user exception
	 */
	@GetMapping(ControllerUrl.ROLES)
	public ResponseDto getAllRoles() throws UserException {
		final List<RoleDto> roleDtos = userManager.getRoles();
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.ROLES);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(roleDtos);
		return responseDto;
	}

	/**
	 * Get all preferences.
	 *
	 * @return the allpreferences
	 * @throws UserException
	 *             the user exception
	 */
	@GetMapping(value = ControllerUrl.GET_PREFERENCES, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseDto getAllpreferences() throws UserException {
		final List<PreferenceDto> preferences = userManager.getAllpreferences();
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setData(preferences);
		responseDto.setStatus(Constant.OK);
		responseDto.setMessage(Constant.GET_PREFERENCES_LIST);
		return responseDto;

	}

	/**
	 * get all the companies.
	 *
	 * @return the companies
	 * @throws SystemException
	 *             the system exception
	 */
	@GetMapping(ControllerUrl.COMPANIES)
	public ResponseDto getCompanies() throws SystemException {
		final List<CompanyDto> companyDtos = userManager.getCompanies();
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.COMPANIES);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(companyDtos);
		return responseDto;
	}

	/**
	 * Get all the regions.
	 *
	 * @return regions
	 * @throws SystemException
	 *             the system exception
	 */
	@GetMapping(ControllerUrl.REGIONS)
	public ResponseDto getRegions() throws SystemException {
		final List<RegionDto> regionDtos = userManager.getRegions();
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.REGIONS);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(regionDtos);
		return responseDto;
	}

	/**
	 * get all the states.
	 *
	 * @return ResponseDto
	 * @throws SystemException
	 *             the system exception
	 */
	@GetMapping(ControllerUrl.STATES)
	public ResponseDto getStates() throws SystemException {
		final List<StateDto> stateDtos = userManager.getStates();
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.STATES);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(stateDtos);
		return responseDto;
	}

	/**
	 * get the states on the basis of region.
	 *
	 * @param region
	 *            the region
	 * @return ResponseDto
	 * @throws SystemException
	 *             the system exception
	 */
	@GetMapping(value = ControllerUrl.GET_STATES, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseDto getState(@RequestParam(value = "region", required = true) final String region)
			throws SystemException {
		final List<String> states = userManager.getStateName(region);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setData(states);
		responseDto.setStatus(Constant.OK);
		responseDto.setMessage(Constant.GET_LIST_OF_STATES);
		return responseDto;

	}

	/**
	 * Gets the events.
	 *
	 * @return the events
	 * @throws SystemException
	 *             the system exception
	 */
	@GetMapping(ControllerUrl.EVENTS)
	public ResponseDto getEvents() throws SystemException {
		final List<EventDto> eventDtos = userManager.getEvents();
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(eventDtos);
		return responseDto;
	}

	/**
	 * Gets the accordion info.
	 *
	 * @param token
	 *            the token
	 * @return the accordion info
	 * @throws UserException
	 *             the user exception
	 */
	@AUTHORIZED(value = { Constant.ADMIN, Constant.SUPER_ADMIN })
	@GetMapping(ControllerUrl.ACCORDION)
	public ResponseDto getAccordionInfo(@RequestParam(value = "token", required = false) String token)
			throws UserException {
		final AccordionInfo accordionInfo = userManager.getAccordionInfo(token);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.ACCORDION);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(accordionInfo);
		return responseDto;
	}

	/**
	 * Change status.
	 *
	 * @param statusInfoDto
	 *            the status info dto
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 */
	@AUTHORIZED(value = { Constant.ADMIN, Constant.SUPER_ADMIN })
	@PutMapping(value = ControllerUrl.STATUS_CHANGE)
	public ResponseDto changeStatus(final @RequestBody StatusInfoDto statusInfoDto) throws UserException {
		log.debug("data:{}", SecuirtyUtils.removeCFLRChar(statusInfoDto.toString()));
		userManager.changeStatus(statusInfoDto);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.USER_STATUS_CHANGE);
		responseDto.setStatus(Constant.OK);
		return responseDto;
	}

	/**
	 * Delete users.
	 *
	 * @param statusInfoDto
	 *            the status info dto
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 */
	@AUTHORIZED(value = { Constant.ADMIN, Constant.SUPER_ADMIN })
	@DeleteMapping(value = ControllerUrl.DELETE_USERS)
	public ResponseDto deleteUsers(final @RequestBody StatusInfoDto statusInfoDto) throws UserException {
		userManager.deleteUsers(statusInfoDto);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.USER_DELETED);
		responseDto.setStatus(Constant.OK);
		return responseDto;

	}

	/**
	 * Send notification.
	 *
	 * @param file
	 *            the file
	 * @param subject
	 *            the subject
	 * @param body
	 *            the body
	 * @param data
	 *            the data
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 */
	@AUTHORIZED(value = { Constant.ADMIN, Constant.SUPER_ADMIN })
	@PostMapping(value = ControllerUrl.USER_NOTIFICATION)
	public ResponseDto sendNotification(@RequestParam(value = "file", required = false) MultipartFile file,
			@RequestParam(value = "subject", required = true) final String subject,
			@RequestParam(value = "body", required = true) final String body,
			@RequestParam(value = "data", required = true) final String data) throws UserException {
		log.debug("subject:{}", SecuirtyUtils.removeCFLRChar(subject), " body:{}", SecuirtyUtils.removeCFLRChar(body),
				" data:{}", SecuirtyUtils.removeCFLRChar(data));
		StatusInfoDto statusInfoDto = null;
		try {
			statusInfoDto = Utill.readJson(data, StatusInfoDto.class);
		} catch (final Exception e) {
			throw new UserException(ErrorCode.INVALID_JSON.getErrorMessage(), ErrorCode.INVALID_JSON.getErrorCode());
		}
		userManager.sendNotification(file, subject, body, statusInfoDto);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.NOTIFICATION);
		responseDto.setStatus(Constant.OK);
		return responseDto;

	}

	/**
	 * Gets the contact.
	 *
	 * @return the contact
	 * @throws UserException
	 *             the user exception
	 */
	@GetMapping(ControllerUrl.CONTACT_US)
	public ResponseDto getContact() throws UserException {
		final ContactDto contactDto = userManager.getContact();
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.CONTACT);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(contactDto);
		return responseDto;
	}

	/**
	 * Uplodad file.
	 *
	 * @param file
	 *            the file
	 * @param version
	 *            the version
	 * @param type
	 *            the type
	 * @param description
	 *            the description
	 * @param size
	 *            the size
	 * @param location
	 *            the location
	 * @param name
	 *            the name
	 * @return the response entity
	 */
	@PostMapping("/upload")
	public ResponseEntity<String> UplodadFile(@RequestParam("fileName") MultipartFile file,
			@RequestParam("Version") String version, @RequestParam("Type") String type,
			@RequestParam(value = "Description", required = false) Optional<String> description,
			@RequestParam(value = "Size", required = false) Optional<String> size,
			@RequestParam(value = "Location", required = false) Optional<String> location,
			@RequestParam(value = "Name", required = false) Optional<String> name) {
		log.info("these are the got in request id  Version:{},type:{},Description{},Size:{},Location {},Name{}",
				SecuirtyUtils.removeCFLRChar(version), SecuirtyUtils.removeCFLRChar(type),
				SecuirtyUtils.removeCFLRChar(description), SecuirtyUtils.removeCFLRChar(size),
				SecuirtyUtils.removeCFLRChar(location), SecuirtyUtils.removeCFLRChar(name));
		return new ResponseEntity<>("{ \"message\": \""
				+ userManager.validateAndUploadFile(file, version, type, name, description, size, location) + "\"}",
				HttpStatus.OK);
	}

	/**
	 * File download handler.
	 *
	 * @param file
	 *            the file
	 * @return the response entity
	 */
	@GetMapping(value = "/export")
	public ResponseEntity<Resource> fileDownloadHandler(@RequestParam(value = "file", required = true) String file) {
		ByteArrayResource resource = null;
		HttpHeaders headers = null;
		headers = new HttpHeaders();
		resource = userManager.fileDownloadHandler(file);
		final String fileName = file.substring(file.lastIndexOf('/') + 1);
		headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
		headers.add("Pragma", "no-cache");
		headers.add("Expires", "0");
		headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName.trim());
		return ResponseEntity.ok().headers(headers).contentLength(resource.contentLength()).body(resource);
	}

	/**
	 * Gets the list.
	 *
	 * @param type
	 *            the type
	 * @return the list
	 */
	@GetMapping(value = "/listMetaData")
	public ResponseEntity<List<FileUploadDto>> getList(@RequestParam("type") Optional<String> type) {
		return new ResponseEntity<>(userManager.getList(type), HttpStatus.OK);
	}

	@PostMapping(value = ControllerUrl.REGISTER_SOFTWARE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> registerSoftware(@RequestParam("fileName") MultipartFile file,
			@RequestParam(value = "deviceOs", required = false) String deviceOs,
			@RequestParam(value = "versionName", required = false) String versionName,
			@RequestParam(value = "latest", required = false, defaultValue = "false") boolean latest,
			@RequestParam(value = "buildFlavor", required = false, defaultValue = "0") int buildFlavor) {
		log.info("Registering Software - ManageOTA request id  deviceOs:{},versionName:{},latest{},buildFlavor:{}",
				SecuirtyUtils.removeCFLRChar(deviceOs), SecuirtyUtils.removeCFLRChar(versionName),
				SecuirtyUtils.removeCFLRChar(latest), SecuirtyUtils.removeCFLRChar(buildFlavor));
		ResponseDto responseDto = new ResponseDto();
		try {
			SoftwareVersionDto svd = new SoftwareVersionDto();
			svd.setBuildFlavor(buildFlavor);
			svd.setDeviceOs(deviceOs);
			svd.setLatest(latest);
			svd.setVersionName(versionName);
			svd.setApk(file.getBytes());
			responseDto = userManager.registerSoftware(svd);
		} catch (IOException ex) {
			log.error("Exception in uploading APK-ManageOTA" + ex.getMessage());
			responseDto.setErrorCode(1);
			responseDto.setMessage("Error in uploading APK-ManageOTA");
			responseDto.setDeveloperMessage("Error in uploading APK-ManageOTA");
		}
		return new ResponseEntity<>(responseDto, HttpStatus.OK);
	}

	@GetMapping(value = "/softwareList")
	public ResponseEntity<ResponseDto> getSoftwareList() {
		ResponseDto responseDto = new ResponseDto();
		responseDto.setStatus(Constant.OK);
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setData(userManager.getSoftwareList());
		return new ResponseEntity<>(responseDto, HttpStatus.OK);
	}

	@DeleteMapping(value = "/deleteSw")
	public ResponseDto deleteSoftware(@RequestParam(value = "sid", required = true) int softwareId)
			throws InvalidRequestPayloadException {
		final Boolean result = userManager.deleteSoftware(softwareId);
		final ResponseDto responseDto = new ResponseDto();
		if (result) {
			responseDto.setData(result);
			responseDto.setStatus(Constant.OK);
			responseDto.setMessage(Constant.SOFTWARE_DELETED_SUCCESSFULLY);
			return responseDto;
		} else {
			responseDto.setData(result);
			responseDto.setStatus(Constant.OK);
			responseDto.setMessage(Constant.SOFTWARE_NOT_DELETED);
			return responseDto;
		}

	}

	@PutMapping(value = "/setLatest")
	public ResponseDto setLatestSoftware(@RequestParam(value = "sid", required = true) int softwareId,
			@RequestParam(value = "osid", required = true) int osId,
			@RequestParam(value = "latest", required = true, defaultValue = "true") boolean latest)
			throws InvalidRequestPayloadException {
		final Boolean result = userManager.setLatestSoftware(softwareId, osId, latest);
		final ResponseDto responseDto = new ResponseDto();
		if (result) {
			responseDto.setData(result);
			responseDto.setStatus(Constant.OK);
			responseDto.setMessage("Set/Unset Latest has been modified successfully");
			return responseDto;
		} else {
			responseDto.setData(result);
			responseDto.setStatus(Constant.OK);
			responseDto.setMessage("Set/Unset Latest cannot be modified. Please try again later");
			return responseDto;
		}
	}

	/**
	 * Save last activity.
	 *
	 * @param userDto
	 *            the user dto
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 */
	@PostMapping(ControllerUrl.USER_LAST_ACTIVITY)
	public ResponseDto saveLastActivity(@Valid @RequestBody final LastActivitiyDto userDto) throws UserException {
		if (!Utill.isJSONValid(userDto.getLastActivityJson())) {
			throw new UserException(ErrorCode.INVALID_JSON.getErrorMessage(), ErrorCode.INVALID_JSON.getErrorCode());
		}
		userManager.saveLastActivity(userDto);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.LAST_ACTIVITY);
		responseDto.setStatus(Constant.OK);
		return responseDto;

	}

	/**
	 * Save sim card request.
	 *
	 * @param simRequestDto
	 *            the sim request dto
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 */
	@PostMapping(ControllerUrl.SIM_CARD_REQUEST)
	public ResponseDto saveSimCardRequest(@RequestBody final SimRequestDto simRequestDto) throws UserException {
		userManager.saveSimCardRequest(simRequestDto);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		return responseDto;

	}

	/**
	 * Gets the device.
	 *
	 * @return the device
	 * @throws UserException
	 *             the user exception
	 */
	@GetMapping(ControllerUrl.DEVICE)
	public ResponseDto getDevice() throws UserException {
		final List<DeviceDto> deviceDtos = userManager.getDevice();
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(deviceDtos);
		return responseDto;

	}

	/**
	 * Removes the device.
	 *
	 * @param deviceIds
	 *            the device ids
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 */
	@AUTHORIZED(value = { Constant.ADMIN, Constant.SUPER_ADMIN })
	@DeleteMapping(ControllerUrl.DEVICE)
	public ResponseDto removeDevice(@RequestBody List<Integer> deviceIds) throws UserException {
		userManager.removeDevice(deviceIds);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		return responseDto;

	}

	/**
	 * Adds the device.
	 *
	 * @param deviceDto
	 *            the device dto
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 */
	@AUTHORIZED(value = { Constant.ADMIN, Constant.SUPER_ADMIN })
	@PostMapping(ControllerUrl.DEVICE)
	public ResponseDto addDevice(@RequestBody final DeviceDto deviceDto) throws UserException {
		if (deviceDto.getDeviceManufacturer() == null || deviceDto.getDeviceModel() == null
				|| deviceDto.getDeviceName() == null) {
			throw new InvalidRequestPayloadException();
		}
		userManager.addDevice(deviceDto);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.DEVICE_ADDED);
		responseDto.setStatus(Constant.OK);
		return responseDto;

	}

	/**
	 * Edits the device.
	 *
	 * @param deviceDto
	 *            the device dto
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 */
	@AUTHORIZED(value = { Constant.ADMIN, Constant.SUPER_ADMIN })
	@PutMapping(ControllerUrl.DEVICE)
	public ResponseDto editDevice(@RequestBody final DeviceDto deviceDto) throws UserException {
		if (deviceDto.getDeviceManufacturer() == null || deviceDto.getDeviceModel() == null
				|| deviceDto.getDeviceName() == null) {
			throw new InvalidRequestPayloadException();
		}
		userManager.editDevice(deviceDto);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.DEVICE_EDIT);
		responseDto.setStatus(Constant.OK);
		return responseDto;

	}

	/**
	 * Import excel file.
	 *
	 * @param file
	 *            the file
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 */
	@AUTHORIZED(value = { Constant.ADMIN, Constant.SUPER_ADMIN })
	@PostMapping(ControllerUrl.IMPORT_EXCEL_FILE)
	public ResponseDto importExcelFile(@RequestParam("file") MultipartFile file) throws UserException {
		if (file == null) {
			throw new InvalidRequestPayloadException("File is not attached.");
		}
		userManager.importExcelFile(file);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		return responseDto;

	}

	/**
	 * Adds the os.
	 *
	 * @param osDto
	 *            the os dto
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 */
	@AUTHORIZED(value = { Constant.ADMIN, Constant.SUPER_ADMIN })
	@PostMapping(ControllerUrl.OS)
	public ResponseDto addOs(@RequestBody OsDto osDto) throws UserException {
		userManager.addOs(osDto);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		return responseDto;

	}

	/**
	 * Gets the os.
	 *
	 * @return the os
	 * @throws UserException
	 *             the user exception
	 */
	@GetMapping(ControllerUrl.OS)
	public ResponseDto getOS() throws UserException {
		final List<OsDto> osDtos = userManager.getOs();
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(osDtos);
		return responseDto;

	}

	/**
	 * Creates the group.
	 *
	 * @param groupDto
	 *            the group dto
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 */
	@AUTHORIZED(value = { Constant.GROUP_ADMIN }, notAllowed = { Constant.OEM })
	@PostMapping(ControllerUrl.GROUP)
	public ResponseDto createGroup(@RequestBody final GroupDto groupDto) throws UserException {
		if (groupDto.getGroupName() == null) {
			throw new InvalidRequestPayloadException();
		}
		userManager.createGroup(groupDto);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		return responseDto;

	}

	/**
	 * Update group.
	 *
	 * @param groupDto
	 *            the group dto
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 */
	@AUTHORIZED(value = { Constant.GROUP_ADMIN }, notAllowed = { Constant.OEM })
	@PutMapping(ControllerUrl.GROUP)
	public ResponseDto updateGroup(@RequestBody final GroupDto groupDto) throws UserException {
		if (groupDto.getGroupId() == null) {
			throw new InvalidRequestPayloadException();
		}
		userManager.updateGroup(groupDto);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		return responseDto;

	}

	/**
	 * Delete group.
	 *
	 * @param groupId
	 *            the group id
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 */
	@AUTHORIZED(value = { Constant.GROUP_ADMIN }, notAllowed = { Constant.OEM })
	@DeleteMapping(ControllerUrl.GROUP)
	public ResponseDto deleteGroup(@NotNull @RequestBody final Map<String, Integer[]> groupMap) throws UserException {
		userManager.deleteGroup(groupMap.get("groupIds"));
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		return responseDto;

	}

	/**
	 * Gets the groups.
	 *
	 * @return the groups
	 * @throws SystemException
	 *             the system exception
	 * @throws UserException
	 */
	@AUTHORIZED(value = { Constant.GROUP_ADMIN }, notAllowed = { Constant.OEM })
	@GetMapping(ControllerUrl.GROUP)
	public ResponseDto getGroups() throws UserException {
		final List<GroupDto> groupDtos = userManager.getGroups();
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(groupDtos);
		return responseDto;
	}

	/**
	 * Sets the group request status.
	 *
	 * @param groupRequestDto
	 *            the group request dto
	 * @return the response dto
	 * @throws UserException
	 *             the user exception
	 */
	@AUTHORIZED(notAllowed = { Constant.OEM })
	@PutMapping(ControllerUrl.GROUP_REQUEST_STATUS)
	public ResponseDto setGroupRequestStatus(@Valid @RequestBody GroupRequestDto groupRequestDto) throws UserException {
		userManager.setGroupRequestStatus(groupRequestDto);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		return responseDto;
	}

	/**
	 * Gets the user brief info.
	 *
	 * @param offset
	 *            the offset
	 * @param limit
	 *            the limit
	 * @return the user brief info
	 * @throws UserException
	 *             the user exception
	 */
	@AUTHORIZED(value = { Constant.GROUP_ADMIN })
	@GetMapping(ControllerUrl.USER_BREIF_INFO)
	public ResponseDto getUserBriefInfo(@RequestParam("offset") final Integer offset,
			@RequestParam("limit") final Integer limit) throws UserException {
		final List<UserDto> users = userManager.getUserBriefInfo(offset, limit);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(users);
		return responseDto;
	}

	/**
	 * Gets the sim info.
	 *
	 * @param offset
	 *            the offset
	 * @param limit
	 *            the limit
	 * @return the sim info
	 * @throws UserException
	 *             the user exception
	 */

	@GetMapping(ControllerUrl.SIM_INFO)
	public ResponseDto getSimInfo(@RequestParam("offset") final Integer offset,
			@RequestParam("limit") final Integer limit) throws UserException {
		final SimRequestData simInfo = userManager.getSimInfo(offset, limit);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(simInfo);
		return responseDto;
	}

	/**
	 * Gets the user groups.
	 *
	 * @return the user groups
	 * @throws UserException
	 *             the user exception
	 */
	@AUTHORIZED(notAllowed = { Constant.OEM })
	@GetMapping(value = ControllerUrl.USER_GROUPS)
	public ResponseDto getMyGroups() throws UserException {
		final List<GroupDto> groupDtos = userManager.getMyGroups();
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setData(groupDtos);
		responseDto.setStatus(Constant.OK);
		responseDto.setMessage(Constant.SUCCESS);
		return responseDto;
	}

	/**
	 * Gets the group requests.
	 *
	 * @return the group requests
	 * @throws UserException
	 *             the user exception
	 */
	@AUTHORIZED(notAllowed = { Constant.OEM })
	@GetMapping(ControllerUrl.GROUP_REQUREST)
	public ResponseDto getGroupRequests() throws UserException {
		final List<GroupRequestDto> groupRequests = userManager.getGroupRequests();
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(groupRequests);
		return responseDto;
	}

	@AUTHORIZED(value = { Constant.GROUP_ADMIN }, notAllowed = { Constant.OEM })
	@DeleteMapping(ControllerUrl.USER_GRUID)
	public ResponseDto deleteUserGuideAndApk(@RequestBody final Map<String, Integer> fileInfo) throws UserException {
		userManager.deleteUserGuide(fileInfo.get("fileId"));
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		return responseDto;
	}

	@PostMapping(ControllerUrl.REFRESHTOKEN)
	public ResponseDto refreshToken(@Valid @RequestBody final ValidatedDto validatedDto) throws UserException {
		final ValidatedDto validateResponseDto = userManager.refreshToken(validatedDto.getRefreshToken());
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.REFRESH_TOKEN);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(validateResponseDto);
		return responseDto;
	}

	@GetMapping(ControllerUrl.USER_GROUPS + "/GroupName")
	public ResponseEntity<Boolean> checkIFTheGroupNameAvailable(@RequestParam("groupName") final String groupName) {
		return new ResponseEntity<>(userManager.checkIFTheGroupNameAvailable(groupName), HttpStatus.OK);
	}

	/**
	 * Gets the events.
	 *
	 * @return the events
	 * @throws SystemException
	 *             the system exception
	 */
	@PostMapping(ControllerUrl.EVENTS_LEGENDS)
	public ResponseDto getEventsLegends(@RequestBody final EventsBodyDto eventsBodyDto) throws SystemException {
		final EventDtos eventDtos = userManager.getEventsLegends(eventsBodyDto);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(eventDtos);
		return responseDto;
	}
	
	/**
	 * Gets the events based on map extent.
	 *
	 * @return the events
	 * @throws SystemException
	 *             the system exception
	 */
	@PostMapping(ControllerUrl.EVENTS_COUNT)
	public ResponseDto getEventsCount(@RequestBody final EventsBodyDto eventsBodyDto) throws SystemException {
		final List<EventsCountDto> eventCountDtoList = userManager.getEventsCounts(eventsBodyDto);
		final ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setStatus(Constant.OK);
		responseDto.setData(eventCountDtoList);
		return responseDto;
	}
}
