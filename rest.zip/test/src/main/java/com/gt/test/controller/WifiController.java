package com.harman.dmat.controller;

import com.harman.dmat.common.dto.*;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.constant.ControllerUrl;
import com.harman.dmat.manager.WifiManager;
import com.harman.dmat.utils.SecuirtyUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;

@RestController
@RequestMapping(ControllerUrl.WIFI_ROOTPATH)
@Slf4j
public class WifiController {

	@Inject
    WifiManager wifiManager;

	@ResponseBody
	@GetMapping(value = ControllerUrl.WIFI_INFO, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getWifiInfo(
			@RequestParam(value = "latitude", required = true) final String latitude,
			@RequestParam(value = "longitude", required = true) final String longitude,
			@RequestParam(value = "scale", required = false) final String scale,
			@RequestParam(value = "startDate", required = true) final String startDate,
			@RequestParam(value = "endDate", required = true) final String endDate) {

		log.debug("getWifiInfo in... {}", latitude + " " + longitude + " " + scale + " " + startDate + " " + endDate);

		WifiDto data = wifiManager.getWifiInfo(latitude, longitude, scale, startDate, endDate);

		ResponseDto responseDto = new ResponseDto();
		responseDto.setStatus(Constant.OK);
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setData(data);

		log.debug("getWifiInfo out.");
		return new ResponseEntity<>(responseDto, HttpStatus.OK);
	}

	/**
	 * Gets the wifi cluster data counts from ES
	 * @param timeStampFrm
	 * @param timeStampTo
	 * @param tl_lat
	 * @param tl_lon
	 * @param br_lat
	 * @param br_lon
	 * @param locCode
	 * @return
	 * @throws DataNotFoundException
	 */
	@GetMapping(value = ControllerUrl.WIFI_CLUSTER, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getWifiDataClusters(@RequestParam(value = "timeStampFrm", required = true) final String timeStampFrm,
                                                           @RequestParam(value = "timeStampTo", required = true) final String timeStampTo,
                                                           @RequestParam(value = "tl_lat", required = true) final String tl_lat,
                                                           @RequestParam(value = "tl_lon", required = true) final String tl_lon,
                                                           @RequestParam(value = "br_lat", required = true) final String br_lat,
                                                           @RequestParam(value = "br_lon", required = true) final String br_lon,
                                                           @RequestParam(value = "locCode", required = true) final String locCode,
														   @RequestParam(value = "wifiRequest", required = false, defaultValue = "False") final boolean wifiRequest,
														   @RequestParam(value = "escherRequest", required = false, defaultValue = "False") final boolean escherRequest) throws DataNotFoundException {
		ResponseDto responseDto = new ResponseDto();

		if (log.isDebugEnabled()) {
			log.debug(SecuirtyUtils.removeCFLRChar ("getWifiDataClusters() request params: " + " timeStampFrm= " + timeStampFrm +
					", timeStampTo= " + timeStampTo +
					", tl_lat= "+ tl_lat + ", tl_lon= "+ tl_lon + ", br_lat= "+ br_lat + ", br_lon= "+ br_lon + ", locCode= "+ locCode+ ", wifiRequest= "+ wifiRequest+ ", escherRequest= "+ escherRequest));
		}

		WifiClusterRequestDto wifiClusterRequestDto = new WifiClusterRequestDto();

		wifiClusterRequestDto.setTimeStampFrm(timeStampFrm);
		wifiClusterRequestDto.setTimeStampTo(timeStampTo);
		wifiClusterRequestDto.setTlLat(tl_lat);
		wifiClusterRequestDto.setTlLon(tl_lon);
		wifiClusterRequestDto.setBrLat(br_lat);
		wifiClusterRequestDto.setBrLon(br_lon);
		wifiClusterRequestDto.setLocCode(locCode);
		wifiClusterRequestDto.setEscherRequest(escherRequest);
		wifiClusterRequestDto.setWifiRequest(wifiRequest);

		WifiClusterResponseDto wifiClusterResponseDto = wifiManager.getWifiClusterData(wifiClusterRequestDto);

		responseDto.setStatus(Constant.OK);
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setData(wifiClusterResponseDto);

		return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
	}

	/**
	 * Gets the wificluster info for the given request.
	 * @param timeStampFrm
	 * @param timeStampTo
	 * @param ssid
	 * @param scale
	 * @param locMx
	 * @param locMy
	 * @return
	 * @throws DataNotFoundException
	 */
	@GetMapping(value = ControllerUrl.WIFI_CLUSTER_INFO, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDto> getWifiClusterInfo(@RequestParam(value = "timeStampFrm", required = true) final String timeStampFrm,
                                                          @RequestParam(value = "timeStampTo", required = true) final String timeStampTo,
														  @RequestParam(value = "ssid", required = true) final String ssid,
														  @RequestParam(value = "scale", required = false) final String scale,
                                                          @RequestParam(value = "locMx", required = true) final String locMx,
                                                          @RequestParam(value = "locMy", required = true) final String locMy,
														  @RequestParam(value = "wifiType", required = true) final String wifiType) throws DataNotFoundException {
		ResponseDto responseDto = new ResponseDto();

		if (log.isDebugEnabled()) {
			log.debug(SecuirtyUtils.removeCFLRChar ("getWifiClusterInfo() request params: " + " timeStampFrm= " + timeStampFrm +
					", timeStampTo= " + timeStampTo +
					", ssid= "+ ssid + ", scale= "+ scale + ", locMx= "+ locMx + ", locMy= "+ locMy + ", wifiType= " + wifiType));
		}

		WifiClusterInfoRequestDto infoDto = new WifiClusterInfoRequestDto();

		infoDto.setTimeStampFrm(timeStampFrm);
		infoDto.setTimeStampTo(timeStampTo);
		infoDto.setScale(scale);
		infoDto.setLocMx(locMx);
		infoDto.setLocMy(locMy);
		infoDto.setSsid(ssid);
		infoDto.setWifiType(wifiType);

		WifiClusterInfoResponseDto infoResponseDto = wifiManager.getWifiClusterInfoData(infoDto);

		responseDto.setStatus(Constant.OK);
		responseDto.setMessage(Constant.SUCCESS);
		responseDto.setData(infoResponseDto);

		return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
	}

}