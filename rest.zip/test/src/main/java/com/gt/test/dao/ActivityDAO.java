/**
 * 
 */
package com.harman.dmat.dao;

import java.util.List;
import java.util.Optional;

import com.harman.dmat.common.dto.ActivitiesDetailsDto;
import com.harman.dmat.common.dto.ActivityCommentDto;
import com.harman.dmat.common.dto.ActivityDTO;
import com.harman.dmat.common.dto.ActivityShareDto;

/**
 * The Interface ActivityDAO.
 *
 * @author insgupta06
 */
public interface ActivityDAO {

	/**
	 * Saves the activity.
	 *
	 * @param activityDto
	 *            the activity dto
	 */
	public void saveActivity(ActivityDTO activityDto);

	/**
	 * Gets created activity list.
	 * 
	 * @return list of created activities.
	 */
	public List<ActivitiesDetailsDto> getCreatedActivities();

	/**
	 * Gets assigned activities list.
	 * 
	 * @return list of created activities.
	 */
	public List<ActivitiesDetailsDto> getAssignedActivities();

	/**
	 * Delete activity.
	 *
	 * @param activityId
	 *            the activity id
	 */
	public void deleteActivity(Integer activityId);

	/**
	 * Creates the activity status.
	 *
	 * @param shareActivityId
	 *            the share activity id
	 * @param status
	 *            the status
	 */
	public void createActivityStatus(Integer shareActivityId, String status);

	/**
	 * Share activity.
	 *
	 * @param activityShareDto
	 *            the activity share dto
	 * @param integer
	 */
	public void shareActivity(ActivityShareDto activityShareDto, Integer integer);

	/**
	 * Creates the comment.
	 *
	 * @param activityCommentDto
	 *            the activity comment dto
	 */
	public void createComment(ActivityCommentDto activityCommentDto);

	/**
	 * Gets the comments.
	 *
	 * @param activityId
	 *            the activity id
	 * @return the comments
	 */
	public List<ActivityCommentDto> getComments(Integer activityId);

	/**
	 * Gets the share activity.
	 *
	 * @return the share activity
	 */
	public List<ActivitiesDetailsDto> getShareActivity();

	public boolean getActivity(Integer userid, String activityName);

}
