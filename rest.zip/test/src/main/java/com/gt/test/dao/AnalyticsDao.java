package com.harman.dmat.dao;

import com.harman.dmat.common.dto.AnalyticsResponseDto;
import com.harman.dmat.common.dto.DeviceStatsResponseDto;

import java.util.List;

public interface AnalyticsDao {
    AnalyticsResponseDto getModels(String query, String indices);
    List<DeviceStatsResponseDto> getDeviceStats(String query, String indices, String locCode);
}
