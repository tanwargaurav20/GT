package com.harman.dmat.dao;

import com.harman.dmat.common.dto.BaselineCountyResDto;

public interface BaselineCountyDao {
    BaselineCountyResDto getBaselineCounty(String query, String indices);
}
