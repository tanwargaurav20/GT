package com.harman.dmat.dao;

import com.harman.dmat.common.dto.CellSiteClusterResponseDto;

public interface CellSiteDao {
	CellSiteClusterResponseDto getCellSiteDataClusters(String cellSiteDataClusterQuery, String indices, String locCode);
}
