package com.harman.dmat.dao;

import com.harman.dmat.common.dto.*;

import java.util.List;

/**
 * Data Access Interface for ClientAPI
 */
public interface ClientAPIDao {
    String updatePin(String strICCID, String strPIN);

    String getPin(String strICCID);

    String addDmatLive(List<DataPointsLiveDto> points);

    List<InBuildingClientImageDto> getFilteredDataForUser(int userId, InBuildingFiltersDto inBuildingFiltersDto);

    byte[] getInbuildingImage(int id);

    List<InBuildingLocationDto> getInbuildingLocations(int userId);

    SoftwareVersionDto getSoftwareVersion(SoftwareDto softwareDto);

    String updateVersionNumber(int userId, String imei, String imsi, String versionCode);

    String getLatest();

    String getOlderVersion(String versionCode);

    byte[] getApkData(String version);

    String addDeviceTestSummary(int id, TestResultsWrapper testResultsWrapper);

    String addInbuildingImage(int userId, InbuildingUploadImageDto imageDto);

    String addWifiData(WifiDataDto wifiDataDto, int userId, WifiDataLocDto wifiDataLocDto) throws IllegalAccessException, InstantiationException;
}
