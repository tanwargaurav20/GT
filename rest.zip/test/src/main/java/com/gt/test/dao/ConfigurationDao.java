package com.harman.dmat.dao;

import java.util.Map;

/**
 * The Interface ConfigurationDao.
 */
public interface ConfigurationDao {

	/**
	 * Gets the all configurations.
	 *
	 * @return the all configurations
	 */
	public Map<String, String> getAllConfigurations();
}
