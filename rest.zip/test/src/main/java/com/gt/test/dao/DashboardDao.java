package com.harman.dmat.dao;

import com.harman.dmat.common.dto.*;

import java.util.List;
import java.util.Map;

public interface DashboardDao {

    /**
     * @return
     */
    UserCountDto getUserCount();

    /**
     * @param userType
     * @param offset
     * @param limit
     * @return
     */
    List<UserDto> getUserList(String userType, int offset, int limit);

    /**
     * @param offset
     * @param limit
     * @return
     */
    ApkDetailsDto getApkVersionDetails(int offset, int limit);

    List<FilePreProcessDto> getFilePreProcessingList(String startDate, String endDate);

    List<FilePostProcessDto> getFilePostProcessingList(String startDate, String endDate);

    List<FileProcessStatusDto> getFileProcessStatusList(String startDate, String endDate);

    List<FileProcessDirComparisonDto> getPhysicalDirComparisonList(String startDate, String endDate);

    Map<String, Long[]> getFileCountRecordCount(String startDate, String endDate);

    Map<String, Long> getEsEventsCount(String startDate, String endDate);

    Map<String, List<Integer>> getTestId(String startDate, String endDate);

}
