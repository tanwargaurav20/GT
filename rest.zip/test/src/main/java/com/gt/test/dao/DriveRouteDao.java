package com.harman.dmat.dao;

import java.util.List;

/**
 * @author GTanwar Fetches the data from the ES.
 */
public interface DriveRouteDao {

	public List<String> getLatLon(String files, String indices);
}
