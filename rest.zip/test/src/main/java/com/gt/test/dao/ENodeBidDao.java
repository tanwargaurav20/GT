package com.harman.dmat.dao;

import java.util.List;

public interface ENodeBidDao {
    List<String> getENodeBids(String query, String indices);
}
