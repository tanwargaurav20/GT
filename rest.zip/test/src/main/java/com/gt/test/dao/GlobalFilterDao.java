package com.harman.dmat.dao;

import java.util.List;
import java.util.Map;

import com.harman.dmat.common.dto.*;

/**
 * The Interface GlobalFilterDao.
 *
 * @author prakash.bisht@harman.com
 */
public interface GlobalFilterDao {


	/**
	 * get the status on the basis of userId.
	 *
	 * @param userId the user id
	 * @return the status
	 */
	StatusDto getStatus(Integer userId);
	
	/**
	 * get the model name on the basis of modelId.
	 *
	 * @param modelId the model id
	 * @return the model data
	 */
	String getModelData(Integer modelId);

	/**
	 * get the modelId on the basis of UserId.
	 *
	 * @param userId the user id
	 * @return the model id
	 */
	List<Integer> getModelId(Integer userId);

	/**
	 * get the imei data on the basis of userId.
	 *
	 * @param userId the user id
	 * @return the user imei data
	 */
	List<ImeiDto> getUserImeiData(Integer userId);

	/**
	 * get the mdn data on the basis of userId.
	 *
	 * @param userId the user id
	 * @return the user mdn data
	 */
	List<ImeiDto> getUserMdnData(Integer userId);

	/**
	 * get the model data on the basis of userId.
	 *
	 * @param modelId the model id
	 * @return the user model data
	 */
	ModelDto getUserModelData(Integer modelId);

	/**
	 * Gets the all model data.
	 *
	 * @param offset the offset
	 * @param limit the limit
	 * @return the all model data
	 */
	List<ModelDto> getAllModelData(Integer offset, Integer limit);

	/**
	 * get all the imei data.
	 *
	 * @param offset the offset
	 * @param limit the limit
	 * @return the all imei data
	 */
	List<ImeiDto> getAllImeiData(Integer offset, Integer limit);

	/**
	 * get all the mdn data.
	 *
	 * @param offset the offset
	 * @param limit the limit
	 * @return the all mdn data
	 */
	List<ImeiDto> getAllMdnData(Integer offset, Integer limit);
	
	/**
	 * get all the logs.
	 *
	 * @param offset the offset
	 * @param limit the limit
	 * @return the all logs
	 */
	List<LogMgrDto> getAllLogs(Integer offset, Integer limit);

	/**
	 * get the log data on the basis of user id.
	 *
	 * @param userId the user id
	 * @param offset the offset
	 * @param limit the limit
	 * @return the user log data
	 */
	List<LogMgrDto> getUserLogData(Integer userId, Integer offset, Integer limit);

	/**
	 * get the user data on the basis of user Id.
	 *
	 * @param userId the user id
	 * @return the user state data
	 */
	List<StateDto> getUserStateData(Integer userId);

	/**
	 * get the global filter data on the basis of date.
	 *
	 * @param userId the user id
	 * @param calFilterType the cal filter type
	 * @param date the date
	 * @param mdn the mdn
	 * @param model the model
	 * @param fileName the file name
	 * @param imei the imei
	 * @return the filter results
	 */
	List<GlobalFilterDto> getFilterResults(String userId, String calFilterType,
			String date, String mdn, Integer model, String fileName,
			String imei);

	/**
	 * Gets the user log files.
	 *
	 * @param userId the user id
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param token the token
	 * @param userLimit the user limit
	 * @param fileLimit the file limit
	 * @param offset the offset
	 * @param mdn the mdn
	 * @param model the model
	 * @param imei the imei
	 * @return the user log files
	 */
	List<UserLogFileDto> getUserLogFiles(Integer userId,String startDate, String endDate, String token, Integer userLimit,Integer fileLimit, Integer offset, String mdn, Integer model, String imei);

	/**
	 * Gets the models.
	 *
	 * @param userId the user id
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param globalFilterDtos the global filter dtos
	 * @return the models
	 */
	List<String> getModels(Integer userId, String startDate, String endDate, GlobalFilterRequestDto globalFilterDtos);

	/**
	 * Gets the imeis.
	 *
	 * @param userId the user id
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param globalFilterDtos the global filter dtos
	 * @return the imeis
	 */
	List<String> getImeis(Integer userId, String startDate, String endDate, GlobalFilterRequestDto globalFilterDtos);

	/**
	 * Gets the mdns.
	 *
	 * @param userId the user id
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param globalFilterDtos the global filter dtos
	 * @return the mdns
	 */
	List<String> getMdns(Integer userId, String startDate, String endDate, GlobalFilterRequestDto globalFilterDtos);

	/**
	 * Gets the filtered data from Elastic Search.
	 * @param query
	 * @param indices
	 * @return
	 */
	GlobalFilterDataDto getFilterDataFromES(String query, String indices);

	Map<String, List<UserDto>> getUserGroups();

}
