package com.harman.dmat.dao;

import com.harman.dmat.common.dto.HeatMapResponseDto;

/**
 * All the access calls to Elastic Search for HeatMap will be handled by this class.
 */
public interface HeatMapDao {
    HeatMapResponseDto getHeatMapLocations(String query, String indices, String locCode);
}
