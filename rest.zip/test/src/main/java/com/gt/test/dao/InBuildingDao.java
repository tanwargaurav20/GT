package com.harman.dmat.dao;

import com.harman.dmat.common.dto.InBuildingImageDto;
import com.harman.dmat.common.dto.InBuildingLogViewDto;

import java.util.List;
import java.util.Map;

public interface InBuildingDao {

    Map<String, Object> getInbuildingImage(int imageId);

    List<InBuildingLogViewDto> getLogsByDate(String startDate, String endDate, Integer userId, String indices);

    Map<String, String> getInfoPoints(double xCoordinate, double yCoordinate, String fileName, String indices);

    boolean registerInBuilding(Map<String, Object> inBuildingParameter);
    
    Long registerInBuildingWithoutImage(InBuildingImageDto inBuildingImageDto);

    List<InBuildingImageDto> getInBuildingList(Integer offset, Integer limit, Integer userId, Integer access);

    boolean removeInBuilding(String id);

    long getInBuildingCount(Integer userId, Integer access);

    boolean updateInBuildingImage(Integer imageId, byte[] image, int width, int height);

    long updateInBuildingInfo(InBuildingImageDto inBuildingImageDto);

    List<Integer> getImageIdsToRemoveForLogFiles(List<Integer> inBuildingImageIds, Integer userId);
}
