package com.harman.dmat.dao;

import java.util.List;
import java.util.Map;

import com.harman.dmat.common.dto.EventsInfoDto;
import com.harman.dmat.common.dto.LiveInfoPointsDto;

/**
 * @author GTanwar Fetches the data from the ES.
 */
public interface InfoPointsDao {

	List<String> getInfoPoints(String query, String indices);

	Map<String, Object> getEventInfoPoints(String query);

	LiveInfoPointsDto getLiveInfoPoints(String query, String lat, String lng);

	List<EventsInfoDto> getEventsList(String query, String indices);
}
