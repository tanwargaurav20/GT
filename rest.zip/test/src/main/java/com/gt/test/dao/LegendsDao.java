package com.harman.dmat.dao;

import java.util.List;
import java.util.Optional;

import com.harman.dmat.legends.dto.Kpi;
import com.harman.dmat.legends.dto.KpiInfo;
import com.harman.dmat.legends.dto.NewFixedValueColorDto;
import com.harman.dmat.legends.dto.NewVariableRangeColorDto;
import com.harman.dmat.legends.dto.Template;

public interface LegendsDao {

	List<Kpi> getUserLegends(Long userId, int groupId);

	Kpi getLegendForKpi(Long userId, Long kpiId);

	Template createNewTemplate(Template template);

	Object getDefaultKpiLegends(Long teplateId, Long kpiId);

	int deleteTemplate(Long userId, Long teplateId);

	Template getTemplateForUser(Long userId, Long templateid);

	List<Template> getUserTemplates(Long userId);

	Template updateTeplate(Template teplate);

	List<KpiInfo> getKpiInfo();

	Template applyTeplate(Template teplate);

	void updateTeplate(Template template, Long userId, Long tep);

	void deleteOnlylegends(Template template);

	int[] saveNewVeriableLegends(List<NewVariableRangeColorDto> list, Long teplateId);

	int[] saveNewFixedLegends(List<NewFixedValueColorDto> list, Long teplateId);

	Optional<Long> getTemplateName(Long userId, String templateName);

	int[] updateNewFixedValueColorDto(List<NewFixedValueColorDto> listNewFixedValueColorDto, Optional<Long> templateId);

	void validateAndUpdateDefaultTemplate();
}
