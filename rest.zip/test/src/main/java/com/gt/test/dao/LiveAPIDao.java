package com.harman.dmat.dao;

import java.util.List;

import com.harman.dmat.common.dto.LiveAPIDto;
import com.harman.dmat.common.dto.LiveTrendingDto;

/**
 * @author GTanwar Fetches the data from the Database.
 */
public interface LiveAPIDao {

	/**
	 * Retrieves the all the imei against the requested parameters
	 * 
	 * @return LiveAPIDto
	 */
	public LiveAPIDto getLiveImei(String query);

	/**
	 * Fetches the live trending data
	 * 
	 * @param query
	 * @return
	 */
	public List<LiveTrendingDto> getLiveTrend(String query);

	public List<Integer> getKpiValuesFromPs(List<String> imei);

}
