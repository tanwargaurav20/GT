package com.harman.dmat.dao;

import com.harman.dmat.common.dto.AutoTestReportDto;
import com.harman.dmat.common.dto.EventStatusDto;
import com.harman.dmat.common.dto.LogViewDto;

import java.util.List;
import java.util.Map;

public interface LogViewDao {
    String getFileId(LogViewDto logViewDto);

    String updateEvtStatus(List<LogViewDto> statusList, boolean inProgressStatus);

    List<LogViewDto> getEventsList();
    EventStatusDto getStatusReportCount(String startDate, String endDate);

    List<AutoTestReportDto> getAutoTestReport(String fileName);
}
