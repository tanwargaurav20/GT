package com.harman.dmat.dao;

import com.harman.dmat.common.dto.PostProcLogsDto;

import java.util.List;

public interface PostProcLogsDao {
    String addPostProcLogs(List<PostProcLogsDto> postProcLogsDto);
}
