package com.harman.dmat.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.harman.dmat.common.dto.*;
import com.harman.dmat.common.exception.UserException;

/**
 * The Interface UserDao.
 *
 * @author inasandhu
 */
public interface UserDao {

	/**
	 * Gets the users.
	 *
	 * @return the users
	 * @throws UserException
	 *             the user exception
	 */
	public List<Map<String, Object>> getUsers() throws UserException;

	/**
	 * Gets the user.
	 *
	 * @param userId
	 *            the user id
	 * @return the user
	 * @throws UserException
	 *             the user exception
	 */
	public UserDto getUser(Integer userId) throws UserException;

	/**
	 * Gets the company list.
	 *
	 * @return the company list
	 */
	public List<CompanyDto> getCompanyList();

	/**
	 * Update user password.
	 *
	 * @param userId
	 *            the user id
	 * @param hashPassword
	 *            the hash password
	 * @param passwordReset
	 *            the password reset
	 * @return the boolean
	 */
	public Boolean updateUserPassword(Integer userId, String hashPassword, boolean passwordReset);

	/**
	 * Gets the user count.
	 *
	 * @return the user count
	 */
	public Integer getUserCount();

	/**
	 * Gets the user details.
	 *
	 * @param offset
	 *            the offset
	 * @param limit
	 *            the limit
	 * @param userType
	 *            the user type
	 * @return the user details
	 */
	public List<UserDto> getUserDetails(Integer offset, Integer limit, String userType);

	/**
	 * Register user.
	 *
	 * @param userDto
	 *            the user dto
	 * @return the int
	 */
	public int registerUser(UserDto userDto);

	/**
	 * Check user exist.
	 *
	 * @param userId
	 *            the user id
	 * @return the user dto
	 */
	public UserDto checkUserExist(Integer userId);

	/**
	 * delete the user on the basis of userIds.
	 *
	 * @param userIds
	 *            the user ids
	 * @return the boolean
	 */
	public Boolean deleteUserData(List<Integer> userIds);

	/**
	 * Gets the search user data.
	 *
	 * @param email
	 *            the email
	 * @return the search user data
	 */
	public List<UserDto> getSearchUserData(String email);

	/**
	 * Edits the user status.
	 *
	 * @param userEmail
	 *            the user email
	 * @param roleId
	 *            the role id
	 * @param isActive
	 *            the is active
	 * @return the int
	 */
	public int editUserStatus(String userEmail, int roleId, int isActive);

	/**
	 * Gets the priviledgefor role.
	 *
	 * @param email
	 *            the email
	 * @return the priviledgefor role
	 */
	public UserDto getPriviledgeforRole(String email);

	/**
	 * Gets the privilege data.
	 *
	 * @param roleId
	 *            the role id
	 * @return the privilege data
	 */
	public List<PrivilegeDto> getprivilegeData(Integer roleId);

	/**
	 * Update last login time.
	 *
	 * @param userId
	 *            the user id
	 */
	public void updateLastLoginTime(Integer userId);

	/**
	 * Gets the last login time.
	 *
	 * @param userId
	 *            the user id
	 * @return the last login time
	 */
	public Date getLastLoginTime(Integer userId);

	/**
	 * Upadate access code.
	 *
	 * @param userId
	 *            the user id
	 * @param generatedAccessCode
	 *            the generated access code
	 * @param suspendUser
	 *            the suspend user
	 */
	public void upadateAccessCode(Integer userId, String generatedAccessCode, int suspendUser);

	/**
	 * Gets the admin email.
	 *
	 * @return the admin email
	 */
	public List<String> getAdminEmail();

	/**
	 * Gets the role id.
	 *
	 * @param userId
	 *            the user id
	 * @return the role id
	 */
	public Integer getRoleId(Integer userId);

	/**
	 * Update userdata.
	 *
	 * @param userInfo
	 *            the user info
	 * @return the int
	 */
	public int updateUserdata(Map<String, String> userInfo);

	/**
	 * Gets the inactive users.
	 *
	 * @param days
	 *            the days
	 * @return the inactive users
	 */
	public List<UserDto> getInactiveUsers(int days);

	/**
	 * Edit the role for the user.
	 *
	 * @param userEmail
	 *            the user email
	 * @param newroleId
	 *            the newrole id
	 * @return the integer
	 */
	public Integer editRoleforUser(String userEmail, int newroleId);

	/**
	 * Activate users.
	 *
	 * @param userIds
	 *            the user ids
	 */
	public void activateUsers(List<Integer> userIds);

	/**
	 * edit the user preference.
	 *
	 * @param userPreferenceDto
	 *            the user preference dto
	 * @return the boolean
	 */
	public Boolean saveUserPreferenceData(UserPreferenceDto userPreferenceDto);

	/**
	 * edit the user preference.
	 *
	 * @param userPreferenceDto
	 *            the user preference dto
	 * @return the boolean
	 */
	public Boolean saveUserPreferenceExtentData(UserPreferenceDto userPreferenceDto);

	/**
	 * edit the user preference and states.
	 *
	 * @param userPreferenceDto
	 *            the user preference dto
	 * @param states
	 *            the states
	 * @return the boolean
	 */
	public Boolean saveUserPreferenceData(UserPreferenceDto userPreferenceDto, StringBuilder states);

	/**
	 * Check email exist.
	 *
	 * @param userEmail
	 *            the user email
	 * @return the int
	 */
	public int checkEmailExist(String userEmail);

	/**
	 * Gets the user preference.
	 *
	 * @param userId
	 *            the user id
	 * @return the user preference
	 */
	public UserPreferenceDto getUserPreference(Integer userId);

	/**
	 * Gets the user preference.
	 *
	 * @param states
	 *            the states
	 * @return the user preference
	 */
	public AreaDto getUserPreferredArea(String states);

	/**
	 * Gets the user detail.
	 *
	 * @param userId
	 *            the user id
	 * @return the user detail
	 */
	public UserDto getUserDetail(Integer userId);

	/**
	 * Gets the all user.
	 *
	 * @param offset
	 *            the offset
	 * @param limit
	 *            the limit
	 * @param userType
	 *            the user type
	 * @param token
	 *            the token
	 * @return the all user
	 */
	public List<UserDto> getUserDetails(Integer offset, Integer limit, String userType, String token, String sortBy);

	/**
	 * Gets the roles.
	 *
	 * @return the roles
	 */
	public List<RoleDto> getRoles();

	/**
	 * Gets the listofpreferences.
	 *
	 * @return the listofpreferences
	 */
	public List<PreferenceDto> getListofpreferences();

	/**
	 * Update is first login.
	 *
	 * @param userId
	 *            the user id
	 * @param i
	 *            the i
	 */
	public void updateIsFirstLogin(Integer userId, int i);

	/**
	 * Check value exist.
	 *
	 * @param userId
	 *            the user id
	 * @return the integer
	 */
	public Integer checkValueExist(Integer userId);

	/**
	 * Gets the user by email.
	 *
	 * @param email
	 *            the email
	 * @return the user by email
	 * @throws UserException
	 *             the user exception
	 */
	public UserDto getUserByEmail(String email) throws UserException;

	/**
	 * Gets the companies.
	 *
	 * @return the companies
	 */
	List<CompanyDto> getCompanies();

	/**
	 * Gets the states.
	 *
	 * @return the states
	 */
	List<StateDto> getStates();

	/**
	 * Gets the regions.
	 *
	 * @return the regions
	 */
	List<RegionDto> getRegions();

	/**
	 * Gets the state name.
	 *
	 * @param region
	 *            the region
	 * @return the state name
	 */
	List<String> getStateName(String region);

	/**
	 * Gets the events.
	 *
	 * @return the events
	 */
	List<EventDto> getEvents();

	/**
	 * Gets the accordion info.
	 *
	 * @return the accordion info
	 */
	public AccordionInfo getAccordionInfo();

	/**
	 * Gets the accordion info.
	 *
	 * @param token
	 *            the token
	 * @return the accordion info
	 */
	public AccordionInfo getAccordionInfo(String token);

	/**
	 * Change user status.
	 *
	 * @param statusInfoDto
	 *            the status info dto
	 */
	public void changeUserStatus(StatusInfoDto statusInfoDto);

	/**
	 * Change user status.
	 *
	 * @param token
	 *            the token
	 * @param statusInfoDto
	 *            the status info dto
	 */
	public void changeUserStatus(String token, StatusInfoDto statusInfoDto);

	/**
	 * Delete users.
	 *
	 * @param statusInfoDto
	 *            the status info dto
	 */
	public void deleteUsers(StatusInfoDto statusInfoDto);

	/**
	 * Delete users.
	 *
	 * @param token
	 *            the token
	 * @param statusInfoDto
	 *            the status info dto
	 */
	public void deleteUsers(String token, StatusInfoDto statusInfoDto);

	/**
	 * Send notification.
	 *
	 * @param statusInfoDto
	 *            the status info dto
	 * @return the list
	 */
	public List<UserDto> sendNotification(StatusInfoDto statusInfoDto);

	/**
	 * Send notification.
	 *
	 * @param token
	 *            the token
	 * @param statusInfoDto
	 *            the status info dto
	 * @return the list
	 */
	public List<UserDto> sendNotification(String token, StatusInfoDto statusInfoDto);

	/**
	 * Creates the record.
	 *
	 * @param fileUploadDto
	 *            the file upload dto
	 * @return the long
	 */
	public Long createRecord(FileUploadDto fileUploadDto);

	/**
	 * Gets the list of dowload metadata.
	 *
	 * @param type
	 *            the type
	 * @return the list of dowload metadata
	 */
	public List<FileUploadDto> getListOfDowloadMetadata(String type);

	/**
	 * Save last activity.
	 *
	 * @param lastActivitiyDto
	 *            the last activitiy dto
	 */
	public void saveLastActivity(LastActivitiyDto lastActivitiyDto);

	/**
	 * Gets the last activity.
	 *
	 * @param userId
	 *            the user id
	 * @return the last activity
	 */
	public String getLastActivity(Integer userId);

	/**
	 * Save sim card request.
	 *
	 * @param simRequestDto
	 *            the sim request dto
	 */
	public void saveSimCardRequest(SimRequestDto simRequestDto);

	/**
	 * Gets the device.
	 *
	 * @return the device
	 */
	public List<DeviceDto> getDevice();

	/**
	 * Adds the device.
	 *
	 * @param deviceDto
	 *            the device dto
	 */
	public void addDevice(DeviceDto deviceDto);

	/**
	 * Removes the device.
	 *
	 * @param deviceIds
	 *            the device ids
	 */
	public void removeDevice(List<Integer> deviceIds);

	/**
	 * Edits the device.
	 *
	 * @param deviceDto
	 *            the device dto
	 */
	public void editDevice(DeviceDto deviceDto);

	/**
	 * Adds the excel info.
	 *
	 * @param lines
	 *            the lines
	 */
	public void addExcelInfo(List<String[]> lines);

	/**
	 * Gets the sim info.
	 *
	 * @param iccid
	 *            the iccid
	 * @return the sim info
	 */
	public List<SimInfoDto> getSimInfo(String iccid);

	/**
	 * Adds the os.
	 *
	 * @param osDto
	 *            the os dto
	 */
	public void addOs(OsDto osDto);

	/**
	 * Gets the os.
	 *
	 * @return the os
	 */
	public List<OsDto> getOs();

	/**
	 * Creates the group.
	 *
	 * @param groupDto
	 *            the group dto
	 */
	public List<UserDto> createGroup(GroupDto groupDto);

	/**
	 * Update group.
	 *
	 * @param groupDto
	 *            the group dto
	 */
	public void updateGroup(GroupDto groupDto);

	/**
	 * Delete group.
	 *
	 * @param groupIds
	 *            the group id
	 */

	public void deleteGroup(Integer[] groupIds);

	/**
	 * Gets the groups.
	 *
	 * @return the groups
	 */
	public List<GroupDto> getGroups();

	/**
	 * Gets the group users.
	 *
	 * @return the group users
	 */
	public Map<Integer, List<UserDto>> getGroupUsers();

	/**
	 * Gets the user detail.
	 *
	 * @param userIds
	 *            the user ids
	 * @return the user detail
	 */
	public List<UserDto> getUserDetail(List<Integer> userIds);

	/**
	 * Sets the group request status.
	 *
	 * @param groupRequestDto
	 *            the new group request status
	 */
	public void setGroupRequestStatus(GroupRequestDto groupRequestDto);

	/**
	 * Gets the group admin.
	 *
	 * @param groupId
	 *            the group id
	 * @return the group admin
	 */
	public UserDto getGroupAdmin(Integer groupId);

	/**
	 * Gets the group request.
	 *
	 * @param userId
	 *            the user id
	 * @return the group request
	 */
	public List<GroupRequestDto> getGroupRequest(Integer userId);

	/**
	 * Gets the user brief info.
	 *
	 * @param offset
	 *            the offset
	 * @param limit
	 *            the limit
	 * @return the user brief info
	 */
	public List<UserDto> getUserBriefInfo(Integer offset, Integer limit);

	/**
	 * Gets the sim info.
	 *
	 * @param offset
	 *            the offset
	 * @param limit
	 *            the limit
	 * @return the sim info
	 */
	public SimRequestData getSimInfo(Integer offset, Integer limit);

	/**
	 * Gets the user groups.
	 *
	 * @param loinUserId
	 *            the loin user id
	 * @return the user groups
	 */
	public List<GroupDto> getUserGroups(Integer loinUserId);

	/**
	 * Gets the group users.
	 *
	 * @param loinUserId
	 *            the loin user id
	 * @return the group users
	 */
	public Map<Integer, List<UserDto>> getGroupUsers(Integer loinUserId);

	/**
	 * Checks if is unique email.
	 *
	 * @param email
	 *            the email
	 * @return true, if is unique email
	 */
	boolean isUniqueEmail(String email);

	/**
	 * Checks if is conatin admin.
	 *
	 * @param users
	 *            the users
	 * @return true, if is conatin admin
	 */
	public boolean isConatinAdminSuperAdmin(List<Integer> users);

	/**
	 * Gets the record.
	 *
	 * @param name
	 *            the name
	 * @param type
	 *            the type
	 * @return the record
	 */
	public Optional<Long> getRecord(String name, String type);

	/**
	 * Update record.
	 *
	 * @param id
	 *            the id
	 * @param fileUploadDto
	 *            the file upload dto
	 * @return the int
	 */
	public int updateRecord(Long id, FileUploadDto fileUploadDto);

	/**
	 * Gets the group request count.
	 *
	 * @param userId
	 *            the user id
	 * @return the group request count
	 */
	boolean getGroupRequestCount(Integer userId);

	/**
	 * Checks if is activity shared.
	 *
	 * @param userId
	 *            the user id
	 * @return the boolean
	 */
	public Boolean isActivityShared(Integer userId);

	public boolean isUniqueDevice(String deviceName, String deviceModel);

	String getFileUploadDto(Integer id);

	public void deletFileUploadDto(Integer fileId);

	public Boolean checkIFTheGroupNameAvailable(String groupName);

	public boolean storeUserFeedback(FeedBackDto feedBackDto);

	public List<SoftwareVersionDto> getSoftwareList();

	public Boolean deleteSoftware(int softwareId);

	public Boolean setLatestSoftware(int softwareId, int osId, boolean latest);

	public String registerSoftware(SoftwareVersionDto softwareVersionDto);

	public EventDtos getEventsLegends(EventsBodyDto eventsBodyDto);

	public List<EventsCountDto> getEventsCount(EventsBodyDto eventsBodyDto);
}
