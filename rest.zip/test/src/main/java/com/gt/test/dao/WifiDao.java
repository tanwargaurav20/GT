package com.harman.dmat.dao;

import com.harman.dmat.common.dto.WifiClusterInfoResponseDto;
import com.harman.dmat.common.dto.WifiClusterResponseDto;
import com.harman.dmat.common.dto.WifiDto;

public interface WifiDao {

	WifiDto getWifiInfo(String query);
	WifiClusterResponseDto getWifiDataClusters(String wifiType, String dataPointType, String wifiDataClusterQuery, String indices, String locCode);
	WifiClusterInfoResponseDto getWifiDataClusterInfo(String dataPointType, String wifiClusterInfoQuery, String indices, String ssid, String wifiType);
}
