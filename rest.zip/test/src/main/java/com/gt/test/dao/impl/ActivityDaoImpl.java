/**
 * 
 */
package com.harman.dmat.dao.impl;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.Optional;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;

import com.harman.dmat.common.config.BaseDao;
import com.harman.dmat.common.dto.ActivitiesDetailsDto;
import com.harman.dmat.common.dto.ActivityCommentDto;
import com.harman.dmat.common.dto.ActivityDTO;
import com.harman.dmat.common.dto.ActivityShareDto;
import com.harman.dmat.common.security.User;
import com.harman.dmat.dao.ActivityDAO;
import com.harman.dmat.enums.LogActivityStatus;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class ActivityDaoImpl.
 *
 * @author insgupta06
 */

/** The Constant log. */
@Slf4j
@Repository
public class ActivityDaoImpl extends BaseDao implements ActivityDAO {

	/**
	 * Saves the activity.
	 *
	 * @param activityDto
	 *            the activity dto
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.ActivityDAO#saveActivity(com.harman.dmat.common.dto.
	 * ActivityDTO)
	 */
	@Override
	public void saveActivity(ActivityDTO activityDto) {
		final String sql = "insert into user_log_activity (USER_ID, DEFINITION_EXPRESION, ZOOM_LEVEL, XY_POINTS,STATUS,GEO_POLYGON, TEST_ID, ACTIVITY_NAME,FILE_NAME)"
				+ "VALUES (?, ?, ?, ?,?,?,?,?,?)";
		final Integer loginUserId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();

		final KeyHolder keyHolder = new GeneratedKeyHolder();
		getJdbcTemplate().update((PreparedStatementCreator) connection -> {
			final PreparedStatement ps = connection.prepareStatement(sql, new String[] { "activity_id" });
			ps.setInt(1, loginUserId);
			ps.setString(2, activityDto.getDefinitionExpression());
			ps.setInt(3, activityDto.getZoomLevel());
			ps.setString(4, activityDto.getXyPoints());
			ps.setString(5, LogActivityStatus.PENDING.name());
			ps.setString(6, activityDto.getGeoPolygon());
			ps.setString(7, activityDto.getTestIds());
			ps.setString(8, activityDto.getActivityName());
			ps.setString(9, activityDto.getFileNames());
			return ps;
		}, keyHolder);

		final long activityId = keyHolder.getKey().longValue();
		final StringBuilder logsql = new StringBuilder("insert into activity_log_mapping (ACTIVITY_ID, FILE_NAME) VALUES");
		
		String[] fileNamesArray = activityDto.getFileNames().split(",");
		for (final String fileName : fileNamesArray) {
			logsql.append("(");
			logsql.append(activityId + ", '" + fileName + "'");
			logsql.append("),");
		}
		logsql.replace(logsql.length() - 1, logsql.length(), "");
		getJdbcTemplate().update(logsql.toString());

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.ActivityDAO#getCreatedActivities()
	 */
	@Override
	public List<ActivitiesDetailsDto> getCreatedActivities() {
		final Integer loginUserId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();
		final String loginUserName = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserName();
		final String sql = "select a.status,a.GEO_POLYGON,a.TEST_ID,a.USER_ID,a.ACTIVITY_ID,a.ACTIVITY_NAME,a.DEFINITION_EXPRESION,a.ZOOM_LEVEL,a.XY_POINTS,a.CreatedTimestamp,a.FILE_NAME from user_log_activity a "
				+ "join activity_log_mapping b on a.ACTIVITY_ID=b.ACTIVITY_ID where a.USER_ID=? group by a.USER_ID,a.ACTIVITY_ID,a.DEFINITION_EXPRESION";
		final List<ActivitiesDetailsDto> activitiesDetailsDtoList = getJdbcTemplate().query(sql,
				new Object[] { loginUserId },
				new BeanPropertyRowMapper<ActivitiesDetailsDto>(ActivitiesDetailsDto.class));
		for (final ActivitiesDetailsDto activitiesDetailsDto : activitiesDetailsDtoList) {
			final Integer activityId = activitiesDetailsDto.getActivityId();
			final String sqlLogId = "SELECT FILE_NAME FROM activity_log_mapping where ACTIVITY_ID=" + activityId;
			final List<String> fileNamesList = getJdbcTemplate().queryForList(sqlLogId, String.class);
			activitiesDetailsDto.setFileNames(fileNamesList);
			activitiesDetailsDto.setUserName(loginUserName);
		}
		return activitiesDetailsDtoList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.ActivityDAO#getAssignedActivities()
	 */
	@Override
	public List<ActivitiesDetailsDto> getAssignedActivities() {
		final Integer loginUserId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();
		final String loginUserName = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserName();
		final String sql = "select a.GEO_POLYGON,a.TEST_ID,a.status,a.USER_ID,a.ACTIVITY_ID,a.ACTIVITY_NAME,a.DEFINITION_EXPRESION,a.ZOOM_LEVEL,a.XY_POINTS,a.CreatedTimestamp,a.FILE_NAME from user_log_activity a "
				+ "join activity_log_mapping b on a.ACTIVITY_ID=b.ACTIVITY_ID join log_share_activity c on a.ACTIVITY_ID=c.ACTIVITY_ID "
				+ "where c.USER_ID=? group by a.USER_ID,a.ACTIVITY_ID,a.DEFINITION_EXPRESION";
		final List<ActivitiesDetailsDto> activitiesDetailsDtoList = getJdbcTemplate().query(sql,
				new Object[] { loginUserId },
				new BeanPropertyRowMapper<ActivitiesDetailsDto>(ActivitiesDetailsDto.class));
		for (final ActivitiesDetailsDto activitiesDetailsDto : activitiesDetailsDtoList) {
			final Integer activityId = activitiesDetailsDto.getActivityId();
			final String sqlLogId = "SELECT FILE_NAME FROM activity_log_mapping where ACTIVITY_ID=" + activityId;
			final List<String> fileNamesList = getJdbcTemplate().queryForList(sqlLogId, String.class);
			activitiesDetailsDto.setFileNames(fileNamesList);
			activitiesDetailsDto.setUserName(loginUserName);
		}
		return activitiesDetailsDtoList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.ActivityDAO#deleteActivity(java.lang.Integer)
	 */
	@Override
	public void deleteActivity(Integer activityId) {
		deleteFromActivityLogComment(activityId);
		deleteFromLogShareActivity(activityId);
		deleteFromActivityLogMapping(activityId);
		final String sql = "delete from user_log_activity where ACTIVITY_ID=?";
		log.info("removing activity :{} from the user_log_activity ", activityId);
		getJdbcTemplate().update(sql, activityId);
	}

	private void deleteFromActivityLogComment(Integer activityId) {
		log.info("removing the activity: {} from log_activity_comment table", activityId);
		final String sql = "delete from log_activity_comment where ACTIVITY_ID=?";
		getJdbcTemplate().update(sql, activityId);
	}

	private void deleteFromLogShareActivity(Integer activityId) {
		log.info("removing the activity: {} from log_share_activity table", activityId);
		final String sql = "delete from log_share_activity where ACTIVITY_ID=?";
		getJdbcTemplate().update(sql, activityId);
	}

	private void deleteFromActivityLogMapping(Integer activityId) {
		log.info("removing the activity: {} from activity_log_mapping table", activityId);
		final String sql = "delete from activity_log_mapping where ACTIVITY_ID=?";
		getJdbcTemplate().update(sql, activityId);
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.ActivityDAO#createActivityStatus(java.lang.Integer,
	 * java.lang.String)
	 */
	@Override
	public void createActivityStatus(Integer activityId, String status) {
		final String sql = "Update user_log_activity set status=? where activity_id=?";
		getJdbcTemplate().update(sql, status, activityId);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.ActivityDAO#shareActivity(com.harman.dmat.common.dto.
	 * ActivityShareDto)
	 */
	@Override
	public void shareActivity(ActivityShareDto activityShareDto, Integer userId) {
		final StringBuilder sql = new StringBuilder("insert into log_share_activity (ACTIVITY_ID,USER_ID) VALUES(?,?)");
		getJdbcTemplate().update(sql.toString(), activityShareDto.getActivityId(), userId);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.ActivityDAO#createComment(com.harman.dmat.common.dto.
	 * ActivityCommentDto)
	 */
	@Override
	public void createComment(ActivityCommentDto activityCommentDto) {

		final String sql = "insert into log_activity_comment (LOG_SHARE_ACTIVITY_ID,ACTIVITY_ID,COMMENT,USER_ID)"
				+ "VALUES (?, ?,?,?)";
		getJdbcTemplate().update(sql, activityCommentDto.getLogShareActivityId(), activityCommentDto.getActivityId(),
				activityCommentDto.getComment(), activityCommentDto.getUserId());

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.ActivityDAO#getComments(java.lang.Integer)
	 */
	@Override
	public List<ActivityCommentDto> getComments(Integer activityId) {
		final String sql = "select users.USER_ID,(users.first_name || ' ' || users.last_name ) as userName,a.CreatedTimestamp,a.LOG_SHARE_ACTIVITY_ID,a.comment from log_activity_comment a left join users on a.user_id=users.user_id left join log_share_activity b on a.LOG_SHARE_ACTIVITY_ID=b.ID left join user_log_activity c on b.ACTIVITY_ID=c.ACTIVITY_ID where c.ACTIVITY_ID=? or a.activity_id=? group by a.id,users.user_id";
		return getJdbcTemplate().query(sql, new Object[] { activityId, activityId },
				new BeanPropertyRowMapper<ActivityCommentDto>(ActivityCommentDto.class));
	}

	@Override
	public List<ActivitiesDetailsDto> getShareActivity() {
		final Integer loginUserId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();

		final String sql = "select a.status,a.GEO_POLYGON,a.TEST_ID,a.FILE_NAME, d.id as shareActivityId,users.USER_ID,(users.first_name || ' ' || users.last_name ) as userName,a.ACTIVITY_ID,a.ACTIVITY_NAME,a.DEFINITION_EXPRESION,a.ZOOM_LEVEL,a.XY_POINTS,a.CreatedTimestamp from user_log_activity a join log_share_activity d on a.activity_id=d.activity_id join users on a.user_id=users.user_id"
				+ " join activity_log_mapping b on a.ACTIVITY_ID=b.ACTIVITY_ID where d.USER_ID=? group by a.ACTIVITY_ID,d.id, users.USER_ID";
		final List<ActivitiesDetailsDto> activitiesDetailsDtoList = getJdbcTemplate().query(sql,
				new Object[] { loginUserId },
				new BeanPropertyRowMapper<ActivitiesDetailsDto>(ActivitiesDetailsDto.class));
		for (final ActivitiesDetailsDto activitiesDetailsDto : activitiesDetailsDtoList) {
			final Integer activityId = activitiesDetailsDto.getActivityId();
			final String sqlLogId = "SELECT FILE_NAME FROM activity_log_mapping where ACTIVITY_ID=" + activityId;
			final List<String> fileNamesList = getJdbcTemplate().queryForList(sqlLogId, String.class);
			activitiesDetailsDto.setFileNames(fileNamesList);
		}
		return activitiesDetailsDtoList;
	}

	@Override
	public boolean getActivity(Integer userid, String activityName) {
		String sql = "select count(*)  from user_log_activity where activity_name=? AND user_id=?";
		Optional<Integer> noOfRecordFound =  Optional
				.of(getJdbcTemplate().queryForObject(sql, new Object[] {  activityName,userid }, Integer.class));
		return noOfRecordFound.isPresent() && noOfRecordFound.get() > 0;
	}
}
