package com.harman.dmat.dao.impl;

import com.esri.hex.HexXY;
import com.harman.dmat.common.dto.*;
import com.harman.dmat.dao.AnalyticsDao;
import com.harman.dmat.utils.EsClient;
import com.harman.dmat.utils.Utill;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.script.mustache.SearchTemplateRequestBuilder;
import org.elasticsearch.script.mustache.SearchTemplateResponse;
import org.elasticsearch.search.aggregations.*;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import javax.inject.Inject;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
@Repository
public class AnalyticsDaoImpl implements AnalyticsDao {
    @Inject
    Environment environment;

    /**
     * Gets the unique models for the given search request.
     * @param query
     * @param indices
     * @return
     */
    @Override
    public AnalyticsResponseDto getModels(String query, String indices) {
        AnalyticsResponseDto analyticsResponseDto = new AnalyticsResponseDto();

        final SearchRequest searchRequest = new SearchRequest();
        final String dataPointType = environment.getRequiredProperty("data-point-es-type");
        final String[] sIndices = indices.split(",");
        searchRequest.indices(sIndices).types(dataPointType);

        final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
                .setRequest(searchRequest).setScript(query).setScriptType(ScriptType.INLINE).get();

        for (final Aggregation aggregation : searchResponse.getResponse().getAggregations().asList()) {
            final String aggName = aggregation.getName();
            final Terms terms = searchResponse.getResponse().getAggregations().get(aggName);
            List<String> devices = new ArrayList<String>();

            if (terms.getBuckets().size() > 0) {
                for (int i = 0; i < terms.getBuckets().size(); i++) {
                    String key = terms.getBuckets().get(i).getKeyAsString();
                    devices.add(key);
                }
            }

            Collections.sort(devices);
            analyticsResponseDto.setModels(devices);
        }

        return analyticsResponseDto;
    }

    /**
     * Get device stats for the given request.
     * @param query
     * @param indices
     * @param locCode
     * @return
     */
    @Override
    public List<DeviceStatsResponseDto> getDeviceStats(String query, String indices, String locCode) {
        final SearchRequest searchRequest = new SearchRequest();
        final String dataPointType = environment.getRequiredProperty("data-point-es-type");
        final String[] sIndices = indices.split(",");
        searchRequest.indices(sIndices).types(dataPointType);

        List<DeviceStatsResponseDto> deviceStatsResponses = new ArrayList<DeviceStatsResponseDto>();
        Map<String, String> fileNameMap = new HashMap<>();

        final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
                .setRequest(searchRequest).setScript(query).setScriptType(ScriptType.INLINE).get();
        final Aggregations aggregations = searchResponse.getResponse().getAggregations();

        if (aggregations != null) {
            for (final Aggregation aggregation : aggregations.asList()) {
                final String aggName = aggregation.getName();
                final Terms terms = searchResponse.getResponse().getAggregations().get(aggName);

                if (terms.getBuckets().size() > 0) {
                    for (int i = 0; i < terms.getBuckets().size(); i++) {
                        String fileName = terms.getBuckets().get(i).getKeyAsString();

                        for (final Aggregation locAggs : terms.getBuckets().get(i).getAggregations().asList()) {
                            final String locAggsName = locAggs.getName();
                            final Terms locTerms = terms.getBuckets().get(i).getAggregations().get(locAggsName);
                            if (locTerms.getBuckets().size() > 0) {
                                locTerms.getBuckets().forEach(x -> {
                                    fileNameMap.put(fileName, x.getKey().toString());
                                });
                            }
                        }
                    }
                }
            }

            if(fileNameMap.size() > 0) {
                AtomicInteger id = new AtomicInteger(0);
                Map<String,Long> groupByLocs =  fileNameMap.values().stream().
                        collect(Collectors.groupingBy(Function.identity(),
                                Collectors.counting()));
                for(Map.Entry<String,Long> locs : groupByLocs.entrySet()) {
                    DeviceStatsResponseDto deviceStatsResponseDto = new DeviceStatsResponseDto();
                    AnalyticsGeometryDto geometryDto = new AnalyticsGeometryDto();
                    AnalyticsAttributeDto attributeDto = new AnalyticsAttributeDto();

                    String[] locCodes = locs.getKey().split(":");
                    HexXY hexXY = Utill.getRowColToMxMy(Double.parseDouble(locCode.split("_")[1]), Long.parseLong(locCodes[0]), Long.parseLong(locCodes[1]));
                    geometryDto.setX(hexXY.x());
                    geometryDto.setY(hexXY.y());

                    attributeDto.setMag(locs.getValue());
                    attributeDto.setI(id.incrementAndGet());

                    deviceStatsResponseDto.setGeometry(geometryDto);
                    deviceStatsResponseDto.setAttributes(attributeDto);

                    deviceStatsResponses.add(deviceStatsResponseDto);
                }
            }
        }

        return deviceStatsResponses;
    }
}
