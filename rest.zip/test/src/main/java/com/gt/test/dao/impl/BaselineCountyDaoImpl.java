package com.harman.dmat.dao.impl;

import com.harman.dmat.common.dto.BaselineCountyResDto;
import com.harman.dmat.dao.BaselineCountyDao;
import com.harman.dmat.utils.EsClient;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.script.mustache.SearchTemplateRequestBuilder;
import org.elasticsearch.script.mustache.SearchTemplateResponse;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import javax.inject.Inject;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Repository
public class BaselineCountyDaoImpl implements BaselineCountyDao {
    @Inject
    private Environment environment;

    @Override
    public BaselineCountyResDto getBaselineCounty(String query, String indices) {
        final SearchRequest searchRequest = new SearchRequest();
        final String dataPointType = environment.getRequiredProperty("data-point-es-type");
        final String[] sIndices = indices.split(",");
        searchRequest.indices(sIndices).types(dataPointType);

        final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
                .setRequest(searchRequest).setScript(query).setScriptType(ScriptType.INLINE).get();

        BaselineCountyResDto responseDto = new BaselineCountyResDto();
        searchResponse.getResponse().getAggregations().asList().forEach(aggregation -> {
            Terms terms = searchResponse.getResponse().getAggregations().get(aggregation.getName());

            if (aggregation.getName().equalsIgnoreCase("County")) {
                Map<String, Long> counties = new HashMap<>();
                terms.getBuckets().forEach(bucket -> {
                    counties.put(bucket.getKeyAsString(), bucket.getDocCount());
                });
                responseDto.setCounties(counties);
            }

            if (aggregation.getName().equalsIgnoreCase("StateCode")) {
                Map<String, Long> states = new HashMap<>();
                terms.getBuckets().forEach(bucket -> {
                    states.put(bucket.getKeyAsString(), bucket.getDocCount());
                });
                responseDto.setStates(states);
            }

            if (aggregation.getName().equalsIgnoreCase("VzwRegions")) {
                Map<String, Long> regions = new HashMap<>();
                terms.getBuckets().forEach(bucket -> {
                    regions.put(bucket.getKeyAsString(), bucket.getDocCount());
                });
                responseDto.setRegions(regions);
            }
        });

        return responseDto;
    }
}
