package com.harman.dmat.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.script.mustache.SearchTemplateRequestBuilder;
import org.elasticsearch.script.mustache.SearchTemplateResponse;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHits;
import org.springframework.stereotype.Repository;

import com.esri.hex.HexXY;
import com.harman.dmat.common.dto.CellSiteClusterResponseDto;
import com.harman.dmat.common.dto.CellsiteAttributesDto;
import com.harman.dmat.common.dto.CellsiteFeaturesDto;
import com.harman.dmat.common.dto.FieldAliasDto;
import com.harman.dmat.common.dto.FieldsDto;
import com.harman.dmat.common.dto.GeometryDto;
import com.harman.dmat.common.dto.SpatialReferenceDto;
import com.harman.dmat.dao.CellSiteDao;
import com.harman.dmat.utils.EsClient;
import com.harman.dmat.utils.Utill;

@Repository

public class CellSiteDaoImpl implements CellSiteDao {

	@Override
	public CellSiteClusterResponseDto getCellSiteDataClusters(String cellSiteDataClusterQuery, String indices,
			String locCode) {
		CellSiteClusterResponseDto responseDto = new CellSiteClusterResponseDto();

		final SearchRequest searchRequest = new SearchRequest();
		searchRequest.indices(indices);

		final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
				.setRequest(searchRequest).setScript(cellSiteDataClusterQuery).setScriptType(ScriptType.INLINE).get();

		List<CellsiteFeaturesDto> features = new ArrayList<CellsiteFeaturesDto>();

		List<FieldsDto> fieldsList = new ArrayList<>();
		FieldsDto fieldsDto10 = new FieldsDto();
		fieldsDto10.setName("ID");
		fieldsDto10.setType("esriFieldTypeOID");
		fieldsDto10.setAlias("ID");

		fieldsList.add(fieldsDto10);

		FieldsDto fieldsDto20 = new FieldsDto();
		fieldsDto20.setName("count");
		fieldsDto20.setType("esriFieldTypeDouble");

		fieldsList.add(fieldsDto20);

		FieldsDto fieldsDto30 = new FieldsDto();
		fieldsDto30.setName("sitename");
		fieldsDto30.setType("esriFieldTypeString");

		fieldsList.add(fieldsDto30);

		final Aggregations aggregations = searchResponse.getResponse().getAggregations();
		if (aggregations != null) {
			for (final Aggregation aggregation : searchResponse.getResponse().getAggregations().asList()) {
				final String aggName = aggregation.getName();
				final Terms terms = searchResponse.getResponse().getAggregations().get(aggName);
				AtomicInteger id = new AtomicInteger(0);
				if (terms.getBuckets().size() > 0) {
					for (int i = 0; i < terms.getBuckets().size(); i++) {
						String loc = terms.getBuckets().get(i).getKeyAsString();
						TopHits top_loc = terms.getBuckets().get(i).getAggregations().get("top_loc");
						CellsiteFeaturesDto cellsiteFeaturesDto = new CellsiteFeaturesDto();
						GeometryDto geometryDto = new GeometryDto();
						CellsiteAttributesDto cellsiteAttributesDto = new CellsiteAttributesDto();
						for (SearchHit hit : top_loc.getHits().getHits()) {
							String[] locCodes = loc.split(":");
							HexXY hexXY = Utill.getRowColToMxMy(Double.parseDouble(locCode.split("_")[1]),
									Long.parseLong(locCodes[0]), Long.parseLong(locCodes[1]));
							geometryDto.setX(hexXY.x());
							geometryDto.setY(hexXY.y());
							geometryDto.setLocX((Double) hit.getSource().get("loc_mx"));
							geometryDto.setLocY((Double) hit.getSource().get("loc_my"));
						}
						cellsiteFeaturesDto.setAttributes(cellsiteAttributesDto);
						cellsiteFeaturesDto.setGeometry(geometryDto);
						cellsiteAttributesDto.setLoc(loc);
						cellsiteAttributesDto.setID(Integer.toString(id.incrementAndGet()));

						features.add(cellsiteFeaturesDto);
					}
				}

				SpatialReferenceDto spatRef = new SpatialReferenceDto();
				spatRef.setWkid(102100);

				FieldAliasDto fieldAliasDto = new FieldAliasDto();
				fieldAliasDto.setID("ID");

				responseDto.setObjectIdFieldName("ID");
				responseDto.setFieldAlias(fieldAliasDto);
				responseDto.setGeometryType("esriGeometryPoint");
				responseDto.setSpatialReference(spatRef);
				responseDto.setFields(fieldsList);
				responseDto.setFeatures(features);
			}
		}
		return responseDto;
	}
}