package com.harman.dmat.dao.impl;

import com.google.gson.Gson;
import com.harman.dmat.common.config.BaseDao;
import com.harman.dmat.common.dto.*;
import com.harman.dmat.dao.ClientAPIDao;
import com.harman.dmat.utils.EsClient;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.common.geo.GeoPoint;
import org.elasticsearch.common.xcontent.XContentType;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.inject.Inject;

/**
 * Data Access for ClientAPI calls
 */
@Slf4j
@Repository
public class ClientAPIDaoImpl extends BaseDao implements ClientAPIDao {
    private static String SCHEME = "http";
    private static String HTTPMETHOD = "PUT";
    private static int HTTPSTATUS_OK = 200;
    private static int HTTPSTATUS_CREATED = 201;
    private static String SUCCESS = "Success";
    private static String FAILED = "Failure";
    private static String ES_DATEFORMAT = "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
    private static String GMT = "GMT";

    @Inject
    public Environment environment;

    @Override
    public String updatePin(String strICCID, String strPin) {
        String result = "";
        String updateResult = "";

        final String selectSql = "select (select 1 from \"Encrypt_Decrypt_Master_tbl\" where \"ICCID\" = ?) as value";
        final String updateSql = "update \"Encrypt_Decrypt_Master_tbl\" set \"Pin1\" = ? where \"ICCID\" = ?";
        result = getJdbcTemplate().queryForObject(selectSql, new Object[]{strICCID}, String.class);
        if (result == null) {
            return "Fail";
        } else {
            int status = getJdbcTemplate().update(updateSql, new Object[]{strPin, strICCID});
            if (status > 0)
                updateResult = "Success";
        }
        return updateResult;
    }

    @Override
    public String getPin(String strICCID) {
        String result = "";
        final String sql = "select (select edt.\"Pin1\" from \"Encrypt_Decrypt_Master_tbl\" as edt where edt.\"ICCID\" = ? limit 1) as value";

        result = getJdbcTemplate().queryForObject(sql, new Object[]{strICCID}, String.class);
        if (result == null) {
            return "";
        }
        return result;
    }

    public DataPointsLiveDto getUSStatesCounty(DataPointsLiveDto dataPointsLiveDto) {
        final DataPointsLiveDto localDataPointsLiveDto = dataPointsLiveDto;
        final String pointString = removeScientificNotation(dataPointsLiveDto.getX_mercator()+"") + " " + removeScientificNotation(dataPointsLiveDto.getY_mercator()+"");
        if (pointString != "") {
            final String sql = "SELECT s.stusps,c.COUNTYNS,s.VZ_Regions, (case when s.ID_Country=244 then 'USA' else s.VZ_REGIONS end) as country, st_geometry( 'point( " + pointString + " )', 3857) as shape FROM sde.counties_wm AS c JOIN sde.states_wm s ON c.STATEFP = s.STATEFP WHERE ST_Intersects(c.shape, st_geometry( 'point( " + pointString + " )', 3857))";

            dataPointsLiveDto = getMapJdbcTemplate().query(sql, (ResultSetExtractor<DataPointsLiveDto>) rs -> {
                while (rs.next()) {
                    localDataPointsLiveDto.setStatecode(rs.getString("stusps"));
                    localDataPointsLiveDto.setCounty_ns(rs.getString("COUNTYNS"));
                    localDataPointsLiveDto.setVZ_Regions(rs.getString("VZ_Regions"));
                    localDataPointsLiveDto.setCountry(rs.getString("country"));
                    localDataPointsLiveDto.setShape(rs.getString("shape"));
                }
                return localDataPointsLiveDto;
            });
        }

        return dataPointsLiveDto;
    }

    public String removeScientificNotation(String scientificNotation){
        String retunrStr = "";
        try {
            Double scientificDouble = Double.parseDouble(scientificNotation);
            NumberFormat nf = new DecimalFormat("################################################.###########################################");
            retunrStr = nf.format(scientificDouble);
            //log.debug("decimalString:"+retunrStr);
        } catch (Exception e) {
            log.error("Error Converting Scientific Notation to Number  "+scientificNotation +"  "+e.getMessage(), e);
        }
        return retunrStr;
    }


    public WifiDataLocDto getWifiUSStatesCounty(WifiDataLocDto wifiDataLocDto) throws IllegalAccessException, InstantiationException {
        final WifiDataLocDto localWifiDataLocDto = wifiDataLocDto;
        final String pointString = localWifiDataLocDto.getLoc_mx() + " " + localWifiDataLocDto.getLoc_my();
        if (pointString != "") {
            final String sql = "SELECT s.stusps,c.COUNTYNS,s.VZ_Regions, (case when s.ID_Country=244 then 'USA' else s.VZ_REGIONS end) as country, st_geometry( 'point( " + pointString + " )', 3857) as shape FROM sde.counties_wm AS c JOIN sde.states_wm s ON c.STATEFP = s.STATEFP WHERE ST_Intersects(c.shape, st_geometry( 'point( " + pointString + " )', 3857))";

            wifiDataLocDto = getMapJdbcTemplate().query(sql, (ResultSetExtractor<WifiDataLocDto>) rs -> {
                while (rs.next()) {
                    localWifiDataLocDto.setStatecode(rs.getString("stusps"));
                    localWifiDataLocDto.setCounty_ns(rs.getString("COUNTYNS"));
                    localWifiDataLocDto.setVZ_Regions(rs.getString("VZ_Regions"));
                    localWifiDataLocDto.setCountry(rs.getString("country"));
                    localWifiDataLocDto.setShape(rs.getString("shape"));
                }
                return localWifiDataLocDto;
            });
        }

        return wifiDataLocDto;
    }

    @Override
    public String addDmatLive(List<DataPointsLiveDto> pointsList) {
        SimpleJdbcInsert simpleJdbcInsert = getClientApiMapSimpleJdbcInsert();
        pointsList.forEach(x -> {
            x = getUSStatesCounty(x);
        });

        String statusStr = "Success";

        List<Map<String, Object>> batchValues = new ArrayList<>(pointsList.size());

        for (DataPointsLiveDto dataPointsLiveDto : pointsList) {
            Map<String, Object> map = new HashMap<>();

            map.put("rsrp", (!dataPointsLiveDto.getRsrp().equalsIgnoreCase("-") ? dataPointsLiveDto.getRsrp() : 0));
            map.put("rsrq", (!dataPointsLiveDto.getRsrq().equalsIgnoreCase("-") ? dataPointsLiveDto.getRsrq() : 0));
            map.put("rssi", (!dataPointsLiveDto.getRssi().equalsIgnoreCase("-") ? dataPointsLiveDto.getRssi() : 0));
            map.put("sinr", (!dataPointsLiveDto.getSinr().equalsIgnoreCase("-") ? dataPointsLiveDto.getSinr() : 0));
            map.put("puschtx", (!dataPointsLiveDto.getPuschTx().equalsIgnoreCase("-") ? dataPointsLiveDto.getPuschTx() : 0));
            map.put("servingcell", (!dataPointsLiveDto.getServingCell().equalsIgnoreCase("-") ? dataPointsLiveDto.getServingCell() : 0));
            map.put("pucchactualtx", (!dataPointsLiveDto.getPucchActualTx().equalsIgnoreCase("-") ? dataPointsLiveDto.getPucchActualTx() : 0));
            map.put("statecode", dataPointsLiveDto.getStatecode());
            map.put("file_name", dataPointsLiveDto.getFilename());
            map.put("dm_user", 0);
            map.put("imei", dataPointsLiveDto.getImei());
            map.put("lat", (!dataPointsLiveDto.getLat().equalsIgnoreCase("-") ? dataPointsLiveDto.getLat() : 0));
            map.put("lng", (!dataPointsLiveDto.getLng().equalsIgnoreCase("-") ? dataPointsLiveDto.getLng() : 0));
            map.put("dm_timestamp", dataPointsLiveDto.getRecordTime());
            map.put("county_ns", dataPointsLiveDto.getCounty_ns());
            map.put("vz_regions", dataPointsLiveDto.getVZ_Regions());
            map.put("bandindicator", (!dataPointsLiveDto.getBandIndicator().equalsIgnoreCase("-") ? dataPointsLiveDto.getBandIndicator() : 0));
            map.put("rat", dataPointsLiveDto.getRat());
            map.put("country", dataPointsLiveDto.getCountry());
            map.put("cdma_nid", (!dataPointsLiveDto.getCdmaNID().equalsIgnoreCase("-") ? dataPointsLiveDto.getCdmaNID() : 0));
            map.put("cdma_sid", (!dataPointsLiveDto.getCdmaSID().equalsIgnoreCase("-") ? dataPointsLiveDto.getCdmaSID() : 0));
            map.put("cdma_ecio", (!dataPointsLiveDto.getCdmaECIO().equalsIgnoreCase("-") ? dataPointsLiveDto.getCdmaECIO() : 0));
            map.put("cdma_bandclass", dataPointsLiveDto.getCdmaBandClass());
            map.put("imsi", dataPointsLiveDto.getImsi());
            map.put("recordsetid", 0);
            map.put("mdn", dataPointsLiveDto.getMdn());
            map.put("pdschthroughput", (!dataPointsLiveDto.getPDSCH().equalsIgnoreCase("-") ? dataPointsLiveDto.getPDSCH() : 0));
            map.put("puschthroughput", (!dataPointsLiveDto.getPUSCH().equalsIgnoreCase("-") ? dataPointsLiveDto.getPUSCH() : 0));
            map.put("macultx", (!dataPointsLiveDto.getMACUL().equalsIgnoreCase("-") ? dataPointsLiveDto.getMACUL() : 0));
            map.put("macdltx", (!dataPointsLiveDto.getMACDL().equalsIgnoreCase("-") ? dataPointsLiveDto.getMACDL() : 0));
            map.put("rlcul", (!dataPointsLiveDto.getRLCUL().equalsIgnoreCase("-") ? dataPointsLiveDto.getRLCUL() : 0));
            map.put("rlcdl", (!dataPointsLiveDto.getRLCDL().equalsIgnoreCase("-") ? dataPointsLiveDto.getRLCDL() : 0));
            map.put("pdcpul", (!dataPointsLiveDto.getPDCPUL().equalsIgnoreCase("-") ? dataPointsLiveDto.getPDCPUL() : 0));
            map.put("pdcpdl", (!dataPointsLiveDto.getPDCPDL().equalsIgnoreCase("-") ? dataPointsLiveDto.getPDCPDL() : 0));

            if(StringUtils.isNotBlank(dataPointsLiveDto.getShape())) {
                map.put("shape", dataPointsLiveDto.getShape());
            }

            if (!dataPointsLiveDto.getLat().trim().equalsIgnoreCase("") && !dataPointsLiveDto.getLng().trim().equalsIgnoreCase("")) {
                batchValues.add(map);
            }
        }

        try {
            if (!simpleJdbcInsert.isCompiled()) {
                simpleJdbcInsert.withTableName("data_points_live_wm").usingGeneratedKeyColumns("objectid");
            }

            int[] status = simpleJdbcInsert.executeBatch(batchValues.toArray(new Map[batchValues.size()]));

            statusStr = (status.length == batchValues.size()) ? "Success" : "Failed";
        } catch(Exception ex) {
            statusStr = "Failed";
            log.error("Exception in inserting DMATLive datapoints "+ex.getMessage());
        }

        return statusStr;
    }

    @Override
    public List<InBuildingClientImageDto> getFilteredDataForUser(int userId, InBuildingFiltersDto inBuildingFiltersDto) {
        final String sql = "select * from getinbuildingfiltereddata(?, ?, ?, ?)";

        return getJdbcTemplate().query(sql, new Object[]{userId,
                inBuildingFiltersDto.getState(),
                inBuildingFiltersDto.getCity(),
                inBuildingFiltersDto.getZip()}, new BeanPropertyRowMapper<>(InBuildingClientImageDto.class));
    }

    @Override
    public byte[] getInbuildingImage(int id) {
        final String sql = "select (select buildingImage from InBuilding where id = ?) as value";

        return getJdbcTemplate().queryForObject(sql, new Object[]{id}, (rs, rowNum) -> rs.getBytes(1));
    }

    @Override
    public List<InBuildingLocationDto> getInbuildingLocations(int userId) {
        List<InBuildingLocationDto> inBuildingLocations = new ArrayList<>();
        final String sql = "select * from getinbuildinglocations(?)";

        inBuildingLocations = getJdbcTemplate().query(sql, new Object[]{userId}, new BeanPropertyRowMapper<InBuildingLocationDto>(InBuildingLocationDto.class));

        return inBuildingLocations;
    }

    @Override
    public SoftwareVersionDto getSoftwareVersion(SoftwareDto softwareDto) {
        final SoftwareVersionDto softwareVersionDto = new SoftwareVersionDto();

        String sql = "";
        if (Integer.parseInt(softwareDto.getSdkLevel()) < 24) {
            sql = "select version, versioncode, buildflavor, variant from software where latest=true and variant=? and buildflavor=23 and versioncode > ?";
        } else {
            sql = "select version, versioncode, buildflavor, variant from software where latest=true and variant=? and buildflavor=24 and versioncode > ?";
        }

        return getJdbcTemplate().query(sql, new Object[]{Integer.parseInt(softwareDto.getVariant()), Integer.parseInt(softwareDto.getVersionCode())}, (ResultSetExtractor<SoftwareVersionDto>) rs -> {
            while (rs.next()) {
                softwareVersionDto.setVersionName(rs.getString("version"));
                softwareVersionDto.setVersionCode(rs.getInt("versioncode"));
                softwareVersionDto.setBuildFlavor(rs.getInt("buildflavor"));
                softwareVersionDto.setVariant(rs.getInt("variant"));
            }

            return softwareVersionDto;
        });
    }

    @Override
    public String updateVersionNumber(int userId, String imei, String imsi, String versionCode) {
        String updateResult = "";
// chaging to remove sql injection 
       // final String updateSql = "update secure_access set version_num="+versionCode+", creation_time=now() where imei=? and imsi=? and dm_user=?";
        final String updateSql = "update secure_access set version_num=?, creation_time=now() where imei=? and imsi=? and dm_user=?";
        int status = getJdbcTemplate().update(updateSql, new Object[]{ versionCode,imei, imsi, userId});

        if (status > 0) {
            updateResult = "Success";
        } else {
            updateResult = "Failed";
        }

        return updateResult;
    }

    public String getLatest() {
        final String sql = "select versioncode from software where latest=true limit 1";

        return getJdbcTemplate().queryForObject(sql, (rs, rowNum) -> rs.getString(1));
    }

    public String getOlderVersion(String versionCode) {
        final String sql = "select (select version from software where version=?) as value";

        return getJdbcTemplate().queryForObject(sql, new Object[]{versionCode}, (rs, rowNum) -> rs.getString(1));
    }

    public byte[] getApkData(String version) {
        final String sql = "select (select apk from software where version = ?) as value";

        return getJdbcTemplate().queryForObject(sql, new Object[]{version}, (rs, rowNum) -> rs.getBytes(1));
    }

    @Transactional
    @Override
    public String addDeviceTestSummary(int secureAccessId, TestResultsWrapper testResultsWrapper) {
        SimpleJdbcInsert simpleJdbcInsert = getClientApiDeviceSimpleJdbcInsert();
        final String sql = "insert into device_test_summary(secureaccessid, filename, summarytestcasename, " +
                "detailsid, total, passed, failed, starttime, endtime) values (?, ?, ?, ?, ?, ?, ?, ?, ? )";

        KeyHolder keyHolder = new GeneratedKeyHolder();

        String strStatus = "";

        for (TestResultsDto testResults : testResultsWrapper.getTestResults()) {

            String testCaseName = testResults.getTestName();

            for (Detail detail : testResults.getDetails()) {
                Map<String, Object> detailsSummaryMap = new HashMap<>();

                if (!StringUtils.isBlank(testCaseName) && (testCaseName.equalsIgnoreCase("HttpSpeedTest") || testCaseName.equalsIgnoreCase("FtpSpeedTest"))) {
                    detailsSummaryMap.put("downloadspeed", detail.getDownloadSpeed());
                    detailsSummaryMap.put("pingduration", detail.getPingDuration());
                    detailsSummaryMap.put("uploadspeed", detail.getUploadSpeed());
                } else if (testCaseName.equalsIgnoreCase("IPV4")) {
                    detailsSummaryMap.put("losspercentage", detail.getLossPercentage());
                    detailsSummaryMap.put("packetreceived", detail.getPacketReceived());
                    detailsSummaryMap.put("packetsent", detail.getPacketSent());
                } else if (testCaseName.equalsIgnoreCase("IPERF")) {
                    detailsSummaryMap.put("bandwidth", detail.getBandwidth());
                    detailsSummaryMap.put("interval", detail.getInterval());
                    detailsSummaryMap.put("transfer", detail.getTransfer());
                } else if (testCaseName.equalsIgnoreCase("VoiceCall")) {
                    detailsSummaryMap.put("actualduration", detail.getActualDuration());
                    detailsSummaryMap.put("configuredduration", detail.getConfiguredDuration());
                    detailsSummaryMap.put("mo", detail.getMo());
                    detailsSummaryMap.put("mt", detail.getMt());
                } else if (testCaseName.equalsIgnoreCase("sms")) {
                    detailsSummaryMap.put("smsdelivered", detail.isSmsDelivered());
                    detailsSummaryMap.put("smssent", detail.isSmsSent());
                    detailsSummaryMap.put("receiver", detail.getReceiver());
                    detailsSummaryMap.put("sender", detail.getSender());
                } else if (testCaseName.equalsIgnoreCase("e911")) {
                    detailsSummaryMap.put("actualduration", detail.getActualDuration());
                    detailsSummaryMap.put("configuredduration", detail.getConfiguredDuration());
                    detailsSummaryMap.put("mo", detail.getMo());
                    detailsSummaryMap.put("mt", detail.getMt());
                }

                detailsSummaryMap.put("starttime", detail.getStartTime());
                detailsSummaryMap.put("endtime", detail.getEndTime());
                detailsSummaryMap.put("iteration", detail.getIteration());
                detailsSummaryMap.put("latitude", detail.getLatitude());
                detailsSummaryMap.put("longitude", detail.getLongitude());
                detailsSummaryMap.put("name", detail.getName());
                detailsSummaryMap.put("teststatus", detail.getTestStatus());
                detailsSummaryMap.put("errormsg", detail.getErrorMsg());

                if (!simpleJdbcInsert.isCompiled()) {
                    simpleJdbcInsert.withTableName("detailssummary").usingGeneratedKeyColumns("detailsid");
                }

                keyHolder = simpleJdbcInsert.executeAndReturnKeyHolder(detailsSummaryMap);

                detail.setDetailsId((int)keyHolder.getKeys().get("detailsid"));
            }

            int[] status = getJdbcTemplate().batchUpdate(sql, new BatchPreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps, int element) throws SQLException {
                    Detail detail = testResults.getDetails().get(element);
                    ps.setInt(1, secureAccessId);
                    ps.setString(2, String.join(",", testResults.getLogFiles()));
                    ps.setString(3, testResults.getTestName());
                    ps.setInt(4, testResults.getDetails().get(element).getDetailsId());
                    ps.setString(5, testResults.getTotal());
                    ps.setString(6, testResults.getPassed());
                    ps.setString(7, testResults.getFailed());
                    ps.setString(8, testResults.getStartTime());
                    ps.setString(9, testResults.getEndTime());
                }

                @Override
                public int getBatchSize() {
                    return testResults.getDetails().size();
                }
            });

            strStatus = status.length > 0 ? SUCCESS : FAILED;
        }

        log.debug("DEVICE TEST SUMMARY STATUS IN DAO "+strStatus);
        return strStatus;
    }

    @Override
    public String addInbuildingImage(int userId, InbuildingUploadImageDto imageDto) {
        SimpleJdbcInsert simpleJdbcInsert = getClientApiInbuildingSimpleJdbcInsert();
        Map<String, Object> parameters = new HashMap<String, Object>();

        parameters.put("image_width", imageDto.getImageWidth());
        parameters.put("image_height", imageDto.getImageHeight());
        parameters.put("buildingimage", imageDto.getImage());
        parameters.put("name", imageDto.getBuildingName());
        parameters.put("buildingaddress", imageDto.getBuildingAddress());
        parameters.put("dm_user", userId);
        parameters.put("access", imageDto.getAccess());
        parameters.put("floorlevel", imageDto.getFloorLevel());
        parameters.put("statecode", imageDto.getState());
        parameters.put("zipcode", imageDto.getZipCode());
        parameters.put("city", imageDto.getCity());

        if (!simpleJdbcInsert.isCompiled()) {
            simpleJdbcInsert.withTableName("InBuilding").usingGeneratedKeyColumns("id");
        }

        int status = simpleJdbcInsert.execute(parameters);

        return status > 0 ? SUCCESS : FAILED;
    }

    @Override
    public String addWifiData(WifiDataDto wifiDataDto, int userId, WifiDataLocDto wifiLocDto) throws IllegalAccessException, InstantiationException{
        WifiDataLocDto wifiDataLocDto = getWifiUSStatesCounty(wifiLocDto);

        List<Map<String, Object>> wifiData = new ArrayList<>();

        wifiData.add(getConnectedMap(wifiDataDto, userId, wifiDataLocDto));

        for (NeighborDto neighbor : wifiDataDto.getNeighbors()) {
            Map<String, Object> map = new HashMap<>();
            map = getConnectedMap(wifiDataDto, userId, wifiDataLocDto);
            map.put("wifitype", "neighbourap");
            map.put("neighbourssid", neighbor.getSsid());
            map.put("neighbourrssi", neighbor.getRssi());
            map.put("neighbourbssid", neighbor.getBssid());
            map.put("neighbourchannel", neighbor.getChannel());
            map.put("neighboursecuritytype", neighbor.getSecurityType());
            map.put("neighbourfrequency", neighbor.getFrequency());

            wifiData.add(map);
        }

        IndexResponse response = null;

        for(Map map : wifiData) {
            response = EsClient.client.prepareIndex(environment.getRequiredProperty("esIndexEndPoint"), environment.getRequiredProperty("esIndexType"))
                    .setSource(new Gson().toJson(map), XContentType.JSON)
                    .get();
        }

        return (response.getResult().toString() == "CREATED" || response.getResult().toString() == "UPDATED" ? SUCCESS : FAILED);
    }

    private Map<String, Object> getConnectedMap(WifiDataDto wifiDataDto, int userId, WifiDataLocDto wifiDataLocDto) {
        final DateFormat inputFormat = new SimpleDateFormat(ES_DATEFORMAT);
        inputFormat.setTimeZone(TimeZone.getTimeZone(GMT));
        Map<String, Object> connectedMap = new HashMap<String, Object>();

        String locStr = wifiDataDto.getLatitude() + "," + wifiDataDto.getLongitude();

        connectedMap.put("wifitype", "servingap");
        connectedMap.put("ssid", wifiDataDto.getConnected().getSsid());
        connectedMap.put("bssid", wifiDataDto.getConnected().getBssid());
        connectedMap.put("rssi", wifiDataDto.getConnected().getRssi());
        connectedMap.put("ipaddress", wifiDataDto.getConnected().getIpAddress());
        connectedMap.put("linkspeed", wifiDataDto.getConnected().getLinkSpeed());
        connectedMap.put("macaddress", wifiDataDto.getConnected().getMacAddress());
        connectedMap.put("networkid", wifiDataDto.getConnected().getNetworkId());
        connectedMap.put("hiddenssid", wifiDataDto.getConnected().getHiddenSsid());
        connectedMap.put("gateway", wifiDataDto.getConnected().getGateway());
        connectedMap.put("networkid", wifiDataDto.getConnected().getNetworkId());
        connectedMap.put("hiddenssid", wifiDataDto.getConnected().getHiddenSsid());
        connectedMap.put("gateway", wifiDataDto.getConnected().getGateway());
        connectedMap.put("netmask", wifiDataDto.getConnected().getNetmask());
        connectedMap.put("encryption", wifiDataDto.getConnected().getEncryption());
        connectedMap.put("dhcpserver", wifiDataDto.getConnected().getDhcpServer());
        connectedMap.put("secondarydns", wifiDataDto.getConnected().getSecondryDns());
        connectedMap.put("channel", Integer.parseInt(wifiDataDto.getConnected().getChannel()));
        connectedMap.put("latitude", wifiDataDto.getLatitude());
        connectedMap.put("longitude", wifiDataDto.getLongitude());
        connectedMap.put("timespent", wifiDataDto.getTimeSpent());
        connectedMap.put("count", wifiDataDto.getCount());
        connectedMap.put("datasent", wifiDataDto.getDataSent());
        connectedMap.put("datareceived", wifiDataDto.getDataReceived());
        connectedMap.put("totaldata", wifiDataDto.getTotalData());
        connectedMap.put("uploaddownloadspeed", wifiDataDto.getUploadDownloadSpeed());
        connectedMap.put("userid", userId);
        connectedMap.put("loc", new GeoPoint(locStr));
        connectedMap.put("loc_mx", wifiDataLocDto.getLoc_mx());
        connectedMap.put("loc_my", wifiDataLocDto.getLoc_my());
        connectedMap.put("loc_2", wifiDataLocDto.getLoc_2());
        connectedMap.put("loc_5", wifiDataLocDto.getLoc_5());
        connectedMap.put("loc_10", wifiDataLocDto.getLoc_10());
        connectedMap.put("loc_25", wifiDataLocDto.getLoc_25());
        connectedMap.put("loc_50", wifiDataLocDto.getLoc_50());
        connectedMap.put("loc_100", wifiDataLocDto.getLoc_100());
        connectedMap.put("loc_200", wifiDataLocDto.getLoc_200());
        connectedMap.put("loc_500", wifiDataLocDto.getLoc_500());
        connectedMap.put("loc_1000", wifiDataLocDto.getLoc_1000());
        connectedMap.put("loc_2000", wifiDataLocDto.getLoc_2000());
        connectedMap.put("loc_4000", wifiDataLocDto.getLoc_4000());
        connectedMap.put("loc_5000", wifiDataLocDto.getLoc_5000());
        connectedMap.put("loc_10000", wifiDataLocDto.getLoc_10000());
        connectedMap.put("loc_15000", wifiDataLocDto.getLoc_15000());
        connectedMap.put("loc_25000", wifiDataLocDto.getLoc_25000());
        connectedMap.put("loc_50000", wifiDataLocDto.getLoc_50000());
        connectedMap.put("loc_75000", wifiDataLocDto.getLoc_75000());
        connectedMap.put("loc_100000", wifiDataLocDto.getLoc_100000());
        connectedMap.put("shape", wifiDataLocDto.getShape());
        connectedMap.put("country", wifiDataLocDto.getCountry());
        connectedMap.put("county_ns", wifiDataLocDto.getCounty_ns());
        connectedMap.put("vz_regions", wifiDataLocDto.getVZ_Regions());
        connectedMap.put("statecode", wifiDataLocDto.getStatecode());
        connectedMap.put("createddate", inputFormat.format(Calendar.getInstance().getTime()));

        return connectedMap;
    }
}