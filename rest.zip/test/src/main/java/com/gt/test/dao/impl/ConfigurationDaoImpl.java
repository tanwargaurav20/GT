package com.harman.dmat.dao.impl;

import java.util.HashMap;
import java.util.Map;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;
import com.harman.dmat.common.config.BaseDao;
import com.harman.dmat.dao.ConfigurationDao;

/**
 * The Class ConfigurationDaoImpl.
 */
@Repository
public class ConfigurationDaoImpl extends BaseDao implements ConfigurationDao {

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.ConfigurationDao#getAllConfigurations()
	 */
	@Override
	public Map<String, String> getAllConfigurations() {
		final String sql = "SELECT param_key,value FROM app_config";

		final Map<String, String> configurationMap = getJdbcTemplate().query(sql,
				(ResultSetExtractor<Map<String, String>>) rs -> {
					final HashMap<String, String> mapRet = new HashMap<String, String>();
					while (rs.next()) {
						mapRet.put(rs.getString("param_key"), rs.getString("value"));
					}
					return mapRet;
				});
		return configurationMap;
	}

}
