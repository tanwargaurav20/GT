package com.harman.dmat.dao.impl;

import com.harman.dmat.common.config.BaseDao;
import com.harman.dmat.common.dto.*;
import com.harman.dmat.dao.DashboardDao;
import com.harman.dmat.enums.UserStatusEnum;
import com.harman.dmat.utils.EsClient;
import com.harman.dmat.utils.Utill;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.script.mustache.SearchTemplateRequestBuilder;
import org.elasticsearch.script.mustache.SearchTemplateResponse;
import org.elasticsearch.search.aggregations.bucket.histogram.InternalDateHistogram;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Repository;

import javax.inject.Inject;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;

@Repository
@Slf4j
public class DashboardDaoImpl extends BaseDao implements DashboardDao {

    private static final DateTimeFormatter dtFmtyyyyMMdd = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private static final String[] esEventsFields;

    static {
        esEventsFields = new String[]{
                "LTEAttRej", "LTEReselToGsmUmtsFail", "LTEAuthRej", "LTEReselFromGsmUmtsFail", "LTEIntraReselFail",
                "LTEIntraHoFail", "LTEMobilityFromEutraFail", "LTEOos", "LTEPdnRej", "LTERlf", "LTERrcConRestRej",
                "LTERrcConRej", "LTEServiceRej", "LTESibReadFailure", "LTETaRej", "LTEVoLTEDrop"
        };
    }

    @Inject
    private Environment environment;

    @Override
    public UserCountDto getUserCount() {

        final String sql = "SELECT "
                + "sum(case when (status = 1 and DATE_PART('day', current_date - last_login) <= 60) then 1 end) AS active, "
                + "sum(case when (status = 1 and DATE_PART('day', current_date - last_login) > 60) then 1 end) AS inacctive, "
                + "sum(case when status = 0 then 1 end)  AS deactive FROM users GROUP BY status";
        log.debug("getUserCount: Query:{}", sql);
        List<Map<String, Object>> resultSet = getJdbcTemplate().queryForList(sql);
        UserCountDto userCountDto = new UserCountDto();
        if (resultSet.size() > 0) {
            Map firstRows = resultSet.get(0);
            userCountDto.setDeactive((Long) firstRows.get("deactive"));
            Map rows1 = resultSet.get(1);
            userCountDto.setActive((Long) rows1.get("active"));
            userCountDto.setInactive((Long) rows1.get("inacctive"));
        }

        return userCountDto;
    }

    @Override
    public List<UserDto> getUserList(String userType, int offset, int limit) {
        log.debug("getUserList in...");

        String sql;
        if (userType.equals(UserStatusEnum.ACTIVE.getValue())) {
            sql = "select first_name, last_name, email from users where status = 1 and DATE_PART('day', current_date - last_login) <= 60 order by first_name, last_name offset ? limit ?";
        } else if (userType.equals(UserStatusEnum.INACTIVE.getValue())) {
            sql = "select first_name, last_name, email from users where status = 1 and DATE_PART('day', current_date - last_login) > 60 order by first_name, last_name offset ? limit ?";
        } else {
            sql = "select first_name, last_name, email from users where status = 0 order by first_name, last_name offset ? limit ?";
        }
        log.debug("SQL Query:-" + sql);

        List<UserDto> resultSet = getJdbcTemplate().query(sql, new Object[]{offset > 0 ? offset - 1 : 1, limit},
                new BeanPropertyRowMapper<>(UserDto.class));

        log.debug("getUserList out.");
        return resultSet;
    }

    @Override
    public ApkDetailsDto getApkVersionDetails(int offset, int limit) {
        log.debug("getApkVersionDetails in...");

        long resultSet = 0;
        if (offset == 1) {
            final String sqlForDataCount = "select count(distinct(version_num)) from secure_access where version_num IS NOT NULL and version_num not like '1.%'";
            log.debug("SQL Query (TotalCount):-" + sqlForDataCount);
            resultSet = getJdbcTemplate().queryForObject(sqlForDataCount, Long.class);
        }

        final String sqlForAPKDetails = "select count(dm_user), version_num  from secure_access where version_num IS NOT NULL and version_num not like '1.%' "
                + "group by version_num order by version_num desc offset ? limit ?";
        log.debug("SQL Query (APK Details):-" + sqlForAPKDetails);
        List<ApkDto> apkDetailResultSet = getJdbcTemplate().query(sqlForAPKDetails, new Object[]{offset > 0 ? offset - 1 : 1, limit},
                new BeanPropertyRowMapper<>(ApkDto.class));

        ApkDetailsDto apkDetailsDto = new ApkDetailsDto();
        apkDetailsDto.setCount(resultSet);
        apkDetailsDto.setApkList(apkDetailResultSet);

        log.debug("getApkVersionDetails out.");
        return apkDetailsDto;
    }

    @Override
    public List<FilePreProcessDto> getFilePreProcessingList(String startDate, String endDate) {
        final String sql = "SELECT pp.processdate, SUM(pp.files_picked) AS filespicked, SUM(pp.zip_count) AS zipfiles, SUM(pp.dlf_count) AS dlffiles, SUM(pp.other_count) AS others, SUM(pp.files_staged) AS staged, " +
                "SUM(pp.files_pre_processed) AS preprocessed, SUM(pre_process_failed) AS failed, SUM(moved_to_workdir) AS mvworkdir, SUM(moved_to_partdir) AS mvpartdir FROM  " +
                "(SELECT date(start_time) AS processdate, files_picked, zip_count, dlf_count, other_count, files_staged, files_pre_processed, pre_process_failed, " +
                "moved_to_workdir, moved_to_partdir FROM pre_process WHERE start_time >= ?::timestamp AND start_time <= ?::timestamp) " +
                "AS pp GROUP BY pp.processdate ORDER BY pp.processdate DESC";
        startDate = startDate + " 00:00:00";
        endDate = endDate + " 23:59:59";
        log.debug("getCurrentDayFilePreProcessingList: startDate: {} endDate:{}", startDate, endDate);
        log.debug("getCurrentDayFilePreProcessingList by date: sql:{}", sql);
        return getJdbcTemplate().query(sql, new Object[]{startDate, endDate}, new BeanPropertyRowMapper<>(FilePreProcessDto.class));
    }

    @Override
    public List<FilePostProcessDto> getFilePostProcessingList(String startDate, String endDate) {
        final String sql = "SELECT pp.processdate, SUM(pp.files_picked) AS filespicked, SUM(pp.part_dir_picked) AS partdir, SUM(pp.total_file_inpartdir) AS partfiles, SUM(pp.files_post_processed) AS filesprocessed, " +
                "SUM(pp.part_files_post_processed) AS partfilesprocessed, SUM(pp.post_process_failed) AS processfailed, SUM(pp.total_files_processed) AS totalfilesprocessed FROM  " +
                "(SELECT date(start_time) AS processdate, files_picked, part_dir_picked, total_file_inpartdir, files_post_processed, part_files_post_processed, " +
                "post_process_failed, total_files_processed FROM post_process WHERE start_time >= ?::timestamp AND start_time <= ?::timestamp) " +
                "AS pp GROUP BY pp.processdate ORDER BY pp.processdate DESC";
        startDate = startDate + " 00:00:00";
        endDate = endDate + " 23:59:59";

        log.debug("getCurrentDayFilePreProcessingList: startDate: {} endDate:{}", startDate, endDate);
        log.debug("getCurrentDayFilePostProcessingList by date: sql: {}", sql);

        return getJdbcTemplate().query(sql, new Object[]{startDate, endDate}, new BeanPropertyRowMapper<>(FilePostProcessDto.class));
    }

    @Override
    public List<FileProcessStatusDto> getFileProcessStatusList(String startDate, String endDate) {
        String sql = "SELECT reftbl.refdate as processdate, efs.ftpFiles, pretbl.preProcessedFiles, logs.postProcessedFiles, logs.postProcessedRecords, evtbl.postProcessedEvents, fldtbl.failedFiles FROM  " +
                "(SELECT (generate_series(?::timestamp, ?::timestamp, '1 day'::interval))::date AS refdate) reftbl LEFT JOIN (SELECT pp.processdate, sum(pp.files_pre_processed) as preProcessedFiles FROM " +
                "(SELECT date(start_time) as processdate, files_pre_processed FROM pre_process WHERE start_time >= ?::timestamp AND start_time <= ?::timestamp) as pp " +
                "GROUP BY pp.processdate) pretbl ON reftbl.refdate = pretbl.processdate LEFT JOIN (SELECT date(last_log_time) as processdate, count(distinct file_name) as postProcessedFiles, sum(es_record_count) as postProcessedRecords " +
                "FROM logs where es_data_status ='complete' and last_log_time >= ?::timestamp AND last_log_time <= ?::timestamp GROUP BY date(last_log_time)) " +
                "logs ON reftbl.refdate = logs.processdate LEFT JOIN (SELECT date(report_date) as processdate, sum(total_files) as ftpFiles FROM eod_file_stats WHERE " +
                "report_date >= ?::timestamp AND report_date <= ?::timestamp GROUP BY date(report_date)) efs ON reftbl.refdate = efs.processdate LEFT JOIN " +
                "(SELECT date(failed_timestamp) as processdate, count(*) as failedFiles FROM  process_failed " +
                "WHERE failed_timestamp >= ?::timestamp AND failed_timestamp <= ?::timestamp GROUP BY date(failed_timestamp)) " +
                "fldtbl ON reftbl.refdate = fldtbl.processdate LEFT JOIN (SELECT date(evt_timestamp) as processdate, count(*) as postProcessedEvents FROM  sde.event_lvanalysis " +
                "WHERE evt_timestamp >= ?::timestamp AND evt_timestamp <= ?::timestamp GROUP BY date(evt_timestamp)) " +
                "evtbl ON reftbl.refdate = evtbl.processdate ORDER BY processdate DESC";
        startDate = startDate + " 00:00:00";
        endDate = endDate + " 23:59:59";

        log.debug("getFileProcessStatusList input: startDate: {} endDate:{}", startDate, endDate);
        log.debug("getFileProcessStatusList sql: {}", sql);

        return getJdbcTemplate().query(sql, new Object[]{startDate, endDate, startDate, endDate, startDate, endDate,
                startDate, endDate, startDate, endDate, startDate, endDate}, new BeanPropertyRowMapper<>(FileProcessStatusDto.class));
    }

    @Override
    public List<FileProcessDirComparisonDto> getPhysicalDirComparisonList(String startDate, String endDate) {
        final String sql = "select DATE(report_date) AS processDate, SUM(ind_files) AS individualFiles, SUM(part_dir) AS partDirCount, SUM(part_files) AS totalPartFiles, SUM(failed) AS filesFailed " +
                "FROM eod_file_stats WHERE report_date >= ?::timestamp AND report_date <= ?::timestamp GROUP BY date(report_date) ORDER BY processDate DESC";
        startDate = startDate + " 00:00:00";
        endDate = endDate + " 23:59:59";

        log.debug("getPhysicalDirComparisonList: startDate: {} endDate:{}", startDate, endDate);
        log.debug("getPhysicalDirComparisonList by date: sql: {}", sql);

        return getJdbcTemplate().query(sql, new Object[]{startDate, endDate}, new BeanPropertyRowMapper<>(FileProcessDirComparisonDto.class));
    }

    @Override
    public Map<String, List<Integer>> getTestId(String startDate, String endDate) {
        Map<String, List<Integer>> testIds = new HashMap<>();
        String sql = "select date(last_log_time) as processdate, id from logs where es_data_status ='complete' and last_log_time >= ?::timestamp AND last_log_time <= ?::timestamp";
        startDate = String.join(" ", startDate, "00:00:00");
        endDate = String.join(" ", endDate, "23:59:59");
        log.debug("getTestId startDate: {}; endDate:{}; query: {}", startDate, endDate, sql);
        List<Map<String, Object>> resultSet = getJdbcTemplate().queryForList(sql, new Object[]{startDate, endDate});
        resultSet.forEach(map -> {
            String date = map.get("processdate").toString();
            int testId = Integer.parseInt(map.get("id").toString());
            List<Integer> indTestIds;
            if (testIds.containsKey(date)) {
                indTestIds = testIds.get(date);
                indTestIds.add(testId);
                testIds.put(date, indTestIds);
            } else {
                indTestIds = new ArrayList<>();
                indTestIds.add(testId);
            }
            testIds.put(date, indTestIds);
        });
        return testIds;
    }

    @Override
    public Map<String, Long[]> getFileCountRecordCount(String startDate, String endDate) {
        Map<String, Long[]> fileRecordCountResult = new HashMap<>();
        String query = "{\"size\": 0,\"query\": {\"bool\": {\"must\": {\"range\": {\"TimeStamp\": " +
                "{\"from\": \"START_DATE\",\"to\": \"END_DATE\",\"include_lower\": true,\"include_upper\": true}}}}}," +
                "\"_source\": {\"includes\": [\"FileName\",\"TestId\"]},\"aggs\": {\"langs\": " +
                "{\"terms\": {\"field\": \"FileName\",\"size\": 50000}," +
                "\"aggs\": {\"langs\": {\"terms\": {\"field\": \"TestId\"}}}}}}";

        final String dataPointType = environment.getRequiredProperty("data-point-es-type");
        Map<String, List<Integer>> dateBasedTestIds = getTestId(startDate, endDate);
        String[] indices = Utill.getIndex(startDate, endDate).split(",");

        String[] sStartDate = startDate.split("-");
        String[] sEndDate = endDate.split("-");
        LocalDate startDateInst = LocalDate.of(Integer.parseInt(sStartDate[0]), Integer.parseInt(sStartDate[1]), Integer.parseInt(sStartDate[2]));
        LocalDate endDateInst = LocalDate.of(Integer.parseInt(sEndDate[0]), Integer.parseInt(sEndDate[1]), Integer.parseInt(sEndDate[2]));

        findEsFileRecordCount(fileRecordCountResult, query, indices, dataPointType, dateBasedTestIds, startDateInst, endDateInst);

        return fileRecordCountResult;
    }

    private void findEsFileRecordCount(Map<String, Long[]> fileRecordCountResult, String query,
                                       String[] indices, String dataPointType, Map<String, List<Integer>> dateBasedTestIds, LocalDate startDate, LocalDate endDate) {

        String esQuery = query.replace("START_DATE", startDate.format(dtFmtyyyyMMdd)).replace("END_DATE", endDate.format(dtFmtyyyyMMdd));
        Map<String, List<Long[]>> fileRecordCount = new HashMap<>();
        SearchRequest searchRequest = new SearchRequest();
        searchRequest.indices(indices).types(dataPointType);
        log.debug("getFileCountRecordCount index: {}; query: {}", indices, esQuery);
        SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
                .setRequest(searchRequest).setScript(esQuery).setScriptType(ScriptType.INLINE).get();
        searchResponse.getResponse().getAggregations().asList().forEach(aggregation -> {
            Terms terms = searchResponse.getResponse().getAggregations().get(aggregation.getName());
            terms.getBuckets().forEach(bucket -> {
                String fileName = bucket.getKeyAsString();
                List<Long[]> testIds = new ArrayList<>();
                Terms testIdTerm = bucket.getAggregations().get("langs");
                testIdTerm.getBuckets().forEach(testIdBucket -> testIds.add(new Long[]{(long) testIdBucket.getKeyAsNumber(), testIdBucket.getDocCount()}));
                fileRecordCount.put(fileName, testIds);
            });
        });
        if (fileRecordCount.size() < 50000) {
            fileRecordCountResult.putAll(getLogFilesCount(fileRecordCount, dateBasedTestIds, startDate, endDate));
        } else {
            long numberOfDays = startDate.until(endDate, ChronoUnit.DAYS) + 1;
            int[] parts = splitIntoParts(((Long) numberOfDays).intValue(), 2);
            for (int index = 0; index < parts.length; index++) {
                int startDay = 0;
                if (index != 0) {
                    int intIndex = index - 1;
                    do {
                        startDay += parts[intIndex];
                        intIndex--;
                    } while (intIndex >= 0);
                }
                LocalDate intStartDate = startDate.plusDays(startDay);
                LocalDate intEndDate = intStartDate.plusDays((index + 1 != parts.length) ? parts[index] - 1 : parts[index]);
                findEsFileRecordCount(fileRecordCountResult, query, indices, dataPointType, dateBasedTestIds, intStartDate, intEndDate);
            }
        }
    }

    private Map<String, Long[]> getLogFilesCount(Map<String, List<Long[]>> fileRecordCount, Map<String, List<Integer>> testIds, LocalDate startDate, LocalDate endDate) {
        Map<String, Long[]> logFilesCountMap = new HashMap<>();
        long numberOfDays = startDate.until(endDate, ChronoUnit.DAYS) + 1;
        for (int day = 0; day < numberOfDays; day++) {
            LocalDate dayInst = startDate.plusDays(day);
            String dateString = dayInst.format(dtFmtyyyyMMdd);
            List<Integer> testIdsForDay = testIds.getOrDefault(dateString, null);
            if (testIdsForDay != null) {
                fileRecordCount.forEach((key, value) -> {
                    Optional<Long[]> optional = value.stream().filter(e -> testIdsForDay.contains(e[0].intValue())).findFirst();
                    Long[] indTestId = optional.orElse(null);
                    if (indTestId != null) {
                        if (logFilesCountMap.containsKey(dateString)) {
                            Long[] fileRecord = logFilesCountMap.get(dateString);
                            logFilesCountMap.put(dateString, new Long[]{fileRecord[0] + 1, fileRecord[1] + indTestId[1]});
                        } else {
                            logFilesCountMap.put(dateString, new Long[]{1L, indTestId[1]});
                        }
                    }
                });
            }
        }
        return logFilesCountMap;
    }


    @Override
    public Map<String, Long> getEsEventsCount(String startDate, String endDate) {
        Map<String, Long> eventsCount = new HashMap<>();
        String query = "{\"size\": 0, \"_source\": { \"includes\": [\"TimeStamp \"]}, \"query\": " +
                "{ \"bool\": { \"must\": [ { \"range\": { \"TimeStamp\": { \"from\": \""+startDate+"\", \"to\": \""+endDate+"\", " +
                "\"include_lower\": true, \"include_upper\": true, \"boost\": 1.0} } }, " +
                "{ \"bool\": { \"should\": [ " + getEventsShouldQuery() + "] } } ] } }," +
                "\"aggs\": {\"agg_by_day\": {\"date_histogram\": {\"field\": \"TimeStamp\", \"interval\":\"day\"}}}}";
        final String dataPointType = environment.getRequiredProperty("data-point-es-type");
        String indices = Utill.getIndex(startDate, endDate);
        final String[] indexArray = indices.split(",");
        SearchRequest searchRequest = new SearchRequest();
        searchRequest.indices(indexArray).types(dataPointType);
        log.debug("getEsEventsCount index: {}; query: {}", indices, query);
        SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
                .setRequest(searchRequest).setScript(query).setScriptType(ScriptType.INLINE).get();
        searchResponse.getResponse().getAggregations().asList().forEach(aggregation ->
                ((InternalDateHistogram) aggregation).getBuckets().forEach(bucket ->
                        eventsCount.put(Utill.esUsDateToDateFormat(bucket.getKeyAsString()), bucket.getDocCount())));
        return eventsCount;
    }

    private static int[] splitIntoParts(int whole, int parts) {
        int[] arr = new int[parts];
        for (int i = 0; i < arr.length; i++)
            whole -= arr[i] = (whole + parts - i - 1) / (parts - i);
        return arr;
    }

    private static String getEventsShouldQuery() {
        StringBuilder eventsQuery = new StringBuilder();
        for (String esField : esEventsFields) {
            eventsQuery.append(",{\"exists\": {\"field\":\"");
            eventsQuery.append(esField).append("\"}}");
        }
        return eventsQuery.toString().replaceFirst(",", "");
    }

}