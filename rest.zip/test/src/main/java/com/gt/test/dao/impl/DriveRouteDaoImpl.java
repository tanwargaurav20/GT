package com.harman.dmat.dao.impl;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.script.mustache.SearchTemplateRequestBuilder;
import org.elasticsearch.script.mustache.SearchTemplateResponse;
import org.elasticsearch.search.SearchHit;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;
import com.harman.dmat.dao.DriveRouteDao;
import com.harman.dmat.utils.EsClient;

/**
 * @author GTanwar Interacts with the ES
 */

@Repository
public class DriveRouteDaoImpl implements DriveRouteDao {

	@Inject
	private Environment environment;

	@Override
	public List<String> getLatLon(String query, String indices) {
		final List<String> list = new ArrayList<>();
		String lat = null;
		String lon = null;
		final SearchRequest searchRequest = new SearchRequest();
		final String dataPointType = environment.getRequiredProperty("data-point-es-type");
		final String[] sIndices = indices.split(",");
		searchRequest.indices(sIndices).types(dataPointType);

		final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
				.setRequest(searchRequest).setScript(query).setScriptType(ScriptType.INLINE).get();

		SearchHit[] searchHits = searchResponse.getResponse().getHits().getHits();
		for (int i = 0; i < searchHits.length - 1; i++) {
			if (searchHits[i].getSource().get("lat") != null && searchHits[i].getSource().get("lon") != null) {
				lat = searchHits[i].getSource().get("lat").toString();
				lon = searchHits[i].getSource().get("lon").toString();
				break;
			} else
				continue;

		}
		list.add("Lat:" + lat);
		list.add("Lon:" + lon);
		return list;
	}

}