package com.harman.dmat.dao.impl;

import com.harman.dmat.dao.ENodeBidDao;
import com.harman.dmat.utils.EsClient;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.script.mustache.SearchTemplateRequestBuilder;
import org.elasticsearch.script.mustache.SearchTemplateResponse;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@Service
public class ENodeBidDaoImpl implements ENodeBidDao {
    @Inject
    Environment environment;

    @Override
    public List<String> getENodeBids(String query, String indices) {
        List<String> eNodeBids = new ArrayList<String>();
        final SearchRequest searchRequest = new SearchRequest();
        final String dataPointType = environment.getRequiredProperty("data-point-es-type");
        final String[] sIndices = indices.split(",");
        searchRequest.indices(sIndices).types(dataPointType);

        final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
                .setRequest(searchRequest).setScript(query).setScriptType(ScriptType.INLINE).get();

        for (final Aggregation aggregation : searchResponse.getResponse().getAggregations().asList()) {
            final String aggName = aggregation.getName();
            final Terms terms = searchResponse.getResponse().getAggregations().get(aggName);

            if (terms.getBuckets().size() > 0) {
                for (int i = 0; i < terms.getBuckets().size(); i++) {
                    String key = terms.getBuckets().get(i).getKeyAsString();
                    eNodeBids.add(key);
                }
            }
        }

        return eNodeBids;
    }
}
