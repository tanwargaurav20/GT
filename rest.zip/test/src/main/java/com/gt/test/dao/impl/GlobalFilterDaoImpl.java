package com.harman.dmat.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import javax.inject.Inject;

import com.harman.dmat.common.dto.*;
import com.harman.dmat.common.exception.DataAccessException;
import com.harman.dmat.utils.EsClient;
import org.apache.commons.lang.StringUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.script.mustache.SearchTemplateRequestBuilder;
import org.elasticsearch.script.mustache.SearchTemplateResponse;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;
import com.harman.dmat.common.config.BaseDao;
import com.harman.dmat.common.security.User;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.dao.GlobalFilterDao;
import com.harman.dmat.enums.GroupStatus;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class GlobalFilterDaoImpl extends BaseDao implements GlobalFilterDao {

	@Inject
	private Environment environment;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.GlobalFilterDao#getModelId(java.lang.Integer)
	 */
	@Override
	public List<Integer> getModelId(Integer userId) {
		final String sql = "Select MODEL_ID FROM LOGS WHERE USER_ID=?";
		return getJdbcTemplate().queryForList(sql, new Object[] { userId }, Integer.class);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.GlobalFilterDao#getUserImeiData(java.lang.Integer)
	 */
	@Override
	public List<ImeiDto> getUserImeiData(Integer userId) {
		final String sql = "Select DISTINCT IMEI,userLastName,USER_ID from logs WHERE user_id=?";
		return getJdbcTemplate().query(sql, new Object[] { userId }, new BeanPropertyRowMapper<ImeiDto>(ImeiDto.class));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.GlobalFilterDao#getUserMdnData(java.lang.Integer)
	 */
	@Override
	public List<ImeiDto> getUserMdnData(Integer userId) {
		final String sql = "Select DISTINCT IMEI,userLastName,USER_ID from logs WHERE user_id=?";
		return getJdbcTemplate().query(sql, new Object[] { userId }, new BeanPropertyRowMapper<ImeiDto>(ImeiDto.class));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.GlobalFilterDao#getModelData(java.lang.Integer)
	 */
	@Override
	public String getModelData(Integer model) {
		final String sql = "Select MODEL_NAME FROM MODEL WHERE MODEL_ID=?";
		return getJdbcTemplate().queryForObject(sql, new Object[] { model },
				new BeanPropertyRowMapper<String>(String.class));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.GlobalFilterDao#getStatus(java.lang.Integer)
	 */
	@Override
	public StatusDto getStatus(Integer userId) {
		final String sql = "select user_id,is_Active from users where user_id=?";
		final StatusDto statusDto = getJdbcTemplate().queryForObject(sql, new Object[] { userId },
				new BeanPropertyRowMapper<StatusDto>(StatusDto.class));
		return statusDto;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.GlobalFilterDao#getUserModelData(java.lang.Integer)
	 */
	@Override
	public ModelDto getUserModelData(Integer modelId) {
		final String sql = "Select MODEL_ID,MODEL_NAME FROM MODEL where MODEL_ID=?";
		return getJdbcTemplate().queryForObject(sql, new Object[] { modelId },
				new BeanPropertyRowMapper<ModelDto>(ModelDto.class));

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.GlobalFilterDao#getAllModelData(java.lang.Integer,
	 * java.lang.Integer)
	 */
	@Override
	public List<ModelDto> getAllModelData(Integer offset, Integer limit) {
		final String sql = "Select MODEL_ID,MODEL_NAME FROM MODEL limit ? offset ?";
		return getJdbcTemplate().query(sql, new Object[] { limit, offset - 1 },
				new BeanPropertyRowMapper<ModelDto>(ModelDto.class));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.GlobalFilterDao#getAllImeiData(java.lang.Integer,
	 * java.lang.Integer)
	 */
	@Override
	public List<ImeiDto> getAllImeiData(Integer offset, Integer limit) {
		final String sql = "Select DISTINCT IMEI,userLastName,user_id FROM logs limit ? offset ?";
		return getJdbcTemplate().query(sql, new Object[] { limit, offset - 1 },
				new BeanPropertyRowMapper<ImeiDto>(ImeiDto.class));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.GlobalFilterDao#getAllMdnData(java.lang.Integer,
	 * java.lang.Integer)
	 */
	@Override
	public List<ImeiDto> getAllMdnData(Integer offset, Integer limit) {
		final String sql = "Select DISTINCT MDN,userLastName,user_id FROM logs limit ? offset ?";
		return getJdbcTemplate().query(sql, new Object[] { limit, offset },
				new BeanPropertyRowMapper<ImeiDto>(ImeiDto.class));
	}

	public List<StateDto> getStates() {
		final List<StateDto> states = getJdbcTemplate().query(
				"SELECT state_code,state_name,region FROM state limit ? offset ?",
				new BeanPropertyRowMapper<StateDto>(StateDto.class));
		return states;
	}

	@Override
	public List<LogMgrDto> getAllLogs(Integer offset, Integer limit) {
		final List<LogMgrDto> logs = getJdbcTemplate().query(
				"SELECT fileName,userLastName,USER_ID FROM logs limit ? offset ?", new Object[] { limit, offset - 1 },
				new BeanPropertyRowMapper<LogMgrDto>(LogMgrDto.class));
		return logs;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.GlobalFilterDao#getUserLogData(java.lang.Integer,
	 * java.lang.Integer, java.lang.Integer)
	 */
	@Override
	public List<LogMgrDto> getUserLogData(Integer userId, Integer offset, Integer limit) {
		final List<LogMgrDto> logs = getJdbcTemplate().query(
				"SELECT fileName,userLastName,USER_ID FROM logs where USER_ID=?  limit ? offset ?",
				new Object[] { userId, limit, offset - 1 }, new BeanPropertyRowMapper<LogMgrDto>(LogMgrDto.class));
		return logs;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.GlobalFilterDao#getUserStateData(java.lang.Integer)
	 */
	@Override
	public List<StateDto> getUserStateData(Integer userId) {
		final String stateCode = getJdbcTemplate().queryForObject("SELECT state_code FROM users where user_id=?",
				new Object[] { userId }, String.class);
		final List<StateDto> states = getJdbcTemplate().query(
				"SELECT state_code,state_name,region FROM state where state_code=?", new Object[] { stateCode },
				new BeanPropertyRowMapper<StateDto>(StateDto.class));
		return states;
	}

	/**
	 * Creates filter based on the passed parameters and creates an updated SQL
	 * 
	 * @param name
	 * @param calFilterType
	 * @param date
	 * @param mdn
	 * @param model
	 * @param fileName
	 * @param imei
	 * @param status
	 * @return
	 */
	private String[] createSQLToFilterData(String userId, String startDate, String endDate, String mdn, Integer model,
			String fileName, String imei) {
		String sql = "";
		final String sqlCount = "";
		String[] sSql;
		final String userDomain = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserDomain();
		String domainQuery = getDomainSqlQuery(userDomain);
		if (Constant.ALL.equalsIgnoreCase(userId)) {
			sql = " SELECT DISTINCT mdn,imei,user_id as dm_user,model_name as model from vw_logmgr " + "where "
					+ domainQuery;
		} else {
			sql = " SELECT DISTINCT mdn,imei,user_id as dm_user,model_name as model from vw_logmgr where user_id=? and "
					+ domainQuery;

		}
		StringBuffer sb = new StringBuffer();
		final Map<String, Object> map = new HashMap<>();
		map.put("mdn", mdn);
		map.put("model", model);
		map.put("fileName", fileName);
		map.put("imei", imei);
		final Iterator<String> itr = map.keySet().iterator();
		while (itr.hasNext()) {
			final String key = itr.next();
			final Object value = map.get(key);
			if (value != null) {
				sb = sb.append(" and ").append(key).append(" = ").append("\"").append(value).append("\"");
			}
		}
		sql = sql + createSqlWithDateFilters(startDate, endDate, userId, domainQuery) + sb.toString();
		sSql = new String[] { sql, sqlCount };
		return sSql;

	}

	/**
	 * Creates filter based on the calendar parameters and creates an updated
	 * SQL
	 * 
	 * @param calFilterType
	 * @param date
	 * @return String
	 *
	 */
	private String createSqlWithDateFilters(String startDate, String endDate, String userId, String domainQuery) {
		String sql = " ";
		if ("".equals(domainQuery)) {
			sql = sql + " log_captured_date >=" + "'" + startDate + "'" + " and log_captured_date <" + "('" + endDate
					+ "'" + "::date +'1 day'::interval)";
		} else {
			sql = sql + " and log_captured_date >=" + "'" + startDate + "'" + " and log_captured_date <" + "('"
					+ endDate + "'" + "::date +'1 day'::interval)";
		}
		return sql;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.GlobalFilterDao#getFilterResults(java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.Integer,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.Integer,
	 * java.lang.Integer)
	 */
	@Override
	public List<GlobalFilterDto> getFilterResults(String userId, String startDate, String endDate, String mdn,
			Integer model, String fileName, String imei) {
		final String[] sql = createSQLToFilterData(userId, startDate, endDate, mdn, model, fileName, imei);
		List<GlobalFilterDto> globalFilterDtos;
		Integer usrId = null;
		if (Constant.ALL.equalsIgnoreCase(userId)) {
			globalFilterDtos = getJdbcTemplate().query(sql[0],
					new BeanPropertyRowMapper<GlobalFilterDto>(GlobalFilterDto.class));
		} else {
			usrId = Integer.parseInt(userId);
			globalFilterDtos = getJdbcTemplate().query(sql[0], new Object[] { usrId },
					new BeanPropertyRowMapper<GlobalFilterDto>(GlobalFilterDto.class));
		}
		final List<StateDto> states = getJdbcTemplate().query("SELECT state_code,state_name,region FROM state ",
				new BeanPropertyRowMapper<StateDto>(StateDto.class));
		final List<String> stateCode = new ArrayList<String>();
		final List<String> stateName = new ArrayList<String>();
		final Set<String> region = new HashSet<String>();
		for (final StateDto statecode : states) {
			stateCode.add(statecode.getStateCode());
			region.add(statecode.getRegion());
			stateName.add(statecode.getStateName());
		}
		final List<GlobalFilterDto> globalDtos = new ArrayList<GlobalFilterDto>();
		final GlobalFilterDto globalDto = new GlobalFilterDto();
		final Set<String> imeiValues = new HashSet<String>();
		final Set<String> mdnValues = new HashSet<String>();
		final Set<String> modelValues = new HashSet<String>();
		for (final GlobalFilterDto dto : globalFilterDtos) {
			if (dto.getImei() != null) {
				imeiValues.addAll(dto.getImei());
			}
			if (dto.getMdn() != null) {
				mdnValues.addAll(dto.getMdn());
			}
			if (dto.getModel() != null) {
				modelValues.addAll(dto.getModel());
			}

		}
		if (usrId != null && userId.equalsIgnoreCase("all")) {
			userId = null;
		}

		globalDto.setImei(imeiValues);
		globalDto.setMdn(mdnValues);
		globalDto.setModel(modelValues);
		globalDto.setStatecode(stateCode);
		globalDto.setVz_regions(region);
		globalDto.setStatename(stateName);
		globalDto.setTotalUser(getUserCount(startDate, endDate, mdn, model, imei));
		globalDtos.add(globalDto);
		return globalDtos;
	}

	private Integer getUserCount(String startDate, String endDate, String mdn, Integer model, String imei) {
		final String userDomain = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserDomain();
		String criteria = " log_captured_date >=" + "'" + startDate + "'" + " and log_captured_date  <" + "('" + endDate
				+ "'" + "::date +'1 day'::interval)";
		if (model != null) {
			criteria += " and model_name='" + model + "'";
		}

		if (imei != null) {
			criteria += " and imei='" + imei + "'";

		}
		if (mdn != null) {
			criteria += " and mdn='" + mdn + "'";

		}

		criteria += " and " + getDomainSqlQuery(userDomain);

		final String sql = "select count(distinct user_id)  from vw_logmgr  where filename <> '' and  " + criteria + "";
		return getJdbcTemplate().queryForObject(sql, Integer.class);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.GlobalFilterDao#getUserLogFiles(java.lang.Integer,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.Integer,
	 * java.lang.Integer)
	 */
	@Override
	public List<UserLogFileDto> getUserLogFiles(Integer userId, String startDate, String endDate, String token,
			Integer userLimit, Integer fileLimit, Integer offset, String mdn, Integer model, String imei) {
		String dateCriteria = " log_captured_date >=" + "'" + startDate + "'" + " and log_captured_date <" + "('"
				+ endDate + "'" + "::date +'1 day'::interval)";
		final String userDomain = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserDomain();
		String domainQuery = getDomainSqlQuery(userDomain);
		if (model != null) {
			dateCriteria += " and model_name='" + model + "'";
		}

		if (imei != null) {
			dateCriteria += " and imei='" + imei + "'";

		}
		if (mdn != null) {
			dateCriteria += " and mdn='" + mdn + "'";

		}

		domainQuery = " and " + domainQuery;

		if (userId != null && token == null) {
			dateCriteria = dateCriteria + " and user_id=" + userId;
			return getUserLogFiles(dateCriteria, fileLimit, offset);
		}
		if (userId != null && token != null) {
			dateCriteria = dateCriteria + " and filename ilike '%" + token + "%' or firstname ilike '%" + token
					+ "%' or lastname ilike '%" + token + "%' and user_id=" + userId;
			return getUserLogFiles(dateCriteria, fileLimit, offset);
		}
		final String newFilter = dateCriteria.replace("log_captured_date", "last_log_time");

		String sql = "SELECT user_id,firstname,lastname,filename FROM (SELECT ROW_NUMBER() OVER (PARTITION BY user_id) AS row, user_id,firstname,lastname,filename FROM vw_logmgr"
				+ " where filename <> '' and " + dateCriteria
				+ " and user_id in (select dm_user from(select distinct dm_user,firstname from logs where file_name <> '' and  "
				+ newFilter + " order by firstname limit ? offset ? )as y) " + domainQuery
				+ ") x WHERE x.row <=? order by firstname, lastname";

		if (token != null) {
			sql = "SELECT  user_id,firstname,lastname,filename FROM (SELECT ROW_NUMBER() OVER (PARTITION BY user_id) AS row, user_id,firstname,lastname,filename FROM vw_logmgr"
					+ " where filename <> '' "
					+ " and user_id in (select dm_user from(select distinct dm_user from logs where file_name ilike '%"
					+ token + "%' or lastname ilike '%" + token + "%' or firstname ilike '%" + token
					+ "%' limit ? offset ? )as y) " + domainQuery + " and (filename ilike '%" + token
					+ "%' or lastname ilike '%" + token + "%' or firstname ilike '%" + token + "%') and " + dateCriteria
					+ ") x WHERE x.row <=? order by firstname, lastname";

		}
		final List<UserLogFileDto> userLogFileDtos = getJdbcTemplate().queryForObject(sql,
				new Object[] { userLimit, offset, fileLimit }, new RowMapper<List<UserLogFileDto>>() {

					@Override
					public List<UserLogFileDto> mapRow(ResultSet rs, int rowNum) throws SQLException {
						final List<UserLogFileDto> userLogFileDtos = new ArrayList<>();
						Integer lastUserId = -1;
						List<String> logFiles = new ArrayList<>();
						UserLogFileDto userLogFileDto = null;
						if (rs.getRow() == 1) {
							final int userId = rs.getInt(1);
							if (lastUserId != userId) {
								logFiles = new ArrayList<>();
								userLogFileDto = new UserLogFileDto();
								userLogFileDto.setUserId(userId);
								userLogFileDto.setFirstName(rs.getString(2));
								userLogFileDto.setLastName(rs.getString(3));
								userLogFileDto.setLogFiles(logFiles);
								userLogFileDtos.add(userLogFileDto);
							}
							lastUserId = userId;
							logFiles.add(rs.getString(4));
						}
						while (rs.next()) {
							final int userId = rs.getInt(1);
							if (lastUserId != userId) {
								logFiles = new ArrayList<>();
								userLogFileDto = new UserLogFileDto();
								userLogFileDto.setUserId(userId);
								userLogFileDto.setFirstName(rs.getString(2));
								userLogFileDto.setLastName(rs.getString(3));
								userLogFileDto.setLogFiles(logFiles);
								userLogFileDtos.add(userLogFileDto);
							}
							lastUserId = userId;
							logFiles.add(rs.getString(4));
						}
						return userLogFileDtos;
					}
				});
		return userLogFileDtos;
	}

	private List<UserLogFileDto> getUserLogFiles(String dateCriteria, Integer fileLimit, Integer offset) {
		final String sql = "SELECT user_id,firstname,lastname,filename FROM vw_logmgr" + " where filename <> '' and "
				+ dateCriteria + " limit ? offset ? ";
		final List<UserLogFileDto> userLogFileDtos = getJdbcTemplate().queryForObject(sql,
				new Object[] { fileLimit, offset }, new RowMapper<List<UserLogFileDto>>() {

					@Override
					public List<UserLogFileDto> mapRow(ResultSet rs, int rowNum) throws SQLException {
						final List<UserLogFileDto> userLogFileDtos = new ArrayList<>();
						Integer lastUserId = -1;
						List<String> logFiles = new ArrayList<>();
						UserLogFileDto userLogFileDto = null;
						if (rs.getRow() == 1) {
							final int userId = rs.getInt(1);
							if (lastUserId != userId) {
								logFiles = new ArrayList<>();
								userLogFileDto = new UserLogFileDto();
								userLogFileDto.setUserId(userId);
								userLogFileDto.setFirstName(rs.getString(2));
								userLogFileDto.setLastName(rs.getString(3));
								userLogFileDto.setLogFiles(logFiles);
								userLogFileDtos.add(userLogFileDto);
							}
							lastUserId = userId;
							logFiles.add(rs.getString(4));
						}
						while (rs.next()) {
							final int userId = rs.getInt(1);
							if (lastUserId != userId) {
								logFiles = new ArrayList<>();
								userLogFileDto = new UserLogFileDto();
								userLogFileDto.setUserId(userId);
								userLogFileDto.setFirstName(rs.getString(2));
								userLogFileDto.setLastName(rs.getString(3));
								userLogFileDto.setLogFiles(logFiles);
								userLogFileDtos.add(userLogFileDto);
							}
							lastUserId = userId;
							logFiles.add(rs.getString(4));
						}
						return userLogFileDtos;
					}
				});
		return userLogFileDtos;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.GlobalFilterDao#getModels(java.lang.Integer,
	 * java.lang.String, java.lang.String,
	 * com.harman.dmat.common.dto.GlobalFilterRequestDto)
	 */
	@Override
	public List<String> getModels(Integer userId, String startDate, String endDate,
			GlobalFilterRequestDto globalFilterDtos) {
		final String sql = "Select DISTINCT model_name FROM logs"
				// + " JOIN device d ON d.id = logs.device JOIN model mo ON
				// d.model = mo.model_id "
				+ " where model_name is not null and "
				+ getGlobalFilterCriteria(userId, startDate, endDate, globalFilterDtos);
		return getJdbcTemplate().queryForList(sql, String.class);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.GlobalFilterDao#getImeis(java.lang.Integer,
	 * java.lang.String, java.lang.String,
	 * com.harman.dmat.common.dto.GlobalFilterRequestDto)
	 */
	@Override
	public List<String> getImeis(Integer userId, String startDate, String endDate,
			GlobalFilterRequestDto globalFilterDtos) {
		final String sql = "Select DISTINCT IMEI FROM logs where IMEI is not null and "
				+ getGlobalFilterCriteria(userId, startDate, endDate, globalFilterDtos);
		return getJdbcTemplate().queryForList(sql, String.class);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.GlobalFilterDao#getMdns(java.lang.Integer,
	 * java.lang.String, java.lang.String,
	 * com.harman.dmat.common.dto.GlobalFilterRequestDto)
	 */
	@Override
	public List<String> getMdns(Integer userId, String startDate, String endDate,
			GlobalFilterRequestDto globalFilterDtos) {
		final String sql = "Select DISTINCT MDN FROM logs where MDN is not null and "
				+ getGlobalFilterCriteria(userId, startDate, endDate, globalFilterDtos);
		return getJdbcTemplate().queryForList(sql, String.class);
	}

	/**
	 * Gets the global filter criteria.
	 *
	 * @param userId
	 *            the user id
	 * @param startDate
	 *            the start date
	 * @param endDate
	 *            the end date
	 * @param globalFilterDtos
	 *            the global filter dtos
	 * @return the global filter criteria
	 */
	private String getGlobalFilterCriteria(Integer userId, String startDate, String endDate,
			GlobalFilterRequestDto globalFilterDtos) {
		String dateCriteria = " last_log_time >=" + "'" + startDate + "'" + " and last_log_time <" + "'" + endDate
				+ "'";
		if (userId != null) {
			dateCriteria = dateCriteria + " and logs.dm_user=" + userId;
		}
		if (globalFilterDtos.getModels() != null && !globalFilterDtos.getModels().isEmpty()) {
			dateCriteria += " and model_name in(" + makeComaSperated(globalFilterDtos.getModels()) + ")";
		}

		if (globalFilterDtos.getImeis() != null && !globalFilterDtos.getImeis().isEmpty()) {
			dateCriteria += " and imei in(" + makeComaSperated(globalFilterDtos.getImeis()) + ")";
		}
		if (globalFilterDtos.getMdns() != null && !globalFilterDtos.getMdns().isEmpty()) {
			dateCriteria += " and mdn in(" + makeComaSperated(globalFilterDtos.getMdns()) + ")";
		}
		if (globalFilterDtos.getLogfiles() != null && !globalFilterDtos.getLogfiles().isEmpty()) {
			dateCriteria += " and file_name in(" + makeComaSperated(globalFilterDtos.getLogfiles()) + ")";
		}
		return dateCriteria;
	}

	/**
	 * Make coma sperated.
	 *
	 * @param ids
	 *            the ids
	 * @return the string
	 */
	private String makeComaSperated(List<String> ids) {
		final StringBuilder stringBuilder = new StringBuilder();
		for (final String id : ids) {
			stringBuilder.append("'" + id + "',");
		}
		stringBuilder.replace(stringBuilder.length() - 1, stringBuilder.length(), "");
		return stringBuilder.toString();
	}

	/**
	 * Creates the domain SQL query
	 * 
	 * @param userDomain
	 * @return
	 */
	private String getDomainSqlQuery(String userDomain) {
		String domainQuery = "";
		userDomain = userDomain == null ? "null" : userDomain;
		StringBuffer sb = new StringBuffer();
		try {
			List<String> listVzDomains = Arrays
					.asList(environment.getRequiredProperty("verizon.domains").toLowerCase().split(","));

			if (listVzDomains.contains(userDomain.toLowerCase())) {
				for (String domain : listVzDomains) {
					sb = sb.append("'").append(domain.toLowerCase()).append("'").append(",");
				}
				sb.deleteCharAt(sb.length() - 1);
				domainQuery = " LOWER(user_domain) in (" + sb + ")";
			} else {
				domainQuery = " LOWER(user_domain) = LOWER('" + userDomain + "')";
			}
		} catch (Exception e) {
			log.error("Error Getting Vz domains");
		}

		return domainQuery;
	}

	@Override
	public GlobalFilterDataDto getFilterDataFromES(String query, String indices) {
		log.debug("Query to fetch Filter data from ES " + query);
		log.debug("Indices to fetch Filter data from ES " + indices);

		final SearchRequest searchRequest = new SearchRequest();
		final String dataPointType = environment.getRequiredProperty("data-point-es-type");
		final String[] sIndices = indices.split(",");
		searchRequest.indices(sIndices).types(dataPointType);

		final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
				.setRequest(searchRequest).setScript(query).setScriptType(ScriptType.INLINE).get();

		GlobalFilterDataDto globalFilterDto = new GlobalFilterDataDto();
		searchResponse.getResponse().getAggregations().asList().forEach(aggregation -> {
			Terms terms = searchResponse.getResponse().getAggregations().get(aggregation.getName());

			if (aggregation.getName().equalsIgnoreCase("ModelName")) {
				Set<String> modelNames = new HashSet<>();
				if(terms.getBuckets().size() > 0) {
					terms.getBuckets().forEach(bucket -> {
						if(StringUtils.isNotBlank(bucket.getKeyAsString().trim())) {
							modelNames.add(bucket.getKeyAsString());
						}
					});
				}

				globalFilterDto.setModels(modelNames);
			}

			if (aggregation.getName().equalsIgnoreCase("MDN")) {
				Set<String> mdns = new HashSet<>();
				if(terms.getBuckets().size() > 0) {
					terms.getBuckets().forEach(bucket -> {
						if (StringUtils.isNotBlank(bucket.getKeyAsString().trim())) {
							mdns.add(bucket.getKeyAsString());
						}
					});
				}

				globalFilterDto.setMdns(mdns);
			}

			if (aggregation.getName().equalsIgnoreCase("Imei")) {
				Set<String> imeis = new HashSet<>();
				if(terms.getBuckets().size() > 0) {
					terms.getBuckets().forEach(bucket -> {
						if (StringUtils.isNotBlank(bucket.getKeyAsString().trim())) {
							imeis.add(bucket.getKeyAsString());
						}
					});
				}
				globalFilterDto.setImeis(imeis);
			}

			List<LogUserDto> logUsers = new ArrayList<>();

			if (aggregation.getName().equalsIgnoreCase("DmUser")) {
				if(terms.getBuckets().size() > 0) {
					terms.getBuckets().forEach(bucket -> {
						LogUserDto logUserDto = new LogUserDto();
						logUserDto.setUserId(new Integer(bucket.getKeyAsString()).intValue());
						Terms firstName = bucket.getAggregations().get("FirstName");

						if(firstName.getBuckets().size() > 0) {
							firstName.getBuckets().forEach(firstNameBucket -> {
								if (StringUtils.isNotBlank(firstNameBucket.getKeyAsString())) {
									logUserDto.setFirstName(firstNameBucket.getKeyAsString());
								}
							});
						}

						Terms lastName = bucket.getAggregations().get("LastName");

						if(lastName.getBuckets().size() > 0) {
							lastName.getBuckets().forEach(lastNameBucket -> {
								if (StringUtils.isNotBlank(lastNameBucket.getKeyAsString())) {
									logUserDto.setLastName(lastNameBucket.getKeyAsString());
								}
							});
						}

						Terms fileName = bucket.getAggregations().get("FileName");

						Set<String> filenames = new HashSet<>();
						if(fileName.getBuckets().size() > 0) {
							fileName.getBuckets().forEach(fileNameBucket -> {
								if (StringUtils.isNotBlank(fileNameBucket.getKeyAsString())) {
									filenames.add(fileNameBucket.getKeyAsString());
									logUserDto.setFileNames(filenames);
								}
							});
						}

						logUsers.add(logUserDto);
					});
				}

				globalFilterDto.setLogUsers(logUsers);
			}

			if (aggregation.getName().equalsIgnoreCase("StateCode")) {
				Set<String> stateCodes = new HashSet<>();
				if(terms.getBuckets().size() > 0) {
					terms.getBuckets().forEach(bucket -> {
						if(StringUtils.isNotBlank(bucket.getKeyAsString().trim())) {
							stateCodes.add(bucket.getKeyAsString());
						}
					});
				}

				globalFilterDto.setStatCodes(stateCodes);
			}
		});

		return globalFilterDto;
	}
	
	@Override
	public Map<String, List<UserDto>> getUserGroups() {
		final Integer loinUserId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();
		final String sql = "select users.user_id,users.email,users.first_name,users.last_name,user_group.id as groupId,name as groupName "
				+ "from user_group join user_group_mapping on user_group.id=user_group_mapping.group_id join users on user_group_mapping.user_id=users.user_id "
				+ " where group_id in(select group_id from user_group_mapping where user_id=? group by group_id) and user_group_mapping.is_accept=?";
		final Map<String, List<UserDto>> groupMap = new HashMap<>();
		getJdbcTemplate().query(sql, new Object[] { loinUserId, GroupStatus.ACCEPT.getValue() },
				new ResultSetExtractor<Void>() {

					@Override
					public Void extractData(ResultSet rs) throws SQLException, DataAccessException {
						while (rs.next()) {
							final UserDto user = new UserDto();
							user.setUserId(rs.getInt(1));
							final String groupName = rs.getString(6);
							List<UserDto> users = groupMap.get(groupName);
							if (users == null) {
								users = new ArrayList<UserDto>();
							}
							users.add(user);
							groupMap.put(groupName, users);

						}
						return null;
					}
				});

		return groupMap;

	}

}
