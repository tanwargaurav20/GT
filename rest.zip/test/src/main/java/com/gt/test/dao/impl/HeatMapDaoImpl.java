package com.harman.dmat.dao.impl;

import com.esri.hex.HexXY;
import com.harman.dmat.common.config.BaseDao;
import com.harman.dmat.common.dto.*;
import com.harman.dmat.dao.HeatMapDao;
import com.harman.dmat.utils.EsClient;
import com.harman.dmat.utils.Utill;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.script.mustache.SearchTemplateRequestBuilder;
import org.elasticsearch.script.mustache.SearchTemplateResponse;
import org.elasticsearch.search.aggregations.*;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;
import org.elasticsearch.search.aggregations.Aggregations;

import javax.inject.Inject;
import java.util.*;

/**
 * All the access calls to Elastic Search for HeatMap will be handled by this class.
 */
@Slf4j
@Repository
public class HeatMapDaoImpl extends BaseDao implements HeatMapDao {
    @Inject
    Environment environment;

    @Override
    public HeatMapResponseDto getHeatMapLocations(String query, String indices, String locCode) {
        HeatMapResponseDto responseDto = new HeatMapResponseDto();

        HeatMapResponseDto heatMapResponseDto = new HeatMapResponseDto();
        final SearchRequest searchRequest = new SearchRequest();
        final String dataPointType = environment.getRequiredProperty("data-point-es-type");
        final String[] sIndices = indices.split(",");
        searchRequest.indices(sIndices).types(dataPointType);
        String[] loc_code_no = locCode.split("_");

        final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
                .setRequest(searchRequest).setScript(query).setScriptType(ScriptType.INLINE).get();

        List<FeaturesDto> features = new ArrayList<>();

        List<FieldsDto> fieldsList = new ArrayList<>();
        FieldsDto fieldsDto1 = new FieldsDto();
        fieldsDto1.setName("ID");
        fieldsDto1.setType("esriFieldTypeOID");
        fieldsDto1.setAlias("ID");

        fieldsList.add(fieldsDto1);

        FieldsDto fieldsDto2 = new FieldsDto();
        fieldsDto2.setName("M");
        fieldsDto2.setType("esriFieldTypeDouble");

        fieldsList.add(fieldsDto2);

        final Aggregations aggregations = searchResponse.getResponse().getAggregations();
        if (aggregations != null) {
            for (final Aggregation aggregation : searchResponse.getResponse().getAggregations().asList()) {
                final String aggName = aggregation.getName();
                final Terms terms = searchResponse.getResponse().getAggregations().get(aggName);
                if (terms.getBuckets().size() > 0) {
                    for (int i = 0; i < terms.getBuckets().size(); i++) {
                        String key = terms.getBuckets().get(i).getKeyAsString();
                        String[] locCoOrds = key.split(":");
                        HexXY hexXY = Utill.getRowColToMxMy(Double.parseDouble(locCode.split("_")[1]), Long.parseLong(locCoOrds[0]), Long.parseLong(locCoOrds[1]));
                        FeaturesDto featuresDto = new FeaturesDto();
                        GeometryDto geometryDto = new GeometryDto();
                        AttributesDto attributesDto = new AttributesDto();

                        attributesDto.setID(Integer.toString(i+1));
                        attributesDto.setM(20);

                        geometryDto.setX(hexXY.x());
                        geometryDto.setY(hexXY.y());

                        featuresDto.setAttributes(attributesDto);
                        featuresDto.setGeometry(geometryDto);
                        features.add(featuresDto);
                    }
                }

                SpatialReferenceDto spatRef = new SpatialReferenceDto();
                spatRef.setWkid(102100);

                FieldAliasDto fieldAliasDto = new FieldAliasDto();
                fieldAliasDto.setID("ID");

                responseDto.setDisplayFieldID("ID");
                responseDto.setFieldAlias(fieldAliasDto);
                responseDto.setGeometryType("esriGeometryPoint");
                responseDto.setSpatialReference(spatRef);
                responseDto.setFields(fieldsList);
                responseDto.setFeatures(features);
            }
        }

        return responseDto;
    }
}
