package com.harman.dmat.dao.impl;

import com.harman.dmat.common.config.BaseDao;
import com.harman.dmat.common.dto.InBuildingImageDto;
import com.harman.dmat.common.dto.InBuildingLogViewDto;
import com.harman.dmat.common.exception.DataAccessException;
import com.harman.dmat.dao.InBuildingDao;
import com.harman.dmat.utils.EsClient;
import com.harman.dmat.utils.Utill;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.script.mustache.SearchTemplateRequestBuilder;
import org.elasticsearch.script.mustache.SearchTemplateResponse;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.metrics.avg.Avg;
import org.elasticsearch.search.aggregations.metrics.avg.InternalAvg;
import org.elasticsearch.search.aggregations.metrics.valuecount.InternalValueCount;
import org.elasticsearch.search.aggregations.metrics.valuecount.ValueCount;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import javax.inject.Inject;
import java.sql.PreparedStatement;
import java.util.*;

@Repository
@Slf4j
public class InBuildingDaoImpl extends BaseDao implements InBuildingDao {

    @Inject
    private Environment environment;

    public Map<String, Object> getInbuildingImage(int imageId) {

        Map<String, Object> imageMap = new HashMap<>();
        final String sql = "select image_width,image_height, buildingImage from InBuilding where id = " + imageId;
        List<Map<String, Object>> resultSet = getJdbcTemplate().queryForList(sql);
        if (resultSet.size() > 0) {
            Map rows = resultSet.get(0);
            imageMap.put("image_width", rows.get("image_width"));
            imageMap.put("image_height", rows.get("image_height"));
            imageMap.put("buildingimage", Base64.getEncoder().encodeToString((byte[]) rows.get("buildingimage")));
        } else {
            imageMap.put("image_width", null);
            imageMap.put("image_height", null);
            imageMap.put("buildingimage", null);
        }
        return imageMap;
    }

    public List<InBuildingLogViewDto> getLogsByDate(String startDate, String endDate, Integer userId,String indices) {

        List<InBuildingLogViewDto> logFiles = new ArrayList<>();
        final SearchRequest searchRequest = new SearchRequest();
        String query;
        final String[] sIndices = indices.split(",");
        final String dataPointType = environment.getRequiredProperty("data-point-es-type");
        searchRequest.indices(sIndices).types(dataPointType);
        String userQuery = "";
        if(userId != null && userId > 0) {
            userQuery = "{\"bool\": {\"must\": {\"match_phrase\": {\"DmUser\": {\"query\": "+userId+"}}}}},";
        }

        query = "{ \"from\": 0, \"size\": 0, \"query\": { \"bool\": { \"must\": { \"bool\": { \"must\": [ { \"bool\": " +
                "{ \"must\": { \"range\": { \"TimeStamp\": { \"from\":\"" + startDate + "\", \"to\": \""+endDate+"\", " +
                "\"include_lower\": true, \"include_upper\": true } } } } }, "+userQuery+"{ \"bool\": { \"must\": { \"match_phrase\": " +
                "{ \"InbuildinguserMark\": { \"query\": true } } } } } ] } } } }, \"_source\": " +
                "{ \"includes\": [ \"FileName\", \"InbuildingimageId\", \"TestId\" ], \"excludes\": [] }, \"stored_fields\": " +
                "[ \"FileName\", \"InbuildingimageId\", \"TestId\" ], \"aggregations\": { \"FileName\": { \"terms\": " +
                "{ \"field\": \"FileName\", \"size\": 1000}, \"aggregations\": { \"InbuildingimageId\": { \"terms\": { \"field\":" +
                " \"InbuildingimageId\" }, \"aggregations\": { \"TestId\": { \"terms\": { \"field\": \"TestId\" } } } } } } } } ";

        log.debug("getLogsByDate ES indices: {}", indices);
        log.debug("getLogsByDate ES query: {}", query);

        final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
                .setRequest(searchRequest).setScript(query).setScriptType(ScriptType.INLINE).get();

        searchResponse.getResponse().getAggregations().asList().forEach(aggregation -> {
            Terms terms = searchResponse.getResponse().getAggregations().get(aggregation.getName());
            terms.getBuckets().forEach(bucket -> {
                InBuildingLogViewDto logViewDto = new InBuildingLogViewDto();
                logViewDto.setFileName(bucket.getKeyAsString());
                Terms imageIdTerms = bucket.getAggregations().get("InbuildingimageId");
                logViewDto.setImageIds(imageIdTerms.getBuckets().get(0).getKeyAsNumber().intValue());
                List<Integer> testIds = new ArrayList<>();
                imageIdTerms.getBuckets().forEach(testIdBucket -> {
                    Terms testIdTerms = testIdBucket.getAggregations().get("TestId");
                    testIdTerms.getBuckets().forEach(testIdBuckets -> testIds.add(testIdBuckets.getKeyAsNumber().intValue()));
                });
                logViewDto.setTestId(Collections.max(testIds));
                logFiles.add(logViewDto);
            });
        });

        return logFiles;
    }

    @Override
    public Map<String, String> getInfoPoints(double xCoordinate, double yCoordinate, String fileName, String indices) {
        final Map<String, String> list = new HashMap<>();
        final String[] sIndices = indices.split(",");
        final String dataPointType = environment.getRequiredProperty("data-point-es-type");

        final SearchRequest searchRequest = new SearchRequest();
        searchRequest.indices(sIndices).types(dataPointType);
        int adjustConstant = 10;
        double fromXCoordinate = xCoordinate - adjustConstant;
        double toXCoordinate = xCoordinate + adjustConstant;
        double fromYCoordinate = yCoordinate - adjustConstant;
        double toYCoordinate = yCoordinate + adjustConstant;

        final String query = "{\"size\": 10000, \"_source\": {\"includes\": " +
                "[ \"TimeStamp\", \"FileName\", \"ModelName\", \"MDN\", \"ServingCell\", \"VoiceRAT\", \"DataRAT\",\"LTEPccRsrp\", " +
                "\"LTEPccRsrq\", \"LTEPccRssi\", \"LTEPccSinr\", \"Accuracy\", \"Altitude\", \"FirstName\", \"LastName\", \"DmUser\" ], " +
                "\"excludes\": [] }, \"query\": { \"bool\": { \"must\": { \"bool\": { \"must\": [ { \"range\": { \"Inbuildingx\":" +
                "{ \"from\": " + fromXCoordinate + ", \"to\": " + toXCoordinate + ", \"include_lower\": true, \"include_upper\": true } } }, { \"range\": { \"Inbuildingy\": " +
                "{ \"from\": " + fromYCoordinate + ", \"to\": " + toYCoordinate + ", \"include_lower\": true, \"include_upper\": true } } }, " +
                "{ \"match_phrase\": { \"FileName\": { \"query\": \"" + fileName + "\" } } } ] } } } }, \"aggs\": " +
                "{ \"LTEPccRsrp\": { \"avg\": { \"field\": \"LTEPccRsrp\" } }, \"LTEPccRsrq\": { \"avg\": { \"field\": \"LTEPccRsrq\" } }, \"LTEPccRssi\": { \"avg\": " +
                "{ \"field\": \"LTEPccRssi\" } }, \"LTEPccSinr\": { \"avg\": { \"field\": \"LTEPccSinr\" } }, \"TimeStamp\": { \"terms\": " +
                "{ \"field\": \"TimeStamp\" } }, \"FileName\": { \"terms\": { \"field\": \"FileName\" } }, \"ModelName\": " +
                "{ \"terms\": { \"field\": \"ModelName\" } }, \"MDN\": { \"terms\": { \"field\": \"MDN\" } }, \"ServingCell\": " +
                "{ \"terms\": { \"field\": \"ServingCell\" } }, \"VoiceRAT\": { \"terms\": { \"field\": \"VoiceRAT\" } }, \"DataRAT\": { \"terms\": { \"field\": \"DataRAT\" } }, \"Accuracy\": " +
                "{ \"terms\": { \"field\": \"Accuracy\" } }, \"Altitude\": { \"terms\": { \"field\": \"Altitude\" }}, \"UserId\": { \"terms\": { \"field\": \"DmUser\" }}" +
                ", \"FirstName\": { \"terms\": { \"field\": \"FirstName\" }}, \"LastName\": { \"terms\": { \"field\": \"LastName\" }}}}";

        log.debug("getInfoPoints ES query: {}", query);

        final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
                .setRequest(searchRequest).setScript(query).setScriptType(ScriptType.INLINE).get();

        for (final Aggregation aggregation : searchResponse.getResponse().getAggregations().asList()) {
            final String aggName = aggregation.getName();
            if (searchResponse.getResponse().getAggregations().get(aggName).getClass() == InternalAvg.class) {
                final Avg avg = searchResponse.getResponse().getAggregations().get(aggName);
                if (!"NaN".equalsIgnoreCase(avg.getValueAsString())) {
                    list.put(avg.getName(), String.format("%.4f", avg.getValue()));
                }
            } else if (searchResponse.getResponse().getAggregations().get(aggName)
                    .getClass() == InternalValueCount.class) {

                final ValueCount vc = searchResponse.getResponse().getAggregations().get(aggName);
                if (vc != null) {
                    list.put(aggName, vc.getValueAsString());
                }
            } else {
                final Terms terms = searchResponse.getResponse().getAggregations().get(aggName);
                if (terms.getBuckets().size() > 0) {
                    if ("TimeStamp".equalsIgnoreCase(aggName))
                        list.put(aggName, Utill.esdateToUsFormat(terms.getBuckets().get(0).getKeyAsString()));
                    else
                        list.put(aggName, terms.getBuckets().get(0).getKeyAsString());
                } else {
                    list.put(aggName, "null");
                }
            }
        }

        return list;
    }

    public boolean registerInBuilding(Map<String, Object> inBuildingParameter) {
        SimpleJdbcInsert simpleJdbcInsert = getClientApiInbuildingSimpleJdbcInsert();

        if (!simpleJdbcInsert.isCompiled()) {
            simpleJdbcInsert.withTableName("InBuilding").usingGeneratedKeyColumns("id");
        }
        int status = simpleJdbcInsert.execute(inBuildingParameter);

        return status > 0 ? true : false;
    }

    @Override
    public List<InBuildingImageDto> getInBuildingList(Integer offset, Integer limit, Integer userId, Integer access) {

        String limitQuery = "";
        if (offset != null && limit != null) {
            limitQuery = " ORDER BY id DESC OFFSET " + (offset > 0 ? (offset - 1) : 1) + " LIMIT " + limit;
        }
        String roleQuery = "select role_id from users where user_id="+userId;
        String subQuery = "(select coalesce(user_id, "+userId+") from (select distinct user_id from user_group_mapping where group_id " +
                "in (select distinct group_id from user_group_mapping where user_id = "+userId+") union select null) as result)";
        int roleId = (int)getJdbcTemplate().queryForList(roleQuery).get(0).get("role_id");
        String sql = "";
        String sqlAddition = " where (dm_user="+userId+" and access in (0,2)) or (access=1)";
        switch(access){
            case -1:
                break;
            case 0:
                sqlAddition = (roleId==2)?" where access=0":" where (dm_user="+userId+" and access=0)";
                break;
            case 1:
                sqlAddition = " where access=1";
                break;
            case 2:
                sqlAddition = " where access=2 and dm_user in "+subQuery;
                break;
        }
        if(roleId==2)
            sqlAddition = (access==-1)?"":sqlAddition;
        sql = "select id, name, buildingaddress, dm_user, access, floorlevel, statecode, zipcode, city from inbuilding" + sqlAddition + limitQuery;

        return getJdbcTemplate().query(sql, new BeanPropertyRowMapper<>(InBuildingImageDto.class));
    }

    @Override
    public long getInBuildingCount(Integer userId, Integer access) {
        String roleQuery = "select role_id from users where user_id="+userId;
        int roleId = (int)getJdbcTemplate().queryForList(roleQuery).get(0).get("role_id");
        String sql = "";
        String sqlAddition = " where (dm_user=" + userId + " and access in (0,2)) or (access=1)";
        String subQuery = "(select coalesce(user_id, "+userId+") from (select distinct user_id from user_group_mapping where group_id " +
                "in (select distinct group_id from user_group_mapping where user_id = "+userId+") union select null) as result)";
        switch(access){
            case -1:
                break;
            case 0:
                sqlAddition = (roleId==2)?" where access=0":" where (dm_user="+userId+" and access=0)";
                break;
            case 1:
                sqlAddition = " where access=1";
                break;
            case 2:
                sqlAddition = " where access=2 and dm_user in "+subQuery;
                break;
        }
        if(roleId==2)
            sqlAddition = (access==-1)?"":sqlAddition;
        sql = "SELECT count(*) FROM inbuilding"+sqlAddition;

        return (long) getJdbcTemplate().queryForList(sql).get(0).get("count");
    }

    @Override
    public boolean removeInBuilding(String id) {
        int intId = 0;
        if(StringUtils.isNotBlank(id)) {
            intId = new Integer(id).intValue();
        }
    	// changing to remove sql injection
        //final String sql = "delete from inbuilding where id=" + "'" + id + "'";
    	final String sql = "delete from inbuilding where id=?";
    	boolean result = false;
        int count;
        try {
            count = getJdbcTemplate().update(sql,new Object[]{intId} );
        } catch (final DataAccessException e) {
            throw new DataAccessException();
        }
        if (count > 0) {
            log.debug("Deleted from RDBMS");
            result = true;
        }
        return result;
    }

    @Override
    public boolean updateInBuildingImage(Integer imageId, byte[] image, int width, int height) {
        boolean updateStatus = false;
        final String updateSql = "update inbuilding set buildingimage=?, image_width=?, image_height=? where id=?";
        int status = getJdbcTemplate().update(updateSql, new Object[]{image, width, height, imageId});
        if (status > 0) {
            updateStatus = true;
        }
        return updateStatus;
    }

    @Override
    public Long registerInBuildingWithoutImage(InBuildingImageDto inBuildingImageDto) {
        final String sql = "insert into inbuilding(name, buildingaddress, dm_user,access,floorlevel, statecode, zipcode, city) values(?,?,?,?,?,?,?,?)";

        final KeyHolder keyHolder = new GeneratedKeyHolder();
        getJdbcTemplate().update(connection -> {
            final PreparedStatement ps = connection.prepareStatement(sql, new String[]{"id"});
            ps.setString(1, inBuildingImageDto.getName());
            ps.setString(2, inBuildingImageDto.getBuildingaddress());
            ps.setInt(3, inBuildingImageDto.getDmuser());
            ps.setInt(4, inBuildingImageDto.getAccess());
            ps.setInt(5, inBuildingImageDto.getFloorlevel());
            ps.setString(6, inBuildingImageDto.getStatecode());
            ps.setString(7, inBuildingImageDto.getZipcode());
            ps.setString(8, inBuildingImageDto.getCity());
            return ps;

        }, keyHolder);
        final long result = keyHolder.getKey().longValue();
        return result;
    }

    @Override
    public long updateInBuildingInfo(InBuildingImageDto inBuildingImageDto) {
        final String updateSql = "update inbuilding set name=?, buildingaddress=?, access=?, floorlevel=?, " +
                "statecode=?, zipcode=?, city=? where id=?";
        Object[] updatedDetails = new Object[]{
                inBuildingImageDto.getName(),
                inBuildingImageDto.getBuildingaddress(),
                inBuildingImageDto.getAccess(),
                inBuildingImageDto.getFloorlevel(),
                inBuildingImageDto.getStatecode(),
                inBuildingImageDto.getZipcode(),
                inBuildingImageDto.getCity(),
                inBuildingImageDto.getId(),
        };
        int status = getJdbcTemplate().update(updateSql, updatedDetails);
        return status;
    }

    @Override
    public List<Integer> getImageIdsToRemoveForLogFiles(List<Integer> inBuildingImageIds, Integer userId) {
        String ids = inBuildingImageIds.toString().substring(1, inBuildingImageIds.toString().length()-1);
        String sql = "select distinct id from inbuilding where access = 0 and id in ("+ids+") and dm_user <> ?";
        return getJdbcTemplate().queryForList(sql, new Object[] {userId}, Integer.class);
    }

}