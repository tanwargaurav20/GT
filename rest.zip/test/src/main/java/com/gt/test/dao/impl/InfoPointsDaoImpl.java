package com.harman.dmat.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.script.mustache.SearchTemplateRequestBuilder;
import org.elasticsearch.script.mustache.SearchTemplateResponse;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.metrics.avg.Avg;
import org.elasticsearch.search.aggregations.metrics.avg.InternalAvg;
import org.elasticsearch.search.aggregations.metrics.valuecount.InternalValueCount;
import org.elasticsearch.search.aggregations.metrics.valuecount.ValueCount;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.harman.dmat.common.config.BaseDao;
import com.harman.dmat.common.dto.EventsInfoDto;
import com.harman.dmat.common.dto.LiveInfoPointsDto;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.dao.InfoPointsDao;
import com.harman.dmat.utils.EsClient;
import com.harman.dmat.utils.Utill;

import lombok.extern.slf4j.Slf4j;

/**
 * @author GTanwar Interacts with the ES
 */
@Slf4j
@Repository
public class InfoPointsDaoImpl extends BaseDao implements InfoPointsDao {

	@Inject
	private Environment environment;

	private static final Map<String, String> eventNameMap = new HashMap<>();

	static {
		eventNameMap.put("LTEAttRej", "LTE Attach Reject");
		eventNameMap.put("LTEReselToGsmUmtsFail", "LTE Resel To GSM UMTS Fail");
		eventNameMap.put("LTEAuthRej", "LTE Auth Reject");
		eventNameMap.put("LTEReselFromGsmUmtsFail", "LTE Resel From GSM UMTS Fail");
		eventNameMap.put("LTEIntraReselFail", "LTE Intra Resel Fail");
		eventNameMap.put("LTEIntraHoFail", "LTE Intra Ho Fail");
		eventNameMap.put("LTEMobilityFromEutraFail", "LTE Mobility From Eutra Fail");
		eventNameMap.put("LTEOos", "LTE Out Of Service");
		eventNameMap.put("LTEPdnRej", "LTE PDN Reject");
		eventNameMap.put("LTERlf", "LTE Rlf");
		eventNameMap.put("LTERrcConRestRej", "LTE RRC Connection Rest Reject");
		eventNameMap.put("LTERrcConRej", "LTE RRC Connection Reject");
		eventNameMap.put("LTEServiceRej", "LTE Service Reject");
		eventNameMap.put("LTESibReadFailure", "LTE Sib Read Failure");
		eventNameMap.put("LTETaRej", "LTE TA Reject");
		eventNameMap.put("LTEVoLTEDrop", "LTE VoLTE Drop");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.InfoPointsDao#getInfoPoints(java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public List<String> getInfoPoints(String query, String indices) {
		final List<String> list = new ArrayList<>();
		StringBuilder sb = new StringBuilder();
		final SearchRequest searchRequest = new SearchRequest();
		final String dataPointType = environment.getRequiredProperty("data-point-es-type");
		final String[] sIndices = indices.split(",");
		searchRequest.indices(sIndices).types(dataPointType);

		final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
				.setRequest(searchRequest).setScript(query).setScriptType(ScriptType.INLINE).get();

		for (final Aggregation aggregation : searchResponse.getResponse().getAggregations().asList()) {
			final String aggName = aggregation.getName();
			if (searchResponse.getResponse().getAggregations().get(aggName).getClass() == InternalAvg.class) {
				final Avg avg = searchResponse.getResponse().getAggregations().get(aggName);
				if (!"NaN".equalsIgnoreCase(avg.getValueAsString())) {
					if ((avg.getValue() == Math.floor(avg.getValue())) && !Double.isInfinite(avg.getValue())) {
						try {
							list.add(avg.getName() + ":" + String.format("%d", (int) avg.getValue()));
						} catch (NumberFormatException ex) {
							log.error("Can not convert the number to int for kpi {} {} ", avg.getName(), ex);
						}
					} else
						list.add(avg.getName() + ":" + String.format("%.4f", avg.getValue()));
				}
			} else if (searchResponse.getResponse().getAggregations().get(aggName)
					.getClass() == InternalValueCount.class) {

				final ValueCount vc = searchResponse.getResponse().getAggregations().get(aggName);
				if (vc != null) {
					list.add(aggName + ":" + vc.getValueAsString());
				}

			} else {
				final Terms terms = searchResponse.getResponse().getAggregations().get(aggName);

				if (terms.getBuckets().size() > 0) {
					if ("timestamp".equalsIgnoreCase(aggName))
						list.add(aggName + ":" + Utill.esdateToUsFormat(terms.getBuckets().get(0).getKeyAsString()));
					else if (aggName.contains(" ")) {

						for (int i = 0; i < terms.getBuckets().size(); i++) {
							if (terms.getBuckets().get(i).getKeyAsNumber().intValue() > 0) {
								if (sb.toString().contains(aggName))
									continue;

								sb = sb.append(aggName).append(",");

							}
						}

					} else if ("mcc".equalsIgnoreCase(aggName)) {
						list.add(aggName + ":" + terms.getBuckets().get(0).getKeyAsString());
						list.add(Constant.OPERATOR + getOperator(terms.getBuckets().get(0).getKeyAsString()));
					} else
						list.add(aggName + ":" + terms.getBuckets().get(0).getKeyAsString());
				}

			}
		}
		if (sb.length() > 0) {
			list.add("EventName" + ":" + sb.deleteCharAt(sb.length() - 1));
		}

		if (list != null && list.size() == 1 && list.contains("kpicount:0.0")) {
			list.clear();
		}

		return list;

		/*
		 * List<String> sortedList = new ArrayList<>();
		 * 
		 * Iterator<String> itr = list.iterator(); while (itr.hasNext()) {
		 * String kpi = (String)itr.next(); if (kpi.matches("(?i)(puschtx).*")
		 * || kpi.matches("(?i)(puschtx).*") || kpi.matches("(?i)(rat).*") ||
		 * kpi.matches("(?i)(rssi).*") || kpi.matches("(?i)(rsrp).*") ||
		 * kpi.matches("(?i)(rsrq).*") || kpi.matches("(?i)(sinr).*") ||
		 * kpi.matches("(?i)(bandindicator).*") ||
		 * kpi.matches("(?i)("+kpiName+").*")) { sortedList.add(kpi);
		 * itr.remove(); } } Collections.sort(sortedList); for(String element :
		 * list) { sortedList.add(element); } return sortedList;
		 */
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.InfoPointsDao#getEventInfoPoints(java.lang.String)
	 */
	@Override
	public Map<String, Object> getEventInfoPoints(String query) {
		final SearchRequest searchRequest = new SearchRequest();
		final String eventIndex = environment.getRequiredProperty("event-es-index");
		final String eventType = environment.getRequiredProperty("event-es-type");
		searchRequest.indices(eventIndex).types(eventType);

		final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
				.setRequest(searchRequest).setScript(query).setScriptType(ScriptType.INLINE).get();

		final SearchHit[] s = searchResponse.getResponse().getHits().getHits();
		Map<String, Object> sourceMap = null;
		for (final SearchHit a : s) {
			sourceMap = a.getSource();
		}
		final Aggregations aggregations = searchResponse.getResponse().getAggregations();
		if (aggregations != null) {
			for (final Aggregation aggregation : searchResponse.getResponse().getAggregations().asList()) {
				final String aggName = aggregation.getName();
				final Terms terms = searchResponse.getResponse().getAggregations().get(aggName);
				if (terms.getBuckets().size() > 0) {
					sourceMap.put("eventid", terms.getBuckets().get(0).getKeyAsString());
					break;
				}
			}
		}

		return sourceMap;
	}

	@Override
	public LiveInfoPointsDto getLiveInfoPoints(String query, String lat, String lng) {

		final List<LiveInfoPointsDto> pointsDto = getLiveJdbcTemplate().query(query,
				new Double[] { Double.parseDouble(lat), Double.parseDouble(lng) },
				new BeanPropertyRowMapper<LiveInfoPointsDto>(LiveInfoPointsDto.class));
		return pointsDto.isEmpty() ? new LiveInfoPointsDto() : pointsDto.get(0);
	}

	@Override
	public List<EventsInfoDto> getEventsList(String query, String indices) {
		List<EventsInfoDto> eventsInfoList = new ArrayList<>();
		final SearchRequest searchRequest = new SearchRequest();
		final String dataPointType = environment.getRequiredProperty("data-point-es-type");
		final String[] sIndices = indices.split(",");
		searchRequest.indices(sIndices).types(dataPointType);

		final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
				.setRequest(searchRequest).setScript(query).setScriptType(ScriptType.INLINE).get();

		final SearchHit[] s = searchResponse.getResponse().getHits().getHits();
		Map<String, Object> sourceMap = null;

		for (final SearchHit a : s) {
			sourceMap = a.getSource();
			String objectId = sourceMap.get("ObjectId").toString();
			String status = getStatus(objectId);
			log.debug("Status {} for ObjectId {} from ES in eventsInfoList api", status, objectId);

			for (String eventName : eventNameMap.keySet()) {
				EventsInfoDto eventsInfoDto = new EventsInfoDto();
				if (sourceMap.containsKey(eventName)) {
					if (!(eventName.equalsIgnoreCase("LTERlf") && ((sourceMap.get("LTERlf") != null)
							&& sourceMap.get("LTERlf").toString().equalsIgnoreCase("0")))) {
						if (sourceMap.get(eventName) != null) {
							int eventsCount = Integer.parseInt(sourceMap.get(eventName).toString());

							for (int i = 0; i < eventsCount; i++) {
								eventsInfoDto.setEventName(eventNameMap.get(eventName).toString());
								eventsInfoDto.setEventESName(eventName);
								eventsInfoDto.setObjectId(sourceMap.get("ObjectId").toString());
								eventsInfoDto.setFileName(sourceMap.get("FileName").toString());
								eventsInfoDto.setTimeStamp(sourceMap.get("TimeStamp").toString());
								eventsInfoDto.setLat(sourceMap.get("lat").toString());
								eventsInfoDto.setLon(sourceMap.get("lon").toString());
								eventsInfoDto.setFirstName(sourceMap.get("FirstName").toString());
								eventsInfoDto.setLastName(sourceMap.get("LastName").toString());
								eventsInfoDto.setEmailId(sourceMap.get("EmailId").toString());
								eventsInfoDto.setUserId(sourceMap.get("DmUser").toString());
								eventsInfoDto.setStatus(status);

								eventsInfoList.add(eventsInfoDto);
							}
						}
					}
				}
			}
		}

		return eventsInfoList;
	}

	private String getStatus(String objectId) {
		StringBuilder status = new StringBuilder("");
		final String sql = "select status from event_lvanalysis where objectId=?";
		return getMapJdbcTemplate().query(sql, new Object[] { new Integer(objectId).intValue() },
				(ResultSetExtractor<String>) rs -> {
					while (rs.next()) {
						status.append(rs.getString("status"));
					}
					return status.toString();
				});
	}

	/**
	 * Fetches operator from MCC MNC Id
	 * 
	 * @param mccMnc
	 * @return
	 */
	private String getOperator(String mccMnc) {
		String operator = null;
		String mcc = "";
		String mnc = "";
		String sql = "Select operator from operator_master where mcc =? and mnc =?";
		try {
			if (mccMnc.contains("/")) {
				mcc = mccMnc.split("/")[0];
				mnc = mccMnc.split("/")[1];
				operator = getJdbcTemplate().queryForObject(sql, String.class, new Object[] { mcc, mnc });
			} else if (!mccMnc.contains("/") && mccMnc.length() > 3) {
				mcc = getMCCAndMNCWithoutSeprator(mccMnc, "mcc");
				mnc = getMCCAndMNCWithoutSeprator(mccMnc, "mnc");
				if (mcc != null && !mcc.isEmpty() && mnc != null && !mnc.isEmpty())
					operator = getJdbcTemplate().queryForObject(sql, String.class, new Object[] { mcc, mnc });
			} else {
				log.info("mccMNC id:{} doesn't hold the contract of mcc/mnc   ", mccMnc);
				operator = "N/A";
			}
		} catch (DataAccessException ex) {
			log.error(String.format("Data not exist for the mcc:%s and mnc :%s  ", mcc, mnc), ex);

		} catch (Exception e) {
			log.error("error in getiing operetator  the MCC MNC  ", e);
		}
		return operator != null ? operator : "N/A";
	}

	private String getMCCAndMNCWithoutSeprator(String mccMncString, String param) {
		String value = "";
		if (param.equalsIgnoreCase("Mcc"))
			value = mccMncString.substring(0, 3);
		else if (param.equalsIgnoreCase("Mnc")) {
			value = mccMncString.substring(3);
		}
		return value;
	}

}