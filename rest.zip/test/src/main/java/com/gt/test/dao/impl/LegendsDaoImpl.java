package com.harman.dmat.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.harman.dmat.common.config.BaseDao;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.InvalidRequestPayloadException;
import com.harman.dmat.constant.LegendsConstant;
import com.harman.dmat.dao.LegendsDao;
import com.harman.dmat.enums.LegendsEnum;
import com.harman.dmat.legends.dto.ColoredVeriableRange;
import com.harman.dmat.legends.dto.FixedValueColorDto;
import com.harman.dmat.legends.dto.Kpi;
import com.harman.dmat.legends.dto.KpiInfo;
import com.harman.dmat.legends.dto.NewFixedValueColorDto;
import com.harman.dmat.legends.dto.NewVariableRangeColorDto;
import com.harman.dmat.legends.dto.Template;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
@Transactional
public class LegendsDaoImpl extends BaseDao implements LegendsDao {

	public List<Long> insertFixedLegendsForUser(List<FixedValueColorDto> list, Long userId) {
		List<Long> listToReturn = new ArrayList<>();
		final String sql = "INSERT INTO LEGEND_FIXED_RANGE_USER (LegendId,Value,Color,Unit,KpiId,UserId,CreatedBy,UpdatedBy) values(?,?,?,?,?,?,?,?)";
		list.forEach(legend -> {
			GeneratedKeyHolder holder = new GeneratedKeyHolder();
			getJdbcTemplate().update(new PreparedStatementCreator() {
				@Override
				public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
					PreparedStatement statement = null;
					statement = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
					statement.setLong(1, legend.getLegend_id());
					statement.setString(2, legend.getValue());
					statement.setString(3, legend.getColor());
					statement.setString(4, legend.getUnit());
					statement.setLong(5, legend.getKpiId());
					statement.setLong(6, userId);
					statement.setLong(7, userId);
					statement.setLong(8, userId);
					return statement;
				}
			}, holder);
			listToReturn.add(Long.parseLong(holder.getKeyList().get(0).get("LegendId").toString()));
		});
		return listToReturn;
	}

	public List<Long> insertVarLegendsForUser(List<ColoredVeriableRange> list, Long userId) {
		List<Long> listToReturn = new ArrayList<>();
		final String sql = "INSERT INTO LEGEND_VARIABLE_RANGE_USER (LegendId,Min,Max,Color,Unit,KpiId,UserId,CreatedBy,UpdatedBy) values(?,?,?,?,?,?,?,?,?)";
		list.forEach(legend -> {
			GeneratedKeyHolder holder = new GeneratedKeyHolder();
			getJdbcTemplate().update(new PreparedStatementCreator() {
				@Override
				public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
					final PreparedStatement statement = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
					statement.setLong(1, legend.getLegend_id());
					statement.setDouble(2, legend.getMin());
					statement.setDouble(3, legend.getMax());
					statement.setString(4, legend.getColor());
					statement.setString(5, legend.getUnit());
					statement.setLong(6, legend.getKpiId());
					statement.setLong(7, userId);
					statement.setLong(8, userId);
					statement.setLong(9, userId);
					return statement;
				}
			}, holder);
			listToReturn.add(Long.parseLong(holder.getKeyList().get(0).get("LegendId").toString()));
		});
		return listToReturn;
	}

	@Override
	public List<Kpi> getUserLegends(Long userId, int groupId) {
		String sql = getGroup(groupId);
		List<Kpi> listOfKpis = getJdbcTemplate().query(sql, (rs, row) -> {
			Kpi kpiCategory = new Kpi();
			kpiCategory.setKpiId(rs.getLong("KpiId"));
			kpiCategory.setKpiParentId(rs.getInt("KpiParentID"));
			kpiCategory.setLabel(rs.getString("KpiDesc"));
			kpiCategory.setLevel(rs.getInt("Level"));
			kpiCategory.setKpiKey(rs.getString("KpiKey"));
			kpiCategory.setGroup(rs.getInt("Group11"));
			kpiCategory.setSubLevel(rs.getInt("SubLevel"));
			kpiCategory.setGroup1(rs.getInt("Group1"));
			kpiCategory.setGroup2(rs.getInt("Group2"));
			kpiCategory.setGroup3(rs.getInt("Group3"));
			kpiCategory.setGroup4(rs.getInt("Group4"));
			kpiCategory.setGroup5(rs.getInt("Group5"));
			kpiCategory.setSubGroup(rs.getInt("SubGroup"));
			kpiCategory.setActive(rs.getInt("IsActive"));
			kpiCategory.setKpiEditable(rs.getBoolean("isKpiEditable"));
			kpiCategory.setType(rs.getString("type"));
			return kpiCategory;
		});
		if (groupId > 0)
			return listOfKpis.parallelStream().filter(kpi -> kpi.getKpiId() > 5).collect(Collectors.toList());
		else
			return listOfKpis;
		// removing the unused code because UI dosen't use the legends of the
		// kpis from this api satyavrat

	}

	public static Predicate<Kpi> isEarfcnKpi() {
		return p -> p.getGroup3() == 3 && p.getType().equalsIgnoreCase(LegendsEnum.TYPE_NO_LEGEND.value);
	}

	public List<Kpi> getEarfcnKpis(final List<Kpi> kpis) {

		final List<Kpi> listOfEarfcnKpis = new ArrayList<>();
		kpis.forEach(kpi -> {
			if (kpi.getGroup3() == 3 && !kpi.getType().equalsIgnoreCase(LegendsEnum.TYPE_NO_LEGEND.value)) {

				kpi.setKpiParentId(5555);
				listOfEarfcnKpis.add(kpi);
			}
		});
		kpis.clear();
		return listOfEarfcnKpis;
	}

	private String getGroup(int group) {
		String sql = "select * from kpi where %s = %d AND IsActive = 1  order by 1 asc";
		switch (group) {
		case 0:
			sql = String.format("select * from kpi where %s = %d AND IsActive = 1 order by 1 asc", "level", 1);
			break;
		case 1:
			sql = String.format(sql, "Group1", group);
			break;
		case 2:
			sql = String.format(sql, "Group2", group);
			break;
		case 3:
			sql = String.format(sql, "Group3", group);
			break;
		case 4:
			sql = String.format(sql, "Group4", group);
			break;
		case 5:
			sql = String.format(sql, "Group5", group);
			break;
		default:
			throw new InvalidRequestPayloadException("invalid group Id " + group);
		}
		log.info("the query using is {}", sql);
		return sql;
	}

	@Override
	public Kpi getLegendForKpi(Long userId, Long kpiId) {
		String sql = "select * from KPI where KpiId=? ";
		Kpi kpi = getJdbcTemplate().queryForObject(sql, (rs, row) -> {
			Kpi kpiCategory = new Kpi();
			kpiCategory.setKpiId(rs.getLong("KpiId"));
			kpiCategory.setKpiParentId(rs.getInt("KpiParentID"));
			kpiCategory.setLabel(rs.getString("KpiDesc"));
			kpiCategory.setLevel(rs.getInt("Level"));
			kpiCategory.setKpiKey(rs.getString("KpiKey"));
			kpiCategory.setGroup(rs.getInt("Group11"));
			kpiCategory.setSubLevel(rs.getInt("SubLevel"));
			kpiCategory.setGroup1(rs.getInt("Group1"));
			kpiCategory.setGroup2(rs.getInt("Group2"));
			kpiCategory.setGroup3(rs.getInt("Group3"));
			kpiCategory.setGroup4(rs.getInt("Group4"));
			kpiCategory.setGroup5(rs.getInt("Group5"));
			kpiCategory.setSubGroup(rs.getInt("SubGroup"));
			kpiCategory.setActive(rs.getInt("IsActive"));
			kpiCategory.setKpiEditable(rs.getBoolean("isKpiEditable"));
			kpiCategory.setType(rs.getString("type"));
			return kpiCategory;
		}, kpiId);
		Long templateId = getUserTeplate(userId);
		String secondQuery = null;
		if (kpi.getType().equalsIgnoreCase(LegendsConstant.TYPE_FIXED_RANGE)) {
			secondQuery = "select Id,Value,Color,Unit from LEGEND_FIXED_RANGE_USER where TemplateId=? AND KpiId=? order by Value DESC";
			List<FixedValueColorDto> lis2 = getJdbcTemplate().query(secondQuery, (rs, rowCount) -> {
				FixedValueColorDto fixedValueColorDto = new FixedValueColorDto();
				fixedValueColorDto.setId(rs.getLong(LegendsConstant.ID));
				fixedValueColorDto.setColor(rs.getString(LegendsConstant.COLOR));
				fixedValueColorDto.setValue(rs.getString(LegendsConstant.VALUE));
				fixedValueColorDto.setKpiId(kpi.getKpiId());
				fixedValueColorDto.setUnit(rs.getString(LegendsConstant.UNIT));
				return fixedValueColorDto;

			}, templateId, kpi.getKpiId());
			kpi.setListFixedValueColorDto(lis2);
		} else if (kpi.getType().equalsIgnoreCase(LegendsConstant.TYPE_VARIABLE_RANGE)) {
			secondQuery = "select * from LEGEND_VARIABLE_RANGE_USER where TemplateId=? AND KpiId=? order by Max DESC";
			List<ColoredVeriableRange> lis2 = getJdbcTemplate().query(secondQuery, (resultSet, rowCount) -> {
				ColoredVeriableRange coloredVeriableRange = new ColoredVeriableRange();
				coloredVeriableRange.setId(resultSet.getLong(LegendsConstant.ID));
				coloredVeriableRange.setColor(resultSet.getString(LegendsConstant.COLOR));
				coloredVeriableRange.setMin(resultSet.getDouble(LegendsConstant.MIN));
				coloredVeriableRange.setMax(resultSet.getDouble(LegendsConstant.MAX));
				coloredVeriableRange.setUnit(resultSet.getString(LegendsConstant.UNIT));
				coloredVeriableRange.setKpiId(kpi.getKpiId());
				return coloredVeriableRange;
			}, templateId, kpi.getKpiId());
			if (!lis2.isEmpty()) {
				kpi.setMax(lis2.get(0).getMax());
				kpi.setMin(lis2.get(lis2.size() - 1).getMin());
			}
			kpi.setListColoredVeriableRange(lis2);
		}
		return kpi;

	}

	private Long getTemplatesForUser(Long userId) {
		String sql = "select TemplateId from usertemplatemap where UserId=? AND isActive=? ";
		return getJdbcTemplate().queryForObject(sql, Long.class, userId, true);
	}

	private boolean checkUserTemplateExist(Long userId) {
		log.info("getting the user teplate userId {} ", userId);
		String sql = "select count(*) from usertemplatemap where userid=? AND isActive=?";
		Object[] inputs = new Object[] { userId, true };
		Integer noOfRecordFound = getJdbcTemplate().queryForObject(sql, inputs, Integer.class);
		log.info("no of record found for the user is {}", noOfRecordFound);
		return noOfRecordFound <= 0 ? false : true;
	}

	/*
	 * private void changeUserLegendsColor(ChangeDefaultKpiColor col, Long
	 * userId) { String sql =
	 * "update into LEGEND_FIXED_RANGE_USER set Color=? where userId=?&&KpiId=?LegendId=? &&Value=? && Unit=? "
	 * ; getJdbcTemplate().update(sql, col.getColor(), userId, col.getKpiId(),
	 * col.getLegendsId()); }
	 */

	@Override
	public Template createNewTemplate(Template template) {
		Optional<Long> tepmlateId = insertTemplate(template.getUserId(), template.getTemplateName());
		insertIntoFixedRangeKpiLegends(template.getFixedValueKpiLegendsList(), tepmlateId);
		insertIntoVariableRangeKpiLegend(template.getVariableRangeKpiLegendsList(), tepmlateId);
		List<Long> kpiIds = template.getFixedValueKpiLegendsList().stream().map(value -> value.getKpiId()).distinct()
				.collect(Collectors.toList());
		kpiIds.addAll(template.getVariableRangeKpiLegendsList().stream().map(value -> value.getKpiId()).distinct()
				.collect(Collectors.toList()));
		template.setListOfKpis(getKpiInfo(kpiIds));
		if (tepmlateId.isPresent())
			template.setTemplateId(tepmlateId.get());
		return getTemplateForUser(template.getUserId(), tepmlateId.get());
	}

	private Optional<Long> insertTemplate(Long userId, String teplateName) {
		final String insertTemplet = "insert into UserTemplateMap (TemplateName,UserId) values(?,?)";
		KeyHolder keyHolder = new GeneratedKeyHolder();
		getJdbcTemplate().update(new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
				PreparedStatement ps = connection.prepareStatement(insertTemplet, Statement.RETURN_GENERATED_KEYS);
				if (StringUtils.isBlank(teplateName))
					ps.setString(1, "Verizon(default)");
				else
					ps.setString(1, teplateName);
				ps.setLong(2, userId);
				connection.commit();
				return ps;

			}
		}, keyHolder);
		return Optional.of((Long) keyHolder.getKeys().get("templateid"));
	}

	private int[] insertIntoFixedRangeKpiLegends(List<NewFixedValueColorDto> listOfNewFixedValueColorDto,
			Optional<Long> teplateId) {
		final String sql = "insert into  legend_fixed_range_user (TemplateId,Value,Color,Unit,KpiId) values(?,?,?,?,?) ";
		return getJdbcTemplate().batchUpdate(sql, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				if (!teplateId.isPresent())
					ps.setLong(1, listOfNewFixedValueColorDto.get(i).getTemplateId());
				else
					ps.setLong(1, teplateId.get());
				ps.setString(2, listOfNewFixedValueColorDto.get(i).getValue());
				ps.setString(3, listOfNewFixedValueColorDto.get(i).getColor());
				ps.setString(4, listOfNewFixedValueColorDto.get(i).getUnit());
				ps.setLong(5, listOfNewFixedValueColorDto.get(i).getKpiId());
			}

			@Override
			public int getBatchSize() {
				return listOfNewFixedValueColorDto.size();
			}
		});

	}

	private int[] insertIntoVariableRangeKpiLegend(List<NewVariableRangeColorDto> listOfNewVariableRangeColorDto,
			Optional<Long> teplateId) {
		final String sql = "insert into legend_variable_range_user (TemplateId,Min,Max,Color,Unit,KpiId) values (?,?,?,?,?,?)";
		return getJdbcTemplate().batchUpdate(sql, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				if (!teplateId.isPresent())
					ps.setLong(1, listOfNewVariableRangeColorDto.get(i).getTemplateId());
				else
					ps.setLong(1, teplateId.get());
				ps.setDouble(2, listOfNewVariableRangeColorDto.get(i).getMin());
				ps.setDouble(3, listOfNewVariableRangeColorDto.get(i).getMax());
				ps.setString(4, listOfNewVariableRangeColorDto.get(i).getColor());
				ps.setString(5, listOfNewVariableRangeColorDto.get(i).getUnit());
				ps.setLong(6, listOfNewVariableRangeColorDto.get(i).getKpiId());
			}

			@Override
			public int getBatchSize() {
				return listOfNewVariableRangeColorDto.size();
			}
		});

	}

	@Override
	public Kpi getDefaultKpiLegends(Long templateId, Long kpiId) {
		String legendType = getLegendType(kpiId);
		Kpi kpi = new Kpi();
		kpi.setKpiId(kpiId);
		if (LegendsEnum.TYPE_FIXED_RANGE.value.equalsIgnoreCase(legendType)) {
			List<NewFixedValueColorDto> list1 = getDefaultNewFixed(kpiId);
			deleteKpiLegendsForTeplate(legendType, templateId, kpiId);
			insertIntoFixedRangeKpiLegends(list1, Optional.of(templateId));
			kpi.setType(LegendsEnum.TYPE_FIXED_RANGE.value);
			kpi.setListFixedValueColorDto(getKpiForTeplate2(kpiId, templateId));
		} else if (LegendsEnum.TYPE_VARIABLE_RANGE.value.equalsIgnoreCase(legendType)) {
			List<NewVariableRangeColorDto> list2 = getDefault(kpiId);
			deleteKpiLegendsForTeplate(legendType, templateId, kpiId);
			insertIntoVariableRangeKpiLegend(list2, Optional.of(templateId));
			kpi.setType(LegendsEnum.TYPE_VARIABLE_RANGE.value);
			kpi.setListColoredVeriableRange(getKpiForTeplate(kpiId, templateId));
		} else {
			throw new DataNotFoundException("kpi is not classified under fxied or varibale range ");
		}
		return kpi;
	}

	private List<ColoredVeriableRange> getKpiForTeplate(Long kpiId, Long teplateId) {
		String sql = "select * from LEGEND_VARIABLE_RANGE_USER where TemplateId=? AND kpiId=?";
		return getJdbcTemplate().query(sql, (rs, row) -> {
			ColoredVeriableRange coloredVeriableRange = new ColoredVeriableRange();
			coloredVeriableRange.setColor(rs.getString("color"));
			coloredVeriableRange.setId(rs.getLong("id"));
			coloredVeriableRange.setKpiId(kpiId);
			coloredVeriableRange.setMin(rs.getDouble("min"));
			coloredVeriableRange.setMax(rs.getDouble("max"));
			return coloredVeriableRange;
		}, teplateId, kpiId);
	}

	private List<FixedValueColorDto> getKpiForTeplate2(Long kpiId, Long teplateId) {
		String sql = "select * from LEGEND_FIXED_RANGE_USER where TemplateId=? AND kpiId=?";
		return getJdbcTemplate().query(sql, (rs, row) -> {
			FixedValueColorDto fixedValueColorDto = new FixedValueColorDto();
			fixedValueColorDto.setColor(rs.getString("color"));
			fixedValueColorDto.setId(rs.getLong("id"));
			fixedValueColorDto.setKpiId(kpiId);
			fixedValueColorDto.setValue(rs.getString("value"));
			fixedValueColorDto.setColor(rs.getString("color"));
			return fixedValueColorDto;
		}, teplateId, kpiId);
	}

	private void deleteKpiLegendsForTeplate(String legendType, Long teplateId, Long kpiId) {
		String sql = null;
		if (LegendsEnum.TYPE_FIXED_RANGE.value.equalsIgnoreCase(legendType)) {
			sql = "delete from LEGEND_FIXED_RANGE_USER where templateid=? AND KpiId=?";

		} else if (LegendsEnum.TYPE_VARIABLE_RANGE.value.equalsIgnoreCase(legendType)) {
			sql = "delete from LEGEND_VARIABLE_RANGE_USER where templateid=? AND KpiId=?";
		}
		getJdbcTemplate().update(sql, teplateId, kpiId);

	}

	private List<NewVariableRangeColorDto> getDefault(Long kpiId) {
		String sql = "SELECT * from legend_variable_range_def where KpiId=? order by Min asc ";
		return getJdbcTemplate().query(sql, (rs, row) -> {
			NewVariableRangeColorDto newVariableRangeColorDto = new NewVariableRangeColorDto();
			newVariableRangeColorDto.setKpiId(kpiId);
			newVariableRangeColorDto.setMin(rs.getDouble("Min"));
			newVariableRangeColorDto.setMax(rs.getDouble("Max"));
			newVariableRangeColorDto.setUnit(rs.getString("Unit"));
			newVariableRangeColorDto.setColor(rs.getString("Color"));
			return newVariableRangeColorDto;
		}, kpiId);

	}

	private List<NewFixedValueColorDto> getDefaultNewFixed(Long kpiId) {
		String sql = "SELECT * from legend_fixed_range_def where KpiId=? order by value asc ";
		return getJdbcTemplate().query(sql, (rs, row) -> {
			NewFixedValueColorDto newFixedValueColorDto = new NewFixedValueColorDto();
			newFixedValueColorDto.setKpiId(kpiId);
			newFixedValueColorDto.setValue(rs.getString("Value"));
			newFixedValueColorDto.setUnit(rs.getString("Unit"));
			newFixedValueColorDto.setColor(rs.getString("Color"));
			return newFixedValueColorDto;
		}, kpiId);

	}

	private String getLegendType(Long kpiId) {
		final String sql = "select type from kpi where kpiid=? ";
		return (String) getJdbcTemplate().query(sql, new ResultSetExtractor<String>() {
			@Override
			public String extractData(ResultSet rs) throws SQLException, DataAccessException {
				return rs.next() ? rs.getString("Type") : null;
			}
		}, kpiId);
	}

	@Override
	public int deleteTemplate(Long userId, Long teplateId) {
		String sql = "delete from legend_fixed_range_user where TemplateId=?";
		int rowCount = getJdbcTemplate().update(sql, teplateId);
		sql = "delete from legend_variable_range_user where TemplateId=?";
		rowCount = getJdbcTemplate().update(sql, teplateId);
		sql = "delete from usertemplatemap where TemplateId=? AND userId=?";
		rowCount = getJdbcTemplate().update(sql, teplateId, userId);
		return rowCount;
	}

	@Override
	public Template getTemplateForUser(Long userId, Long templateId) {
		Template template = getTemplate(userId, templateId);
		List<NewFixedValueColorDto> list1 = getNewFixedValueColorDto(templateId);
		List<NewVariableRangeColorDto> list2 = getNewVariableRangeColorDto(templateId);
		template.setFixedValueKpiLegendsList(list1);
		template.setVariableRangeKpiLegendsList(list2);
		List<Long> kpiIds = list1.stream().map(value -> value.getKpiId()).distinct().collect(Collectors.toList());
		kpiIds.addAll(list2.stream().map(value -> value.getKpiId()).distinct().collect(Collectors.toList()));
		template.setListOfKpis(getKpiInfo(kpiIds));
		return template;
	}

	private Template getTemplate(Long userId, Long templateid) {
		String sql = "select * from usertemplatemap where templateid=?";
		return (Template) getJdbcTemplate().query(sql, new ResultSetExtractor<Template>() {
			@Override
			public Template extractData(ResultSet rs) throws SQLException, DataAccessException {
				Template template = new Template();
				while (rs.next()) {
					template.setTemplateId(templateid);
					template.setTemplateName(rs.getString("templatename"));
					template.setUserId(userId);
					template.setActive(rs.getBoolean("isactive"));
				}

				return template;
			}
		}, templateid);

	}

	private List<NewFixedValueColorDto> getNewFixedValueColorDto(Long teplateId) {
		String sql = "select * from legend_fixed_range_user where TemplateId=? ORDER BY KpiId,Value ASC ";
		return getJdbcTemplate().query(sql, (rs, row) -> {
			NewFixedValueColorDto newFixedValueColorDto = new NewFixedValueColorDto();
			newFixedValueColorDto.setId(rs.getLong("id"));
			newFixedValueColorDto.setKpiId(rs.getLong("KpiId"));
			newFixedValueColorDto.setUnit(rs.getString("Unit"));
			newFixedValueColorDto.setValue(rs.getString("Value"));
			newFixedValueColorDto.setTemplateId(teplateId);
			newFixedValueColorDto.setColor(rs.getString("Color"));
			return newFixedValueColorDto;
		}, teplateId);

	}

	private List<NewVariableRangeColorDto> getNewVariableRangeColorDto(Long teplateId) {
		String sql = "select * from legend_variable_range_user where TemplateId=? ORDER BY KpiId,Max ASC ";
		return getJdbcTemplate().query(sql, (rs, row) -> {
			NewVariableRangeColorDto newVariableRangeColorDto = new NewVariableRangeColorDto();
			newVariableRangeColorDto.setId(rs.getLong("id"));
			newVariableRangeColorDto.setKpiId(rs.getLong("KpiId"));
			newVariableRangeColorDto.setUnit(rs.getString("Unit"));
			newVariableRangeColorDto.setMin(rs.getDouble("Min"));
			newVariableRangeColorDto.setMax(rs.getDouble("Max"));
			newVariableRangeColorDto.setColor(rs.getString("Color"));
			newVariableRangeColorDto.setTemplateId(teplateId);
			return newVariableRangeColorDto;
		}, teplateId);

	}

	@Override
	public List<Template> getUserTemplates(Long userId) {
		List<Template> list = getTemplates(userId);

		list.forEach(temp -> {
			List<NewFixedValueColorDto> list1 = getNewFixedValueColorDto(temp.getTemplateId());
			List<NewVariableRangeColorDto> list2 = getNewVariableRangeColorDto(temp.getTemplateId());
			List<Long> kpiIds = list1.stream().map(value -> value.getKpiId()).distinct().collect(Collectors.toList());
			kpiIds.addAll(list2.stream().map(value -> value.getKpiId()).distinct().collect(Collectors.toList()));
			temp.setListOfKpis(getKpiInfo(kpiIds));
			temp.setFixedValueKpiLegendsList(list1);
			temp.setVariableRangeKpiLegendsList(list2);
		});
		log.debug("geting the list of templates for the user {}", userId);
		return list;
	}

	private List<Template> getTemplates(Long userId) {
		String sql = "select * from usertemplatemap where UserId=? OR TemplateId=? ";
		return getJdbcTemplate().query(sql, (rs, row) -> {
			Template template = new Template();
			template.setTemplateId(rs.getLong("TemplateId"));
			template.setTemplateName(rs.getString("TemplateName"));
			template.setUserId(userId);
			template.setActive(rs.getBoolean("isActive"));
			return template;
		}, userId, 1);
	}

	@Override
	public Template updateTeplate(Template teplate) {
		Optional<Long> templateId = Optional.of(teplate.getTemplateId());
		int[] val = null;
		if (teplate.getFixedValueKpiLegendsList() != null && !teplate.getFixedValueKpiLegendsList().isEmpty()) {
			val = updateNewFixedValueColorDto(teplate.getFixedValueKpiLegendsList(), templateId);
			log.info("updated rows in fixed value color is {}", val);
		}
		if (teplate.getVariableRangeKpiLegendsList() != null && !teplate.getVariableRangeKpiLegendsList().isEmpty()) {
			val = updateNewVariableRangeColorDto(teplate.getVariableRangeKpiLegendsList(), templateId);

		}
		log.info("no of row updated {}", val);
		return getTemplateForUser(teplate.getUserId(), teplate.getTemplateId());
	}

	public int[] updateNewFixedValueColorDto(List<NewFixedValueColorDto> listNewFixedValueColorDto,
			Optional<Long> templateId) {
		List<Object[]> batch = new ArrayList<>();
		for (NewFixedValueColorDto fixedValueLegend : listNewFixedValueColorDto) {
			Object[] values = new Object[] { fixedValueLegend.getColor(), fixedValueLegend.getId() };
			batch.add(values);
		}
		return getJdbcTemplate().batchUpdate("update legend_fixed_range_user SET Color=? where Id=?", batch);
	}

	private int[] updateNewVariableRangeColorDto(List<NewVariableRangeColorDto> newVariableRangeColorDto,
			Optional<Long> templateId) {
		List<Long> kpis = newVariableRangeColorDto.parallelStream().map(value -> value.getKpiId()).distinct()
				.collect(Collectors.toList());
		deleteNewVariableRangeColorDto(kpis, templateId);
		return insertIntoVariableRangeKpiLegend(newVariableRangeColorDto, templateId);

	}

	private int[] deleteNewVariableRangeColorDto(List<Long> kpis, Optional<Long> teplateId) {
		String sql = "delete from legend_variable_range_user where KpiId=? AND TemplateId=? ";
		return getJdbcTemplate().batchUpdate(sql, new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setLong(1, kpis.get(i));
				if (teplateId.isPresent())
					ps.setLong(2, teplateId.get());
				else {
					throw new DataNotFoundException("unable to update because data not found for the template ");
				}

			}

			@Override
			public int getBatchSize() {
				return kpis.size();
			}
		});

	}

	private List<KpiInfo> getKpiInfo(List<Long> list) {
		List<KpiInfo> listtoReturn = new ArrayList<>();
		list.forEach(value -> {
			listtoReturn.add(getKpiInfo(value));
		});
		return listtoReturn;
		/*
		 * return listtoReturn.parallelStream() .sorted((firstKpi, secondKpi) ->
		 * firstKpi.getKpiName().compareTo(secondKpi.getKpiName()))
		 * .collect(Collectors.toList());
		 */
	}

	/*
	 * private String getKpiName(Long kpi) { String sql =
	 * "select KpiDesc from KPI where KpiId=? "; return (String)
	 * getJdbcTemplate().queryForObject(sql, (rs, row) -> { return
	 * rs.getString("KpiDesc");
	 * 
	 * }, kpi); }
	 */
	private KpiInfo getKpiInfo(Long kpiId) {
		String sql = "select KpiDesc,Type,Min,Max from KPI where KpiId=? ";
		return (KpiInfo) getJdbcTemplate().queryForObject(sql, (rs, row) -> {
			final KpiInfo kpiinfo = new KpiInfo();
			kpiinfo.setKpiId(kpiId);
			kpiinfo.setKpiName(rs.getString("KpiDesc"));
			kpiinfo.setMin(rs.getDouble("Min"));
			kpiinfo.setMax(rs.getDouble("Max"));
			kpiinfo.setType(rs.getString("type"));
			return kpiinfo;
		}, kpiId);

	}

	@Override
	public List<KpiInfo> getKpiInfo() {
		String sql = "select kpiId,KpiDesc,type from kpi where type!=?::LegendType";
		return getJdbcTemplate().query(sql, (rs, row) -> {
			KpiInfo kpiInfo = new KpiInfo();
			kpiInfo.setKpiId(rs.getLong("kpiId"));
			kpiInfo.setKpiName(rs.getString("KpiDesc"));
			kpiInfo.setType(rs.getString("type"));
			return kpiInfo;
		}, LegendsEnum.TYPE_NO_LEGEND.getValue());

	}

	/*
	 * private String getKpiType(Long kpi) { String sql =
	 * "select Type from KPI where KpiId=? "; return (String)
	 * getJdbcTemplate().queryForObject(sql, (rs, row) -> { return
	 * rs.getString("Type");
	 * 
	 * }, kpi);
	 * 
	 * }
	 */
	/*
	 * private Long getDefaultTeplate() { Long defaultTeplateId = new Long(1);
	 * String sql =
	 * "select * from usertemplatemap where UserId=? AND templateid=?"; return
	 * (Long) getJdbcTemplate().queryForObject(sql, new Object[] { 1,
	 * defaultTeplateId }, new BeanPropertyRowMapper(Long.class));
	 * 
	 * }
	 */
	private Long getUserTeplate(Long userId) {
		Long templateId = null;
		if (checkUserTemplateExist(userId)) {
			templateId = getTemplatesForUser(userId);
			log.info("getting teplate for the user teplateId {} ", templateId);
		} else {
			templateId = new Long(1);
		}
		log.info("getting the teplate id is {}", templateId);
		return templateId;
	}

	/*
	 * @Override public List<KpiInfo> getKpiInfo() { String sql =
	 * "select kpiId,KpiDesc,type from dump.kpi where type!=?::LegendType";
	 * return getJdbcTemplate().query(sql, (rs, row) -> { KpiInfo kpiInfo = new
	 * KpiInfo(); kpiInfo.setKpiId(rs.getLong("kpiId"));
	 * kpiInfo.setKpiName(rs.getString("KpiDesc"));
	 * kpiInfo.setType(rs.getString("type")); return kpiInfo; },
	 * LegendsEnum.TYPE_NO_LEGEND.getValue());
	 * 
	 * }
	 */
	@Override
	public Template applyTeplate(Template teplate) {
		Template gotTemplate;
		if (teplate.getTemplateId() == 1) {
			makeOtherInactive(teplate.getUserId());
			gotTemplate = getDefaultTeplate();
		} else {
			makeOtherInactive(teplate.getUserId());
			String sql = "update usertemplatemap set isActive=?  where UserId=? AND TemplateId=?";
			int i = getJdbcTemplate().update(sql, teplate.isActive(), teplate.getUserId(), teplate.getTemplateId());
			log.info("number of records updated are {}", i);
			gotTemplate = getTemplate(teplate.getUserId(), teplate.getTemplateId());
		}
		return gotTemplate;

	}

	private Template getDefaultTeplate() {
		String sql = "select * from usertemplatemap where TemplateId=?";
		return getJdbcTemplate().queryForObject(sql, new RowMapper<Template>() {

			@Override
			public Template mapRow(ResultSet rs, int rowNum) throws SQLException {
				Template template = new Template();
				template.setActive(rs.getBoolean("isActive"));
				template.setTemplateId(new Long(1));
				template.setTemplateName("TemplateName");
				return template;
			}

		}, 1);

	}

	private void makeOtherInactive(Long userId) {
		String sql = "update usertemplatemap set isActive=?  where UserId=?";
		getJdbcTemplate().update(sql, false, userId);
	}

	@Override
	public void updateTeplate(Template template, Long userId, Long tep) {

	}

	@Override
	public void deleteOnlylegends(Template template) {
		String sql = "delete from LEGEND_FIXED_RANGE_USER where TemplateId=?";
		getJdbcTemplate().update(sql, template.getTemplateId());
		sql = "delete from LEGEND_VARIABLE_RANGE_USER where TemplateId=?";
		getJdbcTemplate().update(sql, template.getTemplateId());

	}

	@Override
	public int[] saveNewVeriableLegends(List<NewVariableRangeColorDto> list, Long teplateId) {
		return insertIntoVariableRangeKpiLegend(list, Optional.of(teplateId));
	}

	@Override
	public int[] saveNewFixedLegends(List<NewFixedValueColorDto> list, Long teplateId) {
		return insertIntoFixedRangeKpiLegends(list, Optional.of(teplateId));
	}

	@Override
	public Optional<Long> getTemplateName(Long userId, String templateName) {
		if (isUserTeplateExits(userId, templateName)) {
			String sql = "select TemplateId from usertemplatemap where TemplateName=? AND UserId=? ";
			return Optional.of((Long) getJdbcTemplate().queryForObject(sql, (rs, row) -> {
				return rs.getLong("TemplateId");
			}, templateName, userId));
		} else
			return Optional.empty();

	}

	private boolean isUserTeplateExits(Long userId, String templateName) {
		String sql = "select count(*) from usertemplatemap where UserId=? AND TemplateName=?";
		Optional<Integer> noOfRecordFound = Optional
				.of(getJdbcTemplate().queryForObject(sql, Integer.class, userId, templateName));
		return noOfRecordFound.isPresent() && noOfRecordFound.get() > 0;

	}

	@Override
	public void validateAndUpdateDefaultTemplate() {
		final List<KpiInfo> kpiInfo = getKpiInfo();
		List<KpiInfo> variableLegendsKpiList = kpiInfo.parallelStream()
				.filter(value -> value.getType().equalsIgnoreCase(LegendsEnum.TYPE_VARIABLE_RANGE.value))
				.collect(Collectors.toList());
		List<KpiInfo> fixedLegendsKpiList = kpiInfo.parallelStream()
				.filter(value -> value.getType().equalsIgnoreCase(LegendsEnum.TYPE_FIXED_RANGE.value))
				.collect(Collectors.toList());
		List<KpiInfo> listOfUnfoundKpis = variableLegendsKpiList.parallelStream()
				.filter(value -> !checkIfKpiExistVariableUserLegendsTable(value.getKpiId()))
				.collect(Collectors.toList());
		listOfUnfoundKpis.addAll(fixedLegendsKpiList.parallelStream()
				.filter(value -> !checkIfKpiExistFixedUserLegendsTable(value.getKpiId())).collect(Collectors.toList()));
		updateDefaultTemplate(listOfUnfoundKpis);
	}

	private void updateDefaultTemplate(List<KpiInfo> listOfUnfoundKpis) {
		listOfUnfoundKpis.stream()
				.filter(value -> value.getType().equalsIgnoreCase(LegendsEnum.TYPE_VARIABLE_RANGE.value))
				.forEach(value -> {
					insertIntoVariableRangeKpiLegend(getDefaultdataForVariableLegends(value.getKpiId()),
							Optional.empty());
				});
		listOfUnfoundKpis.stream().filter(value -> value.getType().equalsIgnoreCase(LegendsEnum.TYPE_FIXED_RANGE.value))
				.forEach(value -> {
					insertIntoFixedRangeKpiLegends(getDefaultDataForFixedLegends(value.getKpiId()), Optional.empty());
				});

	}

	private List<NewVariableRangeColorDto> getDefaultdataForVariableLegends(Long kpid) {
		String sql = "SELECT * from legend_variable_range_def where KpiId=?  order by legendid asc";
		return getJdbcTemplate().query(sql, (rs, row) -> {
			NewVariableRangeColorDto newVariableRangeColorDto = new NewVariableRangeColorDto();
			newVariableRangeColorDto.setId(rs.getLong("LegendId"));
			newVariableRangeColorDto.setKpiId(rs.getLong("KpiId"));
			newVariableRangeColorDto.setMin(rs.getDouble("Min"));
			newVariableRangeColorDto.setMax(rs.getDouble("Max"));
			newVariableRangeColorDto.setTemplateId(Long.valueOf(1));
			newVariableRangeColorDto.setColor(rs.getString("Color"));
			newVariableRangeColorDto.setUnit(rs.getString("Unit"));
			return newVariableRangeColorDto;
		}, kpid);

	}

	private List<NewFixedValueColorDto> getDefaultDataForFixedLegends(Long kpid) {
		String sql = "SELECT * from legend_fixed_range_def where KpiId=?  order by legendid asc";
		return getJdbcTemplate().query(sql, (rs, row) -> {
			NewFixedValueColorDto newFixedValueColorDto = new NewFixedValueColorDto();
			newFixedValueColorDto.setId(rs.getLong("LegendId"));
			newFixedValueColorDto.setKpiId(rs.getLong("KpiId"));
			newFixedValueColorDto.setValue(rs.getString("Value"));
			newFixedValueColorDto.setTemplateId(Long.valueOf(1));
			newFixedValueColorDto.setColor(rs.getString("Color"));
			newFixedValueColorDto.setUnit(rs.getString("Unit"));
			return newFixedValueColorDto;
		}, kpid);

	}

	private boolean checkIfKpiExistVariableUserLegendsTable(Long kpiId) {
		String sql = "select count(*) from legend_variable_range_user where KpiId=? AND TemplateId=?";
		Optional<Integer> noOfRecordFound = Optional.of(getJdbcTemplate().queryForObject(sql, Integer.class, kpiId, 1));
		return noOfRecordFound.isPresent() && noOfRecordFound.get() > 0;
	}

	private boolean checkIfKpiExistFixedUserLegendsTable(Long kpiId) {
		String sql = "select count(*) from legend_fixed_range_user where KpiId=? AND TemplateId=?";
		Optional<Integer> noOfRecordFound = Optional.of(getJdbcTemplate().queryForObject(sql, Integer.class, kpiId, 1));
		return noOfRecordFound.isPresent() && noOfRecordFound.get() > 0;
	}

}