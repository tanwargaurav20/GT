package com.harman.dmat.dao.impl;

import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.harman.dmat.common.config.BaseDao;
import com.harman.dmat.common.dto.LiveAPIDto;
import com.harman.dmat.common.dto.LiveTrendingDto;
import com.harman.dmat.dao.LiveAPIDao;
import com.itextpdf.text.pdf.PdfStructTreeController.returnType;

/**
 * @author GTanwar Interacts with the database
 */
@Repository

public class LiveAPIDaoImpl extends BaseDao implements LiveAPIDao {

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.LiveAPIDao#getLiveImei(java.lang.String)
	 */
	@Override
	public LiveAPIDto getLiveImei(String query) {
		final List<String> listApiDto = getLiveJdbcTemplate().queryForList(query, String.class);
		LiveAPIDto apiDto = new LiveAPIDto();
		apiDto.setImei(listApiDto);
		return apiDto;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.LiveAPIDao#getLiveTrend(java.lang.String)
	 */
	@Override
	public List<LiveTrendingDto> getLiveTrend(String query) {
		final List<LiveTrendingDto> listApiDto = getLiveJdbcTemplate().query(query,
				new BeanPropertyRowMapper<LiveTrendingDto>(LiveTrendingDto.class));
		return listApiDto;

	}

	@Override
	public List<Integer> getKpiValuesFromPs(List<String> imei) {
		List<Integer> list;
		if (imei != null && !imei.isEmpty()) {
			final String query = "SELECT DISTINCT servingcell FROM data_points_live_wm where imei IN (:ids)";
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("ids", imei);
			NamedParameterJdbcTemplate template = new NamedParameterJdbcTemplate(getLiveJdbcTemplate().getDataSource());
			list = template.queryForList(query, parameters, Integer.class);
		} else {
			final String query = "SELECT DISTINCT servingcell FROM data_points_live_wm";
			list = getLiveJdbcTemplate().query(query, (rs, row) -> {
				return rs.getInt("servingcell");
			});
		}
		return list;
	}

}