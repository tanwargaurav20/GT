package com.harman.dmat.dao.impl;

import java.sql.Array;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.bulk.byscroll.BulkByScrollResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.reindex.DeleteByQueryAction;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.script.mustache.SearchTemplateRequestBuilder;
import org.elasticsearch.script.mustache.SearchTemplateResponse;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.histogram.Histogram;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.metrics.cardinality.InternalCardinality;
import org.elasticsearch.search.aggregations.metrics.tophits.InternalTopHits;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;

import com.harman.dmat.common.config.BaseDao;
import com.harman.dmat.common.dto.CustomReportsDto;
import com.harman.dmat.common.dto.CustomReportsHistogramDto;
import com.harman.dmat.common.dto.CustomReportsLogDto;
import com.harman.dmat.common.dto.CustomReportsRequestDto;
import com.harman.dmat.common.dto.CustomReportsTemplateDto;
import com.harman.dmat.common.dto.LogMgrAnalysisDto;
import com.harman.dmat.common.dto.LogMgrDto;
import com.harman.dmat.common.dto.LogMgrPrefDto;
import com.harman.dmat.common.dto.LogMgrRespDto;
import com.harman.dmat.common.dto.PolygonLogsDto;
import com.harman.dmat.common.exception.DataAccessException;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.LogMgrException;
import com.harman.dmat.common.security.User;
import com.harman.dmat.common.sftp.SftpService;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.dao.LogMgrDao;
import com.harman.dmat.dao.UserDao;
import com.harman.dmat.utils.EsClient;
import com.harman.dmat.utils.Utill;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.SftpException;

import lombok.extern.slf4j.Slf4j;

/**
 * @author GTanwar Interacts with the database
 */
@Repository
@Slf4j
public class LogMgrDaoImpl extends BaseDao implements LogMgrDao {

	@Inject
	private Environment environment;

	@Inject
	SftpService sftpService;
	@Inject
	UserDao userDao;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.LogMgrDao#getLogResults(java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.Integer, java.lang.Integer)
	 */
	@Override
	public LogMgrRespDto getLogResults(final String userId, final String startDate, final String endDate,
			final String mdn, final String model, final String fileName, final String imei, final Integer offset,
			final Integer limit, String sortby, final Integer currUser, String sortCol) {

		sortby = sortby == null ? "log_captured_date" : "uploaded_date";
		sortCol = sortCol == null ? "" : sortCol + ",";
		final String[] sql = createSQLToFilterData(userId, startDate, endDate, mdn, model, fileName, imei, sortby);
		Integer count;

		if (offset != null && limit != null) {
			sql[0] = sql[0] + " ORDER BY " + sortCol + sortby + " desc" + ")" + " OFFSET " + (offset - 1) + " LIMIT "
					+ limit;

		}
		List<LogMgrDto> logMgrDtos;
		Map<String,String> autoTestReportMap;
		final LogMgrRespDto logMgrRespDto = new LogMgrRespDto();

		if (Constant.ALL.equalsIgnoreCase(userId)) {

			logMgrDtos = getJdbcTemplate().query(sql[0], new BeanPropertyRowMapper<LogMgrDto>(LogMgrDto.class));
			count = getJdbcTemplate().queryForObject(sql[1], Integer.class);
		} else {
			logMgrDtos = getJdbcTemplate().query(sql[0], new Integer[] { currUser },
					new BeanPropertyRowMapper<LogMgrDto>(LogMgrDto.class));
			count = getJdbcTemplate().queryForObject(sql[1], new Integer[] { currUser }, Integer.class);
		}

		if(!logMgrDtos.isEmpty()){
			autoTestReportMap = new HashMap<>();
			for(LogMgrDto lmd : logMgrDtos){
				autoTestReportMap.put(lmd.getFileName(),"N");
			}
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("filenames", autoTestReportMap.keySet());
			String atrSql = "select distinct filename from wifi_device_summary where filename in (:filenames)";
			List<String> filesList = getNamedParameterJdbcTemplate().query(atrSql, parameters, new BeanPropertyRowMapper<String>(String.class));
			if(!filesList.isEmpty()){
				for(String file : filesList){
					autoTestReportMap.put(file,"Y");
				}
				for(Map.Entry<String, String> entry : autoTestReportMap.entrySet()){
					if(StringUtils.equalsIgnoreCase("Y",autoTestReportMap.get(entry.getValue()))){
						for(int i=0;i<logMgrDtos.size();i++){
							if(logMgrDtos.get(i)!=null && StringUtils.equalsIgnoreCase(entry.getKey(),logMgrDtos.get(i).getFileName())){
								logMgrDtos.get(i).setAtrFlag(true);
								break;
							}
						}
					}
				}
			}
		}

		logMgrRespDto.setLogMgrDto(logMgrDtos);
		logMgrRespDto.setTotalCount(count);
		return logMgrRespDto;
	}

	/**
	 * Creates filter based on the passed parameters and creates an updated SQL
	 *
	 * @param userId
	 * @param calFilterType
	 * @param date
	 * @param mdn
	 * @param model
	 * @param fileName
	 * @param imei
	 * @return
	 */
	private String[] createSQLToFilterData(final String userId, final String startDate, final String endDate,
			final String mdn, final String model, final String fileName, final String imei, final String sortby) {
		String sql = "";
		String sqlCount = "";
		String[] sSql;
		StringBuffer sb = new StringBuffer();
		String domainQuery = "";
		final String userDomain = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserDomain();
		domainQuery = getDomainSqlQuery(userDomain);

		if (Constant.ALL.equalsIgnoreCase(userId)) {

			sql = "(SELECT log.mdn,log.imei,log.test_id,log.uploaded_date, log.log_captured_date, log.firstName, log.lastname,log.user_id,log.filename, log.size, log.gps,log.email,"
					+ " log.status, log.model_name, count(lvanalysis.testid) as events from vw_logmgr as log left outer join sde.event_lvanalysis as lvanalysis "
					+ "ON log.filename = lvanalysis.filename GROUP BY log.test_id,log.mdn,log.imei,log.test_id, log.uploaded_date, log.log_captured_date, "
					+ "log.firstName, log.lastname,log.user_id,log.filename, log.size, log.gps,log.email, log.status, log.model_name,log.user_domain "
					+ "having " + domainQuery;
			sqlCount = "SELECT count(*) totalCount from vw_logmgr as log where " + domainQuery;

		} else {
			sql = "(SELECT log.mdn,log.imei,log.test_id,log.uploaded_date, log.log_captured_date, log.firstName, log.lastname,log.user_id,log.filename, log.size, log.gps,log.email,"
					+ " log.status, log.model_name, count(lvanalysis.testid) as events from vw_logmgr as log left outer join sde.event_lvanalysis as lvanalysis "
					+ "ON log.filename = lvanalysis.filename GROUP BY log.test_id,log.mdn,log.imei,log.test_id, log.uploaded_date, log.log_captured_date, "
					+ "log.firstName, log.lastname,log.user_id,log.filename, log.size, log.gps,log.email, log.status, log.model_name,log.user_domain having log.user_id=? and "
					+ domainQuery;
			sqlCount = "SELECT count(*) totalCount from vw_logmgr as log where user_id=? and " + domainQuery;
		}
		final Map<String, Object> map = new HashMap<>();

		map.put("log.mdn", mdn);
		map.put("log.model", model);
		map.put("log.fileName", fileName);
		map.put("log.imei", imei);
		final Iterator<String> itr = map.keySet().iterator();
		while (itr.hasNext()) {
			final String key = itr.next();
			final Object value = map.get(key);
			if (value != null) {

				sb = sb.append(" and ").append(key).append(" like ").append("'").append(value).append("%'");

			}
		}
		final String sqlDate = createSqlWithDateFilters(startDate, endDate, userId, sortby, domainQuery);
		sql = sql + sqlDate + sb.toString();
		sqlCount = sqlCount + sqlDate + sb.toString();
		sSql = new String[] { sql, sqlCount };
		return sSql;

	}

	/**
	 * Creates filter based on the calendar parameters and creates an updated
	 * SQL
	 *
	 * @param calFilterType
	 * @param date
	 * @param userId
	 * @return String
	 */
	private String createSqlWithDateFilters(final String startDate, final String endDate, final String userId,
			final String sortby, final String domainQuery) {
		String sql = " ";
		if ("".equals(domainQuery)) {
			sql = sql + sortby + " >=" + "'" + startDate + "'" + " and " + sortby + "<" + "('" + endDate + "'"
					+ "::date +'1 day'::interval)";
		} else {
			sql = sql + " and " + sortby + " >=" + "'" + startDate + "'" + " and " + sortby + "<" + "('" + endDate + "'"
					+ "::date +'1 day'::interval)";
		}
		return sql;
	}

	/**
	 * Creates filter based on the calendar parameters and creates an updated
	 * SQL
	 *
	 * @param calFilterType
	 * @param date
	 * @param userId
	 * @return String
	 */
	private String createSqlSearchDateFilters(final String startDate, final String endDate, final String userId,
			final String sortby) {
		String sql = " ";
		sql = sql + " and " + sortby + " >=" + "'" + startDate + "'" + " and " + sortby + "<" + "('" + endDate + "'"
				+ "::date +'1 day'::interval)";
		return sql;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.LogMgrDao#saveUserPref(com.harman.dmat.common.dto.
	 * LogMgrPrefDto)
	 */
	@Override
	public Boolean saveUserPref(final LogMgrPrefDto logMgrUserPrefDto) {

		int updated = 0;
		updated = saveUserPrefData(logMgrUserPrefDto);

		return updated > 0 ? true : false;
	}

	/**
	 * Saves or updates the user preferences
	 *
	 * @param logMgrUserPrefDto
	 * @return Integer
	 */
	private Integer saveUserPrefData(final LogMgrPrefDto logMgrUserPrefDto) {
		String sql;
		int updated = 0;
		if (!userPrefExists(logMgrUserPrefDto.getUserId())) {
			sql = "Insert into userpref (user_id , uploadedDate, logCapturedDate, username, fileName, testId,"
					+ " size, gps , imei , status , mdn, modelname, email, logtype,events) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

			updated = getJdbcTemplate().update(sql.toString(),
					new Object[] { logMgrUserPrefDto.getUserId(), logMgrUserPrefDto.getUploadedDate(),
							logMgrUserPrefDto.getLogCapturedDate(), logMgrUserPrefDto.getUserName(),
							logMgrUserPrefDto.getFileName(), logMgrUserPrefDto.getTestId(), logMgrUserPrefDto.getSize(),
							logMgrUserPrefDto.getGps(), logMgrUserPrefDto.getImei(), logMgrUserPrefDto.getStatus(),
							logMgrUserPrefDto.getMdn(), logMgrUserPrefDto.getModelName(), logMgrUserPrefDto.getEmail(),
							logMgrUserPrefDto.getLogType(), logMgrUserPrefDto.getEvents() });

		} else {
			sql = "update userpref set  uploadedDate =?, logCapturedDate =?, username =?, fileName =?, testId =?,"
					+ " size =?, gps= ?, imei=?, status=?, mdn=?, modelname=?, email=?, logtype=?,events=? where user_id= ?";
			updated = getJdbcTemplate().update(sql,
					new Object[] { logMgrUserPrefDto.getUploadedDate(), logMgrUserPrefDto.getLogCapturedDate(),
							logMgrUserPrefDto.getUserName(), logMgrUserPrefDto.getFileName(),
							logMgrUserPrefDto.getTestId(), logMgrUserPrefDto.getSize(), logMgrUserPrefDto.getGps(),
							logMgrUserPrefDto.getImei(), logMgrUserPrefDto.getStatus(), logMgrUserPrefDto.getMdn(),
							logMgrUserPrefDto.getModelName(), logMgrUserPrefDto.getEmail(),
							logMgrUserPrefDto.getLogType(), logMgrUserPrefDto.getEvents(),
							logMgrUserPrefDto.getUserId() });
		}
		return updated;

	}

	/**
	 * Checks if the user preferences exists or not.
	 *
	 * @param user
	 * @return Boolean
	 */
	private Boolean userPrefExists(final Integer userId) {
		final String sql = "Select count(*) from userpref where user_id = ?";
		final Integer count = getJdbcTemplate().queryForObject(sql, new Object[] { userId }, Integer.class);
		if (count > 0) {

			return true;
		} else {
			return false;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.LogMgrDao#deleteLogs(java.lang.String[])
	 */
	@Override
	public Boolean deleteLogs(final List<String> deleteFiles, String startDate, String endDate)
			throws LogMgrException {
		boolean esExists = false;
		boolean ftpExists = false;
		boolean rdbmsExists = false;
		boolean delFtp = false;
		boolean delEs = false;
		boolean delDb = false;
		final Integer loginUserId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();
		for (String fileName : deleteFiles) {
			List<CustomReportsDto> customReportsDtoList = getPathFromFileName(fileName);
			String filePath = customReportsDtoList.get(0).getFileLocation() + "/"
					+ customReportsDtoList.get(0).getFileName();
			if (loginUserId != customReportsDtoList.get(0).getDmUser())
				return false;
			ftpExists = checkFtpExists(filePath);
			if (!ftpExists) {
				throw new LogMgrException("File not Found in FTP location.");
			}
			esExists = checkEsExists(customReportsDtoList.get(0).getFileName(), startDate, endDate);
			if (!esExists) {
				throw new LogMgrException("File not Found in ES location.");
			}
			rdbmsExists = checkRdbmsExists(customReportsDtoList.get(0).getFileName());
			if (!rdbmsExists) {
				throw new LogMgrException("File not Found in Database.");
			}
			if (ftpExists && esExists && rdbmsExists) {
				delFtp = deleteFromFTP(filePath);
				delEs = deleteFromEs(customReportsDtoList.get(0).getFileName(), startDate, endDate);
				delDb = deleteFromDb(fileName);
			}

		}
		if (delDb && delEs && delFtp) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Check if file exists in FTP location
	 * 
	 * @param file
	 * @return
	 */
	private boolean checkFtpExists(final String file) {
		boolean deleted = false;
		ChannelSftp channelSftp = null;
		try {
			channelSftp = sftpService.connectChannel();

			channelSftp.lstat(file);

			deleted = true;

		} catch (final SftpException e) {
			if (e.id == ChannelSftp.SSH_FX_NO_SUCH_FILE) {
				deleted = false;
			}
		}
		return deleted;
	}

	/**
	 * Check if file exists in RDBMS
	 * 
	 * @param file
	 * @return
	 */
	private boolean checkRdbmsExists(String file) {

		boolean result = false;
		//
		// final String logSql = "select count(*) from logs where file_name =" +
		// "'" + file + "'" + "";
		final String logSql = "select count(*) from logs where file_name =?";

		int count = 0;
		try {
			count = getJdbcTemplate().queryForObject(logSql, new Object[] { file }, Integer.class);
		} catch (final DataAccessException e) {
			throw new DataAccessException();
		}

		if (count > 0) {
			if (log.isDebugEnabled()) {
				log.debug("RDBMS record exists");
			}
			result = true;
		}

		return result;
	}

	/**
	 * Check if file exists in ES
	 * 
	 * @param file
	 * @return
	 */
	private boolean checkEsExists(final String file, String startDate, String endDate) {
		String indices = Utill.getIndex(startDate, endDate);
		log.debug("Indices it is checking in: " + indices);
		final SearchResponse response = EsClient.client.prepareSearch(indices.split(",")).setTypes("geo")
				.setSearchType(SearchType.QUERY_THEN_FETCH).setFetchSource(true)
				.setQuery(QueryBuilders.termsQuery("FileName", file))

				.execute().actionGet();

		if (response.getHits().getTotalHits() > 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Deletes from RDBMS
	 * @param fileName 
	 * 
	 * @param deleteFiles
	 * @return
	 */
	private boolean deleteFromDb(String fileName) {

		boolean result = false;
		final String logSql = "Delete from logs_multipart where file_name =" + "'" + fileName + "'";
		final String logSql1 = "Delete from logs where file_name =" + "'" + fileName + "'";

		int count = 0;
		int count1 = 0;
		try {
			count = getJdbcTemplate().update(logSql);
			if(count==0 || count < 0)
				count1 = getJdbcTemplate().update(logSql1);
		} catch (final DataAccessException e) {
			throw new DataAccessException();
		}

		if (count > 0 || count1 > 0) {
			if (log.isDebugEnabled()) {
				log.debug("Deleted from RDBMS");
			}
			result = true;
		}

		return result;
	}

	/**
	 * Deletes from Elastic search
	 * 
	 * @return
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	private static boolean deleteFromEs(String file, String startDate, String endDate) {

		long deleted = 0;
		String indices = Utill.getIndex(startDate, endDate);
		log.debug("Indices it is deleting from: " + indices);
		final BulkByScrollResponse response = DeleteByQueryAction.INSTANCE.newRequestBuilder(EsClient.client)
				.filter(QueryBuilders.matchQuery("FileName", file)).source(indices.split(",")).get();

		deleted = response.getDeleted();

		if (deleted > 0) {
			if (log.isDebugEnabled()) {
				log.debug("Deleted from ES");
			}
			return true;
		} else {
			return true;
		}
	}

	/**
	 * Deletes from FTP
	 * 
	 * @return
	 */
	private boolean deleteFromFTP(final String file) {
		boolean deleted;
		ChannelSftp channelSftp = null;
		try {
			channelSftp = sftpService.connectChannel();

			channelSftp.rm(file);

			deleted = true;
			if (log.isDebugEnabled()) {
				log.debug("Deleted from FTP");
			}
		} catch (final Exception e) {
			deleted = false;
		}

		return deleted;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.LogMgrDao#getUserPref(java.lang.String)
	 */
	@Override
	public List<LogMgrPrefDto> getUserPref(final Integer userId) {
		final List<LogMgrPrefDto> listLogMgrPrefDto = getJdbcTemplate().query(
				"select id, uploadedDate, logCapturedDate, username, fileName, testId,"
						+ " size, gps , imei , status , mdn, modelname, email, logtype,events from userpref where user_id=?",
				new Integer[] { userId }, new BeanPropertyRowMapper<LogMgrPrefDto>(LogMgrPrefDto.class));
		return listLogMgrPrefDto;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.LogMgrDao#getLogAnalysisData()
	 */
	@Override
	public Map<String, List<LogMgrAnalysisDto>> getLogAnalysisData(String userId, Integer currUser, String startDate,
			String endDate, String dateType) {
		final Map<String, List<LogMgrAnalysisDto>> dataMap = new HashMap<>();
		String lgsStatsSql = null;
		String gpsSql = null;
		final String userDomain = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserDomain();
		String domainQuery = getDomainSqlQuery(userDomain);
		dateType = dateType == null ? "log_captured_date" : "uploaded_date";
		domainQuery = " where " + domainQuery;

		if (Constant.ALL.equalsIgnoreCase(userId)) {

			lgsStatsSql = "Select status as status, count(*)as count, ((count(*)::decimal*100)/(select count(*)as "
					+ "tot from vw_logmgr where user_id IN (SELECT user_id from users " + domainQuery + ") "
					+ dateFiltersLogAnalysis(startDate, endDate, dateType) + ")) "
					+ "as percentage from vw_logmgr where user_id IN (SELECT user_id from users " + domainQuery + ") "
					+ dateFiltersLogAnalysis(startDate, endDate, dateType) + " group by status";
			gpsSql = "Select count(*)as count, ((count(*)::decimal*100)/(select count(*)as tot from vw_logmgr where user_id IN (SELECT user_id from users "
					+ domainQuery + ") " + dateFiltersLogAnalysis(startDate, endDate, dateType) + ")) "
					+ " as percentage, (case when gps=0 then 'Gps' else 'NonGps' end) as status from vw_logmgr where user_id IN "
					+ "(SELECT user_id from users " + domainQuery + ") "
					+ dateFiltersLogAnalysis(startDate, endDate, dateType) + " group by gps";

		} else {
			lgsStatsSql = "Select status as status, count(*)as count, ((count(*)::decimal*100)/(select count(*)as"
					+ " tot from vw_logmgr where user_id=" + currUser + "" + " and user_id IN (SELECT user_id from users "
					+ domainQuery + ") " + dateFiltersLogAnalysis(startDate, endDate, dateType)
					+ ")) as percentage from vw_logmgr where user_id=" + currUser + ""
					+ " and user_id IN (SELECT user_id from users " + domainQuery + ") "
					+ dateFiltersLogAnalysis(startDate, endDate, dateType) + " group by status";
			gpsSql = "Select count(*)as count, ((count(*)::decimal*100)/(select count(*)as tot from vw_logmgr "
					+ "where user_id=" + currUser + "" + " and user_id IN (SELECT user_id from users " + domainQuery
					+ ") " + dateFiltersLogAnalysis(startDate, endDate, dateType)
					+ ")) as percentage, (case when gps=0 then 'Gps' else 'NonGps' end)as status from vw_logmgr where user_id="
					+ currUser + "" + " and user_id IN (SELECT user_id from users " + domainQuery + ") "
					+ dateFiltersLogAnalysis(startDate, endDate, dateType) + " group by gps";

		}
		final List<LogMgrAnalysisDto> logStats = getJdbcTemplate().query(lgsStatsSql,
				new BeanPropertyRowMapper<LogMgrAnalysisDto>(LogMgrAnalysisDto.class));
		dataMap.put("logStats", logStats);
		final List<LogMgrAnalysisDto> gpsStats = getJdbcTemplate().query(gpsSql,
				new BeanPropertyRowMapper<LogMgrAnalysisDto>(LogMgrAnalysisDto.class));
		dataMap.put("gpsStats", gpsStats);
		return dataMap;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.LogMgrDao#searchLogs(java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.Integer, java.lang.Integer)
	 */
	@Override
	public LogMgrRespDto searchLogs(String user, String startDate, String endDate, String param, String sortby,
			Integer offset, Integer limit, Integer currUser, String sortCol) {
		sortby = sortby == null ? "log_captured_date" : "uploaded_date";
		final String[] sql = createSQLToSearchLogs(user, startDate, endDate, param, sortby);
		sortCol = sortCol == null ? "" : sortCol + ",";
		Integer count;

		if (offset != null && limit != null) {
			sql[0] = sql[0] + " ORDER BY " + sortCol + sortby + " desc" + ")" + " OFFSET " + (offset - 1) + " LIMIT "
					+ limit;

		}
		List<LogMgrDto> logMgrDtos;
		final LogMgrRespDto logMgrRespDto = new LogMgrRespDto();

		if (Constant.ALL.equalsIgnoreCase(user)) {

			logMgrDtos = getJdbcTemplate().query(sql[0], new BeanPropertyRowMapper<LogMgrDto>(LogMgrDto.class));
			count = getJdbcTemplate().queryForObject(sql[1], Integer.class);
		} else {
			logMgrDtos = getJdbcTemplate().query(sql[0], new Integer[] { currUser },
					new BeanPropertyRowMapper<LogMgrDto>(LogMgrDto.class));
			count = getJdbcTemplate().queryForObject(sql[1], new Integer[] { currUser }, Integer.class);
		}

		logMgrRespDto.setLogMgrDto(logMgrDtos);
		logMgrRespDto.setTotalCount(count);
		return logMgrRespDto;

	}

	/**
	 * Creates filter based on the calendar parameters and creates an updated
	 * SQL
	 * 
	 * @param user
	 * @param startDate
	 * @param endDate
	 * @param param
	 * @param sortby
	 * @return
	 */
	private String[] createSQLToSearchLogs(final String user, final String startDate, final String endDate,
			String param, final String sortby) {
		String sql = "";
		String sqlCount = "";
		String[] sSql;
		final String userDomain = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserDomain();
		String domainQuery = getDomainSqlQuery(userDomain);
		if (Constant.ALL.equalsIgnoreCase(user)) {
			if (!param.matches("[-+]?\\d*\\.?\\d+")) {
				sql = "(SELECT log.mdn,log.imei,log.test_id as id, log.test_id as test_id,log.uploaded_date, log.log_captured_date, log.firstName,"
						+ " log.lastname,log.user_id,log.filename, log.size, log.gps,log.email, log.status,"
						+ " log.model_name , count(lvanalysis.testid) as events from vw_logmgr as log left outer join sde.event_lvanalysis as lvanalysis "
						+ "ON log.filename = lvanalysis.filename GROUP BY log.test_id,log.mdn,log.imei,log.test_id, log.uploaded_date, log.log_captured_date, "
						+ "log.firstName, log.lastname,log.user_id,log.filename, log.size, log.gps,log.email, log.status, log.model_name,log.user_domain "
						+ "having " + domainQuery + " and (LOWER(log.filename)" + " like '%" + param
						+ "%' OR LOWER(log.firstname) like '%" + param + "%' OR LOWER(log.lastname) like '%" + param
						+ "%' OR LOWER(log.imei) like '%" + param + "%' OR LOWER(log.mdn) like '%" + param + "%'"
						+ " OR LOWER(log.model_name) like '%" + param + "%'  OR LOWER(log.email) like '%" + param
						+ "%' ) " + " and " + domainQuery;
				sqlCount = "SELECT count(*) as totalCount from vw_logmgr where (LOWER(filename)" + " like '%" + param
						+ "%' OR LOWER(firstname) like '%" + param + "%' OR LOWER(lastname) like '%" + param
						+ "%' OR LOWER(imei) like '%" + param + "%' OR LOWER(mdn) like '%" + param + "%'"
						+ " OR LOWER(model_name) like '%" + param + "%'  OR LOWER(email) like '%" + param + "%' ) "
						+ " and " + domainQuery;
			} else {
				sql = "(SELECT log.mdn,log.imei,log.test_id as id, log.test_id as test_id,log.uploaded_date, log.log_captured_date, log.firstName,"
						+ " log.lastname,log.user_id,log.filename, log.size, log.gps,log.email, log.status,"
						+ " log.model_name , count(lvanalysis.testid) as events from vw_logmgr as log left outer join sde.event_lvanalysis as lvanalysis "
						+ "ON log.filename = lvanalysis.filename GROUP BY log.test_id,log.mdn,log.imei,log.test_id, log.uploaded_date, log.log_captured_date, "
						+ "log.firstName, log.lastname,log.user_id,log.filename, log.size, log.gps,log.email, log.status, log.model_name,log.user_domain "
						+ "having " + domainQuery + " and (log.test_id=" + param + " OR LOWER(log.imei) like '%" + param
						+ "%' OR LOWER(log.filename)" + " like '%" + param + "%' OR LOWER(log.mdn) like '%" + param
						+ "%' )" + " and " + domainQuery;
				sqlCount = "SELECT count(*) as totalCount from vw_logmgr where " + " (test_id=" + param
						+ " OR LOWER(imei) like '%" + param + "%' OR LOWER(filename)" + " like '%" + param
						+ "%' OR LOWER(mdn) like '%" + param + "%' )" + " and " + domainQuery;
			}

		} else {
			if (!param.matches("[-+]?\\d*\\.?\\d+")) {
				sql = "(SELECT log.mdn,log.imei,log.test_id as id, log.test_id as test_id,log.uploaded_date, log.log_captured_date, log.firstName,"
						+ " log.lastname,log.user_id,log.filename, log.size, log.gps,log.email, log.status,"
						+ " log.model_name , count(lvanalysis.testid) as events from vw_logmgr as log left outer join sde.event_lvanalysis as lvanalysis "
						+ "ON log.filename = lvanalysis.filename GROUP BY log.test_id,log.mdn,log.imei,log.test_id, log.uploaded_date, log.log_captured_date, "
						+ "log.firstName, log.lastname,log.user_id,log.filename, log.size, log.gps,log.email, log.status, log.model_name,log.user_domain "
						+ "having " + domainQuery + " and (LOWER(log.filename)" + " like '%" + param
						+ "%' OR LOWER(log.firstname) like '%" + param + "%' OR LOWER(log.lastname) like '%" + param
						+ "%' OR LOWER(log.imei) like '%" + param + "%' OR LOWER(log.mdn) like '%" + param + "%'"
						+ " OR LOWER(log.model_name) like '%" + param + "%'  OR LOWER(log.email) like '%" + param
						+ "%' ) and log.user_id=? and " + domainQuery;
				sqlCount = "SELECT count(*) as totalCount from vw_logmgr where (LOWER(filename)" + " like '%" + param
						+ "%' OR LOWER(firstname) like '%" + param + "%' OR LOWER(lastname) like '%" + param
						+ "%' OR LOWER(imei) like '%" + param + "%' OR LOWER(mdn) like '%" + param + "%'"
						+ " OR LOWER(model_name) like '%" + param + "%'  OR LOWER(email) like '%" + param
						+ "%' ) and user_id=? and " + domainQuery;
			} else {
				sql = "(SELECT log.mdn,log.imei,log.test_id as id, log.test_id as test_id,log.uploaded_date, log.log_captured_date, log.firstName,"
						+ " log.lastname,log.user_id,log.filename, log.size, log.gps,log.email, log.status,"
						+ " log.model_name , count(lvanalysis.testid) as events from vw_logmgr as log left outer join sde.event_lvanalysis as lvanalysis "
						+ "ON log.filename = lvanalysis.filename GROUP BY log.test_id,log.mdn,log.imei,log.test_id, log.uploaded_date, log.log_captured_date, "
						+ "log.firstName, log.lastname,log.user_id,log.filename, log.size, log.gps,log.email, log.status, log.model_name,log.user_domain "
						+ "having " + domainQuery + " and (log.test_id=" + param + " OR LOWER(log.imei) like '%" + param
						+ "%' OR LOWER(log.filename)" + " like '%" + param + "%' OR LOWER(log.mdn) like '%" + param
						+ "%' )" + "and log.user_id=? and " + domainQuery;
				sqlCount = "SELECT count(*) as totalCount from vw_logmgr where " + " (test_id=" + param
						+ " OR LOWER(imei) like '%" + param + "%' OR LOWER(filename)" + " like '%" + param
						+ "%' OR LOWER(mdn) like '%" + param + "%' )" + " and user_id=? and " + domainQuery;
			}
		}
		final String sqlDate = createSqlSearchDateFilters(startDate, endDate, user, sortby);
		sql = sql + sqlDate;
		sqlCount = sqlCount + sqlDate;
		sSql = new String[] { sql, sqlCount };
		return sSql;

	}

	@Override
	public PolygonLogsDto getLogSixMonthLogs(Integer userId, String geoPoints, String mdn, String imei,
			String stateCode, String regions, String modelId, String deviceId, Integer limit, Integer offset,
			String startDate, String endDate, String fileName) {
		final StringBuilder userQuery = new StringBuilder("");
		final String userDomain = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserDomain();
		if (userId != null) {
			userQuery.append("{ \"term\": { \"DmUser\": \"" + userId + "\" } },");
		}
		if (imei != null) {
			userQuery.append("{ \"term\": { \"Imei\": \"" + imei + "\" } },");

		}

		if (mdn != null) {
			userQuery.append("{ \"term\": { \"MDN\": \"" + mdn + "\" } },");

		}

		if (stateCode != null) {
			userQuery.append("{ \"term\": { \"StateCode\": \"" + stateCode + "\" } },");

		}

		if (regions != null) {
			userQuery.append("{ \"term\": { \"VzwRegions\": \"" + regions + "\" } },");

		}

		if (deviceId != null) {
			userQuery.append("{ \"term\": { \"DeviceName\": \"" + deviceId + "\" } },");
		}

		if (modelId != null) {
			userQuery.append("{ \"term\": { \"ModelName\": \"" + modelId + "\" } },");

		}
		if (fileName != null) {
			userQuery.append("{ \"terms\": { \"FileName\": " + getTermsData(Arrays.asList(fileName.split(","))) + " } }, ");
		}

		userQuery.append(getDomainESQuery(userDomain)).append(",");
		if (startDate != null && endDate != null) {
			userQuery.append("{ \"range\": { \"TimeStamp\": { \"from\": \"" + startDate + "\", \"to\": \"" + endDate
					+ "\", " + "\"include_lower\": true, \"include_upper\": true, \"boost\": 1 } } }, ");
		}

		final String query = "{ \"from\": 0, \"size\": 0, \"query\": { \"bool\": { \"filter\": [ "
				+ userQuery.toString() + "{ \"geo_polygon\": { \"loc\": { \"points\": [" + geoPoints
				+ "] } } } ],\"must_not\": [ { \"exists\": { \"field\": \"InbuildinguserMark\" } } ] } }, \"aggregations\": { \"log_files\": { \"terms\": { \"field\": \"FileName\", \"size\": 500000"
				+ ", \"order\": { \"max_play_count\": \"desc\" } }, \"aggs\": { \"max_play_count\": { \"max\": { \"field\":"
				+ " \"TimeStamp\" } }, \"result\": { \"top_hits\": { \"size\": 1, \"_source\": { \"include\": ["
				+ " \"TimeStamp\", \"DmUser\", \"FileName\", \"TestId\", \"Imei\", \"MDN\", \"ModelName\" ] }, \"sort\": [ { \"TimeStamp\": { \"order\": \"desc\" } } ]   } } } }, "
				+ "\"total_log_file\": { \"cardinality\": { \"field\": \"FileName\" } } }}";
		if (log.isDebugEnabled())
			log.debug("Last six month log query:" + query);
		final SearchRequest searchRequest = new SearchRequest();
		String sIndices = Utill.getIndex(startDate, endDate);
		if (log.isDebugEnabled())
			log.debug("Last six month log Indices:" + sIndices);
		final String dataType = environment.getRequiredProperty("data-point-es-type");
		final String[] indices = sIndices.split(",");
		searchRequest.indices(indices).types(dataType);

		final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
				.setRequest(searchRequest).setScript(query).setScriptType(ScriptType.INLINE).get();

		final Aggregations aggregations = searchResponse.getResponse().getAggregations();

		final PolygonLogsDto polygonLogsDto = new PolygonLogsDto();
		polygonLogsDto.setTotal(searchResponse.getResponse().getHits().getTotalHits());
		final List<Object> response = new ArrayList<Object>();

		if (aggregations != null) {
			final InternalCardinality total = searchResponse.getResponse().getAggregations().get("total_log_file");
			polygonLogsDto.setTotal(total.getValue());
			final Terms terms = searchResponse.getResponse().getAggregations().get("log_files");

			for (final Bucket a : terms.getBuckets()) {
				final InternalTopHits internal = a.getAggregations().get("result");
				final SearchHits s = internal.getHits();
				final SearchHit[] sp = s.getHits();
				response.add(sp[0].getSource());
			}
		}

		polygonLogsDto.setLogs(response);
		return polygonLogsDto;

		/*
		 * if (userId != null) { userQuery.append(
		 * "{ \"term\": { \"dm_user\": \"" + userId + "\" } },"); } if (imei !=
		 * null) { userQuery.append("{ \"term\": { \"imei\": \"" + imei +
		 * "\" } },");
		 * 
		 * }
		 * 
		 * if (mdn != null) { userQuery.append("{ \"term\": { \"mdn\": \"" + mdn
		 * + "\" } },");
		 * 
		 * }
		 * 
		 * if (stateCode != null) { userQuery.append(
		 * "{ \"term\": { \"statecode\": \"" + stateCode + "\" } },");
		 * 
		 * }
		 * 
		 * if (regions != null) { userQuery.append(
		 * "{ \"term\": { \"vz_regions\": \"" + regions + "\" } },");
		 * 
		 * }
		 * 
		 * if (deviceId != null) { userQuery.append(
		 * "{ \"term\": { \"device\": \"" + deviceId + "\" } },"); }
		 * 
		 * if (modelId != null) { userQuery.append(
		 * "{ \"term\": { \"model_name\": \"" + modelId + "\" } },");
		 * 
		 * }
		 * 
		 * // userQuery.append("{ \"term\": { \"user_domain\": \"" + userDomain
		 * + // "\" } // },");
		 * 
		 * final String query = "{ \"size\": " + limit + ", \"from\": " + offset
		 * +
		 * ",\"_source\": { \"includes\": [ \"dm_timestamp\", \"dm_user\", \"file_name\", \"dm_timestamp\", "
		 * +
		 * "\"test_id\", \"imei\", \"mdn\", \"model_name\" ], \"excludes\": [] }, \"query\": "
		 * + "{ \"bool\": { \"filter\": [ " + userQuery.toString() +
		 * " { \"range\":" +
		 * " { \"dm_timestamp\": { \"gte\": \"now-6M/M\", \"format\": \"dd/MM/yyyy\" } } },"
		 * + " { \"geo_polygon\": { \"loc\": { \"points\": [ " + geoPoints +
		 * "] } } } ] } }," +
		 * " \"sort\": [ { \"dm_timestamp\": { \"order\": \"desc\" } } ] }";
		 * log.debug("Last six month log query:" + query); final SearchRequest
		 * searchRequest = new SearchRequest(); final String dataIndex =
		 * environment.getRequiredProperty("data-point-es-index"); final String
		 * dataType = environment.getRequiredProperty("data-point-es-type");
		 * final String[] indices = dataIndex.split(",");
		 * searchRequest.indices(indices).types(dataType);
		 * 
		 * final SearchTemplateResponse searchResponse = new
		 * SearchTemplateRequestBuilder(EsClient.client)
		 * .setRequest(searchRequest).setScript(query).setScriptType(ScriptType.
		 * INLINE).get();
		 * 
		 * final SearchHit[] s =
		 * searchResponse.getResponse().getHits().getHits(); final
		 * PolygonLogsDto polygonLogsDto = new PolygonLogsDto();
		 * polygonLogsDto.setTotal(searchResponse.getResponse().getHits().
		 * getTotalHits()); final List<Object> response = new
		 * ArrayList<Object>(); for (final SearchHit a : s) {
		 * response.add(a.getSource()); } polygonLogsDto.setLogs(response);
		 * return polygonLogsDto;
		 */
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.LogMgrDao#searchLogFiles(java.lang.Integer,
	 * java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public CustomReportsLogDto searchLogFiles(Integer data, String from, String to, String param, Integer offset,
			Integer limit) {
		List<CustomReportsDto> customReportsDtos = null;

		CustomReportsLogDto customReportLogDtoObj = new CustomReportsLogDto();

		final String userDomain = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserDomain();
		String domainQuery = "";

		domainQuery = " and " + getDomainSqlQuery(userDomain);

		final String[] sql = new String[2];
		Integer count = 0;

		sql[0] = "SELECT test_id as testId, filename as fileName from vw_logmgr where LOWER(filename)" + " like '%"
				+ param.toLowerCase() + "%'" + domainQuery + " and log_captured_date >=" + "'" + from + "'"
				+ " and log_captured_date" + "<" + "('" + to + "'" + "::date +'1 day'::interval)";

		if (offset != null && limit != null) {
			sql[0] = sql[0] + " ORDER BY fileName desc" + " OFFSET " + (offset - 1) + " LIMIT " + limit;

		}

		sql[1] = "SELECT count(fileName) from vw_logmgr where LOWER(filename)" + " like '%" + param.toLowerCase() + "%'"
				+ domainQuery + " and log_captured_date >=" + "'" + from + "'" + " and log_captured_date" + "<" + "('"
				+ to + "'" + "::date +'1 day'::interval)";

		if ("".equals(param.trim())) {
			customReportsDtos = new ArrayList<>();
		} else {
			customReportsDtos = getJdbcTemplate().query(sql[0],
					new BeanPropertyRowMapper<CustomReportsDto>(CustomReportsDto.class));

			if (offset == 1)
				count = getJdbcTemplate().queryForObject(sql[1], Integer.class);
		}

		customReportLogDtoObj.setCustomReportsDto(customReportsDtos);
		customReportLogDtoObj.setTotalCount(count);

		return customReportLogDtoObj;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.LogMgrDao#getHistogram(java.lang.Integer,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String)
	 */
	@Override
	public Map<String, List<CustomReportsHistogramDto>> getHistogram(CustomReportsRequestDto customReportsRequestDto) {
		final Map<String, List<CustomReportsHistogramDto>> map = new HashMap<>();

		String variableQuery = null;
		String fixedQuery = null;
		String filesQuery = "";
		String statesQuery = "";
		String imeiQuery = "";
		String userQuery = "";
		String interval = "10";
		String from = customReportsRequestDto.getFrom();
		String to = customReportsRequestDto.getTo();
		String dateRangeQuery = "";

		final String userDomain = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserDomain();
		String domainQuery = "";

		domainQuery = getDomainESQuery(userDomain);

		if (from != null && to != null) {
			dateRangeQuery = "{ \"range\": { \"TimeStamp\": { \"from\": \"" + from + "\", \"to\": \"" + to + "\", "
					+ "\"include_lower\": true, \"include_upper\": true, \"boost\": 1 } } }, ";
		}

		final String fileName = getTermsData(customReportsRequestDto.getFileNames());
		final String state = getTermsData(customReportsRequestDto.getStates());
		final String imeis = getTermsData(customReportsRequestDto.getImei());
		final String users = getTermsData(customReportsRequestDto.getUserIds());
		if (fileName != null) {
			filesQuery = "{ \"terms\": { \"FileName\": " + fileName + " } }, ";
		}
		if (state != null) {
			statesQuery = "{ \"terms\": { \"StateCode\": " + state + " } }, ";
		}
		if (imeis != null) {
			imeiQuery = "{ \"terms\": { \"Imei\": " + imeis + " } }, ";
		}
		if (users != null) {
			userQuery = "{ \"terms\": { \"DmUser\": " + users + " } }, ";
		}

		StringBuilder sbVariableKpi = new StringBuilder();
		StringBuilder sbFixedKpi = new StringBuilder();
		final SearchRequest searchRequest = new SearchRequest();
		String indices = Utill.getIndex(from, to);

		final String dataPointType = environment.getRequiredProperty("data-point-es-type");
		final String[] sIndices = indices.split(",");
		searchRequest.indices(sIndices).types(dataPointType);

		final String[] kpiArr = customReportsRequestDto.getKpis()
				.toArray(new String[customReportsRequestDto.getKpis().size()]);
		for (String kpi : kpiArr) {
			// certain kpis will have unique values in x axis
			if (kpi.contains("LTEPccCqiCw0:CQI CW0") || kpi.contains("LTEPccPci:PCI")
					|| kpi.contains("LTEPCccqiCw1:CQI CW1") || kpi.contains("LTEPccBandInd:LTE Band")
					|| kpi.contains("LTEBwUL:UL Bandwidth") || kpi.contains("LTEPccBwDL:DL Bandwidth")) {
				interval = "1";
			} else
				interval = "10";

			if ("v".equalsIgnoreCase(kpi.split(":")[2])) {
				sbVariableKpi = sbVariableKpi.append("\"")
						.append(kpi.split(":")[1] + "\": { \"histogram\": { \"field\": \"" + kpi.split(":")[0]
								+ "\", \"interval\": " + interval + " } },");
			}

			if ("f".equalsIgnoreCase(kpi.split(":")[2])) {

				sbFixedKpi = sbFixedKpi.append("\"").append(kpi.split(":")[1] + "\": { \"terms\": { \"field\": \""
						+ kpi.split(":")[0] + "\",\"size\": 10000, \"order\": { \"_term\": \"asc\" }} },");
			}
		}
		if (sbVariableKpi.length() > 0) {
			variableQuery = "{ \"size\": 0, \"query\": { \"bool\": { \"must\": ["
					+ "{ \"match_phrase\": { \"Outlier\": { \"query\": 0, \"slop\": 0, \"boost\": 1 } } },"
					+ dateRangeQuery + filesQuery + statesQuery + imeiQuery + userQuery + domainQuery + "] } },"
					+ " \"aggs\": {" + sbVariableKpi.toString().substring(0, sbVariableKpi.toString().length() - 1)
					+ "} }";
			if (log.isDebugEnabled()) {
				log.debug("Histogram Variable Query formed: " + variableQuery);
				log.debug("Indices: " + indices);
			}

			final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
					.setRequest(searchRequest).setScript(variableQuery).setScriptType(ScriptType.INLINE).get();

			for (Aggregation key : searchResponse.getResponse().getAggregations()) {
				final Histogram histogram = searchResponse.getResponse().getAggregations().get(key.getName());
				final List<CustomReportsHistogramDto> customReportsHistogramDtos = new ArrayList<>();
				if (histogram.getBuckets().size() > 0) {
					for (int i = 0; i < histogram.getBuckets().size(); i++) {
						final CustomReportsHistogramDto customReportsHistogramDto = new CustomReportsHistogramDto();
						customReportsHistogramDto.setX(histogram.getBuckets().get(i).getKeyAsString());
						customReportsHistogramDto.setY(Long.toString(histogram.getBuckets().get(i).getDocCount()));
						customReportsHistogramDtos.add(customReportsHistogramDto);

					}
					map.put(key.getName(), customReportsHistogramDtos);

				}
			}

		}
		if (sbFixedKpi.length() > 0) {

			fixedQuery = "{ \"size\": 0,\"query\": { \"bool\": { \"must\": [ {"
					+ " \"match_phrase\": { \"Outlier\": { \"query\": 0 } } }," + dateRangeQuery + filesQuery
					+ statesQuery + imeiQuery + userQuery + domainQuery + "]" + "} } , \"aggs\": {"
					+ sbFixedKpi.substring(0, sbFixedKpi.length() - 1) + "} }";

			if (log.isDebugEnabled()) {
				log.debug("Histogram Fixed Query formed: " + fixedQuery);
				log.debug("Indices: " + indices);
			}

			searchRequest.indices(sIndices).types(dataPointType);

			final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
					.setRequest(searchRequest).setScript(fixedQuery).setScriptType(ScriptType.INLINE).get();
			for (Aggregation key : searchResponse.getResponse().getAggregations()) {
				final Terms terms = searchResponse.getResponse().getAggregations().get(key.getName());
				final List<CustomReportsHistogramDto> customReportsHistogramFixedDtos = new ArrayList<>();

				if (terms.getBuckets().size() > 0) {
					for (int i = 0; i < terms.getBuckets().size(); i++) {
						final CustomReportsHistogramDto customReportsHistogramDto = new CustomReportsHistogramDto();
						customReportsHistogramDto.setX(terms.getBuckets().get(i).getKeyAsString());
						customReportsHistogramDto.setY(Long.toString(terms.getBuckets().get(i).getDocCount()));
						customReportsHistogramFixedDtos.add(customReportsHistogramDto);

					}
					map.put(key.getName(), customReportsHistogramFixedDtos);
				}

			}

		}

		return map;
	}

	/**
	 * @param data
	 * @return
	 */
	private String getTermsData(List<String> data) {
		if (data == null) {
			return null;
		}
		StringBuffer sb = new StringBuffer();
		sb.append("[");
		for (String value : data) {
			sb = sb.append("\"").append(value).append("\"").append(",");
		}

		return sb.substring(0, sb.length() - 1) + "]";

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.LogMgrDao#getDevices(java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public List<String> getDevices(String query, String index) throws DataNotFoundException {
		final List<String> list = new ArrayList<>();
		final SearchRequest searchRequest = new SearchRequest();
		final String dataPointType = environment.getRequiredProperty("data-point-es-type");
		final String[] indices = index.split(",");
		searchRequest.indices(indices).types(dataPointType);
		final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
				.setRequest(searchRequest).setScript(query).setScriptType(ScriptType.INLINE).get();

		for (final Aggregation aggregation : searchResponse.getResponse().getAggregations().asList()) {
			final String aggName = aggregation.getName();

			final Terms terms = searchResponse.getResponse().getAggregations().get(aggName);

			for (int i = 0; i < terms.getBuckets().size(); i++) {

				final Terms terms1 = terms.getBuckets().get(i).getAggregations().get("unique_set_2");
				for (int j = 0; j < terms1.getBuckets().size(); j++) {
					list.add(terms.getBuckets().get(i).getKeyAsString() + "_"
							+ terms1.getBuckets().get(j).getKeyAsString());
				}

			}

		}
		return list;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.LogMgrDao#saveTemplate(com.harman.dmat.common.dto.
	 * CustomReportsTemplateDto)
	 */
	@Override
	public Integer saveTemplate(CustomReportsTemplateDto reportsTemplateDto) {
		int rowAffected = 0;
		String sql = "Insert into report_templates (user_id, template_name, graph_type, kpi_id) values (?,?,?,?)";
		try {
			rowAffected = getJdbcTemplate().update(conn -> {
				PreparedStatement ps = conn.prepareStatement(sql);
				Array array = conn.createArrayOf("TEXT", new Object[] { reportsTemplateDto.getKpiIds() });
				ps.setInt(1, reportsTemplateDto.getUserId());
				ps.setString(2, reportsTemplateDto.getTemplateName());
				ps.setInt(3, reportsTemplateDto.getGraphType());
				ps.setArray(4, array);
				return ps;
			});

		} catch (org.springframework.dao.DataAccessException e) {

		}
		return rowAffected;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.LogMgrDao#getAllTemplates(java.lang.String)
	 */
	@Override
	public List<CustomReportsTemplateDto> getAllTemplates(String userId) throws DataNotFoundException {
		String sql = "select template_id as templateId, user_id as userId, template_name as templateName, graph_type as graphType"
				+ ", kpi_id as kpiIds from report_templates where user_id= " + Integer.parseInt(userId)
				+ " order by template_name asc";

		return getJdbcTemplate().query(sql, new ResultSetExtractor<List<CustomReportsTemplateDto>>() {

			@Override
			public List<CustomReportsTemplateDto> extractData(ResultSet rs) throws SQLException, DataAccessException {

				List<CustomReportsTemplateDto> list = new ArrayList<CustomReportsTemplateDto>();
				while (rs.next()) {
					CustomReportsTemplateDto e = new CustomReportsTemplateDto();
					e.setTemplateId(rs.getInt(1));
					e.setUserId(rs.getInt(2));
					e.setTemplateName(rs.getString(3));
					e.setGraphType(rs.getInt(4));
					Array jdbcArray = rs.getArray(5);
					String[] pathArray = (String[]) jdbcArray.getArray();
					List<String> path = Arrays.asList(pathArray);
					e.setKpiIds(path);
					list.add(e);
				}
				return list;
			}
		});
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.LogMgrDao#deleteTemplate(com.harman.dmat.common.dto.
	 * CustomReportsTemplateDto)
	 */
	@Override
	public Integer deleteTemplate(CustomReportsTemplateDto reportsTemplateDto) {
		final String logSql = "Delete from report_templates where user_id =? and template_id=?";

		int count = 0;
		try {
			count = getJdbcTemplate().update(logSql,
					new Object[] { reportsTemplateDto.getUserId(), reportsTemplateDto.getTemplateId() });
		} catch (final org.springframework.dao.DataAccessException e) {
			if (log.isDebugEnabled()) {
				log.debug("Could not delete template");
			}
		}

		if (count > 0) {
			if (log.isDebugEnabled()) {
				log.debug("Deleted template");
			}

		}

		return count;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.LogMgrDao#editTemplate(com.harman.dmat.common.dto.
	 * CustomReportsTemplateDto)
	 */
	@Override
	public Integer editTemplate(CustomReportsTemplateDto reportsTemplateDto) {
		int rowAffected = 0;
		String sql = "update report_templates set  template_name=?, graph_type=?, kpi_id=? where user_id=? and template_id=?";
		try {
			rowAffected = getJdbcTemplate().update(conn -> {
				PreparedStatement ps = conn.prepareStatement(sql);
				Array array = conn.createArrayOf("TEXT", new Object[] { reportsTemplateDto.getKpiIds() });
				ps.setString(1, reportsTemplateDto.getTemplateName());
				ps.setInt(2, reportsTemplateDto.getGraphType());
				ps.setArray(3, array);
				ps.setInt(4, reportsTemplateDto.getUserId());
				ps.setInt(5, reportsTemplateDto.getTemplateId());
				return ps;

			});

		} catch (org.springframework.dao.DataAccessException e) {

		}
		return rowAffected;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.LogMgrDao#getTimeseries(java.lang.Integer,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public Map<String, List<CustomReportsHistogramDto>> getTimeseries(CustomReportsRequestDto customReportsRequestDto) {

		final Map<String, List<CustomReportsHistogramDto>> map = new HashMap<>();
		String from = customReportsRequestDto.getFrom();
		String to = customReportsRequestDto.getTo();
		String query = null;
		String filesQuery = "";
		String userQuery = "";
		String dateRangeQuery = "";
		StringBuilder sbVariableKpi = new StringBuilder();

		final String userDomain = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserDomain();
		String domainQuery = "";

		domainQuery = "," + getDomainESQuery(userDomain);

		if (from != null && to != null) {
			dateRangeQuery = ",{ \"range\": { \"TimeStamp\": { \"from\": \"" + from + "\", \"to\": \"" + to + "\", "
					+ "\"include_lower\": true, \"include_upper\": true, \"boost\": 1 } } } ";
		}
		final String fileNames = getTermsData(customReportsRequestDto.getFileNames());
		final String userId = getTermsData(customReportsRequestDto.getUserIds());
		if (fileNames != null) {
			filesQuery = ",{ \"terms\": { \"FileName\": " + fileNames + " } } ";
		}
		if (userId != null) {
			userQuery = ",{ \"terms\": { \"FileName\": " + fileNames + " } } ";
		}

		final String[] kpiArr = customReportsRequestDto.getKpis()
				.toArray(new String[customReportsRequestDto.getKpis().size()]);
		for (String kpi : kpiArr) {
			sbVariableKpi = sbVariableKpi.append("\"").append(kpi.split(":")[1] + "\"" + ": { \"terms\": { \"field\": "
					+ "\"" + kpi.split(":")[0] + "\"" + ", \"size\": 10000, \"order\": { \"_term\": \"asc\" } } },");
		}
		final SearchRequest searchRequest = new SearchRequest();
		String indices = Utill.getIndex(from, to);
		if (sbVariableKpi.length() > 0) {
			query = "{ \"size\": 0,\"query\": { \"bool\": { \"must\": [ {"
					+ " \"match_phrase\": { \"Outlier\": { \"query\": 0 } } }" + dateRangeQuery + userQuery + filesQuery
					+ domainQuery + "]"
					+ "} } , \"aggs\": { \"Time\": { \"terms\": { \"field\": \"TimeStamp\" , \"size\": 10000, \"order\": { \"_term\": \"asc\" }}, \"aggregations\": { "
					+ sbVariableKpi.substring(0, sbVariableKpi.length() - 1) + "} } } }";
		}
		if (log.isDebugEnabled()) {
			log.debug("Timeseries Query formed: " + query);
			log.debug("Timeseries Indices: " + indices);
		}

		final String dataPointType = environment.getRequiredProperty("data-point-es-type");
		final String[] sIndices = indices.split(",");
		searchRequest.indices(sIndices).types(dataPointType);

		final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
				.setRequest(searchRequest).setScript(query).setScriptType(ScriptType.INLINE).get();
		SimpleDateFormat sdfSource = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat sdfDestination = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");

		for (final Aggregation aggregation : searchResponse.getResponse().getAggregations().asList()) {
			final String aggName = aggregation.getName();
			final Terms terms = searchResponse.getResponse().getAggregations().get(aggName);

			for (int i = 0; i < terms.getBuckets().size(); i++) {
				for (final Aggregation aggregationInternal : terms.getBuckets().get(i).getAggregations()) {
					String name = aggregationInternal.getName();

					final Terms terms1 = terms.getBuckets().get(i).getAggregations().get(name);
					if (terms1.getBuckets().size() > 0) {
						for (int j = 0; j < terms1.getBuckets().size(); j++) {
							final List<CustomReportsHistogramDto> customReportsHistogramDtos = new ArrayList<>();
							final CustomReportsHistogramDto customReportsHistogramDto = new CustomReportsHistogramDto();

							String strDate = terms.getBuckets().get(i).getKeyAsString().substring(0, 19).replace('T',
									' ');

							try {
								Date date = sdfSource.parse(strDate);
								strDate = sdfDestination.format(date);
								customReportsHistogramDto.setX(strDate);
							} catch (ParseException e) {
								e.printStackTrace();
							}

							customReportsHistogramDto.setY(terms1.getBuckets().get(j).getKeyAsString());

							if (map.containsKey(name)) {
								map.get(name).add(customReportsHistogramDto);
								map.put(name, map.get(name));
							} else {
								customReportsHistogramDtos.add(customReportsHistogramDto);
								map.put(name, customReportsHistogramDtos);
							}
						}

					}
				}
			}

		}

		return map;

	}

	/**
	 * Creates the domain SQL query
	 * 
	 * @param userDomain
	 * @return
	 */
	private String getDomainSqlQuery(String userDomain) {
		String domainQuery = "";
		userDomain = userDomain == null ? "null" : userDomain;
		StringBuffer sb = new StringBuffer();
		try {
			List<String> listVzDomains = Arrays
					.asList(environment.getRequiredProperty("verizon.domains").toLowerCase().split(","));

			if (listVzDomains.contains(userDomain.toLowerCase())) {
				for (String domain : listVzDomains) {
					sb = sb.append("'").append(domain.toLowerCase()).append("'").append(",");
				}
				sb.deleteCharAt(sb.length() - 1);
				domainQuery = " LOWER(user_domain) in (" + sb + ")";
			} else {
				domainQuery = " LOWER(user_domain) = LOWER('" + userDomain + "')";
			}
		} catch (Exception e) {
			log.error("Error Getting Vz domains");
		}

		return domainQuery;
	}

	/**
	 * Creates the domain SQL query
	 * 
	 * @param userDomain
	 * @return
	 */
	private String getDomainESQuery(String userDomain) {
		String domainQuery = "";
		userDomain = userDomain == null ? "null" : userDomain;
		StringBuffer sb = new StringBuffer();
		try {
			List<String> listVzDomains = Arrays.asList(environment.getRequiredProperty("verizon.domains").split(","));

			if (listVzDomains.contains(userDomain)) {
				for (String domain : listVzDomains) {
					sb = sb.append("{ \"query_string\": { \"query\": \"EmailId:*").append(domain).append("\"} },");
				}
				sb.deleteCharAt(sb.length() - 1);
				domainQuery = "{ \"bool\": { \"should\": [" + sb.toString() + "] } }";
			} else {
				sb = sb.append("{ \"query_string\": { \"query\": \"EmailId:*").append(userDomain.toLowerCase())
						.append("\"} }");
				domainQuery = "{ \"bool\": { \"must\": [" + sb.toString() + "] } }";
			}
		} catch (Exception e) {
			log.error("Error Getting Vz domains");
		}

		return domainQuery;
	}

	/**
	 * Return file path from logs table
	 * 
	 * @param file
	 * @return
	 */
	public String getFilePath(String file) {
		String filePath = "";
		final String logSql = "select file_location from logs_multipart where file_name =? limit 1";
		final String logSql1 = "select file_location from logs where file_name =? limit 1";
		try {
			if (doFileExistInLogs_MultipartTable(file)) {
				filePath = getJdbcTemplate().queryForObject(logSql, new Object[] { file }, String.class);
			} else if (doFileExistInLogsTable(file)) {
				filePath = getJdbcTemplate().queryForObject(logSql1, new Object[] { file }, String.class);
			} else {
				throw new DataAccessException("file not found in rdbms ");
			}
			return filePath;
		} catch (final DataAccessException e) {
			throw new DataAccessException();
		}
	}

	public boolean doFileExistInLogsTable(String fileName) {
		String sql = "select count(*) from logs where file_name=?";
		Optional<Integer> noOfRecordFound = Optional.of(getJdbcTemplate().queryForObject(sql, Integer.class, fileName));
		return noOfRecordFound.isPresent() && noOfRecordFound.get() > 0;
	}

	public boolean doFileExistInLogs_MultipartTable(String fileName) {
		String sql = "select count(*) from logs_multipart where file_name=?";
		Optional<Integer> noOfRecordFound = Optional.of(getJdbcTemplate().queryForObject(sql, Integer.class, fileName));
		return noOfRecordFound.isPresent() && noOfRecordFound.get() > 0;
	}


	/**
	 * Return file path from logs table
	 * 
	 * @param testId
	 * @return
	 */
	public List<CustomReportsDto> getPathFromFileName(String fileName) {
		List<CustomReportsDto> customReportDtoList = null;
		final String logSql = "select file_location as fileLocation, file_name as fileName, dm_user as dmUser from logs_multipart where file_name = ?";
		final String logSql1 = "select file_location as fileLocation, file_name as fileName, dm_user as dmUser from logs where file_name = ?";
		try {
			customReportDtoList = getJdbcTemplate().query(logSql, new Object[] { fileName },
					new BeanPropertyRowMapper<CustomReportsDto>(CustomReportsDto.class));
			if(customReportDtoList==null || customReportDtoList.isEmpty()) {
				customReportDtoList = getJdbcTemplate().query(logSql1, new Object[] { fileName },
						new BeanPropertyRowMapper<CustomReportsDto>(CustomReportsDto.class));
			}
			return customReportDtoList;
		} catch (final DataAccessException e) {
			throw new DataAccessException();
		}
	}

	/**
	 * Creates filter based on the calendar parameters and creates an updated
	 * SQL
	 *
	 * @param calFilterType
	 * @param date
	 * @param userId
	 * @return String
	 */
	private String dateFiltersLogAnalysis(final String startDate, final String endDate, final String dateType) {
		String sql = " and ";
		sql = sql + dateType + " >=" + "'" + startDate + "'" + " and " + dateType + "<" + "('" + endDate + "'"
				+ "::date +'1 day'::interval)";
		return sql;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.LogMgrDao#getUserNameFromFile(java.lang.String)
	 */
	@Override
	public String getUserFromFile(String file) {
		String userId = "";
		final String logSql = "select user_id from vw_logmgr where filename =? limit 1";
		try {
			userId = getJdbcTemplate().queryForObject(logSql, new Object[] { file }, String.class);
			return userId;
		} catch (final DataAccessException e) {
			throw new DataAccessException();
		}
	}

}