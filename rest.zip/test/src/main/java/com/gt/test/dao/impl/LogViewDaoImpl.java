package com.harman.dmat.dao.impl;

import com.harman.dmat.common.config.BaseDao;
import com.harman.dmat.common.dto.AutoTestReportDto;
import com.harman.dmat.common.dto.EventStatusDto;
import com.harman.dmat.common.dto.LogViewDto;
import com.harman.dmat.dao.LogViewDao;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

@Repository
public class LogViewDaoImpl extends BaseDao implements LogViewDao {
    @Override
    public String getFileId(LogViewDto logViewDto) {
        final String sql = "select (select lvfid from event_lvanalysis where filename = ? and testid = ? and evt_timestamp::text like ?) as value";

        return getMapJdbcTemplate().queryForObject(sql, new Object[] { logViewDto.getFileName(), logViewDto.getTestId(), logViewDto.getEventTimeStamp()+"%" }, (rs, num) -> rs.getString(1));
    }

    @Override
    public String updateEvtStatus(List<LogViewDto> statusList, boolean inProgressStatus){
        final String sql = "update event_lvanalysis set status=? where objectid=?";
        int[][] updateCounts = getMapJdbcTemplate().batchUpdate(sql, statusList, statusList.size(),

                new ParameterizedPreparedStatementSetter<LogViewDto>() {
                    @Override
                    public void setValues(PreparedStatement ps, LogViewDto logViewDto) throws SQLException {
                        ps.setString(1, (inProgressStatus)?"INPROGRESS":logViewDto.getStatus().toUpperCase());
                        ps.setInt(2, logViewDto.getObjectId());
                    }
                });
        String result = (updateCounts[0].length == statusList.size())?"success":"failure";
        return result;
    }
    @Override
    public List<LogViewDto> getEventsList(){
        final String sql = "select objectid, filename as fileName, file_path, evt_timestamp as eventTimeStamp, status from event_lvanalysis where status='NEW' \n" +
                "AND (filename, file_path, evt_timestamp) is not null order by objectid desc";
        return getMapJdbcTemplate().query(sql, new BeanPropertyRowMapper<>(LogViewDto.class));
    }

    @Override
    public EventStatusDto getStatusReportCount(String startDate, String endDate){
        final String sql = "select \n" +
                "(SELECT count(*)\n" +
                "FROM event_lvanalysis \n" +
                "WHERE evt_timestamp between '"+startDate+"'::date and '"+endDate+"'::date + interval '1 day' and status in ('INPROGRESS')) as inProgressEvents,\n" +
                "\n" +
                "(SELECT count(*)\n" +
                "FROM event_lvanalysis \n" +
                "WHERE evt_timestamp between '"+startDate+"'::date and '"+endDate+"'::date + interval '1 day' and status in ('SUCCESS')) as successEvents,\n" +
                "\n" +
                "(SELECT count(*)\n" +
                "FROM event_lvanalysis \n" +
                "WHERE evt_timestamp between '"+startDate+"'::date and '"+endDate+"'::date + interval '1 day' and status in ('FAILURE')) as failureEvents,\n" +
                "\n" +
                "(SELECT count(*)\n" +
                "FROM event_lvanalysis \n" +
                "WHERE evt_timestamp between '"+startDate+"'::date and '"+endDate+"'::date + interval '1 day' and status in ('NEW')) as newEvents";
        return getMapJdbcTemplate().queryForObject(sql, new BeanPropertyRowMapper<>(EventStatusDto.class));
    }

    @Override
    public List<AutoTestReportDto> getAutoTestReport(String fileName){
        final String sql = "select * from detailssummary where detailsid in (select detailsid from device_test_summary where filename like '%"+fileName+"%');";
        return getJdbcTemplate().query(sql, new BeanPropertyRowMapper<>(AutoTestReportDto.class));
    }
}