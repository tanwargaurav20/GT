package com.harman.dmat.dao.impl;

import com.harman.dmat.common.config.BaseDao;
import com.harman.dmat.common.dto.PostProcLogsDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.dao.PostProcLogsDao;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import java.util.*;

@Slf4j
@Repository
public class PostProcLogsDaoImpl extends BaseDao implements PostProcLogsDao {
    @Override
    public String addPostProcLogs(List<PostProcLogsDto> postProcLogs) {
        final ResponseDto responseDto = new ResponseDto();

        SimpleJdbcInsert simpleJdbcInsert = getPostProcSimpleJdbcInsert();
        List<Map<String, Object>> batchValues = new ArrayList<>(postProcLogs.size());

        for (PostProcLogsDto postProcLogsDto : postProcLogs) {
            Map<String, Object> map = new HashMap<>();

            map.put("dm_user", postProcLogsDto.getDmUser());
            map.put("file_name", postProcLogsDto.getFileName());
            map.put("mdn", postProcLogsDto.getMdn());
            map.put("imei", postProcLogsDto.getImei());
            map.put("emailid", postProcLogsDto.getEmailId());
            map.put("model_name", postProcLogsDto.getModelName());
            map.put("file_location", postProcLogsDto.getFileLocation());
            map.put("appversioncode", postProcLogsDto.getAppVersionCode());
            map.put("appversionname", postProcLogsDto.getAppVersionName());
            map.put("basebandversion", postProcLogsDto.getBaseBandVersion());
            map.put("iccid", postProcLogsDto.getIccid());
            map.put("imsfeaturetag", postProcLogsDto.getImsFeatureTag());
            map.put("imsstatus", postProcLogsDto.getImsStatus());
            map.put("imsi", postProcLogsDto.getImsi());
            map.put("islastchunk", postProcLogsDto.getIsLastChunk());
            map.put("oemname", postProcLogsDto.getOemName());
            map.put("osbuildid", postProcLogsDto.getOsBuildId());
            map.put("ossdklevel", postProcLogsDto.getOsSdkLevel());
            map.put("osversion", postProcLogsDto.getOsVersion());
            map.put("isnondmat", postProcLogsDto.getIsnondmat());
            map.put("post_processed", false);
            map.put("creation_time", new Date());

            batchValues.add(map);
        }

        if (!simpleJdbcInsert.isCompiled()) {
            simpleJdbcInsert.withTableName("logs_dmat1_5").usingGeneratedKeyColumns("id");
        }

        int[] status = simpleJdbcInsert.executeBatch(batchValues.toArray(new Map[batchValues.size()]));

        return status.length == batchValues.size() ? "Success" : "Failed";
    }
}
