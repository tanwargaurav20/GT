package com.harman.dmat.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Pattern;

import javax.inject.Inject;

import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.script.mustache.SearchTemplateRequestBuilder;
import org.elasticsearch.script.mustache.SearchTemplateResponse;
import org.elasticsearch.search.aggregations.metrics.cardinality.Cardinality;
import org.elasticsearch.search.aggregations.metrics.valuecount.ValueCount;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.harman.dmat.common.config.BaseDao;
import com.harman.dmat.common.dto.AccordionInfo;
import com.harman.dmat.common.dto.AccordionStats;
import com.harman.dmat.common.dto.AccordionStatusInfo;
import com.harman.dmat.common.dto.AreaDto;
import com.harman.dmat.common.dto.CompanyDto;
import com.harman.dmat.common.dto.DeviceDto;
import com.harman.dmat.common.dto.EventDto;
import com.harman.dmat.common.dto.EventDtos;
import com.harman.dmat.common.dto.EventsBodyDto;
import com.harman.dmat.common.dto.EventsCountDto;
import com.harman.dmat.common.dto.FeedBackDto;
import com.harman.dmat.common.dto.FileUploadDto;
import com.harman.dmat.common.dto.GroupDto;
import com.harman.dmat.common.dto.GroupRequestDto;
import com.harman.dmat.common.dto.LastActivitiyDto;
import com.harman.dmat.common.dto.OsDto;
import com.harman.dmat.common.dto.PreferenceDto;
import com.harman.dmat.common.dto.PrivilegeDto;
import com.harman.dmat.common.dto.RegionDto;
import com.harman.dmat.common.dto.RoleDto;
import com.harman.dmat.common.dto.SimInfoDto;
import com.harman.dmat.common.dto.SimRequestData;
import com.harman.dmat.common.dto.SimRequestDto;
import com.harman.dmat.common.dto.SoftwareVersionDto;
import com.harman.dmat.common.dto.StateDto;
import com.harman.dmat.common.dto.StatusInfoDto;
import com.harman.dmat.common.dto.UserDto;
import com.harman.dmat.common.dto.UserPreferenceDto;
import com.harman.dmat.common.exception.DataAccessException;
import com.harman.dmat.common.exception.FTPException;
import com.harman.dmat.common.exception.UserException;
import com.harman.dmat.common.security.User;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.dao.UserDao;
import com.harman.dmat.enums.FileTypeEnum;
import com.harman.dmat.enums.GroupStatus;
import com.harman.dmat.enums.LogActivityStatus;
import com.harman.dmat.enums.Roles;
import com.harman.dmat.enums.Status;
import com.harman.dmat.utils.EsClient;
import com.harman.dmat.utils.Utill;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class UserDaoImpl.
 *
 * @author <a href="mailto:Prakash.Bisht@harman.com">Prakash Bisht</a>
 */
@Slf4j
@Repository
public class UserDaoImpl extends BaseDao implements UserDao {

	@Inject
	Environment environment;
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dao.UserDao#getUsers()
	 */

	/**
	 * Gets the user.
	 *
	 * @param userId
	 *            the user id
	 * @return the user
	 * @throws UserException
	 *             the user exception
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getUser(java.lang.Integer)
	 */
	@Override
	public UserDto getUser(final Integer userId) throws UserException {
		final List<UserDto> users = getJdbcTemplate().query(
				"SELECT user_id as userId,email,first_name as firstName,last_name as lastName,password,role_id as roleId,"
						+ "state_code as stateCode, region, business_purpose as businessPurpose, company_id as companyId,preference_id as preferenceId,"
						+ "status, is_group_admin as isGroupAdmin, is_first_login as isFirstLogin,"
						+ " is_reset_password as isResetPassword,last_login as lastLogin, access_code as accessCode FROM users where user_id=?",
				new Object[] { userId }, new BeanPropertyRowMapper<UserDto>(UserDto.class));
		return users.isEmpty() ? null : users.get(0);
	}

	/**
	 * Gets the users.
	 *
	 * @return the users
	 * @throws UserException
	 *             the user exception
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getUsers()
	 */
	@Override
	public List<Map<String, Object>> getUsers() throws UserException {
		final String sql = "Select * from USERS where IS_DELETE <> 1";
		return getJdbcTemplate().queryForList(sql);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#updateUserPassword(java.lang.Integer,
	 * java.lang.String, boolean)
	 */
	/**
	 * Update user password.
	 *
	 * @param userId
	 *            the user id
	 * @param hashPassword
	 *            the hash password
	 * @param passwordReset
	 *            the password reset
	 * @return the boolean
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#updateUserPassword(java.lang.Integer,
	 * java.lang.String, boolean)
	 */
	@Override
	public Boolean updateUserPassword(final Integer userId, final String hashPassword, final boolean passwordReset) {
		final int row = getJdbcTemplate().update("update users set PASSWORD = ?,IS_RESET_PASSWORD=? where USER_ID = ?",
				hashPassword, passwordReset ? 1 : 0, userId);
		return row == 1 ? true : false;
	}

	/**
	 * Gets the company list.
	 *
	 * @return the company list
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getCompanyList()
	 */
	@Override
	public List<CompanyDto> getCompanyList() {
		final String sql = "Select * from COMPANY";
		return getJdbcTemplate().queryForList(sql, CompanyDto.class);

	}

	/**
	 * Gets the user count.
	 *
	 * @return the user count
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getUserCount()
	 */
	@Override
	public Integer getUserCount() {
		final String sql = "Select COUNT(*) from users";
		final Integer count = getJdbcTemplate().queryForObject(sql, Integer.class);
		return count;
	}

	/**
	 * Gets the user details.
	 *
	 * @param offset
	 *            the offset
	 * @param limit
	 *            the limit
	 * @param userType
	 *            the user type
	 * @return the user details
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getUserDetails(java.lang.Integer,
	 * java.lang.Integer, java.lang.Integer)
	 */
	@Override
	public List<UserDto> getUserDetails(final Integer offset, final Integer limit, final String userType) {
		final Integer loinUserId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();
		final String sql = "SELECT EMAIL,USER_ID,FIRST_NAME,LAST_NAME,ROLE_ID,"
				+ "USER_CREATED_DATE,BUSINESS_PURPOSE,COMPANY_ID,REGION,STATE_CODE,PREFERENCE_ID,"
				+ "status,IS_GROUP_ADMIN,IS_FIRST_LOGIN,IS_RESET_PASSWORD," + "LAST_LOGIN,ACCESS_CODE,INS_TS,INS_LOGIN,"
				+ "UPD_TS,UPD_LOGIN FROM users where IS_DELETE <> 1 and USER_ID <> ? limit ? offset  ?";
		final List<UserDto> userDto = getJdbcTemplate().query(sql, new Object[] { loinUserId, limit, offset - 1 },
				new BeanPropertyRowMapper<UserDto>(UserDto.class));
		return userDto;

	}

	/**
	 * Register user.
	 *
	 * @param userDto
	 *            the user dto
	 * @return the int
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#registerUser(com.harman.dmat.common.dto.
	 * UserDto)
	 */
	@Override
	public int registerUser(final UserDto userDto) {
		final String sql = "INSERT INTO users (EMAIL,PASSWORD,FIRST_NAME,LAST_NAME,BUSINESS_PURPOSE,COMPANY_ID,REGION,STATE_CODE,INS_LOGIN,STATUS,JOB_TITLE,IS_GROUP_ADMIN,USER_DOMAIN)"
				+ "VALUES (?, ?, ?, ?,?, ?, ?, ?,?,?,?,?,?)";

		final KeyHolder keyHolder = new GeneratedKeyHolder();
		getJdbcTemplate().update((PreparedStatementCreator) connection -> {
			final PreparedStatement ps = connection.prepareStatement(sql, new String[] { "user_id" });
			final Object object = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			Integer roleId = Roles.USER.getValue();
			if (object instanceof User) {
				roleId = ((User) object).getScope();
			}
			Integer status = Status.PENDING.getValue();
			if (roleId == Roles.ADMIN.getValue() || roleId == Roles.SUPER_ADMIN.getValue()) {
				status = Status.INACTIVE.getValue();
			}
			ps.setString(1, userDto.getEmail());
			ps.setString(2, userDto.getPassword());
			ps.setString(3, userDto.getFirstName());
			ps.setString(4, userDto.getLastName());
			ps.setString(5, userDto.getBusinessPurpose());
			ps.setInt(6, userDto.getCompanyId());
			ps.setString(7, userDto.getRegion());
			ps.setString(8, userDto.getStateCode());
			ps.setString(9, userDto.getInsertBy());
			ps.setInt(10, status);
			ps.setString(11, userDto.getJobTitle());
			ps.setInt(12, userDto.getIsGroupAdmin() == null || userDto.getIsGroupAdmin() == 0 ? 0
					: Roles.GROUP_ADMIN.getValue());
			ps.setString(13, userDto.getEmail().split("@")[1]);
			return ps;

		}, keyHolder);
		final long result = keyHolder.getKey().longValue();
		final String preferenceSql = "INSERT INTO user_preferences(USER_ID,PREFERENCE_ID) VALUES (?, ?)";
		return getJdbcTemplate().update(preferenceSql, result, Constant.DEFAULT_PREFERENCE_ID);

	}

	@Override
	public boolean isUniqueEmail(String email) {
		final String sql = "SELECT count(user_id) FROM users WHERE email = ? and is_delete <> 1";
		final int status = getJdbcTemplate().queryForObject(sql, new Object[] { email }, Integer.class);
		return status == 0 ? true : false;
	}

	/**
	 * Check user exist.
	 *
	 * @param userId
	 *            the user id
	 * @return the user dto
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#checkUserExist(java.lang.Integer)
	 */
	@Override
	public UserDto checkUserExist(final Integer userId) {
		final String sql = "SELECT USER_ID,FIRST_NAME,LAST_NAME,ROLE_ID FROM users WHERE USER_ID = ?";
		final UserDto userDto = getJdbcTemplate().queryForObject(sql, new Object[] { userId },
				new BeanPropertyRowMapper<UserDto>(UserDto.class));
		return userDto;
	}

	/**
	 * Delete user data.
	 *
	 * @param userId
	 *            the user id
	 * @return the boolean
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#deleteUserData(java.util.List)
	 */
	@Override
	public Boolean deleteUserData(final List<Integer> userId) {
		Boolean result = false;
		String preferencesql = "DELETE FROM user_preferences WHERE USER_ID IN (";
		{
			for (final Integer id : userId) {
				preferencesql = preferencesql + id + " ,";
			}
		}

		String logsql = "DELETE FROM logs WHERE USER_ID IN (";
		{
			for (final Integer id : userId) {
				logsql = logsql + id + " ,";
			}
		}
		String userprefsql = "DELETE FROM userpref WHERE user_id IN (";
		{
			for (final Integer id : userId) {
				userprefsql = userprefsql + id + " ,";
			}
		}

		String userssql = "DELETE FROM users WHERE USER_ID IN (";
		{
			for (final Integer id : userId) {
				userssql = userssql + id + " ,";
			}
		}
		preferencesql = preferencesql.substring(0, preferencesql.length() - 1) + ")";
		logsql = logsql.substring(0, logsql.length() - 1) + ")";
		userssql = userssql.substring(0, userssql.length() - 1) + ")";
		userprefsql = userprefsql.substring(0, userprefsql.length() - 1) + ")";
		int[] count = null;
		try {
			count = getJdbcTemplate().batchUpdate(preferencesql, logsql, userprefsql, userssql);
		} catch (final DataAccessException e) {
			throw new DataAccessException();

		}
		if (count[0] > 0 || count[1] > 0 || count[2] > 0 || count[3] > 0) {
			result = true;
		}
		return result;

	}

	/**
	 * Gets the search user data.
	 *
	 * @param searchparam
	 *            the searchparam
	 * @return the search user data
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getSearchUserData(java.lang.String)
	 */
	@Override
	public List<UserDto> getSearchUserData(final String searchparam) {
		final String sql = "SELECT EMAIL,USER_ID,FIRST_NAME,LAST_NAME,ROLE_ID,"
				+ "USER_CREATED_DATE,BUSINESS_PURPOSE,COMPANY_ID,REGION,STATE_CODE,PREFERENCE_ID,"
				+ "STATUS,IS_GROUP_ADMIN,IS_FIRST_LOGIN,IS_RESET_PASSWORD,"
				+ "LAST_LOGIN,ACCESS_CODE,INS_TS,INS_LOGIN,UPD_TS,UPD_LOGIN FROM users where  IS_DELETE <> 1 and lower(EMAIL) ilike ?";
		return getJdbcTemplate().query(sql, new Object[] { "%" + searchparam + "%" },
				new BeanPropertyRowMapper<UserDto>(UserDto.class));
	}

	/**
	 * Edits the user status.
	 *
	 * @param userEmail
	 *            the user email
	 * @param roleId
	 *            the role id
	 * @param isActive
	 *            the is active
	 * @return the int
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#editUserStatus(java.lang.String, int,
	 * int)
	 */
	@Override
	public int editUserStatus(final String userEmail, final int roleId, final int isActive) {
		final Timestamp currentTimestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
		final String sqlUpdate = "UPDATE users set status=?,role_id=?,upd_ts=? where email=?";
		return getJdbcTemplate().update(sqlUpdate, new Object[] { isActive, roleId, currentTimestamp, userEmail });

	}

	/**
	 * Gets the user preference.
	 *
	 * @param userId
	 *            the user id
	 * @return the user preference
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getUserPreference(java.lang.Integer)
	 */
	@Override
	public UserPreferenceDto getUserPreference(final Integer userId) {
		final String sql = "select user_id, preference_id, state_code, min_x, min_y, max_x, max_y, zoom_level, wkid from user_preferences where user_id=?";
		/*
		 * final UserPreferenceDto userPreferenceDto =
		 * getJdbcTemplate().queryForObject(sql, new Object[] { userId }, new
		 * BeanPropertyRowMapper<UserPreferenceDto>(UserPreferenceDto.class));
		 */
		final UserPreferenceDto userPreferenceDto = getJdbcTemplate().queryForObject(sql, new Object[] { userId },
				new RowMapper<UserPreferenceDto>() {

					@Override
					public UserPreferenceDto mapRow(ResultSet resultSet, int i) throws SQLException {
						final UserPreferenceDto upd = new UserPreferenceDto();
						if (resultSet != null) {
							final AreaDto areaDto = new AreaDto();
							upd.setUserId(resultSet.getInt("user_id"));
							upd.setPreferenceId(resultSet.getInt("preference_id"));
							upd.setZoomLevel(resultSet.getInt("zoom_level"));
							final List<String> states = new ArrayList<>();
							states.add(resultSet.getString("state_code"));
							upd.setStateCode(states);
							areaDto.setMinX(resultSet.getDouble("min_x"));
							areaDto.setMinY(resultSet.getDouble("min_y"));
							areaDto.setMaxX(resultSet.getDouble("max_x"));
							areaDto.setMaxY(resultSet.getDouble("max_y"));
							areaDto.setWkid(resultSet.getInt("wkid"));
							upd.setMapExtent(areaDto);
						}
						return upd;
					}
				});
		return userPreferenceDto;
	}

	/**
	 * Gets the user preference.
	 *
	 * @param states
	 *            the user states
	 * @return the area of preference
	 */
	/*
	 * (non-Javadoc)
	 *
	 * @see com.harman.dmat.dao.UserDao#getUserPreference(java.lang.Integer)
	 */
	@Override
	public AreaDto getUserPreferredArea(final String states) {
		AreaDto areaDto = null;
		if (!StringUtils.isEmpty(states)) {
			/*
			 * List<String> stateCodes =
			 * Arrays.asList(states.split(Pattern.quote("|")));
			 * MapSqlParameterSource parameters = new MapSqlParameterSource();
			 * parameters.addValue("stateCodes", stateCodes);
			 */
			final String[] stateCodes = states.split(Pattern.quote("|"));
			StringBuilder inputStates = new StringBuilder();
			for (final String str : stateCodes) {
				inputStates.append(formatString(str));
			}
			inputStates = new StringBuilder(inputStates.substring(0, inputStates.length() - 1));
			final String sql = "select min(ST_MinX(st_transform(shape, 3857))) as min_x, min(ST_MinY(st_transform(shape, 3857))) as min_y, max(ST_MaxX(st_transform(shape, 3857))) as max_x, max(ST_MaxY(st_transform(shape, 3857))) as max_y  from states_wm where stusps in ("
					+ inputStates + ")";
			areaDto = getMapJdbcTemplate().queryForObject(sql, new BeanPropertyRowMapper<AreaDto>(AreaDto.class));
		}
		return areaDto;
	}

	/**
	 * Format string.
	 *
	 * @param str
	 *            the str
	 * @return the string
	 */
	private String formatString(String str) {
		final String s = "'".concat(str).concat("',");
		return s;
	}

	/**
	 * Gets the priviledgefor role.
	 *
	 * @param email
	 *            the email
	 * @return the priviledgefor role
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getPriviledgeforRole(java.lang.String)
	 */
	@Override
	public UserDto getPriviledgeforRole(final String email) {
		final String sql = "select ROLE_ID FROM users WHERE EMAIL=?";
		final UserDto userDto = getJdbcTemplate().queryForObject(sql, new Object[] { email },
				new BeanPropertyRowMapper<UserDto>(UserDto.class));
		return userDto;
	}

	/**
	 * Gets the privilege data.
	 *
	 * @param roleId
	 *            the role id
	 * @return the privilege data
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getprivilegeData(java.lang.Integer)
	 */
	@Override
	public List<PrivilegeDto> getprivilegeData(final Integer roleId) {
		final String sql = "select pvl.PRIVILEGE_ID,pvl.PRIVILEGE_NAME from privilege as pvl,role_privileges as rpvl where pvl.PRIVILEGE_ID=rpvl.PRIVILEGE_ID and rpvl.ROLE_ID=?";
		return getJdbcTemplate().query(sql, new Object[] { roleId },
				new BeanPropertyRowMapper<PrivilegeDto>(PrivilegeDto.class));

	}

	/**
	 * Update last login time.
	 *
	 * @param userId
	 *            the user id
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#updateLastLoginTime(java.lang.Integer)
	 */
	@Override
	public void updateLastLoginTime(final Integer userId) {
		final String sql = "update users set last_login = ?  where user_id = ?";
		getJdbcTemplate().update(sql, new Date(), userId);

	}

	/**
	 * Gets the last login time.
	 *
	 * @param userId
	 *            the user id
	 * @return the last login time
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getLastLoginTime(java.lang.Integer)
	 */
	@Override
	public Date getLastLoginTime(final Integer userId) {
		final String sql = "select last_login from users where user_id=?";
		return getJdbcTemplate().queryForObject(sql, new Object[] { userId }, Date.class);
	}

	/**
	 * Upadate access code.
	 *
	 * @param userId
	 *            the user id
	 * @param accessCode
	 *            the access code
	 * @param suspendUser
	 *            the suspend user
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#upadateAccessCode(java.lang.Integer,
	 * java.lang.String, int)
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	@Override
	public void upadateAccessCode(final Integer userId, final String accessCode, final int suspendUser) {
		final String sql = "update users set access_code = ?,status=?  where user_id = ?";
		getJdbcTemplate().update(sql, accessCode, suspendUser, userId);
	}

	/**
	 * Gets the admin email.
	 *
	 * @return the admin email
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getAdminEmail()
	 */
	@Override
	public List<String> getAdminEmail() {
		final String sql = "select email from users where role_id=" + Roles.ADMIN.getValue();
		return getJdbcTemplate().queryForList(sql, String.class);
	}

	/**
	 * Gets the role id.
	 *
	 * @param userId
	 *            the user id
	 * @return the role id
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getRoleId(java.lang.Integer)
	 */
	@Override
	public Integer getRoleId(final Integer userId) {
		final String sql = "SELECT ROLE_ID FROM users WHERE USER_ID = ?";
		return getJdbcTemplate().queryForObject(sql, new Object[] { userId }, Integer.class);

	}

	/**
	 * Update userdata.
	 *
	 * @param userInfo
	 *            the user info
	 * @return the int
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#updateUserdata(java.lang.String,
	 * java.lang.String, java.lang.Integer)
	 */
	@Override
	public int updateUserdata(final Map<String, String> userInfo) {
		final Set<Entry<String, String>> userEntry = userInfo.entrySet();
		String query = "update users set ";
		for (final Entry entry : userEntry) {
			if (!Constant.USER_ID.equalsIgnoreCase(entry.getKey().toString()) && entry.getValue() != null
					&& entry.getValue().toString().trim().length() != 0) {
				query += entry.getKey() + "=";
				query += "'" + entry.getValue() + "',";
			}
		}
		query = query.substring(0, query.length() - 1);
		query += " where user_id=" + userInfo.get(Constant.USER_ID);
		return getJdbcTemplate().update(query);

	}

	/**
	 * Gets the inactive users.
	 *
	 * @param days
	 *            the days
	 * @return the inactive users
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getInactiveUsers(int)
	 */
	@Override
	public List<UserDto> getInactiveUsers(final int days) {
		final String sql = "SELECT user_id as userId,email,first_name as firstName,last_name as lastName FROM users WHERE IS_DELETE <> 1 and last_login < NOW() - INTERVAL '"
				+ days + "' Day";
		return getJdbcTemplate().query(sql, new BeanPropertyRowMapper<UserDto>(UserDto.class));
	}

	/**
	 * Edits the rolefor user.
	 *
	 * @param userEmail
	 *            the user email
	 * @param newroleId
	 *            the newrole id
	 * @return the integer
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#editRoleforUser(java.lang.String, int)
	 */
	@Override
	public Integer editRoleforUser(final String userEmail, final int newroleId) {
		final Timestamp currentTimestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
		return getJdbcTemplate().update("update users set ROLE_ID = ?,UPD_TS=? where EMAIL = ?", newroleId,
				currentTimestamp, userEmail);

	}

	/**
	 * Activate users.
	 *
	 * @param userIds
	 *            the user ids
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#activateUSers(java.util.List)
	 */
	@Override
	public void activateUsers(final List<Integer> userIds) {
		final String inClasue = getInClasue(userIds);
		getJdbcTemplate().update("update users set status =? where USER_ID in (" + inClasue + ")",
				Status.ACTIVE.getValue());

	}

	/**
	 * Gets the in clasue.
	 *
	 * @param ids
	 *            the ids
	 * @return the in clasue
	 */
	private String getInClasue(List<Integer> ids) {
		final StringBuilder stringBuilder = new StringBuilder();
		for (final Integer id : ids) {
			stringBuilder.append(id + ",");
		}
		stringBuilder.replace(stringBuilder.length() - 1, stringBuilder.length(), "");
		return stringBuilder.toString();
	}

	/**
	 * Make coma sperated.
	 *
	 * @param ids
	 *            the ids
	 * @return the string
	 */
	private String makeComaSperated(List<String> ids) {
		if (ids != null && ids.isEmpty() || ids == null) {
			return "";
		}
		final StringBuilder stringBuilder = new StringBuilder();
		for (final String id : ids) {
			stringBuilder.append(id + ",");
		}
		stringBuilder.replace(stringBuilder.length() - 1, stringBuilder.length(), "");
		return stringBuilder.toString();
	}

	/**
	 * Save user preference data.
	 *
	 * @param userPreferenceDto
	 *            the user preference dto
	 * @param states
	 *            the states
	 * @return the boolean
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.UserDao#saveUserPreferenceData(com.harman.dmat.common
	 * .dto.UserPreferenceDto, java.lang.StringBuilder)
	 */
	@Override
	public Boolean saveUserPreferenceData(final UserPreferenceDto userPreferenceDto, final StringBuilder states) {
		final Timestamp currentTimestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
		Boolean result = false;
		final int userstatus = getJdbcTemplate().update("UPDATE users SET PREFERENCE_ID=?,UPD_TS=? WHERE USER_ID=?",
				userPreferenceDto.getPreferenceId(), currentTimestamp, userPreferenceDto.getUserId());
		final int userPrefCount = checkUserPreference(userPreferenceDto.getUserId());
		if (userPrefCount <= 0) {
			final String preferenceSql = "INSERT INTO user_preferences(USER_ID,PREFERENCE_ID) VALUES (?, ?)";
			getJdbcTemplate().update(preferenceSql, userPreferenceDto.getUserId(), Constant.DEFAULT_PREFERENCE_ID);
		}
		final String sql = "UPDATE user_preferences SET PREFERENCE_ID=?,STATE_CODE=?,UPD_TS=? WHERE USER_ID=?";
		final int userpreference = getJdbcTemplate().update(sql, new Object[] { userPreferenceDto.getPreferenceId(),
				states, currentTimestamp, userPreferenceDto.getUserId() });
		if (userstatus > 0 && userpreference > 0) {
			result = true;
		}
		return result;
	}

	/**
	 * Save user preference data.
	 *
	 * @param userPreferenceDto
	 *            the user preference dto
	 * @return the boolean
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.UserDao#saveUserPreferenceData(com.harman.dmat.common
	 * .dto.UserPreferenceDto)
	 */
	@Override
	public Boolean saveUserPreferenceData(final UserPreferenceDto userPreferenceDto) {
		Boolean result = false;
		final Timestamp currentTimestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
		final int userstatus = getJdbcTemplate().update("UPDATE users SET PREFERENCE_ID=?,UPD_TS=? WHERE USER_ID=?",
				userPreferenceDto.getPreferenceId(), currentTimestamp, userPreferenceDto.getUserId());
		final int userPrefCount = checkUserPreference(userPreferenceDto.getUserId());
		if (userPrefCount <= 0) {
			final String preferenceSql = "INSERT INTO user_preferences(USER_ID,PREFERENCE_ID) VALUES (?, ?)";
			getJdbcTemplate().update(preferenceSql, userPreferenceDto.getUserId(), Constant.DEFAULT_PREFERENCE_ID);
		}
		final String sql = "UPDATE user_preferences SET STATE_CODE=NULL, PREFERENCE_ID=?,UPD_TS=? WHERE USER_ID=?";
		final int userpreference = getJdbcTemplate().update(sql,
				new Object[] { userPreferenceDto.getPreferenceId(), currentTimestamp, userPreferenceDto.getUserId() });
		if (userstatus > 0 && userpreference > 0) {
			result = true;
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.harman.dmat.dao.UserDao#saveUserPreferenceData(com.harman.dmat.common
	 * .dto.UserPreferenceDto)
	 */
	@Override
	public Boolean saveUserPreferenceExtentData(final UserPreferenceDto userPreferenceDto) {
		Boolean result = false;
		final Timestamp currentTimestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
		final int userPrefCount = checkUserPreference(userPreferenceDto.getUserId());
		if (userPrefCount <= 0) {
			final String preferenceSql = "INSERT INTO user_preferences(USER_ID,PREFERENCE_ID) VALUES (?, ?)";
			getJdbcTemplate().update(preferenceSql, userPreferenceDto.getUserId(), Constant.DEFAULT_PREFERENCE_ID);
		}
		if (userPreferenceDto.getMapExtent() != null) {
			final AreaDto extentObj = userPreferenceDto.getMapExtent();
			final String sql = "UPDATE user_preferences SET zoom_level=?, min_x=?, max_x=?, min_y=?, max_y=?, wkid=?, PREFERENCE_ID=?,UPD_TS=? WHERE USER_ID=?";
			final int userpreference = getJdbcTemplate().update(sql,
					new Object[] { userPreferenceDto.getZoomLevel(), extentObj.getMinX(), extentObj.getMaxX(),
							extentObj.getMinY(), extentObj.getMaxY(), extentObj.getWkid(),
							userPreferenceDto.getPreferenceId(), currentTimestamp, userPreferenceDto.getUserId() });
			if (userpreference > 0) {
				result = true;
			}
		}
		return result;
	}

	/**
	 * Check user preference.
	 *
	 * @param userId
	 *            the user id
	 * @return the int
	 */
	public int checkUserPreference(final Integer userId) {
		final String sql = "SELECT count(user_id) FROM user_preferences WHERE user_id = ?";
		final int status = getJdbcTemplate().queryForObject(sql, new Object[] { userId }, Integer.class);
		return status;

	}

	/**
	 * Check email exist.
	 *
	 * @param userEmail
	 *            the user email
	 * @return the int
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#checkEmailExist(java.lang.String)
	 */
	@Override
	public int checkEmailExist(final String userEmail) {
		final String sql = "SELECT count(user_id) FROM users WHERE EMAIL = ?";
		final int status = getJdbcTemplate().queryForObject(sql, new Object[] { userEmail }, Integer.class);
		return status;

	}

	/**
	 * Gets the user detail.
	 *
	 * @param userId
	 *            the user id
	 * @return the user detail
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getUserDetail(java.lang.Integer)
	 */
	@Override
	public UserDto getUserDetail(final Integer userId) {
		final String sql = "SELECT EMAIL,FIRST_NAME,LAST_NAME,ROLE_ID,USER_CREATED_DATE,"
				+ "BUSINESS_PURPOSE,COMPANY_ID,REGION,STATE_CODE,PREFERENCE_ID,"
				+ "STATUS,IS_GROUP_ADMIN,IS_FIRST_LOGIN,IS_RESET_PASSWORD,"
				+ "LAST_LOGIN,ACCESS_CODE,INS_TS,INS_LOGIN,UPD_TS,UPD_LOGIN,"
				+ "(case when ((select count(user_group_mapping.user_id) from user_group_mapping where user_group_mapping.user_id=users.user_id) = 0 and users.IS_GROUP_ADMIN=0) then 0 else 1 end)as isGroupMember, user_domain as userDomain FROM users "
				+ " where users.user_id = ?";
		final UserDto userDto = getJdbcTemplate().queryForObject(sql, new Object[] { userId },
				new BeanPropertyRowMapper<UserDto>(UserDto.class));
		return userDto;
	}

	/**
	 * Gets the user details.
	 *
	 * @param offset
	 *            the offset
	 * @param limit
	 *            the limit
	 * @param userType
	 *            the user type
	 * @param token
	 *            the token
	 * @return the user details
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getAllUser(java.lang.Integer,
	 * java.lang.Integer)
	 */
	@Override
	public List<UserDto> getUserDetails(final Integer offset, final Integer limit, String userType, String token,
			String sortBy) {
		String roleIds = "(" + Roles.getRoles(userType) + ")";
		String statusClasue = Status.SUSPENDED.getValue() + "," + Status.PENDING.getValue();
		if (userType.equals(Constant.PENDING)) {
			roleIds = Constant.ALL_ROLE_ID + " and status=" + Status.PENDING.getValue();
			statusClasue = Status.SUSPENDED.getValue() + "";
		}

		String sql = "(SELECT EMAIL,USER_ID,FIRST_NAME,LAST_NAME,ROLE_ID,COMPANY_NAME,STATUS,IS_GROUP_ADMIN,LAST_LOGIN FROM users join company on users.company_id=company.company_id where status not in ("
				+ statusClasue + ") and IS_DELETE <> 1  and role_id in " + roleIds + "order by " + sortBy
				+ ") limit ? offset ?;";
		if (token != null) {

			sql = "(SELECT EMAIL,USER_ID,FIRST_NAME,LAST_NAME,ROLE_ID,COMPANY_NAME,STATUS,IS_GROUP_ADMIN,LAST_LOGIN  FROM users join company on users.company_id=company.company_id where status not in ("
					+ statusClasue + ") and IS_DELETE <> 1  and role_id in" + roleIds + " and (first_name ilike '%"
					+ token + "%' or last_name ilike '%" + token + "%' or email ilike '%" + token + "%' )" + "order by "
					+ sortBy + ") limit ? offset ?;";
		}
		final List<UserDto> userDto = getJdbcTemplate().query(sql, new Object[] { limit, offset - 1 },
				new BeanPropertyRowMapper<UserDto>(UserDto.class));
		return userDto;
	}

	/**
	 * Gets the roles.
	 *
	 * @return the roles
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getRoles()
	 */
	@Override
	public List<RoleDto> getRoles() {
		final List<RoleDto> states = getJdbcTemplate().query(
				"SELECT ROLE_ID as roleId ,ROLE_NAME as roleName, DESCP as desc  FROM role ",
				new BeanPropertyRowMapper<RoleDto>(RoleDto.class));
		return states;
	}

	/**
	 * Gets the listofpreferences.
	 *
	 * @return the listofpreferences
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getListofpreferences()
	 */
	@Override
	public List<PreferenceDto> getListofpreferences() {
		final String sql = "select preference_id,name,'desc' from preference";
		return getJdbcTemplate().query(sql, new BeanPropertyRowMapper<PreferenceDto>(PreferenceDto.class));
	}

	/**
	 * Update is first login.
	 *
	 * @param userId
	 *            the user id
	 * @param i
	 *            the i
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#updateIsFirstLogin(java.lang.Integer,
	 * int)
	 */
	@Override
	public void updateIsFirstLogin(final Integer userId, final int i) {
		getJdbcTemplate().update("update users set IS_FIRST_LOGIN = ? where USER_ID = ?", i, userId);

	}

	/**
	 * Check value exist.
	 *
	 * @param userId
	 *            the user id
	 * @return the integer
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#checkValueExist(java.lang.Integer)
	 */
	@Override
	public Integer checkValueExist(final Integer userId) {
		final String sql = "SELECT count(user_id) FROM users WHERE user_id = ?";
		final int status = getJdbcTemplate().queryForObject(sql, new Object[] { userId }, Integer.class);
		return status;

	}

	/**
	 * Gets the user by email.
	 *
	 * @param email
	 *            the email
	 * @return the user by email
	 * @throws UserException
	 *             the user exception
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getUserByEmail(java.lang.String)
	 */
	@Override
	public UserDto getUserByEmail(final String email) throws UserException {
		final List<UserDto> users = getJdbcTemplate().query(
				"SELECT user_id as userId,email,first_name as firstName,last_name as lastName,password,role_id as roleId,"
						+ "state_code as stateCode, region, business_purpose as businessPurpose, company_id as companyId,preference_id as preferenceId,"
						+ "status, is_group_admin as isGroupAdmin, is_first_login as isFirstLogin,"
						+ " is_reset_password as isResetPassword,last_login as lastLogin, access_code as accessCode, "
						+ " user_domain as userDomain FROM users where  is_delete <> 1 and email ilike ?",
				new Object[] { email }, new BeanPropertyRowMapper<UserDto>(UserDto.class));
		return users.isEmpty() ? null : users.get(0);
	}

	/**
	 * Gets the companies.
	 *
	 * @return the companies
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getCompanies()
	 */
	@Override
	public List<CompanyDto> getCompanies() {
		final List<CompanyDto> companies = getJdbcTemplate().query(
				"SELECT COMPANY_ID as companyId ,COMPANY_NAME as companyName FROM company ",
				new BeanPropertyRowMapper<CompanyDto>(CompanyDto.class));
		return companies;
	}

	/**
	 * Gets the regions.
	 *
	 * @return the regions
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getRegions()
	 */
	@Override
	public List<RegionDto> getRegions() {
		final List<RegionDto> regions = getJdbcTemplate().query("SELECT DISTINCT  REGION  FROM state  ",
				new BeanPropertyRowMapper<RegionDto>(RegionDto.class));
		return regions;
	}

	/**
	 * Gets the states.
	 *
	 * @return the states
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getStates()
	 */
	@Override
	public List<StateDto> getStates() {
		final List<StateDto> states = getJdbcTemplate().query(
				"SELECT state_code as stateCode,state_name as stateName, region FROM state ",
				new BeanPropertyRowMapper<StateDto>(StateDto.class));
		return states;
	}

	/**
	 * Gets the state name.
	 *
	 * @param region
	 *            the region
	 * @return the state name
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getStateName(java.lang.String)
	 */
	@Override
	public List<String> getStateName(final String region) {
		final String sql = "select state_code from state where REGION=?";
		final List<String> data = getJdbcTemplate().queryForList(sql, new Object[] { region }, String.class);
		return data;
	}

	/**
	 * Gets the events.
	 *
	 * @return the events
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getEvents()
	 */
	@Override
	public List<EventDto> getEvents() {
		final String sql = "select id,key,description,icon_path as iconPath, color from events";
		final List<EventDto> data = getJdbcTemplate().query(sql, new BeanPropertyRowMapper<EventDto>(EventDto.class));
		return data;
	}

	/**
	 * Gets the accordion info.
	 *
	 * @return the accordion info
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getAccordionInfo()
	 */
	@Override
	public AccordionInfo getAccordionInfo() {
		final String sql = "select role.role_id, role.role_name, count(users.role_id)as total, sum(case when status="
				+ Status.PENDING.getValue() + " then 1 else 0 end) as pendingCount," + "sum(case when status="
				+ Status.INACTIVE.getValue() + " then 1 else 0 end) as inactiveCount ," + "sum(case when status="
				+ Status.ACTIVE.getValue()
				+ " then 1 else 0 end) as activeCount  from users  join role on users.role_id=role.role_id  where is_delete <> 1 and status <> "
				+ Status.SUSPENDED.getValue() + " group by role.role_id";

		final AccordionInfo accordionInfo = getJdbcTemplate().queryForObject(sql, new RowMapper<AccordionInfo>() {

			@Override
			public AccordionInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
				final AccordionInfo accordionInfo = new AccordionInfo();
				final Map<String, AccordionStats> accordionMap = new HashMap<String, AccordionStats>();

				int pendingCount = 0;
				if (rs.getRow() == 1) {
					final AccordionStats accordionStats = new AccordionStats();
					accordionStats.setName(rs.getString(2));
					final int pendingUserCount = rs.getInt(4);
					pendingCount += pendingUserCount;
					accordionStats.setTotalCount(rs.getInt(3) - pendingUserCount);
					accordionStats.setInactiveCount(rs.getInt(5));
					accordionStats.setActiveCount(rs.getInt(6));
					accordionMap.put(rs.getString(2), accordionStats);
				}
				while (rs.next()) {

					final AccordionStats accordionStats = new AccordionStats();
					accordionStats.setName(rs.getString(2));
					final int pendingUserCount = rs.getInt(4);
					pendingCount += pendingUserCount;
					accordionStats.setTotalCount(rs.getInt(3) - pendingUserCount);
					accordionStats.setInactiveCount(rs.getInt(5));
					accordionStats.setActiveCount(rs.getInt(6));
					accordionMap.put(rs.getString(2), accordionStats);

				}
				accordionMap.put(Constant.PENDING, new AccordionStats(pendingCount));
				accordionInfo.setAccordionStats(accordionMap);

				return accordionInfo;
			}
		});
		return accordionInfo;
	}

	/**
	 * Gets the accordion info.
	 *
	 * @param token
	 *            the token
	 * @return the accordion info
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getAccordionInfo(java.lang.String)
	 */
	@Override
	public AccordionInfo getAccordionInfo(String token) {
		final String sql = "select role.role_id, role.role_name, count(users.role_id)as total, sum(case when status="
				+ Status.PENDING.getValue() + " then 1 else 0 end) as pendingCount,sum(case when status="
				+ Status.INACTIVE.getValue() + " then 1 else 0 end) as inactiveCount ," + "sum(case when status="
				+ Status.ACTIVE.getValue()
				+ " then 1 else 0 end) as activeCount  from users join company on users.company_id=company.company_id join role on users.role_id=role.role_id "
				+ "where is_delete <> 1 and status <> " + Status.SUSPENDED.getValue() + " and (first_name ilike '%"
				+ token + "%' or last_name ilike '%" + token + "%' or email ilike '%" + token
				+ "%' ) group by role.role_id";
		final AccordionInfo accordionInfo = getJdbcTemplate().queryForObject(sql, new RowMapper<AccordionInfo>() {

			@Override
			public AccordionInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
				final AccordionInfo accordionInfo = new AccordionInfo();
				final Map<String, AccordionStats> accordionMap = new HashMap<String, AccordionStats>();

				int pendingCount = 0;
				if (rs.getRow() == 1) {
					final AccordionStats accordionStats = new AccordionStats();
					accordionStats.setName(rs.getString(2));
					final int pendingUserCount = rs.getInt(4);
					pendingCount += pendingUserCount;
					accordionStats.setTotalCount(rs.getInt(3) - pendingUserCount);
					accordionStats.setInactiveCount(rs.getInt(5));
					accordionStats.setActiveCount(rs.getInt(6));
					accordionMap.put(rs.getString(2), accordionStats);
				}
				while (rs.next()) {
					final AccordionStats accordionStats = new AccordionStats();
					accordionStats.setName(rs.getString(2));
					final int pendingUserCount = rs.getInt(4);
					pendingCount += pendingUserCount;
					accordionStats.setTotalCount(rs.getInt(3) - pendingUserCount);
					accordionStats.setInactiveCount(rs.getInt(5));
					accordionStats.setActiveCount(rs.getInt(6));
					accordionMap.put(rs.getString(2), accordionStats);
				}
				accordionMap.put(Constant.PENDING, new AccordionStats(pendingCount));
				accordionInfo.setAccordionStats(accordionMap);
				return accordionInfo;
			}
		});
		return accordionInfo;

	}

	/**
	 * Change user status.
	 *
	 * @param token
	 *            the token
	 * @param statusInfoDto
	 *            the status info dto
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#changeUserStatus(java.lang.String,
	 * com.harman.dmat.common.dto.StatusInfoDto)
	 */
	@Override
	public void changeUserStatus(String token, StatusInfoDto statusInfoDto) {
		token = "'%" + token + "%'";
		final List<Integer> excludedRoleIds = getExcluededRoles();
		final String excludedRoles = getInClasue(excludedRoleIds);
		if (statusInfoDto.isGrand()) {
			getJdbcTemplate().update(
					"Update users set status=? WHERE is_delete <> 1 and role_id NOT in (" + excludedRoles
							+ ") and status <> " + Status.SUSPENDED.getValue() + " and "
							+ "(first_name ilike ? or last_name ilike ? or email ilike ?)",
					statusInfoDto.getStatus(), token, token, token);
		} else {
			final AccordionStatusInfo pending = statusInfoDto.getPending();
			final AccordionStatusInfo superAdmin = statusInfoDto.getSuperAdmin();
			final AccordionStatusInfo admin = statusInfoDto.getAdmin();
			final AccordionStatusInfo groupAdmin = statusInfoDto.getGroupAdmin();
			final AccordionStatusInfo user = statusInfoDto.getUser();
			final AccordionStatusInfo sme = statusInfoDto.getSme();
			final AccordionStatusInfo oem = statusInfoDto.getOem();
			final AccordionStatusInfo lra = statusInfoDto.getLra();
			if (pending != null) {
				if (pending.isAll()) {
					final List<Integer> excluededUsers = pending.getExcludedUserdIds();
					if (excluededUsers != null && !excluededUsers.isEmpty()) {
						final String excluededUser = getInClasue(excluededUsers);
						getJdbcTemplate().update(
								"Update users set status=? WHERE is_delete <> 1 and role_id not in (" + excludedRoles
										+ ") and user_id not in (" + excluededUser + ") and "
										+ "(first_name ilike ? or last_name ilike ? or email ilike ?) and status= ?",
								statusInfoDto.getStatus(), token, token, token, Status.PENDING.getValue());
					} else {
						getJdbcTemplate().update(
								"Update users set status=? WHERE is_delete <> 1 and role_id not in (" + excludedRoles
										+ ") and "
										+ "(first_name ilike ? or last_name ilike ? or email ilike ?) and status= ?",
								statusInfoDto.getStatus(), token, token, token, Status.PENDING.getValue());
					}
				} else {
					final List<Integer> incluededUsers = pending.getIncludedUserIds();
					if (incluededUsers != null && !incluededUsers.isEmpty()) {
						final String includedUser = getInClasue(incluededUsers);
						getJdbcTemplate().update(
								"Update users set status=? WHERE role_id not in (" + excludedRoles
										+ ") and user_id  in (" + includedUser + ") and "
										+ "(first_name ilike ? or last_name ilike ? or email ilike ?) and status= ?",
								statusInfoDto.getStatus(), token, token, token, Status.PENDING.getValue());
					}
				}

			}
			if (superAdmin != null) {
				executeUserStatusForSearch(token, Roles.SUPER_ADMIN.getValue(), superAdmin.isAll(), excludedRoleIds,
						superAdmin.getExcludedUserdIds(), superAdmin.getIncludedUserIds(), statusInfoDto.getStatus());
			}
			if (admin != null) {
				executeUserStatusForSearch(token, Roles.ADMIN.getValue(), admin.isAll(), excludedRoleIds,
						admin.getExcludedUserdIds(), admin.getIncludedUserIds(), statusInfoDto.getStatus());
			}
			if (groupAdmin != null) {
				executeUserStatusForSearch(token, Roles.GROUP_ADMIN.getValue(), groupAdmin.isAll(), excludedRoleIds,
						groupAdmin.getExcludedUserdIds(), groupAdmin.getIncludedUserIds(), statusInfoDto.getStatus());
			}
			if (user != null) {
				executeUserStatusForSearch(token, Roles.USER.getValue(), user.isAll(), excludedRoleIds,
						user.getExcludedUserdIds(), user.getIncludedUserIds(), statusInfoDto.getStatus());
			}
			if (sme != null) {
				executeUserStatusForSearch(token, Roles.SME.getValue(), sme.isAll(), excludedRoleIds,
						sme.getExcludedUserdIds(), sme.getIncludedUserIds(), statusInfoDto.getStatus());
			}
			if (oem != null) {
				executeUserStatusForSearch(token, Roles.OEM.getValue(), oem.isAll(), excludedRoleIds,
						oem.getExcludedUserdIds(), oem.getIncludedUserIds(), statusInfoDto.getStatus());
			}
			if (lra != null) {
				executeUserStatusForSearch(token, Roles.LRA.getValue(), lra.isAll(), excludedRoleIds,
						lra.getExcludedUserdIds(), lra.getIncludedUserIds(), statusInfoDto.getStatus());
			}
		}

	}

	/**
	 * Change user status.
	 *
	 * @param statusInfoDto
	 *            the status info dto
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.UserDao#changeUserStatus(com.harman.dmat.common.dto.
	 * StatusInfoDto)
	 */
	@Override
	public void changeUserStatus(StatusInfoDto statusInfoDto) {
		final List<Integer> excludedRoleIds = getExcluededRoles();
		final String excludedRoles = getInClasue(excludedRoleIds);
		if (statusInfoDto.isGrand()) {
			getJdbcTemplate().update("Update users set status=? WHERE is_delete <> 1 and  status <> "
					+ Status.SUSPENDED.getValue() + " and role_id NOT in (" + excludedRoles + ")",
					statusInfoDto.getStatus());
		} else {
			final AccordionStatusInfo pending = statusInfoDto.getPending();
			final AccordionStatusInfo superAdmin = statusInfoDto.getSuperAdmin();
			final AccordionStatusInfo admin = statusInfoDto.getAdmin();
			final AccordionStatusInfo groupAdmin = statusInfoDto.getGroupAdmin();
			final AccordionStatusInfo user = statusInfoDto.getUser();
			final AccordionStatusInfo sme = statusInfoDto.getSme();
			final AccordionStatusInfo oem = statusInfoDto.getOem();
			final AccordionStatusInfo lra = statusInfoDto.getLra();
			if (pending != null) {
				if (pending.isAll()) {
					final List<Integer> excluededUsers = pending.getExcludedUserdIds();
					if (excluededUsers != null && !excluededUsers.isEmpty()) {
						final String excludedUser = getInClasue(excluededUsers);
						getJdbcTemplate().update(
								"Update users set status=? WHERE is_delete <> 1 and role_id not in (" + excludedRoles
										+ ") and user_id not in (" + excludedUser + ") and status=?",
								statusInfoDto.getStatus(), Status.PENDING.getValue());
					} else {
						getJdbcTemplate().update("Update users set status=? WHERE is_delete <> 1 and role_id not in ("
								+ excludedRoles + ") and status=?", statusInfoDto.getStatus(),
								Status.PENDING.getValue());
					}
				} else {
					final List<Integer> incluededUsers = pending.getIncludedUserIds();
					if (incluededUsers != null && !incluededUsers.isEmpty()) {
						final String includedUser = getInClasue(incluededUsers);
						getJdbcTemplate().update(
								"Update users set status=? WHERE role_id not in (" + excludedRoles
										+ ") and user_id  in (" + includedUser + ") and status=?",
								statusInfoDto.getStatus(), Status.PENDING.getValue());
					}
				}

			}
			if (superAdmin != null) {
				executeUserStatus(Roles.SUPER_ADMIN.getValue(), superAdmin.isAll(), excludedRoleIds,
						superAdmin.getExcludedUserdIds(), superAdmin.getIncludedUserIds(), statusInfoDto.getStatus());
			}
			if (admin != null) {
				executeUserStatus(Roles.ADMIN.getValue(), admin.isAll(), excludedRoleIds, admin.getExcludedUserdIds(),
						admin.getIncludedUserIds(), statusInfoDto.getStatus());
			}
			if (groupAdmin != null) {
				executeUserStatus(Roles.GROUP_ADMIN.getValue(), groupAdmin.isAll(), excludedRoleIds,
						groupAdmin.getExcludedUserdIds(), groupAdmin.getIncludedUserIds(), statusInfoDto.getStatus());
			}
			if (user != null) {
				executeUserStatus(Roles.USER.getValue(), user.isAll(), excludedRoleIds, user.getExcludedUserdIds(),
						user.getIncludedUserIds(), statusInfoDto.getStatus());
			}
			if (sme != null) {
				executeUserStatus(Roles.SME.getValue(), sme.isAll(), excludedRoleIds, sme.getExcludedUserdIds(),
						sme.getIncludedUserIds(), statusInfoDto.getStatus());
			}
			if (oem != null) {
				executeUserStatus(Roles.OEM.getValue(), oem.isAll(), excludedRoleIds, oem.getExcludedUserdIds(),
						oem.getIncludedUserIds(), statusInfoDto.getStatus());
			}
			if (lra != null) {
				executeUserStatus(Roles.LRA.getValue(), lra.isAll(), excludedRoleIds, lra.getExcludedUserdIds(),
						lra.getIncludedUserIds(), statusInfoDto.getStatus());
			}
		}

	}

	/**
	 * Execute user status.
	 *
	 * @param roleId
	 *            the role id
	 * @param isAll
	 *            the is all
	 * @param excluededRoleIds
	 *            the exclueded role ids
	 * @param excluededUsers
	 *            the exclueded users
	 * @param includedUsers
	 *            the included users
	 * @param status
	 *            the status
	 */
	private void executeUserStatus(Integer roleId, boolean isAll, List<Integer> excluededRoleIds,
			List<Integer> excluededUsers, List<Integer> includedUsers, Integer status) {
		final String excluedeRoles = getInClasue(excluededRoleIds);
		if (isAll) {
			if (excluededUsers != null && !excluededUsers.isEmpty()) {
				final String excludedUser = getInClasue(excluededUsers);
				getJdbcTemplate().update("Update users set status=? WHERE  is_delete <> 1 and role_id not in ("
						+ excluedeRoles + ") and user_id not in (" + excludedUser + ") and and role_id =?", status,
						roleId);
			} else {
				getJdbcTemplate().update("Update users set status=? WHERE  is_delete <> 1 and role_id not in ("
						+ excluedeRoles + ") and role_id =?", status, roleId);
			}
		} else {
			if (includedUsers != null && !includedUsers.isEmpty()) {
				final String includedUser = getInClasue(includedUsers);
				getJdbcTemplate().update("Update users set status=? WHERE role_id not in (" + excluedeRoles
						+ ") and role_id =? and user_id in (" + includedUser + ")", status, roleId);
			}
		}
	}

	/**
	 * Execute user status for search.
	 *
	 * @param token
	 *            the token
	 * @param roleId
	 *            the role id
	 * @param isAll
	 *            the is all
	 * @param excluededRoleIds
	 *            the exclueded role ids
	 * @param excluededUsers
	 *            the exclueded users
	 * @param includedUsers
	 *            the included users
	 * @param status
	 *            the status
	 */
	private void executeUserStatusForSearch(String token, Integer roleId, boolean isAll, List<Integer> excluededRoleIds,
			List<Integer> excluededUsers, List<Integer> includedUsers, Integer status) {
		final String excluededRoles = getInClasue(excluededRoleIds);
		if (isAll) {
			if (excluededUsers != null && !excluededUsers.isEmpty()) {
				final String excluededUser = getInClasue(excluededUsers);
				getJdbcTemplate().update(
						"Update users set status=? WHERE is_delete <> 1 and status <> " + Status.SUSPENDED.getValue()
								+ " and role_id not in (" + excluededRoles + ") and user_id not in (" + excluededUser
								+ ") and role_id =? and "
								+ "(first_name ilike ? or last_name ilike ? or email ilike ?)",
						status, roleId, token, token, token);
			} else {
				getJdbcTemplate().update(
						"Update users set status=? WHERE is_delete <> 1 and status <> " + Status.SUSPENDED.getValue()
								+ " and role_id not in (" + excluededRoles + ") and role_id =? and "
								+ "(first_name ilike ? or last_name ilike ? or email ilike ?)",
						status, roleId, token, token, token);
			}
		} else {
			if (includedUsers != null && !includedUsers.isEmpty()) {
				final String incluededUser = getInClasue(includedUsers);
				getJdbcTemplate().update(
						"Update users set status=? WHERE role_id not in (" + excluededRoles
								+ ") and role_id =? and user_id in (" + incluededUser + ") and "
								+ "(first_name ilike ? or last_name ilike ? or email ilike ?)",
						status, roleId, token, token, token);
			}
		}
	}

	/**
	 * Gets the exclueded roles.
	 *
	 * @return the exclueded roles
	 */
	private List<Integer> getExcluededRoles() {
		final Integer roleId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getScope();
		final List<Integer> excludedRoleIds = new ArrayList<Integer>();
		if (roleId == Roles.SUPER_ADMIN.getValue()) {
			excludedRoleIds.add(roleId);
		} else {
			excludedRoleIds.add(roleId);
			excludedRoleIds.add(Roles.SUPER_ADMIN.getValue());
		}
		return excludedRoleIds;
	}

	/**
	 * Delete users.
	 *
	 * @param statusInfoDto
	 *            the status info dto
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#deleteUsers(com.harman.dmat.common.dto.
	 * StatusInfoDto)
	 */
	@Override
	public void deleteUsers(StatusInfoDto statusInfoDto) {
		final List<Integer> excludedRoleIds = getExcluededRoles();
		final String excludedRoles = getInClasue(excludedRoleIds);
		if (statusInfoDto.isGrand()) {
			getJdbcTemplate().update("Update users set is_delete=1 WHERE status <> " + Status.SUSPENDED.getValue()
					+ " and role_id NOT in (" + excludedRoles + ")");
		} else {
			final AccordionStatusInfo pending = statusInfoDto.getPending();
			final AccordionStatusInfo superAdmin = statusInfoDto.getSuperAdmin();
			final AccordionStatusInfo admin = statusInfoDto.getAdmin();
			final AccordionStatusInfo groupAdmin = statusInfoDto.getGroupAdmin();
			final AccordionStatusInfo user = statusInfoDto.getUser();
			final AccordionStatusInfo sme = statusInfoDto.getSme();
			final AccordionStatusInfo oem = statusInfoDto.getOem();
			final AccordionStatusInfo lra = statusInfoDto.getLra();
			if (pending != null) {
				if (pending.isAll()) {
					final List<Integer> excluededUsers = pending.getExcludedUserdIds();
					if (excluededUsers != null && !excluededUsers.isEmpty()) {
						final String excludedUser = getInClasue(excluededUsers);
						getJdbcTemplate().update(
								"Update users set is_delete=1 WHERE role_id not in (" + excludedRoles
										+ ") and user_id not in (" + excludedUser + ") and status=?",
								Status.PENDING.getValue());
					} else {
						getJdbcTemplate().update("Update users set is_delete=1 WHERE role_id not in (" + excludedRoles
								+ ") and status=?", Status.PENDING.getValue());
					}
				} else {
					final List<Integer> incluededUsers = pending.getIncludedUserIds();
					if (incluededUsers != null && !incluededUsers.isEmpty()) {
						final String includedUser = getInClasue(incluededUsers);
						getJdbcTemplate().update(
								"Update users set is_delete=1 WHERE role_id not in (" + excludedRoles
										+ ") and user_id  in (" + includedUser + ") and status=?",
								Status.PENDING.getValue());
					}
				}

			}
			if (superAdmin != null) {
				executeDeleteUser(Roles.SUPER_ADMIN.getValue(), superAdmin.isAll(), excludedRoleIds,
						superAdmin.getExcludedUserdIds(), superAdmin.getIncludedUserIds());
			}
			if (admin != null) {
				executeDeleteUser(Roles.ADMIN.getValue(), admin.isAll(), excludedRoleIds, admin.getExcludedUserdIds(),
						admin.getIncludedUserIds());
			}
			if (groupAdmin != null) {
				executeDeleteUser(Roles.GROUP_ADMIN.getValue(), groupAdmin.isAll(), excludedRoleIds,
						groupAdmin.getExcludedUserdIds(), groupAdmin.getIncludedUserIds());
			}
			if (user != null) {
				executeDeleteUser(Roles.USER.getValue(), user.isAll(), excludedRoleIds, user.getExcludedUserdIds(),
						user.getIncludedUserIds());
			}
			if (sme != null) {
				executeDeleteUser(Roles.SME.getValue(), sme.isAll(), excludedRoleIds, sme.getExcludedUserdIds(),
						sme.getIncludedUserIds());
			}
			if (oem != null) {
				executeDeleteUser(Roles.OEM.getValue(), oem.isAll(), excludedRoleIds, oem.getExcludedUserdIds(),
						oem.getIncludedUserIds());
			}
			if (lra != null) {
				executeDeleteUser(Roles.LRA.getValue(), lra.isAll(), excludedRoleIds, lra.getExcludedUserdIds(),
						lra.getIncludedUserIds());
			}
		}

	}

	/**
	 * Delete users.
	 *
	 * @param token
	 *            the token
	 * @param statusInfoDto
	 *            the status info dto
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#deleteUsers(java.lang.String,
	 * com.harman.dmat.common.dto.StatusInfoDto)
	 */
	@Override
	public void deleteUsers(String token, StatusInfoDto statusInfoDto) {
		token = "'%" + token + "%'";
		final List<Integer> excludedRoleIds = getExcluededRoles();
		final String excludedRoles = getInClasue(excludedRoleIds);
		if (statusInfoDto.isGrand()) {
			getJdbcTemplate().update("Update users set is_delete=1 WHERE role_id NOT in (" + excludedRoles
					+ ") and status <> " + Status.SUSPENDED.getValue() + " and "
					+ "(first_name ilike ? or last_name ilike ? or email ilike ?)", token, token, token);
		} else {
			final AccordionStatusInfo pending = statusInfoDto.getPending();
			final AccordionStatusInfo superAdmin = statusInfoDto.getSuperAdmin();
			final AccordionStatusInfo admin = statusInfoDto.getAdmin();
			final AccordionStatusInfo groupAdmin = statusInfoDto.getGroupAdmin();
			final AccordionStatusInfo user = statusInfoDto.getUser();
			final AccordionStatusInfo sme = statusInfoDto.getSme();
			final AccordionStatusInfo oem = statusInfoDto.getOem();
			final AccordionStatusInfo lra = statusInfoDto.getLra();
			if (pending != null) {
				if (pending.isAll()) {
					final List<Integer> excluededUsers = pending.getExcludedUserdIds();
					if (excluededUsers != null && !excluededUsers.isEmpty()) {
						final String excluededUser = getInClasue(excluededUsers);
						getJdbcTemplate().update(
								"Update users set is_delete=1 WHERE role_id not in (" + excludedRoles
										+ ") and user_id not in (" + excluededUser + ") and "
										+ "(first_name ilike ? or last_name ilike ? or email ilike ?) and status= ?",
								token, token, token, Status.PENDING.getValue());
					} else {
						getJdbcTemplate().update(
								"Update users set is_delete=1 WHERE role_id not in (" + excludedRoles + ") and "
										+ "(first_name ilike ? or last_name ilike ? or email ilike ?) and status= ?",
								token, token, token, Status.PENDING.getValue());
					}
				} else {
					final List<Integer> incluededUsers = pending.getIncludedUserIds();
					if (incluededUsers != null && !incluededUsers.isEmpty()) {
						final String includedUser = getInClasue(incluededUsers);
						getJdbcTemplate().update(
								"Update users set is_delete=1 WHERE role_id not in (" + excludedRoles
										+ ") and user_id  in (" + includedUser + ") and "
										+ "(first_name ilike ? or last_name ilike ? or email ilike ?) and status= ?",
								token, token, token, Status.PENDING.getValue());
					}
				}

			}
			if (superAdmin != null) {
				executeDeleteUserForSearch(token, Roles.SUPER_ADMIN.getValue(), superAdmin.isAll(), excludedRoleIds,
						superAdmin.getExcludedUserdIds(), superAdmin.getIncludedUserIds());
			}
			if (admin != null) {
				executeDeleteUserForSearch(token, Roles.ADMIN.getValue(), admin.isAll(), excludedRoleIds,
						admin.getExcludedUserdIds(), admin.getIncludedUserIds());
			}
			if (groupAdmin != null) {
				executeDeleteUserForSearch(token, Roles.GROUP_ADMIN.getValue(), groupAdmin.isAll(), excludedRoleIds,
						groupAdmin.getExcludedUserdIds(), groupAdmin.getIncludedUserIds());
			}
			if (user != null) {
				executeDeleteUserForSearch(token, Roles.USER.getValue(), user.isAll(), excludedRoleIds,
						user.getExcludedUserdIds(), user.getIncludedUserIds());
			}
			if (sme != null) {
				executeDeleteUserForSearch(token, Roles.SME.getValue(), sme.isAll(), excludedRoleIds,
						sme.getExcludedUserdIds(), sme.getIncludedUserIds());
			}
			if (oem != null) {
				executeDeleteUserForSearch(token, Roles.OEM.getValue(), oem.isAll(), excludedRoleIds,
						oem.getExcludedUserdIds(), oem.getIncludedUserIds());
			}
			if (lra != null) {
				executeDeleteUserForSearch(token, Roles.LRA.getValue(), lra.isAll(), excludedRoleIds,
						lra.getExcludedUserdIds(), lra.getIncludedUserIds());
			}
		}

	}

	/**
	 * Execute delete user.
	 *
	 * @param roleId
	 *            the role id
	 * @param isAll
	 *            the is all
	 * @param excluededRoleIds
	 *            the exclueded role ids
	 * @param excluededUsers
	 *            the exclueded users
	 * @param includedUsers
	 *            the included users
	 */
	private void executeDeleteUser(Integer roleId, boolean isAll, List<Integer> excluededRoleIds,
			List<Integer> excluededUsers, List<Integer> includedUsers) {
		final String excluedeRoles = getInClasue(excluededRoleIds);
		if (isAll) {
			if (excluededUsers != null && !excluededUsers.isEmpty()) {
				final String excludedUser = getInClasue(excluededUsers);
				getJdbcTemplate().update("Update users set is_delete=1 WHERE status <> " + Status.SUSPENDED.getValue()
						+ " and role_id not in (" + excluedeRoles + ") and user_id not in (" + excludedUser
						+ ") and and role_id =?", roleId);
			} else {
				getJdbcTemplate().update("Update users set is_delete=1 WHERE status <> " + Status.SUSPENDED.getValue()
						+ " and role_id not in (" + excluedeRoles + ") and role_id =?", roleId);
			}
		} else {
			if (includedUsers != null && !includedUsers.isEmpty()) {
				final String includedUser = getInClasue(includedUsers);
				getJdbcTemplate().update("Update users set is_delete=1 WHERE role_id not in (" + excluedeRoles
						+ ") and role_id =? and user_id in (" + includedUser + ")", roleId);
			}
		}
	}

	/**
	 * Execute delete user for search.
	 *
	 * @param token
	 *            the token
	 * @param roleId
	 *            the role id
	 * @param isAll
	 *            the is all
	 * @param excluededRoleIds
	 *            the exclueded role ids
	 * @param excluededUsers
	 *            the exclueded users
	 * @param includedUsers
	 *            the included users
	 */
	private void executeDeleteUserForSearch(String token, Integer roleId, boolean isAll, List<Integer> excluededRoleIds,
			List<Integer> excluededUsers, List<Integer> includedUsers) {
		final String excluededRoles = getInClasue(excluededRoleIds);
		if (isAll) {
			if (excluededUsers != null && !excluededUsers.isEmpty()) {
				final String excluededUser = getInClasue(excluededUsers);
				getJdbcTemplate().update("Update users set is_delete=1 WHERE status <> " + Status.SUSPENDED.getValue()
						+ " and role_id not in (" + excluededRoles + ") and user_id not in (" + excluededUser
						+ ") and role_id =? and " + "(first_name ilike ? or last_name ilike ? or email ilike ?)",
						roleId, token, token, token);
			} else {
				getJdbcTemplate().update(
						"Update users set is_delete=1 WHERE status <> " + Status.SUSPENDED.getValue()
								+ " and role_id not in (" + excluededRoles + ") and role_id =? and "
								+ "(first_name ilike ? or last_name ilike ? or email ilike ?)",
						roleId, token, token, token);
			}
		} else {
			if (includedUsers != null && !includedUsers.isEmpty()) {
				final String incluededUser = getInClasue(includedUsers);
				getJdbcTemplate().update(
						"Update users set is_delete=1 WHERE role_id not in (" + excluededRoles
								+ ") and role_id =? and user_id in (" + incluededUser + ") and "
								+ "(first_name ilike ? or last_name ilike ? or email ilike ?)",
						roleId, token, token, token);
			}
		}
	}

	/**
	 * Send notification.
	 *
	 * @param statusInfoDto
	 *            the status info dto
	 * @return the list
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.UserDao#sendNotification(com.harman.dmat.common.dto.
	 * StatusInfoDto)
	 */
	@Override
	public List<UserDto> sendNotification(StatusInfoDto statusInfoDto) {
		final Integer userId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();
		final List<UserDto> userDetails = new ArrayList<>();
		final List<Integer> excludedRoleIds = getExcluededRoles();
		final String excludedRoles = getInClasue(excludedRoleIds);
		if (statusInfoDto.isGrand()) {
			final String sql = "SELECT email,user_id,first_name,last_name,role_id from users WHERE user_id <> " + userId
					+ " and is_delete <> 1 and status <> " + Status.SUSPENDED.getValue() + " and role_id NOT in ("
					+ excludedRoles + ")";
			return getJdbcTemplate().query(sql, new BeanPropertyRowMapper<UserDto>(UserDto.class));
		} else {
			final AccordionStatusInfo pending = statusInfoDto.getPending();
			final AccordionStatusInfo superAdmin = statusInfoDto.getSuperAdmin();
			final AccordionStatusInfo admin = statusInfoDto.getAdmin();
			final AccordionStatusInfo groupAdmin = statusInfoDto.getGroupAdmin();
			final AccordionStatusInfo user = statusInfoDto.getUser();
			final AccordionStatusInfo sme = statusInfoDto.getSme();
			final AccordionStatusInfo oem = statusInfoDto.getOem();
			final AccordionStatusInfo lra = statusInfoDto.getLra();
			String sql = null;
			if (pending != null) {
				if (pending.isAll()) {
					final List<Integer> excluededUsers = pending.getExcludedUserdIds();
					if (excluededUsers != null && !excluededUsers.isEmpty()) {
						excluededUsers.add(userId);
						final String excludedUser = getInClasue(excluededUsers);
						sql = "SELECT email,user_id,first_name,last_name,role_id from users WHERE is_delete <> 1 and user_id not in ("
								+ excludedUser + ") and status=?";
					} else {
						sql = "SELECT email,user_id,first_name,last_name,role_id from users WHERE is_delete <> 1 and user_id <> "
								+ userId + " and status=?";
					}
				} else {
					final List<Integer> incluededUsers = pending.getIncludedUserIds();
					if (incluededUsers != null && !incluededUsers.isEmpty()) {
						final String includedUser = getInClasue(incluededUsers);
						sql = "SELECT email,user_id,first_name,last_name,role_id from users WHERE user_id  in ("
								+ includedUser + ") and status=?";
					}
				}
				if (sql != null) {
					final List<UserDto> userDto = getJdbcTemplate().query(sql,
							new Object[] { Status.PENDING.getValue() },
							new BeanPropertyRowMapper<UserDto>(UserDto.class));
					userDetails.addAll(userDto);
				}
			}
			if (superAdmin != null) {
				final List<UserDto> userDto = getUserDetails(Roles.SUPER_ADMIN.getValue(), superAdmin.isAll(),
						excludedRoleIds, superAdmin.getExcludedUserdIds(), superAdmin.getIncludedUserIds(),
						statusInfoDto.getStatus());
				if (userDto != null) {
					userDetails.addAll(userDto);
				}
			}
			if (admin != null) {
				final List<UserDto> userDto = getUserDetails(Roles.ADMIN.getValue(), admin.isAll(), excludedRoleIds,
						admin.getExcludedUserdIds(), admin.getIncludedUserIds(), statusInfoDto.getStatus());
				if (userDto != null) {
					userDetails.addAll(userDto);
				}
			}
			if (groupAdmin != null) {
				final List<UserDto> userDto = getUserDetails(Roles.GROUP_ADMIN.getValue(), groupAdmin.isAll(),
						excludedRoleIds, groupAdmin.getExcludedUserdIds(), groupAdmin.getIncludedUserIds(),
						statusInfoDto.getStatus());
				if (userDto != null) {
					userDetails.addAll(userDto);
				}
			}
			if (user != null) {
				final List<UserDto> userDto = getUserDetails(Roles.USER.getValue(), user.isAll(), excludedRoleIds,
						user.getExcludedUserdIds(), user.getIncludedUserIds(), statusInfoDto.getStatus());
				if (userDto != null) {
					userDetails.addAll(userDto);
				}
			}
			if (sme != null) {
				final List<UserDto> userDto = getUserDetails(Roles.SME.getValue(), sme.isAll(), excludedRoleIds,
						sme.getExcludedUserdIds(), sme.getIncludedUserIds(), statusInfoDto.getStatus());
				if (userDto != null) {
					userDetails.addAll(userDto);
				}
			}
			if (oem != null) {
				final List<UserDto> userDto = getUserDetails(Roles.OEM.getValue(), oem.isAll(), excludedRoleIds,
						oem.getExcludedUserdIds(), oem.getIncludedUserIds(), statusInfoDto.getStatus());
				if (userDto != null) {
					userDetails.addAll(userDto);
				}
			}
			if (lra != null) {
				final List<UserDto> userDto = getUserDetails(Roles.LRA.getValue(), lra.isAll(), excludedRoleIds,
						lra.getExcludedUserdIds(), lra.getIncludedUserIds(), statusInfoDto.getStatus());
				if (userDto != null) {
					userDetails.addAll(userDto);
				}
			}
		}
		return userDetails;

	}

	/**
	 * Send notification.
	 *
	 * @param token
	 *            the token
	 * @param statusInfoDto
	 *            the status info dto
	 * @return the list
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#sendNotification(java.lang.String,
	 * com.harman.dmat.common.dto.StatusInfoDto)
	 */
	@Override
	public List<UserDto> sendNotification(String token, StatusInfoDto statusInfoDto) {
		token = "'%" + token + "%'";
		final List<UserDto> userDetails = new ArrayList<>();
		final Integer userId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();
		final List<Integer> excludedRoleIds = getExcluededRoles();
		if (statusInfoDto.isGrand()) {
			final String sql = "SELECT email,user_id,first_name,last_name,role_id from users WHERE is_delete <> 1 and status <> "
					+ Status.SUSPENDED.getValue() + " and user_id <> " + userId + " and "
					+ "(first_name ilike ? or last_name ilike ? or email ilike ?)";
			return getJdbcTemplate().query(sql, new Object[] { token, token, token },
					new BeanPropertyRowMapper<UserDto>(UserDto.class));
		} else {
			final AccordionStatusInfo pending = statusInfoDto.getPending();
			final AccordionStatusInfo superAdmin = statusInfoDto.getSuperAdmin();
			final AccordionStatusInfo admin = statusInfoDto.getAdmin();
			final AccordionStatusInfo groupAdmin = statusInfoDto.getGroupAdmin();
			final AccordionStatusInfo user = statusInfoDto.getUser();
			final AccordionStatusInfo sme = statusInfoDto.getSme();
			final AccordionStatusInfo oem = statusInfoDto.getOem();
			final AccordionStatusInfo lra = statusInfoDto.getLra();
			String sql = null;
			if (pending != null) {
				if (pending.isAll()) {
					final List<Integer> excluededUsers = pending.getExcludedUserdIds();
					if (excluededUsers != null && !excluededUsers.isEmpty()) {
						excluededUsers.add(userId);
						final String excluededUser = getInClasue(excluededUsers);
						sql = "SELECT email,user_id,first_name,last_name,role_id from users WHERE is_delete <> 1 and user_id not in ("
								+ excluededUser + ") and "
								+ "(first_name ilike ? or last_name ilike ? or email ilike ?) and status =?";

					} else {
						sql = "SELECT email,user_id,first_name,last_name,role_id from users WHERE is_delete <> 1 and user_id <> "
								+ userId + " and "
								+ "(first_name ilike ? or last_name ilike ? or email ilike ?) and status = ?";

					}
				} else {
					final List<Integer> incluededUsers = pending.getIncludedUserIds();
					if (incluededUsers != null && !incluededUsers.isEmpty()) {
						final String includedUser = getInClasue(incluededUsers);
						sql = "SELECT email,user_id,first_name,last_name,role_id from users WHERE user_id  in ("
								+ includedUser + ") and "
								+ "(first_name ilike ? or last_name ilike ? or email ilike ?) and status =?";

					}
				}
				final List<UserDto> userDto = getJdbcTemplate().query(sql,
						new Object[] { token, token, token, Status.PENDING.getValue() },
						new BeanPropertyRowMapper<UserDto>(UserDto.class));
				userDetails.addAll(userDto);

			}

			if (superAdmin != null) {
				final List<UserDto> userDto = getUserDetailsForSearch(token, Roles.SUPER_ADMIN.getValue(),
						superAdmin.isAll(), excludedRoleIds, superAdmin.getExcludedUserdIds(),
						superAdmin.getIncludedUserIds(), statusInfoDto.getStatus());
				userDetails.addAll(userDto);
			}
			if (admin != null) {
				final List<UserDto> userDto = getUserDetailsForSearch(token, Roles.ADMIN.getValue(), admin.isAll(),
						excludedRoleIds, admin.getExcludedUserdIds(), admin.getIncludedUserIds(),
						statusInfoDto.getStatus());
				userDetails.addAll(userDto);
			}
			if (groupAdmin != null) {
				final List<UserDto> userDto = getUserDetailsForSearch(token, Roles.GROUP_ADMIN.getValue(),
						groupAdmin.isAll(), excludedRoleIds, groupAdmin.getExcludedUserdIds(),
						groupAdmin.getIncludedUserIds(), statusInfoDto.getStatus());
				userDetails.addAll(userDto);
			}
			if (user != null) {
				final List<UserDto> userDto = getUserDetailsForSearch(token, Roles.USER.getValue(), user.isAll(),
						excludedRoleIds, user.getExcludedUserdIds(), user.getIncludedUserIds(),
						statusInfoDto.getStatus());
				userDetails.addAll(userDto);
			}
			if (sme != null) {
				final List<UserDto> userDto = getUserDetailsForSearch(token, Roles.SME.getValue(), sme.isAll(),
						excludedRoleIds, sme.getExcludedUserdIds(), sme.getIncludedUserIds(),
						statusInfoDto.getStatus());
				userDetails.addAll(userDto);
			}
			if (oem != null) {
				final List<UserDto> userDto = getUserDetailsForSearch(token, Roles.OEM.getValue(), oem.isAll(),
						excludedRoleIds, oem.getExcludedUserdIds(), oem.getIncludedUserIds(),
						statusInfoDto.getStatus());
				userDetails.addAll(userDto);
			}
			if (lra != null) {
				final List<UserDto> userDto = getUserDetailsForSearch(token, Roles.LRA.getValue(), lra.isAll(),
						excludedRoleIds, lra.getExcludedUserdIds(), lra.getIncludedUserIds(),
						statusInfoDto.getStatus());
				userDetails.addAll(userDto);
			}
		}
		return userDetails;
	}

	/**
	 * Gets the user details.
	 *
	 * @param roleId
	 *            the role id
	 * @param isAll
	 *            the is all
	 * @param excluededRoleIds
	 *            the exclueded role ids
	 * @param excluededUsers
	 *            the exclueded users
	 * @param includedUsers
	 *            the included users
	 * @param status
	 *            the status
	 * @return the user details
	 */
	private List<UserDto> getUserDetails(Integer roleId, boolean isAll, List<Integer> excluededRoleIds,
			List<Integer> excluededUsers, List<Integer> includedUsers, Integer status) {
		final Integer userId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();
		String sql = null;
		if (isAll) {
			if (excluededUsers != null && !excluededUsers.isEmpty()) {
				excluededUsers.add(userId);
				final String excludedUser = getInClasue(excluededUsers);
				sql = "SELECT email,user_id,first_name,last_name,role_id from users WHERE is_delete <> 1 and status <> "
						+ Status.SUSPENDED.getValue() + " and user_id not in (" + excludedUser + ") and and role_id =?";
			} else {
				sql = "SELECT email,user_id,first_name,last_name,role_id from users WHERE is_delete <> 1 and status <> "
						+ Status.SUSPENDED.getValue() + " and user_id <> " + userId + " and  role_id =?";

			}
		} else {
			if (includedUsers != null && !includedUsers.isEmpty()) {
				final String includedUser = getInClasue(includedUsers);
				sql = "SELECT email,user_id,first_name,last_name,role_id from users WHERE role_id =? and user_id in ("
						+ includedUser + ")";

			}
		}
		if (sql != null) {
			final List<UserDto> userDto = getJdbcTemplate().query(sql, new Object[] { roleId },
					new BeanPropertyRowMapper<UserDto>(UserDto.class));
			return userDto;
		}
		return null;
	}

	/**
	 * Gets the user details for search.
	 *
	 * @param token
	 *            the token
	 * @param roleId
	 *            the role id
	 * @param isAll
	 *            the is all
	 * @param excluededRoleIds
	 *            the exclueded role ids
	 * @param excluededUsers
	 *            the exclueded users
	 * @param includedUsers
	 *            the included users
	 * @param status
	 *            the status
	 * @return the user details for search
	 */
	private List<UserDto> getUserDetailsForSearch(String token, Integer roleId, boolean isAll,
			List<Integer> excluededRoleIds, List<Integer> excluededUsers, List<Integer> includedUsers, Integer status) {
		final Integer userId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();
		String sql = null;
		if (isAll) {
			if (excluededUsers != null && !excluededUsers.isEmpty()) {
				excluededUsers.add(userId);
				final String excluededUser = getInClasue(excluededUsers);
				sql = "SELECT email,user_id,first_name,last_name,role_id from users WHERE is_delete <> 1 and status <> "
						+ Status.SUSPENDED.getValue() + " and user_id not in (" + excluededUser
						+ ") and role_id =? and " + "(first_name ilike ? or last_name ilike ? or email ilike ?)";
			} else {
				sql = "SELECT email,user_id,first_name,last_name,role_id from users WHERE is_delete <> 1 and status <> "
						+ Status.SUSPENDED.getValue() + " and user_id <> " + userId + " and role_id =? and "
						+ "(first_name ilike ? or last_name ilike ? or email ilike ?)";
			}
		} else {
			if (includedUsers != null && !includedUsers.isEmpty()) {
				final String incluededUser = getInClasue(includedUsers);
				sql = "SELECT email,user_id,first_name,last_name,role_id from users WHERE  role_id =? and user_id in ("
						+ incluededUser + ") and " + "(first_name ilike ? or last_name ilike ? or email ilike ?)";
			}
		}

		final List<UserDto> userDto = getJdbcTemplate().query(sql, new Object[] { roleId, token, token, token },
				new BeanPropertyRowMapper<UserDto>(UserDto.class));
		return userDto;
	}

	/**
	 * Creates the record.
	 *
	 * @param fileUploadDto
	 *            the file upload dto
	 * @return the long
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#createRecord(com.harman.dmat.common.dto.
	 * FileUploadDto)
	 */
	@Override
	public Long createRecord(FileUploadDto fileUploadDto) {
		final String sql = "insert into DOWNLOADS_METADATA (FileName,Version,type,Description,Size,Location,CreatedBy,UpdatedBy) values (?,?,?::FILE_TYPE,?,?,?,?,?)";
		final KeyHolder keyHolder = new GeneratedKeyHolder();
		getJdbcTemplate().update((PreparedStatementCreator) connection -> {
			final PreparedStatement ps = connection.prepareStatement(sql, new String[] { "id" });
			ps.setString(1, fileUploadDto.getFileName());
			ps.setString(2, fileUploadDto.getVersion());
			if (fileUploadDto.getType().equalsIgnoreCase("apk")) {
				ps.setString(3, FileTypeEnum.TYPE_APK.getValue());
			} else {
				ps.setString(3, FileTypeEnum.TYPE_USER_GUIDE.getValue());
			}
			ps.setString(4, fileUploadDto.getDescription());
			ps.setString(5, fileUploadDto.getSize());
			ps.setString(6, fileUploadDto.getLocation().get());
			ps.setInt(7, 1);
			ps.setInt(8, 1);
			return ps;
		}, keyHolder);
		return (Long) keyHolder.getKeys().get("id");
	}

	/**
	 * Gets the list of dowload metadata.
	 *
	 * @param type
	 *            the type
	 * @return the list of dowload metadata
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.UserDao#getListOfDowloadMetadata(java.lang.String)
	 */
	@Override
	public List<FileUploadDto> getListOfDowloadMetadata(String type) {
		final String sql = "select * from DOWNLOADS_METADATA where type=?::FILE_TYPE order by createdtimestamp desc, updatedtimestamp desc";
		return getJdbcTemplate().query(sql, (rs, rowcount) -> {
			final FileUploadDto fileUploadDto = new FileUploadDto();
			fileUploadDto.setId(rs.getLong("id"));
			fileUploadDto.setFileName(rs.getString("FileName"));
			fileUploadDto.setVersion(rs.getString("Version"));
			fileUploadDto.setType(type);
			fileUploadDto.setSize(rs.getString("Size"));
			fileUploadDto.setLocation(Optional.of(rs.getString("Location")));
			if (rs.getTimestamp("CreatedTimestamp").before(rs.getTimestamp("updatedtimestamp")))
				fileUploadDto.setCreatedDate(rs.getTimestamp("updatedtimestamp"));
			else
				fileUploadDto.setCreatedDate(rs.getTimestamp("CreatedTimestamp"));
			log.info("-------{}", DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM)
					.format(fileUploadDto.getCreatedDate()));
			fileUploadDto.setCreatedDateTime(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM)
					.format(fileUploadDto.getCreatedDate()));
			return fileUploadDto;
		}, type);
	}

	/**
	 * Save last activity.
	 *
	 * @param lastActivitiyDto
	 *            the last activitiy dto
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.UserDao#saveLastActivity(com.harman.dmat.common.dto.
	 * LastActivitiyDto)
	 */
	@Override
	public void saveLastActivity(LastActivitiyDto lastActivitiyDto) {
		final Integer userId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();
		final String sql = "insert into user_last_activity (user_id,user_state_json)"
				+ "VALUES (?, ?) ON CONFLICT (user_id) DO UPDATE SET user_state_json=? ";
		getJdbcTemplate().update(sql, userId, lastActivitiyDto.getLastActivityJson(),
				lastActivitiyDto.getLastActivityJson());

	}

	/**
	 * Gets the last activity.
	 *
	 * @param userId
	 *            the user id
	 * @return the last activity
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getLastActivity(java.lang.Integer)
	 */
	@Override
	public String getLastActivity(Integer userId) {
		final String sql = "SELECT user_state_json FROM user_last_activity WHERE USER_ID = ?";
		final String lastActivityJson = getJdbcTemplate().query(sql, new Object[] { userId },
				new ResultSetExtractor<String>() {

					@Override
					public String extractData(ResultSet rs) throws SQLException, DataAccessException {
						while (rs.next()) {
							return rs.getString(1);
						}
						return null;
					}
				});

		return lastActivityJson;
	}

	/**
	 * Save sim card request.
	 *
	 * @param simRequestDto
	 *            the sim request dto
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#saveSimCardRequest()
	 */
	@Override
	public void saveSimCardRequest(SimRequestDto simRequestDto) {
		final Integer userId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();
		final String sql = "insert into sim_request (USER_ID,MDN,BUSINESS_REASON,NO_OF_SIM,ADDRESS)"
				+ "VALUES (?, ?,?,?,?)";
		getJdbcTemplate().update(sql, userId, simRequestDto.getMdn(), simRequestDto.getBusinessReason(),
				simRequestDto.getNoOfSim(), simRequestDto.getAddress());

	}

	/**
	 * Gets the device.
	 *
	 * @return the device
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getDevice()
	 */
	@Override
	public List<DeviceDto> getDevice() {
		final String sql = "select id,Device_Name,Device_MODEL,Device_Manufacturer,OS_Supported,OS_Non_Supported as osNotSupported from device_compatible";
		return getJdbcTemplate().query(sql, new BeanPropertyRowMapper<DeviceDto>(DeviceDto.class));
	}

	/**
	 * Adds the device.
	 *
	 * @param deviceDto
	 *            the device dto
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#addDevice(com.harman.dmat.common.dto.
	 * DeviceDto)
	 */
	@Override
	public void addDevice(DeviceDto deviceDto) {
		final String supportedOs = makeComaSperated(deviceDto.getOsSupported());
		final String nonSupportedOs = makeComaSperated(deviceDto.getOsNotSupported());
		final String sql = "insert into device_compatible (Device_Name,Device_MODEL,Device_Manufacturer,OS_Supported,OS_Non_Supported)"
				+ "VALUES (?, ?,?,?,?)";
		getJdbcTemplate().update(sql, deviceDto.getDeviceName(), deviceDto.getDeviceModel(),
				deviceDto.getDeviceManufacturer(), supportedOs, nonSupportedOs);

	}

	/**
	 * Removes the device.
	 *
	 * @param deviceIds
	 *            the device ids
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#removeDevice(java.util.List)
	 */
	@Override
	public void removeDevice(List<Integer> deviceIds) {
		final String inClause = getInClasue(deviceIds);
		final String sql = "Delete from device_compatible where id in (" + inClause + ")";
		getJdbcTemplate().update(sql);

	}

	/**
	 * Edits the device.
	 *
	 * @param deviceDto
	 *            the device dto
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#editDevice(com.harman.dmat.common.dto.
	 * DeviceDto)
	 */
	@Override
	public void editDevice(DeviceDto deviceDto) {
		final String supportedOs = makeComaSperated(deviceDto.getOsSupported());
		final String nonSupportedOs = makeComaSperated(deviceDto.getOsNotSupported());
		getJdbcTemplate().update(
				"update device_compatible set Device_Name = ?,Device_MODEL=?,Device_Manufacturer=?, OS_Supported=?, OS_Non_Supported=? where id = ?",
				deviceDto.getDeviceName(), deviceDto.getDeviceModel(), deviceDto.getDeviceManufacturer(), supportedOs,
				nonSupportedOs, deviceDto.getId());

	}

	/**
	 * Adds the excel info.
	 *
	 * @param lines
	 *            the lines
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#addExcelInfo(java.util.List,
	 * java.lang.String)
	 */
	@Override
	public void addExcelInfo(List<String[]> lines) {
		final StringBuilder sql = new StringBuilder(
				"insert into excel_extracted_info (SIM_ICCID,SIM_PIN,SIM_PUK) values");
		for (final String[] line : lines) {
			sql.append("(");
			for (final String word : line) {
				sql.append(word + ",");
			}
			sql.replace(sql.length() - 1, sql.length(), "");
			sql.append("),");
		}
		sql.replace(sql.length() - 1, sql.length(), "");
		getJdbcTemplate().update(sql.toString());

	}

	/**
	 * Gets the sim info.
	 *
	 * @param iccid
	 *            the iccid
	 * @return the sim info
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getSimInfo(java.lang.String)
	 */
	@Override
	public List<SimInfoDto> getSimInfo(String iccid) {
		final List<SimInfoDto> simInfoDtos = getJdbcTemplate().query(
				"SELECT SIM_ICCID as iccid ,SIM_PIN ,SIM_PUK FROM excel_extracted_info ",
				new BeanPropertyRowMapper<SimInfoDto>(SimInfoDto.class));
		return simInfoDtos;
	}

	/**
	 * Adds the os.
	 *
	 * @param osDto
	 *            the os dto
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#addOs(com.harman.dmat.common.dto.OsDto)
	 */
	@Override
	public void addOs(OsDto osDto) {
		final String sql = "insert into os (name,version)" + "VALUES (?, ?)";
		getJdbcTemplate().update(sql, osDto.getName(), osDto.getVersion());
	}

	/**
	 * Gets the os.
	 *
	 * @return the os
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getOs()
	 */
	@Override
	public List<OsDto> getOs() {
		final List<OsDto> osInfos = getJdbcTemplate().query("SELECT id,name, version from os",
				new BeanPropertyRowMapper<OsDto>(OsDto.class));
		return osInfos;
	}

	/**
	 * Creates the group.
	 *
	 * @param groupDto
	 *            the group dto
	 */
	@Override
	public List<UserDto> createGroup(GroupDto groupDto) {
		List<UserDto> listOfAddedUser = new ArrayList<>();
		final Integer loinUserId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();
		final KeyHolder holder = new GeneratedKeyHolder();
		final String sql = "insert into  user_group (name,group_admin_id) values(?,?)";
		getJdbcTemplate().update((PreparedStatementCreator) connection -> {
			final PreparedStatement ps = connection.prepareStatement(sql, new String[] { "id" });
			ps.setString(1, groupDto.getGroupName().trim());
			ps.setInt(2, loinUserId);
			return ps;
		}, holder);
		final int groupId = holder.getKey().intValue();
		listOfAddedUser.add(getUserDetail(loinUserId));
		if (groupDto.getAddUserIds() != null && !groupDto.getAddUserIds().isEmpty()) {
			String addSql = "insert into user_group_mapping (group_id,user_id,is_accept) values (?,?,?)";
			getJdbcTemplate().batchUpdate(addSql, new BatchPreparedStatementSetter() {

				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setInt(1, groupId);
					ps.setInt(2, groupDto.getAddUserIds().get(i));
					ps.setInt(3, GroupStatus.PENDING.getValue());
				}

				@Override
				public int getBatchSize() {
					return groupDto.getAddUserIds().size();
				}
			});
			groupDto.getAddUserIds().parallelStream().forEach(value -> {
				listOfAddedUser.add(getUserDetail(value));
			});

			/*
			 * if (groupDto.getAddUserIds() != null &&
			 * !groupDto.getAddUserIds().isEmpty()) { final StringBuilder sql1 =
			 * new StringBuilder(
			 * "insert into user_group_mapping (group_id,user_id,is_accept) values"
			 * ); for (final Integer userId : groupDto.getAddUserIds()) {
			 * sql1.append("("); sql1.append(groupId + "," + userId + "," +
			 * GroupStatus.PENDING.getValue()); sql1.append("),"); }
			 * sql1.replace(sql1.length() - 1, sql1.length(), "");
			 * getJdbcTemplate().update(sql1.toString());
			 */

		}
		return listOfAddedUser;
	}

	/**
	 * Update group.
	 *
	 * @param groupDto
	 *            the group dto
	 */
	@Override
	public void updateGroup(GroupDto groupDto) {

		if (groupDto.getGroupName() != null) {
			getJdbcTemplate().update("update user_group set name=? where id=?", groupDto.getGroupName(),
					groupDto.getGroupId());
		}
		if (groupDto.getAddUserIds() != null && !groupDto.getAddUserIds().isEmpty()) {
			final StringBuilder sql = new StringBuilder(
					"insert into user_group_mapping (group_id,user_id,is_accept) values");
			for (final Integer userId : groupDto.getAddUserIds()) {
				sql.append("(");
				sql.append(groupDto.getGroupId() + "," + userId + "," + GroupStatus.PENDING.getValue());
				sql.append("),");
			}
			sql.replace(sql.length() - 1, sql.length(), "");
			getJdbcTemplate().update(sql.toString());

		}
		if (groupDto.getRemoveUserIds() != null && !groupDto.getRemoveUserIds().isEmpty()) {
			String removesql = "delete from user_group_mapping where user_id=? AND group_id=?";
			getJdbcTemplate().batchUpdate(removesql, new BatchPreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setInt(1, groupDto.getRemoveUserIds().get(i));
					ps.setInt(2, groupDto.getGroupId());
				}

				@Override
				public int getBatchSize() {
					return groupDto.getRemoveUserIds().size();
				}
			});
		}

	}

	/**
	 * Delete group.
	 *
	 * @param groupIds
	 *            the group ids
	 */
	@Override
	public void deleteGroup(Integer[] groupIds) {
		final String inClasue = getInClasue(Arrays.asList(groupIds));
		final String sql = "Delete from user_group_mapping where group_id in (" + inClasue + ")";
		getJdbcTemplate().update(sql.toString());
		final String sql1 = "Delete from user_group where id in (" + inClasue + ")";
		getJdbcTemplate().update(sql1.toString());

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getGroups()
	 */
	@Override
	public List<GroupDto> getGroups() {
		final Integer loinUserId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();
		final String sql = "select name as groupName,id as groupId from user_group where group_admin_id=? order by creation_time desc";
		final List<GroupDto> groupDtos = getJdbcTemplate().query(sql, new Object[] { loinUserId },
				new BeanPropertyRowMapper<GroupDto>(GroupDto.class));
		return groupDtos;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getGroupUsers()
	 */
	@Override
	public Map<Integer, List<UserDto>> getGroupUsers() {
		final Integer loinUserId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();
		final String sql = "select users.user_id,users.email,users.first_name,users.last_name,user_group.id as groupId,user_group_mapping.is_accept as groupStatus from user_group join user_group_mapping on user_group.id=user_group_mapping.group_id join users on user_group_mapping.user_id=users.user_id where user_group.group_admin_id=?";
		final Map<Integer, List<UserDto>> groupMap = new HashMap<>();
		getJdbcTemplate().query(sql, new Object[] { loinUserId }, new ResultSetExtractor<Void>() {

			@Override
			public Void extractData(ResultSet rs) throws SQLException, DataAccessException {
				while (rs.next()) {
					final UserDto user = new UserDto();
					user.setUserId(rs.getInt(1));
					user.setEmail(rs.getString(2));
					user.setFirstName(rs.getString(3));
					user.setLastName(rs.getString(4));
					final Integer groupId = rs.getInt(5);
					user.setGroupStatus(rs.getString(6));
					List<UserDto> users = groupMap.get(groupId);
					if (users == null) {
						users = new ArrayList<UserDto>();
					}
					users.add(user);
					groupMap.put(groupId, users);

				}
				return null;
			}
		});

		return groupMap;
	}

	/**
	 * Gets the user detail.
	 *
	 * @param userIds
	 *            the user ids
	 * @return the user detail
	 */
	@Override
	public List<UserDto> getUserDetail(List<Integer> userIds) {
		final String inclasuse = getInClasue(userIds);
		final String sql = "SELECT EMAIL,USER_ID,FIRST_NAME,LAST_NAME FROM users where USER_ID in (" + inclasuse + ")";
		final List<UserDto> userDto = getJdbcTemplate().query(sql, new BeanPropertyRowMapper<UserDto>(UserDto.class));
		return userDto;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.dao.UserDao#setGroupRequestStatus(com.harman.dmat.common.
	 * dto.GroupRequestDto)
	 */
	@Override
	public void setGroupRequestStatus(GroupRequestDto groupRequestDto) {
		final Integer loinUserId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();
		getJdbcTemplate().update("update user_group_mapping set is_accept = ? where user_id=? and group_id=?",
				groupRequestDto.getStatus(), loinUserId, groupRequestDto.getGroupId());

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getGroupAdmin(java.lang.Integer)
	 */
	@Override
	public UserDto getGroupAdmin(Integer groupId) {
		final String sql = "SELECT EMAIL,users.USER_ID,FIRST_NAME,LAST_NAME FROM users join user_group on users.user_id=user_group.GROUP_ADMIN_ID where user_group.id=?";
		final UserDto userDto = getJdbcTemplate().queryForObject(sql, new Object[] { groupId },
				new BeanPropertyRowMapper<UserDto>(UserDto.class));
		return userDto;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getGroupRequest(java.lang.Integer)
	 */
	@Override
	public List<GroupRequestDto> getGroupRequest(Integer userId) {
		final String sql = "select (first_name || ' '|| last_name) AS adminName,group_admin_id, name as groupName,user_group.id as groupId,user_group_mapping.is_accept as status"
				+ " from user_group join users on user_group.group_admin_id=users.user_id   join  user_group_mapping on user_group.id=user_group_mapping.group_id  where user_group_mapping.user_id=?";
		final List<GroupRequestDto> groupRequestDtos = getJdbcTemplate().query(sql, new Object[] { userId },
				new BeanPropertyRowMapper<GroupRequestDto>(GroupRequestDto.class));
		return groupRequestDtos;
	}

	@Override
	public boolean getGroupRequestCount(Integer userId) {
		final String sql = "select count(*) "
				+ " from user_group join users on user_group.group_admin_id=users.user_id   join  user_group_mapping on user_group.id=user_group_mapping.group_id  where user_group_mapping.user_id=? and user_group_mapping.is_accept=?";
		final Integer count = getJdbcTemplate().queryForObject(sql,
				new Object[] { userId, GroupStatus.PENDING.getValue() }, Integer.class);
		return count > 0 ? true : false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getUserBriefInfo(java.lang.Integer,
	 * java.lang.Integer)
	 */
	@Override
	public List<UserDto> getUserBriefInfo(Integer offset, Integer limit) {
		final String sql = "SELECT EMAIL,USER_ID,FIRST_NAME,LAST_NAME FROM users where IS_DELETE <> 1 limit ? offset  ?";
		final List<UserDto> userDto = getJdbcTemplate().query(sql, new Object[] { limit, offset - 1 },
				new BeanPropertyRowMapper<UserDto>(UserDto.class));
		return userDto;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getSimInfo(java.lang.Integer,
	 * java.lang.Integer)
	 */
	@Override
	public SimRequestData getSimInfo(Integer offset, Integer limit) {
		final String sql = "SELECT EMAIL,FIRST_NAME,BUSINESS_REASON,NO_OF_SIM,sim_request.REQUEST_TIME FROM users join sim_request on users.user_id=sim_request.user_id where IS_DELETE <> 1 order by LAST_LOGIN desc limit ? offset  ?";
		final List<SimRequestDto> simDtos = getJdbcTemplate().query(sql, new Object[] { limit, offset - 1 },
				new BeanPropertyRowMapper<SimRequestDto>(SimRequestDto.class));
		final Integer count = getJdbcTemplate().queryForObject("Select COUNT(*) from sim_request", Integer.class);
		final SimRequestData simRequestData = new SimRequestData();
		simRequestData.setSimInfos(simDtos);
		simRequestData.setTotalCount(count);
		return simRequestData;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getUserGroups(java.lang.Integer)
	 */
	@Override
	public List<GroupDto> getUserGroups(Integer loinUserId) {
		final String sql = "select name as groupName,user_group.id as groupId from user_group join user_group_mapping on user_group.id=user_group_mapping.group_id where user_group_mapping.user_id=? and user_group_mapping.is_accept=? group by user_group.id";
		final List<GroupDto> groupDtos = getJdbcTemplate().query(sql,
				new Object[] { loinUserId, GroupStatus.ACCEPT.getValue() },
				new BeanPropertyRowMapper<GroupDto>(GroupDto.class));
		return groupDtos;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#getGroupUsers(java.lang.Integer)
	 */
	@Override
	public Map<Integer, List<UserDto>> getGroupUsers(Integer loinUserId) {
		final String sql = "select users.user_id,users.email,users.first_name,users.last_name,user_group.id as groupId "
				+ "from user_group join user_group_mapping on user_group.id=user_group_mapping.group_id join users on user_group_mapping.user_id=users.user_id "
				+ " where group_id in(select group_id from user_group_mapping where user_id=? group by group_id) and user_group_mapping.is_accept=?";
		final Map<Integer, List<UserDto>> groupMap = new HashMap<>();
		getJdbcTemplate().query(sql, new Object[] { loinUserId, GroupStatus.ACCEPT.getValue() },
				new ResultSetExtractor<Void>() {

					@Override
					public Void extractData(ResultSet rs) throws SQLException, DataAccessException {
						while (rs.next()) {
							final UserDto user = new UserDto();
							user.setUserId(rs.getInt(1));
							user.setEmail(rs.getString(2));
							user.setFirstName(rs.getString(3));
							user.setLastName(rs.getString(4));
							final Integer groupId = rs.getInt(5);
							List<UserDto> users = groupMap.get(groupId);
							if (users == null) {
								users = new ArrayList<UserDto>();
							}
							users.add(user);
							groupMap.put(groupId, users);

						}
						return null;
					}
				});

		return groupMap;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.dao.UserDao#isConatinAdmin(java.util.List)
	 */
	@Override
	public boolean isConatinAdminSuperAdmin(List<Integer> users) {
		final Integer roleId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getScope();
		String roleInclause = "";
		if (Roles.SUPER_ADMIN.getValue() == roleId) {
			roleInclause = "" + roleId;
		} else {
			roleInclause = "" + Roles.ADMIN.getValue() + "," + Roles.SUPER_ADMIN.getValue();
		}
		final String userInclause = getInClasue(users);
		final String sql = "SELECT count(user_id) FROM users WHERE role_id in (" + roleInclause + ")  and user_id in("
				+ userInclause + ")";
		final int status = getJdbcTemplate().queryForObject(sql, Integer.class);
		return status == 0 ? false : true;
	}

	@Override
	public Optional<Long> getRecord(String name, String type) {
		if (checkTheFileAlreadyExist(name, type)) {
			final String sql = "select Id from DOWNLOADS_METADATA where FileName=? AND Type=?::FILE_TYPE";
			if (type.equalsIgnoreCase("apk")) {
				return Optional.of(getJdbcTemplate().queryForObject(sql, (rs, row) -> {
					return rs.getLong("id");
				}, name, FileTypeEnum.TYPE_APK.value));
			} else {
				return Optional.of(getJdbcTemplate().queryForObject(sql, (rs, row) -> {
					return rs.getLong("id");
				}, name, FileTypeEnum.TYPE_USER_GUIDE.value));
			}
		} else {
			return Optional.empty();
		}
	}

	private boolean checkTheFileAlreadyExist(String name, String type) {
		final String sql = "select count(*) from DOWNLOADS_METADATA where FileName=? AND Type=?::FILE_TYPE";
		Optional<Integer> noOfRecordFound = Optional.empty();
		if (type.equalsIgnoreCase("apk")) {
			noOfRecordFound = Optional
					.of(getJdbcTemplate().queryForObject(sql, Integer.class, name, FileTypeEnum.TYPE_APK.value));
		} else {
			noOfRecordFound = Optional
					.of(getJdbcTemplate().queryForObject(sql, Integer.class, name, FileTypeEnum.TYPE_USER_GUIDE.value));
		}
		return noOfRecordFound.isPresent() && noOfRecordFound.get() > 0;
	}

	@Override
	public int updateRecord(Long id, FileUploadDto fileUploadDto) {
		final String sql = "update DOWNLOADS_METADATA set size=?,Version=?,Location=?,Description=?, updatedtimestamp=? where Id=?";
		if (fileUploadDto.getLocation().isPresent()) {
			return getJdbcTemplate().update(sql, fileUploadDto.getSize(), fileUploadDto.getVersion(),
					fileUploadDto.getLocation().get(), fileUploadDto.getDescription(),
					new Timestamp(new Date().getTime()), id);
		} else {
			throw new FTPException("unable to find the location of file  ");
		}
	}

	@Override
	public Boolean isActivityShared(Integer userId) {
		final String sql = "select count(*) "
				+ " from log_share_activity join user_log_activity on user_log_activity.ACTIVITY_ID=log_share_activity.ACTIVITY_ID where log_share_activity.user_id=? and user_log_activity.status=?";
		final Integer count = getJdbcTemplate().queryForObject(sql,
				new Object[] { userId, LogActivityStatus.PENDING.name() }, Integer.class);
		return count > 0 ? true : false;
	}

	@Override
	public boolean isUniqueDevice(String deviceName, String deviceModel) {
		final String sql = "select count(*) from device_compatible where Device_Name=? and Device_MODEL=?";
		final Integer count = getJdbcTemplate().queryForObject(sql, new Object[] { deviceName, deviceModel },
				Integer.class);
		return count > 0 ? false : true;
	}

	@Override
	public String getFileUploadDto(Integer id) {
		final String sql = "Select Location from DOWNLOADS_METADATA  where Id=?";
		return getJdbcTemplate().queryForObject(sql, new Object[] { id }, String.class);

	}

	@Override
	public void deletFileUploadDto(Integer fileId) {
		final String sql = "Delete from DOWNLOADS_METADATA where id=?";
		getJdbcTemplate().update(sql, fileId);
	}

	@Override
	public Boolean checkIFTheGroupNameAvailable(String groupName) {
		String sql = "SELECT count(*) FROM user_group WHERE lower(name) = LOWER(?)";
		int noOfRecordFound = getJdbcTemplate().queryForObject(sql, new Object[] { groupName }, Integer.class);
		return noOfRecordFound <= 0;
	}

	@Override
	public boolean storeUserFeedback(FeedBackDto feedBackDto) {
		final String sql = "INSERT INTO feedback (email,feedback) VALUES (?, ?)";
		int insCount = getJdbcTemplate().update(sql, feedBackDto.getEmail(), feedBackDto.getFeedback());
		return insCount > 0 ? true : false;
	}

	@Override
	public List<SoftwareVersionDto> getSoftwareList() {
		final String sql = "SELECT id, device_os, version as versionName, latest, buildflavor as buildFlavor from software order by buildflavor desc, id desc";
		final List<SoftwareVersionDto> softwareVersionDtos = getJdbcTemplate().query(sql,
				new BeanPropertyRowMapper<SoftwareVersionDto>(SoftwareVersionDto.class));
		return softwareVersionDtos;
	}

	@Override
	public Boolean deleteSoftware(int softwareId) {
		final String sql = "Delete from software where id=?";
		int del = getJdbcTemplate().update(sql, softwareId);
		return (del > 0) ? true : false;
	}

	@Override
	public Boolean setLatestSoftware(int softwareId, int osId, boolean latest) {
		boolean updated = false;
		final int row = getJdbcTemplate().update("update software set latest=false where buildflavor = ?", osId);
		if (row > 0 && latest) {
			int makeLatest = getJdbcTemplate().update("update software set latest=true where id = ?", softwareId);
			updated = (makeLatest == 1) ? true : false;
		} else if (row > 0 && !latest) {
			updated = true;
		}
		return updated;
	}

	@Override
	public String registerSoftware(SoftwareVersionDto softwareVersionDto) {
		if (softwareVersionDto.isLatest()) {
			getJdbcTemplate().update("update software set latest=false where buildflavor = ?",
					softwareVersionDto.getBuildFlavor());
		}
		SimpleJdbcInsert simpleJdbcInsert = getClientApiInbuildingSimpleJdbcInsert();
		Map<String, Object> parameters = new HashMap<String, Object>();

		parameters.put("device_os", softwareVersionDto.getDeviceOs());
		parameters.put("version", softwareVersionDto.getVersionName());
		parameters.put("latest", softwareVersionDto.isLatest());
		parameters.put("buildflavor", softwareVersionDto.getBuildFlavor());
		parameters.put("apk", softwareVersionDto.getApk());

		if (!simpleJdbcInsert.isCompiled()) {
			simpleJdbcInsert.withTableName("software").usingGeneratedKeyColumns("id");
		}

		int status = simpleJdbcInsert.execute(parameters);

		return status > 0 ? "SUCCESS" : "FAILED";
	}

	@Override
	public EventDtos getEventsLegends(EventsBodyDto eventsBodyDto) {
		final String sql = "select id,key,description, color from events";
		final List<EventDto> data = getJdbcTemplate().query(sql, new BeanPropertyRowMapper<EventDto>(EventDto.class));
		EventDtos eventDtos = new EventDtos();
		eventDtos.setEventsInfo(data);
		String count = getEventDetails(eventsBodyDto);
		eventDtos.setTotalEvents(count.split(":")[0]);
		eventDtos.setDistinctEvents(count.split(":")[1]);
		return eventDtos;
	}

	private String getEventDetails(EventsBodyDto eventsBodyDto) {
		final String userDomain = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserDomain();
		String userQuery = "";
		if (eventsBodyDto.getUserId() != null)
			userQuery = ", { \"match\": { \"DmUser\": { \"query\":" + eventsBodyDto.getUserId() + "} } }";
		String domainQuery = getDomainESQuery(userDomain);

		String distinctQuery = "{ \"size\": 0, \"query\": { \"bool\": { \"must\": [ { \"query_string\": { \"query\": \"_exists_:loc_50\" } }, { \"bool\": { \"should\": "
				+ "[ { \"range\": { \"LTEPdnRej\": { \"gt\": 0 } } }, { \"range\": { \"LTERlf\": { \"gt\": 0 } } }, { \"range\": { \"LTERrcConRestRej\": { \"gt\": 0 } } },"
				+ " { \"range\": { \"LTERrcConRej\": { \"gt\": 0 } } }, { \"range\": { \"LTEServiceRej\": { \"gt\": 0 } } }, { \"range\": { \"LTESibReadFailure\": { \"gt\": 0 } }"
				+ " }, { \"range\": { \"LTETaRej\": { \"gt\": 0 } } }, { \"range\": { \"LTEVoLTEDrop\": { \"gt\": 0 } } }, { \"range\": { \"LTEReselFromGsmUmtsFail\": {"
				+ " \"gt\": 0 } } }, { \"range\": { \"LTEIntraReselFail\": { \"gt\": 0 } } }, { \"range\": { \"LTEIntraHoFail\": { \"gt\": 0 } } }, { \"range\": { \"LTEAttRej\""
				+ ": { \"gt\": 0 } } }, { \"range\": { \"LTEAuthRej\": { \"gt\": 0 } } }, { \"range\": { \"LTEMobilityFromEutraFail\": { \"gt\": 0 } } }, { \"range\": { "
				+ "\"LTEReselToGsmUmtsFail\": { \"gt\": 0 } } }, { \"range\": { \"LTEOos\": { \"gt\": 0 } } } ] } }, { \"range\": { \"TimeStamp\": { \"from\": \""
				+ eventsBodyDto.getFrom() + "\", " + "\"to\": \"" + eventsBodyDto.getTo()
				+ "\", \"include_lower\": true, \"include_upper\": true, \"boost\": 1 } } }" + domainQuery + userQuery
				+ "], \"filter\": { \"geo_bounding_box\": { \"loc\": { \"top_left\": { \"lat\": "
				+ eventsBodyDto.getMapExtent().getCorner1() + ", \"lon\": " + +eventsBodyDto.getMapExtent().getCorner2()
				+ "}, \"bottom_right\": { \"lat\":" + eventsBodyDto.getMapExtent().getCorner3() + ", \"lon\": "
				+ eventsBodyDto.getMapExtent().getCorner4() + " } } } } } }, \"aggs\": {"
				+ " \"distinctEvents\": { \"cardinality\": { \"field\": \"loc_50\" } } , \"LTEVoLTEDrop\": { \"value_count\": { \"field\": \"LTEVoLTEDrop\" } } , "
				+ " \"LTEOos\": { \"value_count\": { \"field\": \"LTEOos\" } } , "
				+ " \"LTERlf\": { \"value_count\": { \"field\": \"LTERlf\" } } , "
				+ " \"LTERrcConRestRej\": { \"value_count\": { \"field\": \"LTERrcConRestRej\" } } , "
				+ " \"LTERrcConRej\": { \"value_count\": { \"field\": \"LTERrcConRej\" } } , "
				+ " \"LTEPdnRej\": { \"value_count\": { \"field\": \"LTEPdnRej\" } } , "
				+ " \"LTEServiceRej\": { \"value_count\": { \"field\": \"LTEServiceRej\" } } , "
				+ " \"LTEAttRej\": { \"value_count\": { \"field\": \"LTEAttRej\" } } , "
				+ " \"LTESibReadFailure\": { \"value_count\": { \"field\": \"LTESibReadFailure\" } } , "
				+ " \"LTETaRej\": { \"value_count\": { \"field\": \"LTETaRej\" } } , "
				+ " \"LTEIntraHoFail\": { \"value_count\": { \"field\": \"LTEIntraHoFail\" } } , "
				+ " \"LTEIntraReselFail\": { \"value_count\": { \"field\": \"LTEIntraReselFail\" } } , "
				+ " \"LTEAuthRej\": { \"value_count\": { \"field\": \"LTEAuthRej\" } } , "
				+ " \"LTEMobilityFromEutraFail\": { \"value_count\": { \"field\": \"LTEMobilityFromEutraFail\" } } , "
				+ " \"LTEReselToGsmUmtsFail\": { \"value_count\": { \"field\": \"LTEReselToGsmUmtsFail\" } } , "
				+ " \"LTEReselFromGsmUmtsFail\": { \"value_count\": { \"field\": \"LTEReselFromGsmUmtsFail\" } } } }";

		log.debug("Query formed:{} ", distinctQuery);
		String indices = Utill.getIndex(eventsBodyDto.getFrom(), eventsBodyDto.getTo());
		log.debug("Indices: {}", indices);
		final SearchRequest searchRequest = new SearchRequest();
		final String dataPointType = environment.getRequiredProperty("data-point-es-type");
		final String[] sIndices = indices.split(",");
		searchRequest.indices(sIndices).types(dataPointType);

		final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
				.setRequest(searchRequest).setScript(distinctQuery).setScriptType(ScriptType.INLINE).get();
		String[] eventArray = { "LTEVoLTEDrop", "LTEOos", "LTERlf", "LTERrcConRestRej", "LTERrcConRej", "LTEPdnRej",
				"LTEServiceRej", "LTEAttRej", "LTESibReadFailure", "LTETaRej", "LTEIntraHoFail", "LTEIntraReselFail",
				"LTEAuthRej", "LTEMobilityFromEutraFail", "LTEReselToGsmUmtsFail", "LTEReselFromGsmUmtsFail" };
		long sum = 0;
		for (int i = 0; i < eventArray.length; i++) {
			ValueCount agg = searchResponse.getResponse().getAggregations().get(eventArray[i]);
			long distinctCount = agg.getValue();
			sum = sum + distinctCount;
		}
		Cardinality agg = searchResponse.getResponse().getAggregations().get("distinctEvents");
		long distinctCount = agg.getValue();

		return new String(sum + ":" + distinctCount);
	}

	/**
	 * Creates the domain SQL query
	 * 
	 * @param userDomain
	 * @return
	 */
	private String getDomainESQuery(String userDomain) {
		String domainQuery = "";
		userDomain = userDomain == null ? "null" : userDomain;
		StringBuffer sb = new StringBuffer();
		try {
			List<String> listVzDomains = Arrays.asList(environment.getRequiredProperty("verizon.domains").split(","));

			if (listVzDomains.contains(userDomain)) {
				for (String domain : listVzDomains) {
					sb = sb.append("{ \"query_string\": { \"query\": \"EmailId:*").append(domain).append("\"} },");
				}
				sb.deleteCharAt(sb.length() - 1);
				domainQuery = ", { \"bool\": { \"should\": [" + sb.toString() + "] } }";
			} else {
				sb = sb.append("{ \"query_string\": { \"query\": \"EmailId:*").append(userDomain.toLowerCase())
						.append("\"} }");
				domainQuery = ", { \"bool\": { \"must\": [" + sb.toString() + "] } }";
			}
		} catch (Exception e) {
			log.error("Error Getting Vz domains");
		}

		return domainQuery;
	}

	@Override
	public List<EventsCountDto> getEventsCount(EventsBodyDto eventsBodyDto) {
		final String sql = "select id,key,description from events";
		List<EventsCountDto> eventCountDtoList = getJdbcTemplate().query(sql,
				new BeanPropertyRowMapper<EventsCountDto>(EventsCountDto.class));
		Map<String, Long> eventCounts = getEventCounts(eventsBodyDto);
		for (EventsCountDto eventsCountDto : eventCountDtoList) {
			eventsCountDto.setCount(eventCounts.get(eventsCountDto.getKey()));
		}

		return eventCountDtoList;
	}

	private Map<String, Long> getEventCounts(EventsBodyDto eventsBodyDto) {
		final String userDomain = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserDomain();
		String domainQuery = getDomainESQuery(userDomain);
		String userQuery = "";
		if (eventsBodyDto.getUserId() != null)
			userQuery = ", { \"match\": { \"DmUser\": { \"query\":" + eventsBodyDto.getUserId() + "} } }";
		Map<String, Long> eventCounts = new HashMap<>();

		String distinctQuery = "{ \"size\": 0, \"query\": { \"bool\": { \"must\": [ { \"bool\": { \"should\": "
				+ "[ { \"range\": { \"LTEPdnRej\": { \"gt\": 0 } } }, { \"range\": { \"LTERlf\": { \"gt\": 0 } } }, { \"range\": { \"LTERrcConRestRej\": { \"gt\": 0 } } },"
				+ " { \"range\": { \"LTERrcConRej\": { \"gt\": 0 } } }, { \"range\": { \"LTEServiceRej\": { \"gt\": 0 } } }, { \"range\": { \"LTESibReadFailure\": { \"gt\": 0 } }"
				+ " }, { \"range\": { \"LTETaRej\": { \"gt\": 0 } } }, { \"range\": { \"LTEVoLTEDrop\": { \"gt\": 0 } } }, { \"range\": { \"LTEReselFromGsmUmtsFail\": {"
				+ " \"gt\": 0 } } }, { \"range\": { \"LTEIntraReselFail\": { \"gt\": 0 } } }, { \"range\": { \"LTEIntraHoFail\": { \"gt\": 0 } } }, { \"range\": { \"LTEAttRej\""
				+ ": { \"gt\": 0 } } }, { \"range\": { \"LTEAuthRej\": { \"gt\": 0 } } }, { \"range\": { \"LTEMobilityFromEutraFail\": { \"gt\": 0 } } }, { \"range\": { "
				+ "\"LTEReselToGsmUmtsFail\": { \"gt\": 0 } } }, { \"range\": { \"LTEOos\": { \"gt\": 0 } } } ] } }, { \"range\": { \"TimeStamp\": { \"from\": \""
				+ eventsBodyDto.getFrom() + "\", " + "\"to\": \"" + eventsBodyDto.getTo()
				+ "\", \"include_lower\": true, \"include_upper\": true, \"boost\": 1 } } }" + domainQuery + userQuery
				+ "], \"filter\": { \"geo_bounding_box\": { \"loc\": { \"top_left\": { \"lat\": "
				+ eventsBodyDto.getMapExtent().getCorner1() + ", \"lon\": " + +eventsBodyDto.getMapExtent().getCorner2()
				+ "}, \"bottom_right\": { \"lat\":" + eventsBodyDto.getMapExtent().getCorner3() + ", \"lon\": "
				+ eventsBodyDto.getMapExtent().getCorner4() + " } } } } } }, "
				+ "\"aggs\": { \"LTEVoLTEDrop\": { \"value_count\": { \"field\": \"LTEVoLTEDrop\" } } , "
				+ " \"LTEOos\": { \"value_count\": { \"field\": \"LTEOos\" } } , "
				+ " \"LTERlf\": { \"value_count\": { \"field\": \"LTERlf\" } } , "
				+ " \"LTERrcConRestRej\": { \"value_count\": { \"field\": \"LTERrcConRestRej\" } } , "
				+ " \"LTERrcConRej\": { \"value_count\": { \"field\": \"LTERrcConRej\" } } , "
				+ " \"LTEPdnRej\": { \"value_count\": { \"field\": \"LTEPdnRej\" } } , "
				+ " \"LTEServiceRej\": { \"value_count\": { \"field\": \"LTEServiceRej\" } } , "
				+ " \"LTEAttRej\": { \"value_count\": { \"field\": \"LTEAttRej\" } } , "
				+ " \"LTESibReadFailure\": { \"value_count\": { \"field\": \"LTESibReadFailure\" } } , "
				+ " \"LTETaRej\": { \"value_count\": { \"field\": \"LTETaRej\" } } , "
				+ " \"LTEIntraHoFail\": { \"value_count\": { \"field\": \"LTEIntraHoFail\" } } , "
				+ " \"LTEIntraReselFail\": { \"value_count\": { \"field\": \"LTEIntraReselFail\" } } , "
				+ " \"LTEAuthRej\": { \"value_count\": { \"field\": \"LTEAuthRej\" } } , "
				+ " \"LTEMobilityFromEutraFail\": { \"value_count\": { \"field\": \"LTEMobilityFromEutraFail\" } } , "
				+ " \"LTEReselToGsmUmtsFail\": { \"value_count\": { \"field\": \"LTEReselToGsmUmtsFail\" } } , "
				+ " \"LTEReselFromGsmUmtsFail\": { \"value_count\": { \"field\": \"LTEReselFromGsmUmtsFail\" } } }"
				+ "}";

		log.debug("Query formed:{} ", distinctQuery);
		String indices = Utill.getIndex(eventsBodyDto.getFrom(), eventsBodyDto.getTo());
		log.debug("Indices: {}", indices);
		final SearchRequest searchRequest = new SearchRequest();
		final String dataPointType = environment.getRequiredProperty("data-point-es-type");
		final String[] sIndices = indices.split(",");
		searchRequest.indices(sIndices).types(dataPointType);

		final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
				.setRequest(searchRequest).setScript(distinctQuery).setScriptType(ScriptType.INLINE).get();
		String[] eventArray = { "LTEVoLTEDrop", "LTEOos", "LTERlf", "LTERrcConRestRej", "LTERrcConRej", "LTEPdnRej",
				"LTEServiceRej", "LTEAttRej", "LTESibReadFailure", "LTETaRej", "LTEIntraHoFail", "LTEIntraReselFail",
				"LTEAuthRej", "LTEMobilityFromEutraFail", "LTEReselToGsmUmtsFail", "LTEReselFromGsmUmtsFail" };
		for (int i = 0; i < eventArray.length; i++) {
			ValueCount agg = searchResponse.getResponse().getAggregations().get(eventArray[i]);
			long distinctCount = agg.getValue();
			eventCounts.put(eventArray[i], distinctCount);
		}

		return eventCounts;
	}

}
