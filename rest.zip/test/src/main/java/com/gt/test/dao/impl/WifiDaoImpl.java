package com.harman.dmat.dao.impl;

import com.esri.hex.HexXY;
import com.harman.dmat.common.dto.*;
import com.harman.dmat.dao.WifiDao;
import com.harman.dmat.utils.EsClient;
import com.harman.dmat.utils.Utill;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.script.mustache.SearchTemplateRequestBuilder;
import org.elasticsearch.script.mustache.SearchTemplateResponse;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.metrics.avg.Avg;
import org.elasticsearch.search.aggregations.metrics.avg.InternalAvg;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHits;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

@Repository
@Slf4j

public class WifiDaoImpl implements WifiDao {
	@Inject
	private Environment environment;

	@Override
	public WifiDto getWifiInfo(String query) {
		log.debug("getWifiInfo in...");

		final SearchRequest searchRequest = new SearchRequest();
		final String wifiIndex = environment.getRequiredProperty("esIndexEndPoint");
		final String wifiType = environment.getRequiredProperty("esIndexType");
		searchRequest.indices(wifiIndex).types(wifiType);

		log.debug("ES query: {}", query);

		final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
				.setRequest(searchRequest).setScript(query).setScriptType(ScriptType.INLINE).get();

		final Map<String, String> dataMap = new HashMap<String, String>();
		for (final Aggregation aggregation : searchResponse.getResponse().getAggregations().asList()) {
			final String aggName = aggregation.getName();
			if (searchResponse.getResponse().getAggregations().get(aggName).getClass() == InternalAvg.class) {
				final Avg avg = searchResponse.getResponse().getAggregations().get(aggName);
				dataMap.put(avg.getName(), String.format("%.4f", avg.getValue()));
			} else {
				final Terms terms = searchResponse.getResponse().getAggregations().get(aggName);
				if (terms.getBuckets().size() > 0) {
					dataMap.put(aggName, terms.getBuckets().get(0).getKeyAsString());
				}
			}
		}
		WifiDto WifiDto = new WifiDto();
		WifiDto.setBrssi(dataMap.get("BSSID"));
		WifiDto.setChannel(dataMap.get("channel"));
		WifiDto.setDhcpserver(dataMap.get("dhcpserver"));
		WifiDto.setEncryption(dataMap.get("encryption"));
		WifiDto.setGateway(dataMap.get("gateway"));
		WifiDto.setHiddenSsId(dataMap.get("hiddenssid"));
		WifiDto.setIpAddress(dataMap.get("ipaddress"));
		WifiDto.setLinkSpeed(dataMap.get("linkspeed"));
		WifiDto.setMacAddress(dataMap.get("macaddress"));
		WifiDto.setNetMask(dataMap.get("netmask"));
		WifiDto.setNetworkId(dataMap.get("networkid"));
		if (null != dataMap.get("createddate")) {
			WifiDto.setCreateddate(dataMap.get("createddate").substring(0, 19));
		}
		WifiDto.setRssi(dataMap.get("RSSI"));
		WifiDto.setSecondaryDns(dataMap.get("secondarydns"));
		if (null != dataMap.get("SSID")) {
			WifiDto.setSsid(dataMap.get("SSID").substring(1, dataMap.get("SSID").length() - 1));
		}
		WifiDto.setWifiType(dataMap.get("wifitype"));

		log.debug("getWifiInfo out.");
		return WifiDto;
	}

    /**
     * Retrieves the Wifi/Escher Data clusters
     * @param clusterQuery(wifi/escher)
     * @param indices
     * @param locCode
     * @return
     */
    @Override
    public WifiClusterResponseDto getWifiDataClusters(String wifiType, String dataPointType, String clusterQuery, String indices, String locCode) {
        WifiClusterResponseDto responseDto = new WifiClusterResponseDto();

        final SearchRequest searchRequest = new SearchRequest();
        final String sIndices = indices;
        searchRequest.indices(sIndices).types(dataPointType);

        final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
                .setRequest(searchRequest).setScript(clusterQuery).setScriptType(ScriptType.INLINE).get();

        List<FeaturesDto> features = new ArrayList<>();

        List<FieldsDto> fieldsList = new ArrayList<>();
        FieldsDto fieldsDto1 = new FieldsDto();
        fieldsDto1.setName("ID");
        fieldsDto1.setType("esriFieldTypeOID");
        fieldsDto1.setAlias("ID");

        fieldsList.add(fieldsDto1);

        FieldsDto fieldsDto2 = new FieldsDto();
        fieldsDto2.setName("M");
        fieldsDto2.setType("esriFieldTypeDouble");
        fieldsDto2.setAlias("M");

        fieldsList.add(fieldsDto2);

        FieldsDto fieldsDto3 = new FieldsDto();
        fieldsDto3.setName("ssid");
        fieldsDto3.setType("esriFieldTypeString");
        fieldsDto3.setAlias("ssid");

        fieldsList.add(fieldsDto3);

        Map<String, String> ssidMap = new HashMap<>();

        final Aggregations aggregations = searchResponse.getResponse().getAggregations();
        if (aggregations != null) {
            AtomicInteger id = new AtomicInteger(0);
            for (final Aggregation aggregation : aggregations.asList()) {
                final String aggName = aggregation.getName();
                final Terms terms = searchResponse.getResponse().getAggregations().get(aggName);
                if (terms.getBuckets().size() > 0) {
                    for (int i = 0; i < terms.getBuckets().size(); i++) {
                        String ssid = terms.getBuckets().get(i).getKeyAsString();
                        Terms locTerms = terms.getBuckets().get(i).getAggregations().get(locCode);
                        if(locCode.equalsIgnoreCase("loc_100") || locCode.equalsIgnoreCase("loc_50") || locCode.equalsIgnoreCase("loc_25")
                                || locCode.equalsIgnoreCase("loc_10") || locCode.equalsIgnoreCase("loc_5") || locCode.equalsIgnoreCase("loc_2")) {
                            if (locTerms.getBuckets().size() > 0) {
                                locTerms.getBuckets().forEach(x -> {
                                    FeaturesDto granFeaturesDto = new FeaturesDto();
                                    GeometryDto granGeometryDto = new GeometryDto();
                                    AttributesDto granAttributesDto = new AttributesDto();

                                    TopHits top_loc = x.getAggregations().get("top_loc");
                                    for (SearchHit hit : top_loc.getHits().getHits()) {
                                        granGeometryDto.setX((Double) hit.getSource().get("loc_mx"));
                                        granGeometryDto.setY((Double) hit.getSource().get("loc_my"));
                                    }

                                    granFeaturesDto.setAttributes(granAttributesDto);
                                    granFeaturesDto.setGeometry(granGeometryDto);
                                    granAttributesDto.setSsid(ssid);
                                    granAttributesDto.setID(Integer.toString(id.incrementAndGet()));
                                    granAttributesDto.setWifiType(wifiType);

                                    features.add(granFeaturesDto);
                                });
                            }
                        } else {
                            if (locTerms.getBuckets().size() > 0) {
                                locTerms.getBuckets().forEach(x -> {
                                    ssidMap.put(ssid, x.getKey().toString());
                                });
                            }
                        }
                    }
                }
            }

            if(ssidMap.size() > 0) {
                AtomicInteger highZoomId = new AtomicInteger(0);
               /* Map<String,Long> groupByLocs =  ssidMap.values().stream().
                        collect(Collectors.groupingBy(Function.identity(),
                                Collectors.counting()));*/

                for(Map.Entry<String, String> locs : ssidMap.entrySet()) {
                    FeaturesDto featuresDto = new FeaturesDto();
                    GeometryDto geometryDto = new GeometryDto();
                    AttributesDto attributesDto = new AttributesDto();

                    String[] locCodes = locs.getValue().split(":");

                    geometryDto.setLocX(Double.parseDouble(locCodes[0]));
                    geometryDto.setLocY(Double.parseDouble(locCodes[1]));

                    HexXY hexXY = Utill.getRowColToMxMy(Double.parseDouble(locCode.split("_")[1]), Long.parseLong(locCodes[0]), Long.parseLong(locCodes[1]));
                    geometryDto.setX(hexXY.x());
                    geometryDto.setY(hexXY.y());
                    attributesDto.setSsid(locs.getKey());
                    attributesDto.setM(1);

                    featuresDto.setAttributes(attributesDto);
                    featuresDto.setGeometry(geometryDto);
                    attributesDto.setID(Integer.toString(highZoomId.incrementAndGet()));
                    attributesDto.setWifiType(wifiType);

                    features.add(featuresDto);
                }
            }


            SpatialReferenceDto spatRef = new SpatialReferenceDto();
            spatRef.setWkid(102100);

            FieldAliasDto fieldAliasDto = new FieldAliasDto();
            fieldAliasDto.setID("ID");

            responseDto.setObjectIdFieldName("ID");
            responseDto.setFieldAlias(fieldAliasDto);
            responseDto.setGeometryType("esriGeometryPoint");
            responseDto.setSpatialReference(spatRef);
            responseDto.setFields(fieldsList);
            responseDto.setFeatures(features);
        }

        return responseDto;
    }

    /**
     * Retrieves wificluster info for the given search request.
     * @param wifiClusterInfoQuery
     * @param indices
     * @return
     */
	@Override
	public WifiClusterInfoResponseDto getWifiDataClusterInfo(String dataPointType, String wifiClusterInfoQuery, String indices, String ssid, String wifiType) {
		WifiClusterInfoResponseDto responseDto = new WifiClusterInfoResponseDto();

		final SearchRequest searchRequest = new SearchRequest();
		final String sIndices = indices;
		searchRequest.indices(sIndices).types(dataPointType);

		final SearchTemplateResponse searchResponse = new SearchTemplateRequestBuilder(EsClient.client)
				.setRequest(searchRequest).setScript(wifiClusterInfoQuery).setScriptType(ScriptType.INLINE).get();

		final SearchHit[] s = searchResponse.getResponse().getHits().getHits();
		Map<String, Object> sourceMap = new HashMap<>();

		if(s.length > 0) {
            for (final SearchHit a : s) {
                sourceMap = a.getSource();

                if(sourceMap.get("ssid") != null) {
                    responseDto.setSsid(sourceMap.get("ssid").toString());
                }
                if(sourceMap.get("bssid") != null) {
                    responseDto.setBssid(sourceMap.get("bssid").toString());
                }
                if(sourceMap.get("channel") != null) {
                    responseDto.setChannel(sourceMap.get("channel").toString());
                }
                if(sourceMap.get("dhcpserver") != null) {
                    responseDto.setDhcpServer(sourceMap.get("dhcpserver").toString());
                }
                if(sourceMap.get("encryption") != null) {
                    responseDto.setEncryption(sourceMap.get("encryption").toString());
                }
                if(sourceMap.get("gateway") != null) {
                    responseDto.setGateway(sourceMap.get("gateway").toString());
                }
                if(sourceMap.get("hiddenssid") != null) {
                    responseDto.setHiddenSsid(sourceMap.get("hiddenssid").toString());
                }
                if(sourceMap.get("ipaddress") != null) {
                    responseDto.setIpAddress(sourceMap.get("ipaddress").toString());
                }
                if(sourceMap.get("linkspeed") != null) {
                    responseDto.setLinkSpeed(sourceMap.get("linkspeed").toString());
                }
                if(sourceMap.get("netmask") != null) {
                    responseDto.setNetMask(sourceMap.get("netmask").toString());
                }
                if(sourceMap.get("macaddress") != null) {
                    responseDto.setMacAddress(sourceMap.get("macaddress").toString());
                }
                if(sourceMap.get("networkid") != null) {
                    responseDto.setNetworkId(sourceMap.get("networkid").toString());
                }
                if(sourceMap.get("secondarydns") != null) {
                    responseDto.setSecondaryDns(sourceMap.get("secondarydns").toString());
                }
                if(sourceMap.get("rssi") != null) {
                    responseDto.setRssi(sourceMap.get("rssi").toString());
                }
                if(sourceMap.get("wifitype") != null) {
                    responseDto.setWifiType(sourceMap.get("wifitype").toString());
                }
                if(sourceMap.get("imei") != null) {
                    responseDto.setImei(sourceMap.get("imei").toString());
                }
                if(sourceMap.get("mdn") != null) {
                    responseDto.setMdn(sourceMap.get("mdn").toString());
                }
                if(sourceMap.get("ipass") != null) {
                    responseDto.setIpass(sourceMap.get("ipass").toString());
                }
                if(sourceMap.get("ipassscore") != null) {
                    responseDto.setIpassscore(sourceMap.get("ipassscore").toString());
                }
                if(sourceMap.get("authenticationused") != null) {
                    responseDto.setAuthenticationUsed(sourceMap.get("authenticationused").toString());
                }
                if(sourceMap.get("frequency") != null) {
                    responseDto.setFrequency(sourceMap.get("frequency").toString());
                }
            }
        } else {
            responseDto.setSsid(ssid);
            responseDto.setWifiType(wifiType);
        }

		return responseDto;
	}
}