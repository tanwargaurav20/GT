package com.harman.dmat.enums;

// TODO: Auto-generated Javadoc
/**
 * This enum contain error code and message for rest api.
 *
 * @author prakash.bisht@harman.com
 */
public enum ErrorCode {

	/** The user notfound. */
	USER_NOTFOUND("User does not exist", 500),
	/** The invalid user. */
	INVALID_USER("Username or password seems invalid.", 501),

	/** The invalid user. */
	LICENSE_EXPIRED("Your License has been expired. Please contact administrator.", 507),

	/** The password not match. */
	PASSWORD_NOT_MATCH("Password does not match.", 502),
	/** The last login. */
	LAST_LOGIN("User did not login since last 90 days and access code has been sent on your email.", 503),
	/** The accesscode not match. */
	ACCESSCODE_NOT_MATCH("Access code did not match.", 504),

	/** The invalid password. */
	INVALID_PASSWORD("Please enter a valid email.", 505),

	/** The duplicate email. */
	DUPLICATE_EMAIL("Email id already exist.", 506),

	/** The inactive user. */
	INACTIVE_USER("User is inactive or pending.", 507),

	/** The not exist user. */
	NOT_EXIST_USER("Unauthorized user.", 401),

	/** The access denied. */
	ACCESS_DENIED("Access Denied, You don't have suitable permission to access resource.", 402),

	/** The invalid json. */
	INVALID_JSON("Invalid json data.", 508),

	/** The duplicate group. */
	DUPLICATE_GROUP("Group name already exist.", 509),

	/** The invalid device. */
	INVALID_DEVICE("Device already exist.", 510),

	/** The unable to delete file. */
	UNABLE_TO_DELETE_FILE("unable to delete file from FTP.", 511),

	/** The record not exist. */
	RECORD_NOT_EXIST("File does not exist.", 512),

	/** Cannot share to itself. */
	ACTIVITY_ITSELF("user cannot share activity to itself.", 513),

	/** The token expired. */
	TOKEN_EXPIRED("Token expired, please login again.", 513),

	/** The token expired. */
	REFRESH_TOKEN_EXPIRED("Refresh Token expired, please login again.", 513);

	/** The error code. */
	private final int errorCode;

	/** The error message. */
	private final String errorMessage;

	/**
	 * Instantiates a new error code.
	 *
	 * @param errorMessage
	 *            the error message
	 * @param errorCode
	 *            the error code
	 */
	ErrorCode(final String errorMessage, final int errorCode) {
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	/**
	 * Gets the error code.
	 *
	 * @return the error code
	 */
	public int getErrorCode() {
		return errorCode;
	}

	/**
	 * Gets the error message.
	 *
	 * @return the error message
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

}
