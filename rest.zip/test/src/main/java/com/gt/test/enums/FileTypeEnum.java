package com.harman.dmat.enums;

public enum FileTypeEnum {
	TYPE_APK("apk"),
	TYPE_USER_GUIDE("user_guide");
	public String value;

	FileTypeEnum (String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}
