package com.harman.dmat.enums;

/**
 * The Enum GroupStatus.
 *
 * @author prakash.bisht@harman.com
 */
public enum GroupStatus {
	
	/** The reject. */
	REJECT(0),
	
	/** The accept. */
	ACCEPT(1),
	
	/** The pending. */
	PENDING(2);
	

	
	/**
	 * Instantiates a new group status.
	 *
	 * @param value the value
	 */
	GroupStatus(final int value) {
		this.value = value;
	}

	/** The value. */
	int value;

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public int getValue() {
		return value;
	}
}
