package com.harman.dmat.enums;

public enum LegendsEnum {
	TYPE_FIXED_RANGE("fixed_range_with_color"),
	TYPE_VARIABLE_RANGE("variable_range_with_color"),
	TYPE_NO_LEGEND("no_legend");
	
	public String value;

	LegendsEnum (String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}
