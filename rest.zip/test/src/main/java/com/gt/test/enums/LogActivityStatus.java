package com.harman.dmat.enums;

/**
 * The Enum LogActivityStatus.
 *
 * @author prakash.bisht@harman.com
 */
public enum LogActivityStatus {

	/** The pending. */
	PENDING,
	/** The under review. */
	UNDER_REVIEW,
	/** The analyzing. */
	ANALYZING,
	/** The closed. */
	CLOSED;
}
