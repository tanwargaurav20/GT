package com.harman.dmat.enums;

public enum LogStatus {
	UPLOADING,FILE_UPLOADED,IN_PROCESS,ERROR,ACTIVE;
}
