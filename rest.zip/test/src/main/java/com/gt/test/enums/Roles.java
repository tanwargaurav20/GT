package com.harman.dmat.enums;

/**
 * The Enum Roles.
 *
 * @author prakash.bisht@harman.com
 */
/**
 * @author inpbisht20
 *
 */
public enum Roles {

	/** The admin. */
	ADMIN(2),
	/** The groupt admin. */
	GROUP_ADMIN(999),
	/** The user. */
	USER(0),
	/** The sme. */
	SME(3),
	/** The oem. */
	OEM(5),
	/** The super admin. */
	SUPER_ADMIN(99),

	/** The lra. */
	LRA(4),

	/** The all. */
	ALL(7);

	/**
	 * Instantiates a new roles.
	 *
	 * @param value
	 *            the value
	 */
	Roles(final int value) {
		this.value = value;
	}

	/** The value. */
	int value;

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public int getValue() {
		return value;
	}

	/**
	 * Gets the roles.
	 *
	 * @param roleId
	 *            the role id
	 * @return the roles
	 */
	public static String getRoles(final int roleId) {
		switch (roleId) {
		case 999:
			return GROUP_ADMIN.name();
		case 0:
			return USER.name();
		case 2:
			return ADMIN.name();
		case 3:
			return SME.name();
		case 4:
			return OEM.name();
		case 99:
			return SUPER_ADMIN.name();
		case 6:
			return LRA.name();
		}
		return "ALL";
	}

	/**
	 * Gets the roles.
	 *
	 * @param role
	 *            the role
	 * @return the roles
	 */
	public static int getRoles(final String role) {
		switch (role) {
		case "GROUP_ADMIN":
			return 999;
		case "USER":
			return 0;
		case "ADMIN":
			return 2;
		case "SME":
			return 3;
		case "LRA":
			return 4;
		case "OEM":
			return 5;
		case "SUPER_ADMIN":
			return 99;
		}
		return 7;
	}
}
