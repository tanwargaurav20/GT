package com.harman.dmat.enums;

/**
 * The Enum Status.
 */
/**
 * @author inpbisht20
 *
 */
public enum Status {
	

		
		/** The inactive. */
		INACTIVE(0),
		
		/** The active. */
		ACTIVE(1),
		
		/** The suspended. */
		SUSPENDED(2),
		
		/** The pending. */
		PENDING(3);
		/**
		 * Instantiates a new roles.
		 *
		 * @param value
		 *            the value
		 */
		Status(final int value) {
			this.value = value;
		}

		/** The value. */
		int value;

		/**
		 * Gets the value.
		 *
		 * @return the value
		 */
		public int getValue() {
			return value;
		}

}
