package com.harman.dmat.enums;

/**
 * @This enum will be use for user type (active inactive, deactive).
 *
 */
public enum UserStatusEnum {
	/** The active. */
	ACTIVE("active"),

	/** The inactive. */
	INACTIVE("inactive"),

	/** The deactive. */
	DEACTIVE("deactive");

	String value;

	UserStatusEnum(final String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}