package com.harman.dmat.legends.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class ColoredVeriableRange {
	private Long id;
	private Long legend_id;
	private Long kpiId;
	private String color;
	private Double min;
	private String variable;
	private Double max;
	private String unit;
}
