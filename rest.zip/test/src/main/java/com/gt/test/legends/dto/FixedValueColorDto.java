package com.harman.dmat.legends.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class FixedValueColorDto {
	private Long id;
	private Long legend_id;
	private String color;
	private String value;
	private String unit;
	private Long kpiId;
	
	public FixedValueColorDto(String color, String value, String unit) {
		super();
		this.color = color;
		this.value = value;
		this.unit = unit;
	}

	

}
