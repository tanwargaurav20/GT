package com.harman.dmat.legends.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@ToString
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class Kpi {
	private long kpiId;
	private int kpiParentId;
	private String kpiKey;
	private String label;
	private int level;
	private int group;
	private int subLevel;
	private int group1;
	private int group2;
	private int group3;
	private int group4;
	private int group5;
	private int subGroup;
	private int  active;
	private boolean isKpiEditable;
	private String type;
	private Double min;
	private Double max;
	private List<FixedValueColorDto> listFixedValueColorDto;
	private List<ColoredVeriableRange> listColoredVeriableRange;
	
}
