package com.harman.dmat.legends.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class KpiInfo {
	/*
	 * KpiInfo.java insnayak20
	 **/

	private Long kpiId;
	private String kpiName;
	private String type;
	private Double min;
	private Double max;
}
