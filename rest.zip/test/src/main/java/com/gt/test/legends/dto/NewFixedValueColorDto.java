package com.harman.dmat.legends.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class NewFixedValueColorDto {
	/*
	* NewFixedValueColorDto.java
	* insnayak20
	**/
private Long id;
private Long templateId;
private String value;
private String color;
private String unit;
private Long kpiId;
}
