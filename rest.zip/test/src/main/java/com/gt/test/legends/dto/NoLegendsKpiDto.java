package com.harman.dmat.legends.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class NoLegendsKpiDto {
private String groupName;
private long groupId;
private String kpiName;
private  boolean isKpiEditable;
private String kpiLegendsType;
private String key;
	
	
}
