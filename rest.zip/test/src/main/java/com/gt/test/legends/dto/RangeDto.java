package com.harman.dmat.legends.dto;

import java.util.Comparator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class RangeDto implements Comparator<RangeDto> {
	private String color;
	private Double min;
	private Double max;
	private String unit;
	
	
	@Override
	public int compare(RangeDto first, RangeDto second) {
		if (first.getColor().equalsIgnoreCase(second.getColor()) && Double.compare(first.getMin(), second.getMin())== 0
				&& Double.compare(first.getMax(), second.getMax())== 0)
			return 0;
		else
			return 1;
	}

}
