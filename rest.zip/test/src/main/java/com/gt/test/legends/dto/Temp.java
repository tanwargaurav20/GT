package com.harman.dmat.legends.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class Temp {
	/*
	 * Temp.java insnayak20
	 **/
	private Long Id;
	private Long KpiId;
	private String KpiDesc;
	private Long TemplateId;
	private String type;
	private JsonNode node;
}
