package com.harman.dmat.legends.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class Template {
	/*
	 * TempletDto.java insnayak20
	 **/
	private Long templateId;
	private String templateName;
	private Long userId;
	private boolean isActive;
	private List<NewFixedValueColorDto> fixedValueKpiLegendsList;
	private List<NewVariableRangeColorDto> VariableRangeKpiLegendsList;
	private List<KpiInfo> listOfKpis;
}
