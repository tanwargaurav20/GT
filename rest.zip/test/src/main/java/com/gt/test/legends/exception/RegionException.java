package com.harman.dmat.legends.exception;

public class RegionException extends RuntimeException {
	/*
	* RegionException.java
	* insnayak20
	**/
	private static final long serialVersionUID = 1393806794912607433L;

	public RegionException() {
	}

	public RegionException(String message) {
		super(message);
	}

	public RegionException(Throwable cause) {
		super(cause);
	}

	public RegionException(String message, Throwable cause) {
		super(message, cause);
	}

	public RegionException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
