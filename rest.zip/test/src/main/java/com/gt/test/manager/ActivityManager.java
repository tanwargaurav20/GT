/**
 * 
 */
package com.harman.dmat.manager;

import java.util.List;

import org.springframework.stereotype.Component;

import com.harman.dmat.common.dto.ActivitiesDetailsDto;
import com.harman.dmat.common.dto.ActivityCommentDto;
import com.harman.dmat.common.dto.ActivityDTO;
import com.harman.dmat.common.dto.ActivityShareDto;
import com.harman.dmat.common.exception.ActivityException;

/**
 * @author insgupta06
 *
 */
@Component
public interface ActivityManager {

	public void saveActivity(ActivityDTO activityDto) throws ActivityException;

	public List<ActivitiesDetailsDto> getCreatedActivities() throws ActivityException;

	public List<ActivitiesDetailsDto> getAssignedActivities() throws ActivityException;

	public void deleteActivity(Integer activityId) throws ActivityException;

	public void createActivityStatus(Integer shareActivityId, String status) throws ActivityException;

	public void shareActivity(ActivityShareDto activityShareDto) throws ActivityException;

	public void createComment(ActivityCommentDto activityCommentDto) throws ActivityException;

	public List<ActivityCommentDto> getComments(Integer activityId) throws ActivityException;

	public List<ActivitiesDetailsDto> getShareActivity()throws ActivityException;
}
