package com.harman.dmat.manager;

import com.harman.dmat.common.dto.CellSiteClusterRequestDto;
import com.harman.dmat.common.dto.CellSiteClusterResponseDto;

public interface CellSiteManager {
	CellSiteClusterResponseDto getCellSiteClusterData(CellSiteClusterRequestDto cellSiteClusterRequestDto);
}
