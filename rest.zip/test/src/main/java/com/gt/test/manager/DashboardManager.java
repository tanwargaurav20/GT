package com.harman.dmat.manager;

import java.util.List;

import com.harman.dmat.common.dto.*;

public interface DashboardManager {

	/**
	 * @return
	 */
	UserCountDto getUserCount();

	/**
	 * @param userType
	 * @param offset
	 * @param limit
	 * @return
	 */
	List<UserDto> getUserList(String userType, int offset, int limit);

	/**
	 * @param offset
	 * @param limit
	 * @return
	 */
	ApkDetailsDto getApkVersionDetails(int offset, int limit);

	FilePreProcessResponseDto getFilePreProcessList(String startDate, String endDate, Integer offset, Integer limit);

	FilePostProcessResponseDto getFilePostProcessList(String startDate, String endDate, Integer offset, Integer limit);

    FileProcessStatusResponseDto getFileProcessStatusReport(String startDate, String endDate, Integer offset, Integer limit);

    FileProcessDirComparisonResponseDto getPhysicalDirComparisonReport(String startDate, String endDate, Integer offset, Integer limit);

}
