package com.harman.dmat.manager;

import java.util.List;
import com.harman.dmat.common.exception.DataNotFoundException;

/**
 * @author GTanwar Drive Route Manager interacts with the service layer for
 *         Drive Route module.
 *
 */
public interface DriveRouteManager {

	public List<String> getLatLng(String fileName, String startDate, String endDate) throws DataNotFoundException;

}
