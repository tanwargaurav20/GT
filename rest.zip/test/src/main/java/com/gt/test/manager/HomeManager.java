package com.harman.dmat.manager;

import java.util.List;

import com.harman.dmat.common.dto.CompanyDto;
import com.harman.dmat.common.dto.EventDto;
import com.harman.dmat.common.dto.RegionDto;
import com.harman.dmat.common.dto.StateDto;
import com.harman.dmat.common.exception.SystemException;

public interface HomeManager {

	List<CompanyDto> getCompanies() throws SystemException;

	List<StateDto> getStates() throws SystemException;

	List<RegionDto> getRegions() throws SystemException;

	List<String> getStateName(String region) throws SystemException;

	List<EventDto> getEvents()throws SystemException;



}
