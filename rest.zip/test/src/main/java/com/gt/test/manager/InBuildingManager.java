package com.harman.dmat.manager;

import com.harman.dmat.common.dto.InBuildingImageDto;
import com.harman.dmat.common.dto.InBuildingImageListDto;
import com.harman.dmat.common.dto.InBuildingLogViewDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.common.exception.DataNotFoundException;

import java.util.List;
import java.util.Map;

public interface InBuildingManager {

    Map<String, Object> getInbuildingImage(int imageId);

    List<InBuildingLogViewDto> getLogsByDate(String startDate, String endDate, Integer userId, Integer userType);

    Map<String, String> getInfoPoints(double xCoordinate, double yCoordinate, String fileName, String startDate, String endDate) throws DataNotFoundException;

    ResponseDto registerInBuilding(Map<String, Object> inBuildingParameters);
    
    ResponseDto registerInBuildingWithoutImage(InBuildingImageDto inBuildingImageDto);

    ResponseDto updateInBuildingInfo(InBuildingImageDto inBuildingImageDto);

    InBuildingImageListDto getInBuildingList(Integer offset, Integer limit, Integer userId, Integer access);

    ResponseDto removeInBuilding(String id);

    ResponseDto updateInBuildingImage(Integer id, byte[] image, int width, int height);
}
