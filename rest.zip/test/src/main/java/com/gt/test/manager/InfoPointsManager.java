package com.harman.dmat.manager;

import java.util.List;
import java.util.Map;

import com.harman.dmat.common.dto.EventsInfoDto;
import com.harman.dmat.common.dto.LiveInfoPointsDto;
import com.harman.dmat.common.exception.DataNotFoundException;

/**
 * @author GTanwar Info Points Manager interacts with the service layer for Info
 *         Points module.
 *
 */
public interface InfoPointsManager {

	public List<String> getInfoPoints(String lat, String lon, String dm_user, String fileName, String scale,
			String kpiName, String startDate, String endDate, String mdn, String kpiType, String showEvent,
			String events, int[] bandFilter, String voiceratFilterArr, String earfcnFilterArr, String rsrpFilter,
			String sinrFilter, String rsrqFilter, String rssiFilter, String enbIdFilter) throws DataNotFoundException;

	public Map<String, Object> getEventInfoPoints(String lat, String lon, String dm_user, String scale, String fileName,
			String scaleLoc) throws DataNotFoundException;

	public LiveInfoPointsDto getLiveInfoPoints(String lat, String lon, String imei) throws DataNotFoundException;

	public List<EventsInfoDto> getEventsList(String startDate, String endDate, String userId, String domain,
			String tl_lat, String tl_lon, String br_lat, String br_lon, String[] eventNames, String[] fileNames);

}
