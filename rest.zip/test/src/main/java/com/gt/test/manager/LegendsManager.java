package com.harman.dmat.manager;

import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.harman.dmat.common.dto.DynamicKpiDto;
import com.harman.dmat.common.dto.ResetTeplate;
import com.harman.dmat.common.dto.UniqueKpiDto;
import com.harman.dmat.legends.dto.Kpi;
import com.harman.dmat.legends.dto.Template;

public interface LegendsManager {
	List<Kpi> getUserLegends(Long userId, int groupId);

	Kpi getLegendForKpi(Long userId, Long kpiId);

	Template saveUserFile(MultipartFile file, Long userId);

	Path createWorkShett(Long userId, Long templateid) throws Exception;

	Template createNewTemplate(Template template);

	Object getDefaultKpiLegends(Long teplateId, Long kpi);

	String deleteTemplate(Long userId, Long teplateId);

	Template getTemplate(Long userId, Long templateid);

	List<Template> getUserTemplates(Long userId);

	Template updateTeplate(Template teplate);

	Template applyTeplate(Template teplate);

	Template resetTeplate(ResetTeplate resetTeplate);

	Map<String, List<Integer>> getKpiValuesFromEs(UniqueKpiDto uniqueKpiDto);

	Map<String, String> getDynamicKpiLegendsOnMapExtent(DynamicKpiDto dynamicKpiDto);
}
