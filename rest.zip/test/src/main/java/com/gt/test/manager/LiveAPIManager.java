package com.harman.dmat.manager;

import java.util.List;
import java.util.Map;

import com.harman.dmat.common.dto.LiveAPIDto;
import com.harman.dmat.common.dto.LivePciDto;
import com.harman.dmat.common.dto.LiveTrendingDto;
import com.harman.dmat.common.exception.DataNotFoundException;

/**
 * @author GTanwar Live API Manager interacts with the service layer.
 *
 */
public interface LiveAPIManager {

	/**
	 * Retrieves the all IMEIs
	 * 
	 * @return LiveAPIDto
	 * @throws DataNotFoundException
	 */
	public LiveAPIDto getLiveImei() throws DataNotFoundException;

	/**
	 * Retrieves the live trend data
	 * 
	 * @return LiveAPIDto
	 * @throws DataNotFoundException
	 */
	public List<LiveTrendingDto> getLiveTrend(String imei, String timestamp) throws DataNotFoundException;
	public Map<String, List<Integer>> getKpiValuesFromPs(LivePciDto livePciDto);
}
