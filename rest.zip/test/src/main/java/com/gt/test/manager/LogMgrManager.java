package com.harman.dmat.manager;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;


import org.springframework.web.multipart.MultipartFile;
import com.harman.dmat.common.dto.CustomReportsDownloadPdfRequestDto;
import com.harman.dmat.common.dto.CustomReportsLogDto;
import com.harman.dmat.common.dto.CustomReportsHistogramDto;
import com.harman.dmat.common.dto.CustomReportsRequestDto;
import com.harman.dmat.common.dto.CustomReportsTemplateDto;
import com.harman.dmat.common.dto.LogMgrAnalysisDto;
import com.harman.dmat.common.dto.LogMgrPrefDto;
import com.harman.dmat.common.dto.LogMgrRespDto;
import com.harman.dmat.common.dto.PolygonLogsDto;

import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.InvalidRequestPayloadException;
import com.harman.dmat.common.exception.LogMgrException;

/**
 * @author GTanwar Log Manager interacts with the service layer for Log Manager
 *         module.
 *
 */
public interface LogMgrManager {

	/**
	 * Retrieves the all log records against the requested parameters
	 * 
	 * @param userId
	 * @param name
	 * @param calFilterType
	 * @param date
	 * @param mdn
	 * @param model
	 * @param fileName
	 * @param imei
	 * @param offset
	 * @param limit
	 * @return LogMgrRespDto
	 * @throws DataNotFoundException
	 */
	public LogMgrRespDto getLogReport(String userId, String startDate, String endDate, String mdn, String model,
			String fileName, String imei, Integer offset, Integer limit, String sortby, Integer currUser,
			String sortCol) throws DataNotFoundException;

	/**
	 * Saves the log manager user preferences
	 *
	 * @param logMgrUserPrefDto
	 * @return ResponseDto
	 * @throws LogMgrException
	 */
	public Boolean saveUserPref(LogMgrPrefDto mgrUserPrefDto) throws LogMgrException;

	/**
	 * Deletes the selected/passed log records as delimited String id's
	 *
	 * @param list
	 * @return ResponseDto
	 * @throws InvalidRequestPayloadException
	 * @throws LogMgrException
	 */
	public Boolean deleteLogs(List<String> list, String startDate, String endDate) throws InvalidRequestPayloadException, LogMgrException;

	/**
	 * Retrieves the saved user preferences for a particular user
	 *
	 * @param user
	 * @return ResponseDto
	 * @throws DataNotFoundException
	 */
	public List<LogMgrPrefDto> getUserPref(Integer userId) throws DataNotFoundException;

	/**
	 * Retrieves the log analysis data as percentage of status's.
	 *
	 * @return ResponseDto
	 * @throws DataNotFoundException
	 *             the data not found exception
	 */
	public Map<String, List<LogMgrAnalysisDto>> getLogAnalysisData(String userId, Integer currUser, String startDate,
			String endDate, String dateType) throws DataNotFoundException;

	/**
	 * Return search results
	 * 
	 * @param user
	 * @param startDate
	 * @param endDate
	 * @param param
	 * @param sortby
	 * @param offset
	 * @param limit
	 * @return
	 * @throws DataNotFoundException
	 */
	public LogMgrRespDto searchLogs(String user, String startDate, String endDate, String param, String sortby,
			Integer offset, Integer limit, Integer currUser, String sortCol) throws DataNotFoundException;

	/**
	 * Uploads log file to the FTP location
	 * 
	 * @param file
	 * @return
	 * @throws IOException
	 */
	public Integer fileUploadHandler(MultipartFile file) throws IOException;

	/**
	 * Reprocess file in FTP location
	 * 
	 * @param list
	 * @return
	 * @throws IOException
	 */
	public Integer reprocessLogFile(List<Integer> list) throws IOException;

	/**
	 * downloads file from FTP location
	 * 
	 * @param file
	 * @return
	 * @throws IOException
	 */
	public File fileDownloadHandler(String file) throws IOException;

	/**
	 * Gets the log six month logs.
	 *
	 * @param userId
	 *            the user id
	 * @param geoPoints
	 * @param offset
	 * @param limit
	 * @return the log six month logs
	 * @throws LogMgrException
	 *             the log mgr exception
	 */

	public PolygonLogsDto getLogSixMonthLogs(Integer userId, String geoPoints, String mdn, String imei,
			String stateCode, String regions, String modelId, String deviceId, Integer limit, Integer offset,
			String startDate, String endDate, String fileName) throws LogMgrException;

	/**
	 * Fetches log files for a duration & filter parameter
	 * 
	 * @param data
	 * @param from
	 * @param to
	 * @param param
	 * @return
	 */
	public CustomReportsLogDto searchLogFiles(Integer data, String from, String to, String param, Integer offset, Integer limit);

	/**
	 * Fetches histogram data
	 * 
	 * @param data
	 * @param from
	 * @param to
	 * @param kpis
	 * @return
	 */
	public Map<String, List<CustomReportsHistogramDto>> getHistogram(CustomReportsRequestDto customReportsRequestDto);

	/**
	 * Fetches model+imei's from ES
	 * 
	 * @return
	 */
	public List<String> getDevices(String startDate, String endDate) throws DataNotFoundException;

	/**
	 * @param reportsTemplateDto
	 * @return
	 */
	public Integer saveTemplate(CustomReportsTemplateDto reportsTemplateDto);

	/**
	 * Fetches All templates
	 * 
	 * @return
	 */
	public List<CustomReportsTemplateDto> getAllTemplates(String userId) throws DataNotFoundException;

	/**
	 * @param reportsTemplateDto
	 * @return
	 */
	public Integer deleteTemplate(CustomReportsTemplateDto reportsTemplateDto);

	/**
	 * @param reportsTemplateDto
	 * @return
	 */
	public Integer editTemplate(CustomReportsTemplateDto reportsTemplateDto);

	/**
	 * @param data
	 * @param from
	 * @param to
	 * @param files
	 * @param kpis
	 * @param userIds
	 * @return
	 */
	public Map<String, List<CustomReportsHistogramDto>> getTimeseries(CustomReportsRequestDto customReportsRequestDto);

	void customReportSavePDF(CustomReportsDownloadPdfRequestDto customReportsDownloadPdfRequestDto, String filePath);
}
