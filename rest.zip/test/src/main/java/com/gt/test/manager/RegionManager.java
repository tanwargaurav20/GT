package com.harman.dmat.manager;

import com.harman.dmat.common.dto.Result;
import com.harman.dmat.common.dto.USRegionDto;

public interface RegionManager {
	public Result getRegionData(USRegionDto usRegionDto);


}
