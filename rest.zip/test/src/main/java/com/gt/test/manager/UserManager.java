/*
 * 
 */
package com.harman.dmat.manager;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.harman.dmat.common.dto.*;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import com.harman.dmat.common.exception.DataAccessException;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.InvalidRequestPayloadException;
import com.harman.dmat.common.exception.SystemException;
import com.harman.dmat.common.exception.UserException;

// TODO: Auto-generated Javadoc
/**
 * The Interface UserManager.
 *
 * @author prakash.bisht@harman.com
 */
/**
 * @author inasandhu
 *
 */
@Component
public interface UserManager {

	/**
	 * Validate user.
	 *
	 * @param username
	 *            the username
	 * @param userPass
	 *            the user pass
	 * @param string
	 *            the string
	 * @return the validated dto
	 * @throws UserException
	 *             the user exception
	 */

	public ValidatedDto validateUser(String username, String userPass, String string) throws UserException;

	/**
	 * Forget password.
	 *
	 * @param userName
	 *            the user name
	 * @throws UserException
	 *             the user exception
	 */
	public void forgetPassword(String userName) throws UserException;

	/**
	 * Records feedback.
	 *
	 * @param feedBack
	 * @throws UserException
	 */
	public ResponseDto userFeedback(FeedBackDto feedBack) throws UserException;

	/**
	 * Change password.
	 *
	 * @param userId
	 *            the user id
	 * @param oldPassword
	 *            the old password
	 * @param newPassword
	 *            the new password
	 * @throws UserException
	 *             the user exception
	 */

	public void changePassword(Integer userId, String oldPassword, String newPassword) throws UserException;

	/**
	 * Get users data with status and without status.
	 *
	 * @param offset
	 *            the offset
	 * @param limit
	 *            the limit
	 * @param status
	 *            the status
	 * @param userType
	 *            the user type
	 * @param token
	 *            the token
	 * @return the details with status
	 */
	public List<UserDto> getDetailsWithStatus(Integer offset, Integer limit, Integer status, String userType,
			String token, String sortBy);

	/**
	 * Register user.
	 *
	 * @param userDto
	 *            the user dto
	 * @throws UserException
	 *             the user exception
	 */
	public void registerUser(UserDto userDto) throws UserException;

	/**
	 * delete the user on the basis of userIds.
	 *
	 * @param userIds
	 *            the user ids
	 * @return the boolean
	 * @throws InvalidRequestPayloadException
	 *             the invalid request payload exception
	 */
	public Boolean deleteUser(List<Integer> userIds) throws InvalidRequestPayloadException;

	/**
	 * Update user data.
	 *
	 * @param userInfo
	 *            the user info
	 * @return the int
	 * @throws InvalidRequestPayloadException
	 *             the invalid request payload exception
	 * @throws DataAccessException
	 *             the data access exception
	 */
	public int updateUserData(Map<String, String> userInfo) throws InvalidRequestPayloadException, DataAccessException;

	/**
	 * get the users data on the basis of search param.
	 *
	 * @param email
	 *            the email
	 * @return the searchuser
	 * @throws InvalidRequestPayloadException
	 *             the invalid request payload exception
	 * @throws DataAccessException
	 *             the data access exception
	 */
	public List<UserDto> getSearchuser(String email) throws InvalidRequestPayloadException, DataAccessException;

	/**
	 * Edit the user with new role and active status.
	 *
	 * @param editUserStatusDto
	 *            the edit user status dto
	 * @return the int
	 * @throws DataNotFoundException
	 *             the data not found exception
	 */
	public int editUserStatus(EditUserStatusDto editUserStatusDto) throws DataNotFoundException;

	/**
	 * Edit the role for the user.
	 *
	 * @param editRoleDto
	 *            the edit role dto
	 * @return the int
	 * @throws DataNotFoundException
	 *             the data not found exception
	 */
	public int editRoleforUser(EditRoleDto editRoleDto) throws DataNotFoundException;

	/**
	 * Activate users.
	 *
	 * @param userIds
	 *            the user ids
	 * @throws UserException
	 *             the user exception
	 */
	/**
	 * @param userIds
	 * @throws UserException
	 */
	public void activateUsers(List<Integer> userIds) throws UserException;

	/**
	 * get the user preference on the basis of userId.
	 *
	 * @param userId
	 *            the user id
	 * @return the user preference
	 * @throws UserException
	 *             the user exception
	 */
	public UserPreferenceDto getUserPreference(Integer userId) throws UserException;

	/**
	 * get the user preference on the basis of userId.
	 *
	 * @param String
	 *            the states
	 * @return the area dto
	 * @throws UserException
	 *             the user exception
	 */
	public AreaDto getUserPreferredArea(String states) throws UserException;

	/**
	 * edit the user preference and state record for user.
	 *
	 * @param userPreferenceDto
	 *            the user preference dto
	 * @return the boolean
	 * @throws UserException
	 *             the user exception
	 */
	public Boolean saveUserPreferences(UserPreferenceDto userPreferenceDto) throws UserException;

	/**
	 * edit the user preference and state record for user.
	 *
	 * @param userPreferenceDto
	 *            the user preference dto
	 * @return the boolean
	 * @throws UserException
	 *             the user exception
	 */
	public Boolean saveUserPreferenceExtent(UserPreferenceDto userPreferenceDto) throws UserException;

	/**
	 * get user detail on the basis of userId.
	 *
	 * @param userId
	 *            the user id
	 * @return the user detail
	 * @throws UserException
	 *             the user exception
	 */
	public UserDto getUserDetail(Integer userId) throws UserException;

	/**
	 * get all the roles.
	 *
	 * @return the roles
	 * @throws UserException
	 *             the user exception
	 */
	public List<RoleDto> getRoles() throws UserException;

	/**
	 * get all the preferences.
	 *
	 * @return the allpreferences
	 * @throws UserException
	 *             the user exception
	 */
	public List<PreferenceDto> getAllpreferences() throws UserException;

	/**
	 * Update the user data by admin.
	 *
	 * @param userInfo
	 *            the user info
	 * @return the int
	 * @throws InvalidRequestPayloadException
	 *             the invalid request payload exception
	 * @throws DataAccessException
	 *             the data access exception
	 * @throws UserException
	 */
	public int updateByAdminData(Map<String, String> userInfo)
			throws InvalidRequestPayloadException, DataAccessException, UserException;

	/**
	 * get all the companies.
	 *
	 * @return the companies
	 * @throws SystemException
	 *             the system exception
	 */
	List<CompanyDto> getCompanies() throws SystemException;

	/**
	 * get all the states.
	 *
	 * @return the states
	 * @throws SystemException
	 *             the system exception
	 */
	List<StateDto> getStates() throws SystemException;

	/**
	 * get all the regions.
	 *
	 * @return the regions
	 * @throws SystemException
	 *             the system exception
	 */
	List<RegionDto> getRegions() throws SystemException;

	/**
	 * get the state on the basis of region.
	 *
	 * @param region
	 *            the region
	 * @return the state name
	 * @throws SystemException
	 *             the system exception
	 */
	List<String> getStateName(String region) throws SystemException;

	/**
	 * get all the events.
	 *
	 * @return the events
	 * @throws SystemException
	 *             the system exception
	 */
	List<EventDto> getEvents() throws SystemException;

	/**
	 * Get the users count.
	 *
	 * @return the user count
	 * @throws UserException
	 *             the user exception
	 */
	public Integer getUserCount() throws UserException;

	/**
	 * Gets the accordion info.
	 *
	 * @param token
	 *            the token
	 * @return the accordion info
	 * @throws UserException
	 *             the user exception
	 */
	public AccordionInfo getAccordionInfo(String token) throws UserException;

	/**
	 * Change status.
	 *
	 * @param statusInfoDto
	 *            the status info dto
	 * @throws UserException
	 *             the user exception
	 */
	public void changeStatus(StatusInfoDto statusInfoDto) throws UserException;

	/**
	 * Delete users.
	 *
	 * @param statusInfoDto
	 *            the status info dto
	 * @throws UserException
	 *             the user exception
	 */
	public void deleteUsers(StatusInfoDto statusInfoDto) throws UserException;

	/**
	 * Send notification.
	 *
	 * @param file
	 *            the file
	 * @param subject
	 *            the subject
	 * @param body
	 *            the body
	 * @param statusInfoDto
	 *            the status info dto
	 * @throws UserException
	 *             the user exception
	 */
	public void sendNotification(MultipartFile file, String subject, String body, StatusInfoDto statusInfoDto)
			throws UserException;

	/**
	 * Gets the contact.
	 *
	 * @return the contact
	 * @throws UserException
	 *             the user exception
	 */
	public ContactDto getContact() throws UserException;

	/**
	 * Validate and upload file.
	 *
	 * @param file
	 *            the file
	 * @param version
	 *            the version
	 * @param type
	 *            the type
	 * @param name
	 *            the name
	 * @param description
	 *            the description
	 * @param size
	 *            the size
	 * @param location
	 *            the location
	 * @return the string
	 */
	public String validateAndUploadFile(MultipartFile file, String version, String type, Optional<String> name,
			Optional<String> description, Optional<String> size, Optional<String> location);

	/**
	 * File download handler.
	 *
	 * @param file
	 *            the file
	 * @return the byte array resource
	 */
	public ByteArrayResource fileDownloadHandler(String file);

	/**
	 * Gets the list.
	 *
	 * @param type
	 *            the type
	 * @return the list
	 */
	public List<FileUploadDto> getList(Optional<String> type);

	/**
	 * Gets the list.
	 *
	 *
	 * @return the list
	 */
	public List<SoftwareVersionDto> getSoftwareList();

	/**
	 * Save last activity.
	 *
	 * @param userDto
	 *            the user dto
	 * @throws UserException
	 *             the user exception
	 */
	public void saveLastActivity(LastActivitiyDto userDto) throws UserException;

	/**
	 * Save sim card request.
	 *
	 * @param simRequestDto
	 *            the sim request dto
	 * @throws UserException
	 *             the user exception
	 */
	public void saveSimCardRequest(SimRequestDto simRequestDto) throws UserException;

	/**
	 * Gets the device.
	 *
	 * @return the device
	 * @throws UserException
	 *             the user exception
	 */
	public List<DeviceDto> getDevice() throws UserException;

	/**
	 * Adds the device.
	 *
	 * @param deviceDto
	 *            the device dto
	 * @throws UserException
	 *             the user exception
	 */
	public void addDevice(DeviceDto deviceDto) throws UserException;

	/**
	 * Edits the device.
	 *
	 * @param deviceDto
	 *            the device dto
	 * @throws UserException
	 *             the user exception
	 */
	public void editDevice(DeviceDto deviceDto) throws UserException;

	/**
	 * Removes the device.
	 *
	 * @param deviceIds
	 *            the device ids
	 * @throws UserException
	 *             the user exception
	 */
	public void removeDevice(List<Integer> deviceIds) throws UserException;

	/**
	 * Import excel file.
	 *
	 * @param file
	 *            the file
	 * @throws UserException
	 *             the user exception
	 */
	public void importExcelFile(MultipartFile file) throws UserException;

	/**
	 * Gets the sim info.
	 *
	 * @param iccid
	 *            the iccid
	 * @return the sim info
	 * @throws UserException
	 *             the user exception
	 */
	public List<SimInfoDto> getSimInfo(String iccid) throws UserException;

	/**
	 * Adds the os.
	 *
	 * @param osDto
	 *            the os dto
	 * @throws UserException
	 *             the user exception
	 */
	public void addOs(OsDto osDto) throws UserException;

	/**
	 * Gets the os.
	 *
	 * @return the os
	 * @throws UserException
	 *             the user exception
	 */
	public List<OsDto> getOs() throws UserException;

	/**
	 * Creates the group.
	 *
	 * @param groupDto
	 *            the group dto
	 * @throws UserException
	 *             the user exception
	 */
	public void createGroup(GroupDto groupDto) throws UserException;

	/**
	 * Update group.
	 *
	 * @param groupDto
	 *            the group dto
	 * @throws UserException
	 *             the user exception
	 */
	public void updateGroup(GroupDto groupDto) throws UserException;

	/**
	 * Delete group.
	 *
	 * @param groupIds
	 *            the group id
	 * @throws UserException
	 *             the user exception
	 */
	public void deleteGroup(Integer[] groupIds) throws UserException;

	/**
	 * Gets the groups.
	 *
	 * @return the groups
	 * @throws UserException
	 *             the user exception
	 */
	public List<GroupDto> getGroups() throws UserException;

	/**
	 * Sets the group request status.
	 *
	 * @param groupRequestDto
	 *            the new group request status
	 * @throws UserException
	 */
	public void setGroupRequestStatus(GroupRequestDto groupRequestDto) throws UserException;

	/**
	 * Gets the user brief info.
	 *
	 * @param offset
	 *            the offset
	 * @param limit
	 *            the limit
	 * @return the user brief info
	 * @throws UserException
	 *             the user exception
	 */
	public List<UserDto> getUserBriefInfo(Integer offset, Integer limit) throws UserException;

	/**
	 * Gets the sim info.
	 *
	 * @param offset
	 *            the offset
	 * @param limit
	 *            the limit
	 * @return the sim info
	 * @throws UserException
	 *             the user exception
	 */
	public SimRequestData getSimInfo(Integer offset, Integer limit) throws UserException;

	/**
	 * Gets the user groups.
	 *
	 * @return the user groups
	 * @throws UserException
	 *             the user exception
	 */
	public List<GroupDto> getMyGroups() throws UserException;

	/**
	 * Gets the group requests.
	 *
	 * @return the group requests
	 * @throws UserException
	 *             the user exception
	 */
	public List<GroupRequestDto> getGroupRequests() throws UserException;

	public void deleteUserGuide(Integer fileId) throws UserException;

	/**
	 * @param refreshToken
	 * @return
	 * @throws UserException
	 */
	public ValidatedDto refreshToken(String refreshToken) throws UserException;

	public Boolean checkIFTheGroupNameAvailable(String groupName);

	public Boolean deleteSoftware(int softwareId);

	public Boolean setLatestSoftware(int softwareId, int osId, boolean latest);

	public ResponseDto registerSoftware(SoftwareVersionDto softwareVersionDto);

	/**
	 * get the events legends.
	 *
	 * @return the events
	 * @throws SystemException
	 *             the system exception
	 */
	EventDtos getEventsLegends(EventsBodyDto eventsBodyDto) throws SystemException;

	List<EventsCountDto> getEventsCounts(EventsBodyDto eventsBodyDto) throws SystemException;
}
