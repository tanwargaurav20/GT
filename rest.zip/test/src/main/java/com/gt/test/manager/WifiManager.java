package com.harman.dmat.manager;

import com.harman.dmat.common.dto.*;

public interface WifiManager {

	WifiDto getWifiInfo(String latitude, String longitude, String scale, String startDate, String endDate);
	WifiClusterResponseDto getWifiClusterData(WifiClusterRequestDto wifiClusterRequestDto);
	WifiClusterInfoResponseDto getWifiClusterInfoData(WifiClusterInfoRequestDto requestDto);
}