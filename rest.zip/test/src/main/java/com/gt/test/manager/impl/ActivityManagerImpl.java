/**
 * 
 */
package com.harman.dmat.manager.impl;

import java.util.List;
import javax.inject.Inject;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import com.harman.dmat.common.dto.ActivitiesDetailsDto;
import com.harman.dmat.common.dto.ActivityCommentDto;
import com.harman.dmat.common.dto.ActivityDTO;
import com.harman.dmat.common.dto.ActivityShareDto;
import com.harman.dmat.common.exception.ActivityException;
import com.harman.dmat.common.exception.InvalidRequestPayloadException;
import com.harman.dmat.manager.ActivityManager;
import com.harman.dmat.service.ActivityService;
import lombok.extern.slf4j.Slf4j;

/**
 * The Class ActivityManagerImpl.
 *
 * @author insgupta06
 */

/** The Constant log. */
@Slf4j
@Component
@Transactional(rollbackFor = ActivityException.class)
public class ActivityManagerImpl implements ActivityManager {

	/**
	 * Injected ActivityService implementation.
	 */
	@Inject
	ActivityService activityService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.ActivtiyManager#saveActivity(com.harman.dmat.
	 * common.dto. ActivityDTO)
	 */
	@Override
	public void saveActivity(ActivityDTO activityDto) throws ActivityException {
		if (activityDto.getFileNames() == null) {
			throw new InvalidRequestPayloadException("log Ids not present in the request");
		}
		activityService.saveActivity(activityDto);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.ActivityManager#getCreatedActivities()
	 */
	@Override
	public List<ActivitiesDetailsDto> getCreatedActivities() throws ActivityException {
		return activityService.getCreatedActivities();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.ActivityManager#getAssignedActivities()
	 */
	@Override
	public List<ActivitiesDetailsDto> getAssignedActivities() throws ActivityException {
		return activityService.getAssignedActivities();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.ActivityManager#deleteActivity(java.lang.Integer)
	 */
	@Override
	public void deleteActivity(Integer activityId) throws ActivityException {
		activityService.deleteActivity(activityId);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.ActivityManager#createActivityStatus(java.lang.
	 * Integer, java.lang.String)
	 */
	@Override
	public void createActivityStatus(Integer shareActivityId, String status) throws ActivityException {
		activityService.createActivityStatus(shareActivityId, status);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.ActivityManager#shareActivity(com.harman.dmat.
	 * common.dto.ActivityShareDto)
	 */
	@Override
	public void shareActivity(ActivityShareDto activityShareDto) throws ActivityException {
		activityService.shareActivity(activityShareDto);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.ActivityManager#createComment(com.harman.dmat.
	 * common.dto.ActivityCommentDto)
	 */
	@Override
	public void createComment(ActivityCommentDto activityCommentDto) throws ActivityException {
		activityService.createComment(activityCommentDto);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.ActivityManager#getComments(java.lang.Integer)
	 */
	@Override
	public List<ActivityCommentDto> getComments(Integer activityId) throws ActivityException {
		return activityService.getComments(activityId);
	}

	@Override
	public List<ActivitiesDetailsDto> getShareActivity() throws ActivityException {
		return activityService.getShareActivity();
	}

}
