package com.harman.dmat.manager.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Component;

import com.harman.dmat.common.dto.CellSiteClusterRequestDto;
import com.harman.dmat.common.dto.CellSiteClusterResponseDto;
import com.harman.dmat.manager.CellSiteManager;
import com.harman.dmat.service.CellSiteService;


@Component

public class CellSiteManagerImpl implements CellSiteManager{
	
	@Inject
	CellSiteService cellSiteService;

	@Override
	public CellSiteClusterResponseDto getCellSiteClusterData(CellSiteClusterRequestDto cellSiteClusterRequestDto) {
		return cellSiteService.getCellSiteDataClusters(cellSiteClusterRequestDto);
	}
}