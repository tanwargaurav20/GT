package com.harman.dmat.manager.impl;

import com.harman.dmat.common.dto.*;
import com.harman.dmat.manager.DashboardManager;
import com.harman.dmat.service.DashboardService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.List;

@Component
@Slf4j
public class DashboardManagerImpl implements DashboardManager {

    @Inject
    private DashboardService dashboardService;

    /**
     * @return
     */
    @Override
    public UserCountDto getUserCount() {

        UserCountDto userCountDto = dashboardService.getUserCount();
        return userCountDto;
    }

    @Override
    public FilePreProcessResponseDto getFilePreProcessList(String startDate, String endDate, Integer offset, Integer limit) {
        return dashboardService.getFilePreProcessList(startDate, endDate, offset, limit);
    }

    @Override
    public FilePostProcessResponseDto getFilePostProcessList(String startDate, String endDate, Integer offset, Integer limit) {
        return dashboardService.getFilePostProcessList(startDate, endDate, offset, limit);
    }

    @Override
    public FileProcessStatusResponseDto getFileProcessStatusReport(String startDate, String endDate, Integer offset, Integer limit) {
        return dashboardService.getFileProcessStatusReport(startDate, endDate, offset, limit);
    }

    @Override
    public FileProcessDirComparisonResponseDto getPhysicalDirComparisonReport(String startDate, String endDate, Integer offset, Integer limit) {
        return dashboardService.getPhysicalDirComparisonReport(startDate, endDate, offset, limit);
    }

    /**
     * @param userType
     * @param offset
     * @param limit
     * @return
     */
    @Override
    public List<UserDto> getUserList(String userType, int offset, int limit) {
        List<UserDto> userDtoList = dashboardService.getUserList(userType, offset, limit);
        return userDtoList;
    }

    /**
     * @param offset
     * @param limit
     * @return
     */
    @Override
    public ApkDetailsDto getApkVersionDetails(int offset, int limit) {
        ApkDetailsDto apkDetailsDto = dashboardService.getApkVersionDetails(offset, limit);
        return apkDetailsDto;
    }
}
