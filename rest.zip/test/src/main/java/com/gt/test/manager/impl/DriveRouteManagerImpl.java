package com.harman.dmat.manager.impl;

import java.util.List;
import javax.inject.Inject;
import org.springframework.stereotype.Component;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.manager.DriveRouteManager;
import com.harman.dmat.service.DriveRouteService;

/**
 * @author GTanwar Log Manager interacts with the service layer for Log Manager
 *         module.
 *
 */
@Component
public class DriveRouteManagerImpl implements DriveRouteManager {

	@Inject
	DriveRouteService driveRouteService;

	@Override
	public List<String> getLatLng(String fileName, String startDate, String endDate) throws DataNotFoundException {
		return driveRouteService.getLatLon(fileName, startDate, endDate);
	}

}
