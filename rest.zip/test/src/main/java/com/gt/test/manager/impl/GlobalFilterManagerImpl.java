package com.harman.dmat.manager.impl;

import java.util.List;

import javax.inject.Inject;

import com.harman.dmat.common.dto.*;
import org.springframework.stereotype.Component;

import com.harman.dmat.common.exception.DataAccessException;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.GlobalFilterException;
import com.harman.dmat.manager.GlobalFilterManager;
import com.harman.dmat.service.GlobalFilterService;

/**
 * The Class GlobalFilterManagerImpl.
 *
 * @author prakash.bisht@harman.com
 */
@Component
public class GlobalFilterManagerImpl implements GlobalFilterManager{
	
	/** The global filter service. */
	@Inject
	private GlobalFilterService globalFilterService;

	/* (non-Javadoc)
	 * @see com.harman.dmat.manager.GlobalFilterManager#getModelData(java.lang.Integer)
	 */
	@Override
	public List<ModelDto> getModelData(Integer userId) throws DataNotFoundException,DataAccessException {
		return globalFilterService.getModelData(userId);
	}

	/* (non-Javadoc)
	 * @see com.harman.dmat.manager.GlobalFilterManager#getImeiData(java.lang.Integer)
	 */
	@Override
	public List<ImeiDto> getImeiData(Integer value) throws DataNotFoundException,DataAccessException{
		return globalFilterService.getImeiData(value);
	}

	/* (non-Javadoc)
	 * @see com.harman.dmat.manager.GlobalFilterManager#getUserMdnData(java.lang.Integer)
	 */
	@Override
	public List<ImeiDto> getUserMdnData(Integer value) throws DataNotFoundException,DataAccessException  {
		return globalFilterService.getUserMdnData(value);
	}

	/* (non-Javadoc)
	 * @see com.harman.dmat.manager.GlobalFilterManager#getallModels(java.lang.Integer, java.lang.Integer)
	 */
	@Override
	public List<ModelDto> getallModels(Integer offset, Integer limit) throws DataAccessException {
		return globalFilterService.getAllModels(offset,limit);
	}

	/* (non-Javadoc)
	 * @see com.harman.dmat.manager.GlobalFilterManager#getAllImeiData(java.lang.Integer, java.lang.Integer)
	 */
	@Override
	public List<ImeiDto> getAllImeiData(Integer offset, Integer limit) throws DataAccessException {
		return globalFilterService.getAllImeiData(offset,limit);
	}

	/* (non-Javadoc)
	 * @see com.harman.dmat.manager.GlobalFilterManager#getAllMdnData(java.lang.Integer, java.lang.Integer)
	 */
	@Override
	public List<ImeiDto> getAllMdnData(Integer offset, Integer limit) throws DataAccessException {
		return globalFilterService.getAllMdnData(offset,limit);
	}

	

	/* (non-Javadoc)
	 * @see com.harman.dmat.manager.GlobalFilterManager#getUserLogData(java.lang.Integer, java.lang.Integer, java.lang.Integer)
	 */
	@Override
	public List<LogMgrDto> getUserLogData(Integer userId, Integer offset,
			Integer limit) throws DataNotFoundException,DataAccessException {
		return globalFilterService.getUserLogData(userId,offset,limit) ;
	}

	/* (non-Javadoc)
	 * @see com.harman.dmat.manager.GlobalFilterManager#getAllLogData(java.lang.Integer, java.lang.Integer)
	 */
	@Override
	public List<LogMgrDto> getAllLogData(Integer offset, Integer limit) throws DataAccessException{
		return globalFilterService.getAllLogData(offset,limit);
	}

	/* (non-Javadoc)
	 * @see com.harman.dmat.manager.GlobalFilterManager#getUserStateData(java.lang.Integer)
	 */
	@Override
	public List<StateDto> getUserStateData(Integer userId) throws DataNotFoundException, DataAccessException {
		return globalFilterService.getUserStateData(userId);
	}

	/* (non-Javadoc)
	 * @see com.harman.dmat.manager.GlobalFilterManager#getFilterData(java.lang.String, java.lang.String, java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.String, java.lang.Integer, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public List<GlobalFilterDto> getFilterData(String user, String startDate,
			String endDate, String mdn,
			Integer model, String fileName, String imei) throws GlobalFilterException {
		return globalFilterService.getFilterData(user, startDate, endDate, mdn, model, fileName, imei);
	}

	/* (non-Javadoc)
	 * @see com.harman.dmat.manager.GlobalFilterManager#getUserLogFiles(java.lang.Integer, java.lang.String, java.lang.String, java.lang.String, java.lang.Integer, java.lang.Integer)
	 */
	@Override
	public List<UserLogFileDto> getUserLogFiles(Integer userId,String startDate, String endDate,String token,  Integer userLimit,Integer fileLimit,Integer offset, String mdn,
			Integer model, String imei) throws GlobalFilterException {
		return globalFilterService.getUserLogFiles(userId,startDate, endDate,token, userLimit,fileLimit,offset,mdn, model,  imei);
	}

	/* (non-Javadoc)
	 * @see com.harman.dmat.manager.GlobalFilterManager#getMdns(java.lang.Integer, java.lang.String, java.lang.String, com.harman.dmat.common.dto.GlobalFilterRequestDto)
	 */
	@Override
	public List<String> getMdns(Integer userId, String startDate, String endDate,
			GlobalFilterRequestDto globalFilterDtos) throws GlobalFilterException {
		return globalFilterService.getMdns(userId,startDate, endDate,globalFilterDtos);
	}

	/* (non-Javadoc)
	 * @see com.harman.dmat.manager.GlobalFilterManager#getImeis(java.lang.Integer, java.lang.String, java.lang.String, com.harman.dmat.common.dto.GlobalFilterRequestDto)
	 */
	@Override
	public List<String> getImeis(Integer userId, String startDate, String endDate,
			GlobalFilterRequestDto globalFilterDtos) throws GlobalFilterException {
			return globalFilterService.getImeis(userId,startDate, endDate,globalFilterDtos);
	}

	/* (non-Javadoc)
	 * @see com.harman.dmat.manager.GlobalFilterManager#getModels(java.lang.Integer, java.lang.String, java.lang.String, com.harman.dmat.common.dto.GlobalFilterRequestDto)
	 */
	@Override
	public List<String> getModels(Integer userId, String startDate, String endDate,
			GlobalFilterRequestDto globalFilterDtos) throws GlobalFilterException {
		return globalFilterService.getModels(userId,startDate, endDate,globalFilterDtos);
	}

	@Override
	public GlobalFilterDataDto getFilterDataFromES(String userId, String startDate, String endDate, String domain, String tl_lat, String tl_lon, String br_lat, String br_lon, int offset, int userOffset) throws GlobalFilterException {
		return globalFilterService.getFilterDataFromES(userId, startDate, endDate, domain, tl_lat, tl_lon, br_lat, br_lon, offset, userOffset);
	}

}
