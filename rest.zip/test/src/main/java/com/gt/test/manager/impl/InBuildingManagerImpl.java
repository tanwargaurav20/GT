package com.harman.dmat.manager.impl;

import com.harman.dmat.common.dto.InBuildingImageDto;
import com.harman.dmat.common.dto.InBuildingImageListDto;
import com.harman.dmat.common.dto.InBuildingLogViewDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.manager.InBuildingManager;
import com.harman.dmat.service.InBuildingService;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.List;
import java.util.Map;

@Component
public class InBuildingManagerImpl implements InBuildingManager {

    @Inject
    InBuildingService inBuildingService;

    @Override
    public Map<String, Object> getInbuildingImage(int imageId) {
        return inBuildingService.getInbuildingImage(imageId);
    }

    @Override
    public List<InBuildingLogViewDto> getLogsByDate(String startDate, String endDate, Integer userId, Integer userType) {
        return inBuildingService.getLogsByDate(startDate, endDate, userId, userType);
    }

    @Override
    public Map<String, String> getInfoPoints(double xCoordinate, double yCoordinate, String fileName, String startDate, String endDate) throws DataNotFoundException {
        return inBuildingService.getInfoPoints(xCoordinate, yCoordinate, fileName, startDate, endDate);
    }

    @Override
    public ResponseDto registerInBuilding(Map<String, Object> inBuildingParameters) {
        return inBuildingService.responseDto(inBuildingParameters);
    }

    @Override
    public InBuildingImageListDto getInBuildingList(Integer offset, Integer limit, Integer userId, Integer access) {
        return inBuildingService.getInBuildingList(offset, limit, userId,access);
    }

    @Override
    public ResponseDto removeInBuilding(String id) {
        return inBuildingService.removeInBuilding(id);
    }

    @Override
    public ResponseDto updateInBuildingImage(Integer imageId, byte[] image, int width, int height) {
        return inBuildingService.updateInBuildingImage(imageId, image, width, height);
    }

	@Override
	public ResponseDto registerInBuildingWithoutImage(InBuildingImageDto inBuildingImageDto) {		
		return inBuildingService.registerInBuildingWithoutImage(inBuildingImageDto);
	}

    @Override
    public ResponseDto updateInBuildingInfo(InBuildingImageDto inBuildingImageDto) {
        return inBuildingService.updateInBuildingInfo(inBuildingImageDto);
    }
}
