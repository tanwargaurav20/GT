package com.harman.dmat.manager.impl;

import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import com.harman.dmat.common.dto.EventsInfoDto;
import org.springframework.stereotype.Component;
import com.harman.dmat.common.dto.LiveInfoPointsDto;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.manager.InfoPointsManager;
import com.harman.dmat.service.InfoPointsService;

/**
 * @author GTanwar Log Manager interacts with the service layer for Log Manager
 *         module.
 *
 */
@Component
public class InfoPointsManagerImpl implements InfoPointsManager {

	@Inject
	InfoPointsService infoPointsService;

	@Override
	public List<String> getInfoPoints(String lat, String lon, String dm_user, String fileName, String scale,
			String kpiName, String startDate, String endDate, String mdn, String kpiType, String showEvent,
			String events, int[] bandFilter, String voiceratFilterArr, String earfcnFilterArr, String rsrpFilter,
			String sinrFilter, String rsrqFilter, String rssiFilter, String enbIdFilter) throws DataNotFoundException {
		return infoPointsService.getInfoPoints(lat, lon, dm_user, fileName, scale, kpiName, startDate, endDate, mdn,
				kpiType, showEvent, events, bandFilter, voiceratFilterArr, earfcnFilterArr, rsrpFilter,
				sinrFilter, rsrqFilter, rssiFilter, enbIdFilter);
	}

	@Override
	public Map<String, Object> getEventInfoPoints(String lat, String lon, String dm_user, String scale, String fileName,
			String scaleLoc) throws DataNotFoundException {
		return infoPointsService.getEventInfoPoints(lat, lon, dm_user, scale, fileName, scaleLoc);
	}

	@Override
	public LiveInfoPointsDto getLiveInfoPoints(String lat, String lon, String imei) throws DataNotFoundException {
		return infoPointsService.getLiveInfoPoints(lat, lon, imei);
	}

	@Override
	public List<EventsInfoDto> getEventsList(String startDate, String endDate, String userId, String domain,
			String tl_lat, String tl_lon, String br_lat, String br_lon, String[] eventNames, String[] fileNames) {
		return infoPointsService.getEventsList(startDate, endDate, userId, domain, tl_lat, tl_lon, br_lat, br_lon,
				eventNames, fileNames);
	}

}
