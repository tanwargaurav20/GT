package com.harman.dmat.manager.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.inject.Inject;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.harman.dmat.common.dto.DynamicKpiDto;
import com.harman.dmat.common.dto.ResetTeplate;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.common.dto.UniqueKpiDto;
import com.harman.dmat.common.exception.InvalidRequestPayloadException;
import com.harman.dmat.legends.dto.Kpi;
import com.harman.dmat.legends.dto.NewFixedValueColorDto;
import com.harman.dmat.legends.dto.NewVariableRangeColorDto;
import com.harman.dmat.legends.dto.Template;
import com.harman.dmat.manager.LegendsManager;
import com.harman.dmat.service.LegendsService;
import com.harman.dmat.service.StorageService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author insnayak20
 *
 */
@Slf4j
@Component
public class LegendsManagerImpl implements LegendsManager {
	@Inject
	LegendsService legendsService;
	@Inject
	StorageService storageService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.legends.manager.LegendsManager#getAllKpiFilters()
	 */
	@Override
	public List<Kpi> getUserLegends(Long userId, int group) {
		return legendsService.getUserLegends(userId, group);
	}

	@Override
	public Kpi getLegendForKpi(Long userId, Long kpiId) {
		return legendsService.getLegendForKpi(userId, kpiId);
	}

	@Override
	public Template saveUserFile(MultipartFile file, Long userId) {
		storageService.store(file);
		Path path = storageService.load(file.getOriginalFilename());
		if (file.getName().equalsIgnoreCase("Verizon(default)")) {
			storageService.deleteFile(path);
			throw new InvalidRequestPayloadException(
					"can not update the default template please change the name of file and try again");
		}
		Template template = new Template();
		template.setUserId(userId);
		template.setTemplateName(FilenameUtils.removeExtension(file.getOriginalFilename()));
		template.setVariableRangeKpiLegendsList(legendsService.parseFileForUsersVariableLegendsKpis(path));
		template.setFixedValueKpiLegendsList(legendsService.parseFileForUserFixedLegendsKpis(path));
		storageService.deleteFile(path);
		return legendsService.createNewTemplate(template);
	}

	@Override
	public Path createWorkShett(Long userId, Long teplateId) throws Exception {
		try (XSSFWorkbook workbook = new XSSFWorkbook();) {
			XSSFSheet spreadsheet = workbook.createSheet("LegendsInfo");
			XSSFSheet spreadsheet2 = workbook.createSheet("fixed_value_legends");
			Template teplate = legendsService.getTemplate(userId, teplateId);

			List<String> heading2 = Arrays.asList("ID", "KPIID", "COLOR", "VALUE", "UNIT");
			Map<Integer, List<String>> legendsMap2 = new TreeMap<>();
			legendsMap2.put(0, heading2);
			for (int i = 0; i < teplate.getFixedValueKpiLegendsList().size(); i++) {
				NewFixedValueColorDto newFixedValueColorDto = teplate.getFixedValueKpiLegendsList().get(i);
				List<String> val = Arrays.asList(newFixedValueColorDto.getTemplateId() + "",
						newFixedValueColorDto.getKpiId() + "", "" + newFixedValueColorDto.getColor(),
						newFixedValueColorDto.getValue() + "", newFixedValueColorDto.getUnit());
				int k = i + 1;
				legendsMap2.put(k, val);
			}

			Map<Integer, List<String>> legendsMap1 = new TreeMap<>();
			legendsMap1.put(0, Arrays.asList("ID", "KPIID", "MIN", "MAX", "COLOR", "UNIT"));
			for (int i = 0; i < teplate.getVariableRangeKpiLegendsList().size(); i++) {
				NewVariableRangeColorDto NewVariableRangeColorDto = teplate.getVariableRangeKpiLegendsList().get(i);
				List<String> val = Arrays.asList(NewVariableRangeColorDto.getTemplateId() + "",
						NewVariableRangeColorDto.getKpiId() + "", NewVariableRangeColorDto.getMin() + "",
						NewVariableRangeColorDto.getMax() + "", NewVariableRangeColorDto.getColor(),
						NewVariableRangeColorDto.getUnit());
				int k = i + 1;
				legendsMap1.put(k, val);

			}
			XSSFRow row;
			Set<Integer> keyid = legendsMap1.keySet();
			int rowid = 0;
			for (Integer key : keyid) {
				row = spreadsheet.createRow(rowid++);
				List<String> val = legendsMap1.get(key);
				int cellid = 0;
				for (int i = 0; i < val.size(); i++) {
					Cell cell = row.createCell(cellid++);
					if (i == 5 && key != 0)
						cell.setCellValue(val.get(i));
					else if ((i == 0 || i == 1) && key != 0)
						cell.setCellValue(Long.parseLong(val.get(i)));
					else if ((i == 2 || i == 3) && key != 0)
						cell.setCellValue(Double.parseDouble(val.get(i)));
					else {
						cell.setCellValue(val.get(i));
					}
				}

			}

			XSSFRow row2;
			Set<Integer> keySet = legendsMap2.keySet();
			int rowId = 0;
			for (Integer key : keySet) {
				row2 = spreadsheet2.createRow(rowId++);
				List<String> val = legendsMap2.get(key);
				int cellid = 0;
				for (int i = 0; i < val.size(); i++) {
					Cell cell = row2.createCell(cellid++);
					if ((i == 0 || i == 1) && key != 0)
						cell.setCellValue(Long.parseLong(val.get(i)));
					else if ((i == 2 || i == 5 || i == 3) && key != 0) {
						cell.setCellType(CellType.NUMERIC);
						cell.setCellValue(val.get(i));
					} else {
						cell.setCellValue(val.get(i));
					}
				}
			}
			String fileName = String.format("%s.xlsx", teplate.getTemplateName());
			try (FileOutputStream out = new FileOutputStream(
					new File(storageService.getRootLocation() + File.separator + fileName))) {
				workbook.write(out);
			}
			return storageService.load(fileName);
		}
	}

	@Override
	public Template createNewTemplate(Template template) {
		if (template.getFixedValueKpiLegendsList().equals(Collections.emptyList())
				|| template.getVariableRangeKpiLegendsList().equals(Collections.emptyList()))
			throw new InvalidRequestPayloadException("invalid payload found for creating the legend templet");
		else
			return legendsService.createNewTemplate(template);
	}

	@Override
	public Object getDefaultKpiLegends(Long templateId, Long kpiId) {
		if (kpiId == null)
			throw new InvalidRequestPayloadException("not a valid kpi id");
		else
			return legendsService.getDefaultKpiLegends(templateId, kpiId);
	}

	@Override
	public String deleteTemplate(Long userId, Long teplateId) {
		return legendsService.deleteTemplate(userId, teplateId);
	}

	@Override
	public Template getTemplate(Long userId, Long templateid) {
		return legendsService.getTemplate(userId, templateid);
	}

	@Override
	public List<Template> getUserTemplates(Long userId) {
		return legendsService.getUserTemplates(userId);
	}

	@Override
	public Template updateTeplate(Template teplate) {
		if (teplate.getTemplateName().equalsIgnoreCase("Verizon(default)")) {
			throw new InvalidRequestPayloadException("can not update the default template ");
		}
		return legendsService.updateTeplate(teplate);
	}

	@Override
	public Template applyTeplate(Template teplate) {
		return legendsService.applyTeplate(teplate);
	}

	@Override
	public Template resetTeplate(ResetTeplate resetTeplate) {
		return legendsService.resetTeplate(resetTeplate);

	}

	@Override
	public Map<String, List<Integer>> getKpiValuesFromEs(UniqueKpiDto uniqueKpiDto) {
		if (uniqueKpiDto.getKpiName() != null && uniqueKpiDto.getMapExtent() != null
				&& uniqueKpiDto.getValueColorMap().size() == uniqueKpiDto.getDivisor()) {
			return legendsService.getKpiValuesFromEs(uniqueKpiDto);
		} else {
			throw new InvalidRequestPayloadException("Can not get the kpi values ");
		}
	}

	@Override
	public Map<String, String> getDynamicKpiLegendsOnMapExtent(DynamicKpiDto dynamicKpiDto) {
		if (dynamicKpiDto.getKpiName() != null && !dynamicKpiDto.getKpiName().isEmpty()
				&& dynamicKpiDto.getMapExtent() != null && dynamicKpiDto.getValueColorMap() != null)
			return legendsService.getDynamicKpiLegendsOnMapExtent(dynamicKpiDto);
		else {
			throw new InvalidRequestPayloadException("Can not get the kpi values ");
		}
	}

}
