package com.harman.dmat.manager.impl;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import org.springframework.stereotype.Component;
import com.harman.dmat.common.dto.LiveAPIDto;
import com.harman.dmat.common.dto.LivePciDto;
import com.harman.dmat.common.dto.LiveTrendingDto;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.InvalidRequestPayloadException;
import com.harman.dmat.manager.LiveAPIManager;
import com.harman.dmat.service.LiveAPIService;

/**
 * @author GTanwar LIVE API interacts with the service layer.
 *
 */
@Component
public class LiveAPIManagerImpl implements LiveAPIManager {

	@Inject
	LiveAPIService liveAPIService;

	@Override
	public LiveAPIDto getLiveImei() throws DataNotFoundException {
		return liveAPIService.getLiveImei();
	}

	@Override
	public List<LiveTrendingDto> getLiveTrend(String imei, String timestamp) throws DataNotFoundException {
		return liveAPIService.getLiveTrend(imei, timestamp);
	}

	@Override
	public Map<String, List<Integer>> getKpiValuesFromPs(LivePciDto livePciDto) {
		if (livePciDto.getValueColorMap() != null && livePciDto.getDivisor() != 0
				&& livePciDto.getValueColorMap().size() == livePciDto.getDivisor()) {
			return liveAPIService.getKpiValuesFromPs(livePciDto);
		} else {
			throw new InvalidRequestPayloadException("Can not get the kpi values ");
		}
	}
}
