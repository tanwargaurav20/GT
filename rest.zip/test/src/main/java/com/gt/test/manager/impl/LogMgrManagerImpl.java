package com.harman.dmat.manager.impl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.io.FilenameUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.CategoryDataset;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.harman.dmat.common.dto.CustomReportsDownloadPdfRequestDto;
import com.harman.dmat.common.dto.CustomReportsHistogramDto;
import com.harman.dmat.common.dto.CustomReportsLogDto;
import com.harman.dmat.common.dto.CustomReportsRequestDto;
import com.harman.dmat.common.dto.CustomReportsTemplateDto;
import com.harman.dmat.common.dto.LogMgrAnalysisDto;
import com.harman.dmat.common.dto.LogMgrPrefDto;
import com.harman.dmat.common.dto.LogMgrRespDto;
import com.harman.dmat.common.dto.PolygonLogsDto;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.InvalidRequestPayloadException;
import com.harman.dmat.common.exception.LogMgrException;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.manager.LogMgrManager;
import com.harman.dmat.service.LogMgrService;
import com.harman.dmat.service.StorageService;
import com.harman.dmat.utils.JFreeChartUtil;
import com.harman.dmat.utils.PDFWriterUtil;

/**
 * @author GTanwar Log Manager interacts with the service layer for Log Manager
 *         module.
 *
 */
@Component
public class LogMgrManagerImpl implements LogMgrManager {

	@Inject
	LogMgrService logMgrService;

	@Inject
	StorageService storageService;

	/*
	 * (non-Javadoc)
	 *
	 * @see com.harman.dmat.manager.LogMgrManager#getLogReport(java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.Integer, java.lang.Integer)
	 */
	@Override
	public LogMgrRespDto getLogReport(final String userId, final String startDate, final String endDate,
			final String mdn, final String model, final String fileName, final String imei, final Integer offset,
			final Integer limit, final String sortby, final Integer currUser, final String sortCol)
			throws DataNotFoundException {

		return logMgrService.getLogReport(userId, startDate, endDate, mdn, model, fileName, imei, offset, limit, sortby,
				currUser, sortCol);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.harman.dmat.manager.LogMgrManager#saveUserPref(com.harman.dmat.common
	 * .dto.LogMgrPrefDto)
	 */
	@Override
	public Boolean saveUserPref(final LogMgrPrefDto logMgrUserPrefDto) throws LogMgrException {
		return logMgrService.saveUserPref(logMgrUserPrefDto);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.harman.dmat.manager.LogMgrManager#deleteLogs(java.lang.String)
	 */
	@Override
	public Boolean deleteLogs(final List<String> deleteFiles, String startDate, String endDate) throws InvalidRequestPayloadException, LogMgrException {

		return logMgrService.deleteLogs(deleteFiles, startDate, endDate);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.harman.dmat.manager.LogMgrManager#getUserPref(java.lang.String)
	 */
	@Override
	public List<LogMgrPrefDto> getUserPref(final Integer userId) throws DataNotFoundException {
		return logMgrService.getUserPref(userId);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.harman.dmat.manager.LogMgrManager#getLogAnalysisData()
	 */
	@Override
	public Map<String, List<LogMgrAnalysisDto>> getLogAnalysisData(String userId, Integer currUser, String startDate,
			String endDate, String dateType) throws DataNotFoundException {
		return logMgrService.getLogAnalysisData(userId, currUser, startDate, endDate, dateType);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.LogMgrManager#searchLogs(java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.Integer, java.lang.Integer)
	 */
	@Override
	public LogMgrRespDto searchLogs(String user, String startDate, String endDate, String param, String sortby,
			Integer offset, Integer limit, final Integer currUser, final String sortCol) throws DataNotFoundException {
		return logMgrService.searchLogs(user, startDate, endDate, param, sortby, offset, limit, currUser, sortCol);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.LogMgrManager#fileUploadHandler(org.
	 * springframework.web.multipart.MultipartFile)
	 */
	@Override
	public Integer fileUploadHandler(MultipartFile file) throws IOException {

		if (FilenameUtils.getExtension(file.getOriginalFilename()).equalsIgnoreCase("dlf") && !file.isEmpty()) {
			return logMgrService.fileUploadHandler(file);
		} else {
			return 2;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.LogMgrManager#fileDownloadHandler(java.lang.
	 * String)
	 */
	@Override
	public File fileDownloadHandler(String file) throws IOException {

		return logMgrService.fileDownloadHandler(file);
	}

	@Override
	public PolygonLogsDto getLogSixMonthLogs(Integer userId, String geoPoints, String mdn, String imei,
			String stateCode, String regions, String modelId, String deviceId, Integer limit, Integer offset,
			String startDate, String endDate, String fileName) throws LogMgrException {
		return logMgrService.getLogSixMonthLogs(userId, geoPoints, mdn, imei, stateCode, regions, modelId, deviceId,
				userId, geoPoints, mdn, imei, stateCode, regions, modelId, deviceId, limit, offset, startDate, endDate,
				fileName);
	}

	@Override
	public  CustomReportsLogDto searchLogFiles(Integer data, String from, String to, String param, Integer offset, Integer limit) {
		return logMgrService.searchLogFiles(data, from, to, param,offset,limit);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.LogMgrManager#getHistogram(java.lang.Integer,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String)
	 */
	@Override
	public Map<String, List<CustomReportsHistogramDto>> getHistogram(CustomReportsRequestDto customReportsRequestDto) {
		if (customReportsRequestDto.getData() == 1 && customReportsRequestDto.getImei() == null) {
			throw new InvalidRequestPayloadException("IMEI/Device not present in the request");
		} else if (customReportsRequestDto.getData() == 2 && customReportsRequestDto.getUserIds() == null) {
			throw new InvalidRequestPayloadException("user Ids not present in the request");
		} else if (customReportsRequestDto.getData() == 3 && customReportsRequestDto.getStates() == null) {
			throw new InvalidRequestPayloadException("states not present in the request");
		} else if (customReportsRequestDto.getData() == 4 && customReportsRequestDto.getFileNames() == null) {
			throw new InvalidRequestPayloadException("files list not present in the request");
		} else if (customReportsRequestDto.getData() == 0
				&& (customReportsRequestDto.getFileNames() != null || customReportsRequestDto.getStates() != null
						|| customReportsRequestDto.getUserIds() != null || customReportsRequestDto.getImei() != null)) {
			throw new InvalidRequestPayloadException("Global should not have the params. ");
		}
		return logMgrService.getHistogram(customReportsRequestDto);
	}

	@Override
	public List<String> getDevices(String startDate, String endDate) throws DataNotFoundException {
		if (startDate == null || endDate == null) {
			return new ArrayList<String>();
		}
		return logMgrService.getDevices(startDate, endDate);
	}

	@Override
	public Integer saveTemplate(CustomReportsTemplateDto reportsTemplateDto) {
		return logMgrService.saveTemplate(reportsTemplateDto);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.LogMgrManager#getAllTemplates(java.lang.String)
	 */
	@Override
	public List<CustomReportsTemplateDto> getAllTemplates(String userId) throws DataNotFoundException {
		return logMgrService.getAllTemplates(userId);
	}

	@Override
	public Integer deleteTemplate(CustomReportsTemplateDto reportsTemplateDto) {
		return logMgrService.deleteTemplate(reportsTemplateDto);
	}

	@Override
	public Integer editTemplate(CustomReportsTemplateDto reportsTemplateDto) {
		return logMgrService.editTemplate(reportsTemplateDto);
	}

	@Override
	public Map<String, List<CustomReportsHistogramDto>> getTimeseries(CustomReportsRequestDto customReportsRequestDto) {
		if (customReportsRequestDto.getData() == 4 && customReportsRequestDto.getFileNames() == null) {
			throw new InvalidRequestPayloadException("IMEI/Device not present in the request");
		} else if (customReportsRequestDto.getData() != 4) {
			throw new InvalidRequestPayloadException("Incorrect filter");
		}

		return logMgrService.getTimeseries(customReportsRequestDto);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.harman.dmat.manager.LogMgrManager#reprocessLogFile(java.lang.String)
	 */
	@Override
	public Integer reprocessLogFile(List<Integer> testIds) throws IOException {
		if (!testIds.isEmpty()) {
			return logMgrService.reprocessLogFile(testIds);
		} else {
			return 2;
		}
	}

	@Override
	public void customReportSavePDF(CustomReportsDownloadPdfRequestDto customReportsDownloadPdfRequestDto,
			String filePath) {
		Map<String, JFreeChart> customReportCharts = new HashMap<>();
		Map<String, List<CustomReportsHistogramDto>> customReportsDtos;
		JFreeChartUtil chartUtil = new JFreeChartUtil();
		PDFWriterUtil pdfWriterUtil = new PDFWriterUtil(842, 570);
		int reportType = customReportsDownloadPdfRequestDto.getReportType();
		if (reportType >= 1 && reportType <= 3) {
			if (reportType == 1 || reportType == 3) {
				customReportsDtos = getTimeseries(customReportsDownloadPdfRequestDto.getTimeseriesRequestDto());
				customReportsDtos.forEach((kpiName, customReportsDtoList) -> {
					if (customReportsDtoList.size() > 0) {
						String chartName = String.join(" ", Constant.CUSTOM_REPORT_TIME_SERIES_HEADER, kpiName);
						CategoryDataset xyDataset = chartUtil.createTimeSeriesDataset(kpiName, customReportsDtoList);
						JFreeChart chart = chartUtil.createLineChart(chartName, xyDataset,
								Constant.CUSTOM_REPORT_TIME_SERIES_XLABEL, Constant.CUSTOM_REPORT_TIME_SERIES_YLABEL);
						customReportCharts.put(chartName, chart);
					}
				});
			}
			if (reportType == 2 || reportType == 3) {
				customReportsDtos = getHistogram(customReportsDownloadPdfRequestDto.getHistogramRequestDto());
				customReportsDtos.forEach((kpiName, customReportsDtoList) -> {
					if (customReportsDtoList.size() > 0) {
						String chartName = String.join(" ", Constant.CUSTOM_REPORT_HISTOGRAM_HEADER, kpiName);
						CategoryDataset xyDataset = chartUtil.createHistogramDataset(kpiName, customReportsDtoList);
						JFreeChart chart = chartUtil.createBarChart(chartName, xyDataset,
								Constant.CUSTOM_REPORT_HISTOGRAM_XLABEL, Constant.CUSTOM_REPORT_HISTOGRAM_YLABEL);
						customReportCharts.put(chartName, chart);
					}
				});
			}
		} else {
			throw new InvalidRequestPayloadException("Invalid report type");
		}
		pdfWriterUtil.writeChartToPDF(customReportsDownloadPdfRequestDto, customReportCharts, filePath);
	}

}
