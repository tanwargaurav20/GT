package com.harman.dmat.manager.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Component;

import com.harman.dmat.common.dto.Result;
import com.harman.dmat.common.dto.USRegionDto;
import com.harman.dmat.manager.RegionManager;
import com.harman.dmat.service.RegionService;
@Component
public class RegionManagerImpl implements RegionManager {
	
@Inject
RegionService regionService;
	
	@Override
	public Result getRegionData(USRegionDto usRegionDto) {
		return regionService.getRegionData(usRegionDto);
	}
	/*
	* RegionManagerImpl.java
	* insnayak20
	**/
	
	
}
