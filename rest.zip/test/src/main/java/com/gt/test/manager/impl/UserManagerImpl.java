package com.harman.dmat.manager.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import javax.inject.Inject;
import com.harman.dmat.common.dto.*;
import org.apache.commons.io.FilenameUtils;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import com.harman.dmat.common.exception.DataAccessException;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.FTPException;
import com.harman.dmat.common.exception.InvalidRequestPayloadException;
import com.harman.dmat.common.exception.InvalidRoleException;
import com.harman.dmat.common.exception.SystemException;
import com.harman.dmat.common.exception.TokenGenerationException;
import com.harman.dmat.common.exception.UserException;
import com.harman.dmat.common.security.TokenAuthentication;
import com.harman.dmat.common.security.User;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.enums.Roles;
import com.harman.dmat.manager.UserManager;
import com.harman.dmat.service.UserService;
import com.harman.dmat.utils.UserManagerStringUtil;
import com.harman.dmat.utils.Utill;
import lombok.extern.slf4j.Slf4j;

/**
 * The Class UserManagerImpl.
 *
 * @author prakash.bisht@harman.com
 */

/** The Constant log. */

@Slf4j
@Component
@Transactional(rollbackFor = UserException.class)
public class UserManagerImpl implements UserManager {

	/**
	 * Injected UserService implementation.
	 */
	@Inject
	UserService userService;

	/** The token authentication. */
	@Inject
	TokenAuthentication tokenAuthentication;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#validateUser(java.lang.String,
	 * java.lang.String, java.lang.String)
	 */
	@Override
	public ValidatedDto validateUser(final String username, final String userPass, final String accesCode)
			throws UserException {
		final UserDto userDto = userService.validateUser(username, userPass, accesCode);
		try {
			if (userDto != null) {
				final Map<String, String> tokenMap = tokenAuthentication
						.getToken(new User(userDto.getUserId(), userDto.getEmail(), userDto.getRoleId(),
								userDto.getStatus().intValue(), userDto.getIsGroupAdmin(), userDto.getUserDomain()));
				final ValidatedDto validatedDto = new ValidatedDto();
				validatedDto.setToken(tokenMap.get("accessToken"));
				validatedDto.setRefreshToken(tokenMap.get("refreshToken"));
				validatedDto.setUserId(userDto.getUserId());
				validatedDto.setType(Constant.AUTH_TYPE);
				validatedDto.setFirstName(userDto.getFirstName());
				validatedDto.setLastName(userDto.getLastName());
				validatedDto.setIsResetPassword(userDto.getIsResetPassword());
				return validatedDto;
			}
		} catch (final TokenGenerationException e) {
			throw new UserException(e.getMessage());
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#forgetPassword(java.lang.String)
	 */
	@Override
	public void forgetPassword(final String userName) throws UserException {
		userService.forgetPassword(userName);
	}

	@Override
	public ResponseDto userFeedback(FeedBackDto feedBack) throws UserException {
		return userService.userFeedback(feedBack);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#changePassword(java.lang.String,
	 * java.lang.String, java.lang.String)
	 */
	@Override
	public void changePassword(final Integer userId, final String oldPassword, final String newPassword)
			throws UserException {
		userService.changePassword(userId, oldPassword, newPassword);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.UserManager#registerUser(com.harman.dmat.common.
	 * dto.UserDto)
	 */
	@Override
	public void registerUser(final UserDto userDto) throws UserException {
		if (!UserManagerStringUtil.isNullOrEmpty(userDto.getPassword())) {
			final String pattern = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{8,20})";
			if (UserManagerStringUtil.isNullOrEmpty(userDto.getPassword()) || pattern.matches(userDto.getPassword())) {
				log.error("Please enter valid password.");
				throw new InvalidRequestPayloadException();
			} else {
				userService.addUser(userDto);
			}
		} else {
			final User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			if (UserManagerStringUtil.checkAdminActiveRole(user.getScope(), user.getIsActive())) {
				final String tempPassword = Utill.randomAlphaNumeric(8);
				userDto.setPassword(tempPassword);
				userService.adminUser(userDto);
			} else {
				log.error("Either role is not admin or admin is inactive");
				throw new InvalidRoleException();
			}
		}

	}

	/*
	 * @Override public UserResponseInfo deleteUser(final List<Integer> users)
	 * throws UserException {
	 * 
	 * }
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.UserManager#updateUserData(com.harman.dmat.common
	 * .dto.UserDto)
	 */
	@Override
	public int updateUserData(final Map<String, String> userInfo)
			throws InvalidRequestPayloadException, DataNotFoundException {

		final Map<String, String> map = new HashMap<String, String>();
		final Set<Entry<String, String>> userEntry = userInfo.entrySet();
		for (final Entry<String, String> entry : userEntry) {
			if (Constant.FIRST_NAME.equalsIgnoreCase(entry.getKey().toString())
					|| Constant.LAST_NAME.equalsIgnoreCase(entry.getKey().toString())
					|| Constant.USER_ID.equalsIgnoreCase(entry.getKey().toString())) {
				map.put(entry.getKey(), entry.getValue());
			} else {
				if (Constant.IS_GROUP_ADMIN.equalsIgnoreCase(entry.getKey().toString())) {
					final Integer roleId = ((User) SecurityContextHolder.getContext().getAuthentication()
							.getPrincipal()).getScope();
					if (roleId == Roles.ADMIN.getValue() || roleId == Roles.SUPER_ADMIN.getValue()) {
						map.put(entry.getKey(), entry.getValue());
					}
				}
			}

		}
		return userService.updateUserData(map);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#getSearchuser(java.lang.String)
	 */
	@Override
	public List<UserDto> getSearchuser(final String searchparam)
			throws InvalidRequestPayloadException, DataAccessException {
		return userService.searchUser(searchparam);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.UserManager#editUserStatus(com.harman.dmat.common
	 * .dto.EditUserStatusDto)
	 */
	@Override
	public int editUserStatus(final EditUserStatusDto editUserStatusDto) throws DataNotFoundException {
		return userService.editUserStatus(editUserStatusDto);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#editRoleforUser(com.harman.dmat.
	 * common.dto.EditRoleDto)
	 */
	@Override
	public int editRoleforUser(final EditRoleDto editRoleDto) throws DataNotFoundException {
		return userService.editRoleforUser(editRoleDto);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#activateUsers(java.util.List)
	 */
	@Override
	public void activateUsers(final List<Integer> userIds) throws UserException {
		final User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (UserManagerStringUtil.checkAdminActiveRole(user.getScope(), user.getIsActive())
				|| UserManagerStringUtil.checkSuperAdminActiveRole(user.getScope(), user.getIsActive())) {
			userService.activateUsers(userIds);
		} else {
			log.error("Either role is not admin or admin is inactive");
			throw new InvalidRoleException();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.UserManager#saveUserPreferences(com.harman.dmat.
	 * common.dto.UserPreferenceDto)
	 */
	@Override
	public Boolean saveUserPreferences(final UserPreferenceDto userPreferenceDto) throws UserException {
		return userService.saveUserPreferences(userPreferenceDto);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.harman.dmat.manager.UserManager#saveUserPreferences(com.harman.dmat.
	 * common.dto.UserPreferenceDto)
	 */
	@Override
	public Boolean saveUserPreferenceExtent(final UserPreferenceDto userPreferenceDto) throws UserException {
		return userService.saveUserPreferenceExtent(userPreferenceDto);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.UserManager#getUserPreference(java.lang.String)
	 */
	@Override
	public UserPreferenceDto getUserPreference(final Integer userId) throws UserException {
		return userService.getUserPreference(userId);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.harman.dmat.manager.UserManager#getUserPreference(java.lang.String)
	 */
	@Override
	public AreaDto getUserPreferredArea(final String states) throws UserException {
		return userService.getUserPreferredArea(states);
	}

	/*
	 * (non-Javadoc)
	 */
	@Override
	public UserDto getUserDetail(final Integer userId) throws UserException {
		return userService.getUserDetail(userId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#getUserDetail(java.lang.Integer,
	 * java.lang.Integer)
	 * 
	 * @Override public List<UserDto> getUserDetail(final Integer offset, final
	 * Integer limit) throws UserException { return
	 * userService.getListOfUser(offset, limit); }
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#getRoles()
	 */
	@Override
	public List<RoleDto> getRoles() throws UserException {
		return userService.getRoles();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#getAllpreferences()
	 */
	@Override
	public List<PreferenceDto> getAllpreferences() throws UserException {
		return userService.getListofpreferences();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#getDetailsWithStatus(java.lang.
	 * Integer, java.lang.Integer, java.lang.Integer)
	 */
	@Override
	public List<UserDto> getDetailsWithStatus(final Integer offset, final Integer limit, final Integer status,
			String userType, String token, String sortBy) {
		return userService.getUserDetailsStatus(offset, limit, status, userType, token, sortBy);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#deleteUser(java.util.List)
	 */
	@Override
	public Boolean deleteUser(final List<Integer> userIds) throws InvalidRequestPayloadException {
		return userService.deleteUserData(userIds);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#updateByAdminData(java.util.Map)
	 */
	@Override
	public int updateByAdminData(Map<String, String> userInfo)
			throws InvalidRequestPayloadException, DataAccessException, UserException {
		return userService.updateByAdminData(userInfo);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#getCompanies()
	 */
	@Override
	public List<CompanyDto> getCompanies() throws SystemException {
		return userService.getCompanies();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#getRegions()
	 */
	@Override
	public List<RegionDto> getRegions() throws SystemException {
		return userService.getRegions();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#getStates()
	 */
	@Override
	public List<StateDto> getStates() throws SystemException {
		return userService.getStates();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#getStateName(java.lang.String)
	 */
	@Override
	public List<String> getStateName(String region) throws SystemException {
		return userService.getStateName(region);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#getEvents()
	 */
	@Override
	public List<EventDto> getEvents() throws SystemException {
		return userService.getEvents();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#getUserCount()
	 */
	@Override
	public Integer getUserCount() throws UserException {
		return userService.getUserCount();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#getAccordionInfo()
	 */
	@Override
	public AccordionInfo getAccordionInfo(String token) throws UserException {
		return userService.getAccordionInfo(token);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.UserManager#changeStatus(com.harman.dmat.common.
	 * dto.StatusInfoDto)
	 */
	@Override
	public void changeStatus(StatusInfoDto statusInfoDto) throws UserException {
		userService.changeStatus(statusInfoDto);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.UserManager#deleteUsers(com.harman.dmat.common.
	 * dto.StatusInfoDto)
	 */
	@Override
	public void deleteUsers(StatusInfoDto statusInfoDto) throws UserException {
		userService.deleteUsers(statusInfoDto);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.UserManager#sendNotification(com.harman.dmat.
	 * common.dto.StatusInfoDto)
	 */
	@Override
	public void sendNotification(MultipartFile file, String subject, String body, StatusInfoDto statusInfoDto)
			throws UserException {
		userService.sendNotification(file, subject, body, statusInfoDto);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#getContact()
	 */
	@Override
	public ContactDto getContact() throws UserException {
		return userService.getContact();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#validateAndUploadFile(org.
	 * springframework.web.multipart.MultipartFile, java.lang.String,
	 * java.lang.String, java.util.Optional, java.util.Optional,
	 * java.util.Optional, java.util.Optional)
	 */
	@Override
	public String validateAndUploadFile(MultipartFile file, String version, String type, Optional<String> name,
			Optional<String> description, Optional<String> size, Optional<String> location) {
		final FileUploadDto fileUploadDto = getFileUploadDto(file, version, type, name, description, size, location);
		if (userService.UploadFile(file, fileUploadDto) > 0) {
			return String.format("file : [ %s] Uploaded succeesfully ", fileUploadDto.getFileName());
		} else {
			throw new FTPException("unable to upload the file on ftp location ");
		}
	}

	/**
	 * Gets the file upload dto.
	 *
	 * @param file
	 *            the file
	 * @param version
	 *            the version
	 * @param type
	 *            the type
	 * @param name
	 *            the name
	 * @param description
	 *            the description
	 * @param size
	 *            the size
	 * @param location
	 *            the location
	 * @return the file upload dto
	 */
	private FileUploadDto getFileUploadDto(MultipartFile file, String version, String type, Optional<String> name,
			Optional<String> description, Optional<String> size, Optional<String> location) {
		String finalDescription, finalSize, finalName;
		if (description.isPresent()) {
			finalDescription = description.get();
		} else {
			finalDescription = file.getOriginalFilename();
		}
		if (size.isPresent()) {
			finalSize = size.get();
		} else {
			finalSize = file.getSize() / 1024 + " KBs";
		}
		if (name.isPresent()) {
			finalName = name.get();
		} else {
			finalName = FilenameUtils.removeExtension(file.getOriginalFilename());
		}
		return new FileUploadDto(type, version, finalName, finalDescription, finalSize, location);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.UserManager#fileDownloadHandler(java.lang.String)
	 */
	@Override
	public ByteArrayResource fileDownloadHandler(String file) {
		final ByteArrayResource resource = userService.fileDownloadHandler(file);
		if (resource == null) {
			throw new DataNotFoundException();
		}
		return userService.fileDownloadHandler(file);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#getList(java.util.Optional)
	 */
	@Override
	public List<FileUploadDto> getList(Optional<String> type) {
		if (type.isPresent() && type != null) {
			return userService.getListOfDowloadMetadata(type.get());
		} else {
			throw new InvalidRequestPayloadException("type param can not be null ");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.UserManager#saveLastActivity(com.harman.dmat.
	 * common.dto.LastActivitiyDto)
	 */
	@Override
	public void saveLastActivity(LastActivitiyDto userDto) throws UserException {
		userService.saveLastActivity(userDto);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#saveSimCardRequest()
	 */
	@Override
	public void saveSimCardRequest(SimRequestDto simRequestDto) throws UserException {
		userService.saveSimCardRequest(simRequestDto);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#getDevice()
	 */
	@Override
	public List<DeviceDto> getDevice() throws UserException {
		return userService.getDevice();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.UserManager#addDevice(com.harman.dmat.common.dto.
	 * DeviceDto)
	 */
	@Override
	public void addDevice(DeviceDto deviceDto) throws UserException {
		userService.addDevice(deviceDto);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.UserManager#editDevice(com.harman.dmat.common.dto
	 * .DeviceDto)
	 */
	@Override
	public void editDevice(DeviceDto deviceDto) throws UserException {
		userService.editDevice(deviceDto);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#removeDevice(java.util.List)
	 */
	@Override
	public void removeDevice(List<Integer> deviceIds) throws UserException {
		userService.removeDevice(deviceIds);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.UserManager#importExcelFile(org.springframework.
	 * web.multipart.MultipartFile)
	 */
	@Override
	public void importExcelFile(MultipartFile file) throws UserException {
		userService.importExcelFile(file);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#getSimInfo(java.lang.String)
	 */
	@Override
	public List<SimInfoDto> getSimInfo(String iccid) throws UserException {
		return userService.getSimInfo(iccid);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.UserManager#addOs(com.harman.dmat.common.dto.
	 * OsDto)
	 */
	@Override
	public void addOs(OsDto osDto) throws UserException {
		userService.addOs(osDto);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#getOs()
	 */
	@Override
	public List<OsDto> getOs() throws UserException {
		return userService.getOs();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.UserManager#createGroup(com.harman.dmat.common.
	 * dto.GroupDto)
	 */
	@Override
	public void createGroup(GroupDto groupDto) throws UserException {
		userService.createGroup(groupDto);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.UserManager#updateGroup(com.harman.dmat.common.
	 * dto.GroupDto)
	 */
	@Override
	public void updateGroup(GroupDto groupDto) throws UserException {
		userService.updateGroup(groupDto);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#deleteGroup(java.lang.Integer)
	 */
	@Override
	public void deleteGroup(Integer[] groupIds) throws UserException {
		userService.deleteGroup(groupIds);

	}

	@Override
	public List<GroupDto> getGroups() throws UserException {
		return userService.getGroups();

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.manager.UserManager#setGroupRequestStatus(com.harman.dmat
	 * .common.dto.GroupRequestDto)
	 */
	@Override
	public void setGroupRequestStatus(GroupRequestDto groupRequestDto) throws UserException {
		userService.setGroupRequestStatus(groupRequestDto);
	}

	@Override
	public List<UserDto> getUserBriefInfo(Integer offset, Integer limit) throws UserException {
		return userService.getUserBriefInfo(offset, limit);
	}

	@Override
	public SimRequestData getSimInfo(Integer offset, Integer limit) throws UserException {
		return userService.getSimInfo(offset, limit);
	}

	@Override
	public List<GroupDto> getMyGroups() throws UserException {
		return userService.getMyGroups();
	}

	@Override
	public List<GroupRequestDto> getGroupRequests() throws UserException {
		return userService.getGroupRequests();
	}

	@Override
	public void deleteUserGuide(Integer fileId) throws UserException {
		userService.deleteUserGuide(fileId);

	}

	@Override
	public ValidatedDto refreshToken(final String refreshToken) throws UserException {
		try {
			if (refreshToken != null) {
				String token = tokenAuthentication.getAccessTokenFromRefreshToken(refreshToken);
				final ValidatedDto validatedDto = new ValidatedDto();
				validatedDto.setToken(token);
				validatedDto.setType(Constant.AUTH_TYPE);
				return validatedDto;
			}
		} catch (final TokenGenerationException e) {
			throw new UserException(e.getMessage());
		} catch (final Exception e) {
			throw new UserException(e.getMessage());
		}
		return null;
	}

	@Override
	public Boolean checkIFTheGroupNameAvailable(String groupName) {
		if (groupName != null && !groupName.isEmpty())
			return userService.checkIFTheGroupNameAvailable(groupName);
		else
			throw new InvalidRequestPayloadException(String.format("group name can't be null of empty %s", groupName));
	}

	@Override
	public List<SoftwareVersionDto> getSoftwareList() {
		return userService.getSoftwareList();
	}

	@Override
	public Boolean deleteSoftware(int softwareId) {
		return userService.deleteSoftware(softwareId);
	}

	@Override
	public Boolean setLatestSoftware(int softwareId, int osId, boolean latest) {
		return userService.setLatestSoftware(softwareId, osId, latest);
	}

	@Override
	public ResponseDto registerSoftware(SoftwareVersionDto softwareVersionDto) {
		return userService.registerSoftware(softwareVersionDto);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.manager.UserManager#getEventsLegends()
	 */
	@Override
	public EventDtos getEventsLegends(EventsBodyDto eventsBodyDto) throws SystemException {
		return userService.getEventsLegends(eventsBodyDto);
	}

	@Override
	public List<EventsCountDto> getEventsCounts(EventsBodyDto eventsBodyDto) throws SystemException {
		return userService.getEventsCount(eventsBodyDto);
	}

}
