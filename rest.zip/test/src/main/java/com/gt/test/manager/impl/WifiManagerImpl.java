package com.harman.dmat.manager.impl;

import com.harman.dmat.common.dto.*;
import com.harman.dmat.manager.WifiManager;
import com.harman.dmat.service.WifiService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.inject.Inject;

@Component
@Slf4j
public class WifiManagerImpl implements WifiManager {

	@Inject
    WifiService wifiService;

	@Override
	public WifiDto getWifiInfo(String latitude, String longitude, String scale, String startDate, String endDate) {
		log.debug("getWifiInfo in...");
		WifiDto wifiDto = wifiService.getWifiInfo(latitude, longitude, scale, startDate, endDate);
		log.debug("getWifiInfo out.");
		return wifiDto;
	}

	@Override
	public WifiClusterResponseDto getWifiClusterData(WifiClusterRequestDto wifiClusterRequestDto) {
		return wifiService.getWifiDataClusters(wifiClusterRequestDto);
	}

	@Override
	public WifiClusterInfoResponseDto getWifiClusterInfoData(WifiClusterInfoRequestDto requestDto) {
		return wifiService.getWifiDataClusterInfoData(requestDto);
	}
}