/**
 * 
 */
package com.harman.dmat.service;

import java.util.List;

import com.harman.dmat.common.dto.ActivitiesDetailsDto;
import com.harman.dmat.common.dto.ActivityCommentDto;
import com.harman.dmat.common.dto.ActivityDTO;
import com.harman.dmat.common.dto.ActivityShareDto;
import com.harman.dmat.common.exception.ActivityException;

/**
 * The Interface ActivityService.
 *
 * @author insgupta06
 */
public interface ActivityService {

	/**
	 * Saves the activity.
	 *
	 * @param activityDto
	 *            the activity dto
	 * @throws ActivityException
	 *             the activity exception
	 */
	public void saveActivity(ActivityDTO activityDto) throws ActivityException;

	/**
	 * Gets created activities list.
	 * 
	 * @return list of created activities.
	 * 
	 * @throws ActivityException
	 *             the activity exception
	 */
	public List<ActivitiesDetailsDto> getCreatedActivities() throws ActivityException;

	/**
	 * Gets assigned activities list.
	 * 
	 * @return list of assigned activities.
	 * 
	 * @throws ActivityException
	 *             the activity exception
	 */
	public List<ActivitiesDetailsDto> getAssignedActivities() throws ActivityException;

	/**
	 * Delete activity.
	 *
	 * @param activityId
	 *            the activity id
	 * @throws ActivityException
	 *             the activity exception
	 */
	public void deleteActivity(Integer activityId) throws ActivityException;

	/**
	 * Creates the activity status.
	 *
	 * @param shareActivityId
	 *            the share activity id
	 * @param status
	 *            the status
	 * @throws ActivityException
	 *             the activity exception
	 */
	public void createActivityStatus(Integer shareActivityId, String status) throws ActivityException;

	/**
	 * Share activity.
	 *
	 * @param activityShareDto
	 *            the activity share dto
	 * @throws ActivityException
	 *             the activity exception
	 */
	public void shareActivity(ActivityShareDto activityShareDto) throws ActivityException;

	/**
	 * Creates the comment.
	 *
	 * @param activityCommentDto
	 *            the activity comment dto
	 * @throws ActivityException
	 *             the activity exception
	 */
	public void createComment(ActivityCommentDto activityCommentDto) throws ActivityException;

	/**
	 * Gets the comments.
	 *
	 * @param activityId
	 *            the activity id
	 * @return the comments
	 * @throws ActivityException
	 *             the activity exception
	 */
	public List<ActivityCommentDto> getComments(Integer activityId) throws ActivityException;

	/**
	 * Gets the share activity.
	 *
	 * @return the share activity
	 * @throws ActivityException the activity exception
	 */
	public List<ActivitiesDetailsDto> getShareActivity()throws ActivityException;

}
