package com.harman.dmat.service;

import com.harman.dmat.common.dto.AnalyticsRequestDto;
import com.harman.dmat.common.dto.AnalyticsResponseDto;
import com.harman.dmat.common.dto.DeviceStatsRequestDto;
import com.harman.dmat.common.dto.DeviceStatsResponseDto;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface AnalyticsService {
    AnalyticsResponseDto getModels(AnalyticsRequestDto analyticsRequestDto);
    List<DeviceStatsResponseDto> getDeviceStats(DeviceStatsRequestDto deviceStatsRequestDto);
}
