package com.harman.dmat.service;

import com.harman.dmat.common.dto.BaselineCountyReqDto;
import com.harman.dmat.common.dto.BaselineCountyResDto;

public interface BaselineCountyService {
    BaselineCountyResDto getBaselineCounty(BaselineCountyReqDto baselineCountyReqDto, String userId);
}
