package com.harman.dmat.service;

import com.harman.dmat.common.dto.CellSiteClusterRequestDto;
import com.harman.dmat.common.dto.CellSiteClusterResponseDto;

public interface CellSiteService {
	CellSiteClusterResponseDto getCellSiteDataClusters(CellSiteClusterRequestDto cellSiteClusterRequestDto);
}
