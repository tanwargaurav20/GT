package com.harman.dmat.service;

import com.harman.dmat.common.dto.*;

import java.util.List;

/**
 * Module that has all the services required for Client API call.
 */
public interface ClientAPIService {
    ResponseDto createCrashReport(String crashExceptionString, UserFiltersDto userFiltersDto);
    ResponseDto updatePin(String strICCID, String strPIN, UserFiltersDto userFiltersDto);
    ResponseDto getPin(String strICCID, UserFiltersDto userFiltersDto);
    ResponseDto addDmatLiveDatapoints(String dmatLiveDataPoints, List<DataPointsLiveDto> points, UserFiltersDto userFiltersDto);
    ResponseDto getFilteredData(InBuildingFiltersDto inBuildingFiltersDto);
    byte[] getInbuildingImage(int id);
    ResponseDto getInbuildingLocations(UserFiltersDto userFiltersDto);
    ResponseDto getSoftwareVersion(SoftwareDto softwareDto);
    byte[] getApkData(String version);
    ResponseDto addDeviceTestSummary(TestResultsWrapper testResultsWrapper, UserFiltersDto userFiltersDto);
    ResponseDto addInbuildingImage(InbuildingUploadImageDto imageDto, UserFiltersDto userFiltersDto);
    ResponseDto addWifiData(WifiDataDto wifiDataDto, UserFiltersDto userFiltersDto, WifiDataLocDto wifiDataLocDto);
    ResponseDto sendEventsSummaryEmail(EventsSummaryRequestDto requestDto);
}
