package com.harman.dmat.service;

import java.util.Map;

/**
 * The Interface ConfigurationService.
 */
public interface ConfigurationService {

	/**
	 * Gets the all configuration.
	 *
	 * @return the all configuration
	 */
	public Map<String, String> getAllConfiguration();

}
