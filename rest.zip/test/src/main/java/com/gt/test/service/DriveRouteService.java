package com.harman.dmat.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.harman.dmat.common.exception.DataNotFoundException;

/**
 * @author GTanwar Info Points Service interacts with the Elastic Search DAO
 *         layer.
 */
@Service
public interface DriveRouteService {

	public List<String> getLatLon(String fileName, String startDate, String endDate) throws DataNotFoundException;

}
