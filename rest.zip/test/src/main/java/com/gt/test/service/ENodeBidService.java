package com.harman.dmat.service;

import com.harman.dmat.common.dto.ENodeBidRequestDto;

import java.util.List;

public interface ENodeBidService {
    List<String> getENodeBids(ENodeBidRequestDto requestDto);
}
