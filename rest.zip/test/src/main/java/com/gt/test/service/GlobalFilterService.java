package com.harman.dmat.service;

import java.util.List;

import com.harman.dmat.common.dto.*;
import com.harman.dmat.common.exception.DataAccessException;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.GlobalFilterException;

/**
 * The Interface GlobalFilterService.
 *
 * @author prakash.bisht@harman.com
 */
public interface GlobalFilterService {

	/**
	 * get model data for the user.
	 *
	 * @param userId the user id
	 * @return the model data
	 * @throws DataNotFoundException the data not found exception
	 * @throws DataAccessException the data access exception
	 */
	List<ModelDto> getModelData(Integer userId) throws DataNotFoundException,DataAccessException ;

	/**
	 * get the imei data for user.
	 *
	 * @param value the value
	 * @return the imei data
	 * @throws DataNotFoundException the data not found exception
	 * @throws DataAccessException the data access exception
	 */
	List<ImeiDto> getImeiData(Integer value) throws DataNotFoundException,DataAccessException ;

	/**
	 * get them mdn data for user.
	 *
	 * @param value the value
	 * @return the user mdn data
	 * @throws DataNotFoundException the data not found exception
	 * @throws DataAccessException the data access exception
	 */
	List<ImeiDto> getUserMdnData(Integer value) throws DataNotFoundException,DataAccessException ;

	/**
	 * get all the models.
	 *
	 * @param offset the offset
	 * @param limit the limit
	 * @return the all models
	 * @throws DataAccessException the data access exception
	 */
	List<ModelDto> getAllModels(Integer offset, Integer limit) throws DataAccessException ;

	/**
	 * get all the imeis data.
	 *
	 * @param offset the offset
	 * @param limit the limit
	 * @return the all imei data
	 * @throws DataAccessException the data access exception
	 */
	List<ImeiDto> getAllImeiData(Integer offset, Integer limit) throws DataAccessException;

	/**
	 * get all the mdn data.
	 *
	 * @param offset the offset
	 * @param limit the limit
	 * @return the all mdn data
	 * @throws DataAccessException the data access exception
	 */
	List<ImeiDto> getAllMdnData(Integer offset, Integer limit) throws DataAccessException;

	/**
	 * get all the state data.
	 *
	 * @param offset the offset
	 * @param limit the limit
	 * @return the all state data
	 * @throws DataAccessException the data access exception
	 */
	List<StateDto> getAllStateData(Integer offset, Integer limit) throws DataAccessException;

	/**
	 * get the log for the particular user.
	 *
	 * @param userId the user id
	 * @param offset the offset
	 * @param limit the limit
	 * @return the user log data
	 * @throws DataNotFoundException the data not found exception
	 * @throws DataAccessException the data access exception
	 */
	List<LogMgrDto> getUserLogData(Integer userId, Integer offset, Integer limit) throws DataNotFoundException,DataAccessException ;

	/**
	 * get all the log data.
	 *
	 * @param offset the offset
	 * @param limit the limit
	 * @return the all log data
	 * @throws DataAccessException the data access exception
	 */
	List<LogMgrDto> getAllLogData(Integer offset, Integer limit) throws DataAccessException;

	/**
	 * get the user state data.
	 *
	 * @param userId the user id
	 * @return the user state data
	 * @throws DataNotFoundException the data not found exception
	 * @throws DataAccessException the data access exception
	 */
	List<StateDto> getUserStateData(Integer userId) throws DataNotFoundException,DataAccessException;

	/**
	 * get the filter data on the basis of different param.
	 *
	 * @param user the user
	 * @param calFilterType the cal filter type
	 * @param date the date
	 * @param mdn the mdn
	 * @param model the model
	 * @param fileName the file name
	 * @param imei the imei
	 * @return the filter data
	 * @throws GlobalFilterException 
	 */
	List<GlobalFilterDto> getFilterData(String user, String calFilterType, String date, String mdn,
			Integer model, String fileName, String imei) throws GlobalFilterException;

	/**
	 * Gets the user log files.
	 *
	 * @param userId the user id
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param token the token
	 * @param userLimit the user limit
	 * @param fileLimit the file limit
	 * @param offset the offset
	 * @param mdn the mdn
	 * @param model the model
	 * @param imei the imei
	 * @return the user log files
	 * @throws GlobalFilterException 
	 */
	List<UserLogFileDto> getUserLogFiles(Integer userId,String startDate, String endDate, String token, Integer userLimit,Integer fileLimit,Integer offset, String mdn, Integer model, String imei) throws GlobalFilterException;

	/**
	 * Gets the mdns.
	 *
	 * @param userId the user id
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param globalFilterDtos the global filter dtos
	 * @return the mdns
	 * @throws GlobalFilterException 
	 */
	List<String> getMdns(Integer userId, String startDate, String endDate, GlobalFilterRequestDto globalFilterDtos) throws GlobalFilterException;

	/**
	 * Gets the imeis.
	 *
	 * @param userId the user id
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param globalFilterDtos the global filter dtos
	 * @return the imeis
	 * @throws GlobalFilterException 
	 */
	List<String> getImeis(Integer userId, String startDate, String endDate, GlobalFilterRequestDto globalFilterDtos) throws GlobalFilterException;

	/**
	 * Gets the models.
	 *
	 * @param userId the user id
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param globalFilterDtos the global filter dtos
	 * @return the models
	 * @throws GlobalFilterException 
	 */
	List<String> getModels(Integer userId, String startDate, String endDate, GlobalFilterRequestDto globalFilterDtos) throws GlobalFilterException;

	/**
	 * Gets the filter data from Elastic Search.
	 * @param userId
	 * @param startDate
	 * @param endDate
	 * @param domain
	 * @param tl_lat
	 * @param tl_lon
	 * @param br_lat
	 * @param br_lon
	 * @return
	 * @throws GlobalFilterException
	 */
	GlobalFilterDataDto getFilterDataFromES(String userId, String startDate, String endDate, String domain, String tl_lat, String tl_lon, String br_lat, String br_lon, int offset, int userOffset) throws GlobalFilterException ;
}
