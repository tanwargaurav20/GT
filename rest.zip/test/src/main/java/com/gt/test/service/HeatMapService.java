package com.harman.dmat.service;

import com.harman.dmat.common.dto.HeatMapRequestDto;
import com.harman.dmat.common.dto.HeatMapResponseDto;

/**
 * Service class to handle heatmap API calls.
 */
public interface HeatMapService {
    HeatMapResponseDto getHeatMapLocations(HeatMapRequestDto heatMapRequestDto);
}
