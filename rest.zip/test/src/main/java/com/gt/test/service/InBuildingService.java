package com.harman.dmat.service;

import com.harman.dmat.common.dto.InBuildingImageDto;
import com.harman.dmat.common.dto.InBuildingImageListDto;
import com.harman.dmat.common.dto.InBuildingLogViewDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.common.exception.DataNotFoundException;

import java.util.List;
import java.util.Map;

public interface InBuildingService {

    Map<String, Object> getInbuildingImage(int imageId);

    List<InBuildingLogViewDto> getLogsByDate(String startDate, String endDate, Integer userId, Integer userType);

    Map<String, String> getInfoPoints(double xCoordinate, double yCoordinate, String fileName, String startDate, String endDate) throws DataNotFoundException;

    ResponseDto responseDto(Map<String, Object> inBuildingParameter);

    InBuildingImageListDto getInBuildingList(Integer offset, Integer limit, Integer userId, Integer access);

    ResponseDto removeInBuilding(String id);

    ResponseDto updateInBuildingImage(Integer imageId, byte[] image, int width, int height);

	ResponseDto registerInBuildingWithoutImage(InBuildingImageDto inBuildingImageDto);

    ResponseDto updateInBuildingInfo(InBuildingImageDto inBuildingImageDto);

}
