package com.harman.dmat.service;

import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import com.harman.dmat.common.dto.DynamicKpiDto;
import com.harman.dmat.common.dto.ResetTeplate;
import com.harman.dmat.common.dto.UniqueKpiDto;
import com.harman.dmat.legends.dto.Kpi;
import com.harman.dmat.legends.dto.NewFixedValueColorDto;
import com.harman.dmat.legends.dto.NewVariableRangeColorDto;
import com.harman.dmat.legends.dto.Template;

public interface LegendsService {

	List<Kpi> getUserLegends(Long userId, int groupId);

	Kpi getLegendForKpi(Long userId, Long kpiId);

	List<NewVariableRangeColorDto> parseFileForUsersVariableLegendsKpis(Path path);

	List<NewFixedValueColorDto> parseFileForUserFixedLegendsKpis(Path path);

	Template createNewTemplate(Template template);

	Object getDefaultKpiLegends(Long templateId, Long kpiId);

	String deleteTemplate(Long userId, Long teplateId);

	Template getTemplate(Long userId, Long templateid);

	List<Template> getUserTemplates(Long userId);

	Template updateTeplate(Template teplate);

	Template applyTeplate(Template teplate);

	Template resetTeplate(ResetTeplate resetTeplate);

	Map<String, List<Integer>> getKpiValuesFromEs(UniqueKpiDto uniqueKpiDto);

	Map<String, String> getDynamicKpiLegendsOnMapExtent(DynamicKpiDto dynamicKpiDto);

}
