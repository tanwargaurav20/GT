package com.harman.dmat.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import com.harman.dmat.common.dto.LiveAPIDto;
import com.harman.dmat.common.dto.LivePciDto;
import com.harman.dmat.common.dto.LiveTrendingDto;
import com.harman.dmat.common.exception.DataNotFoundException;

/**
 * @author GTanwar Live API Service interacts with the DAO layer.
 */
@Service
public interface LiveAPIService {

	/**
	 * @return LiveAPIDto
	 * @throws DataNotFoundException
	 */
	public LiveAPIDto getLiveImei() throws DataNotFoundException;

	public List<LiveTrendingDto> getLiveTrend(String imei, String timestamp) throws DataNotFoundException;

	public Map<String, List<Integer>> getKpiValuesFromPs(LivePciDto livePciDto);
}
