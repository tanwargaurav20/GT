package com.harman.dmat.service;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;


import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.harman.dmat.common.dto.CustomReportsLogDto;
import com.harman.dmat.common.dto.CustomReportsHistogramDto;
import com.harman.dmat.common.dto.CustomReportsRequestDto;
import com.harman.dmat.common.dto.CustomReportsTemplateDto;
import com.harman.dmat.common.dto.LogMgrAnalysisDto;
import com.harman.dmat.common.dto.LogMgrPrefDto;
import com.harman.dmat.common.dto.LogMgrRespDto;
import com.harman.dmat.common.dto.PolygonLogsDto;

import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.InvalidRequestPayloadException;
import com.harman.dmat.common.exception.LogMgrException;

/**
 * @author GTanwar Log Service interacts with the DAO layer for Log Manager
 *         module.
 */
@Service
public interface LogMgrService {

	/**
	 * @param userId
	 * @param calFilterType
	 * @param date
	 * @param mdn
	 * @param model
	 * @param fileName
	 * @param imei
	 * @param offset
	 * @param limit
	 * @return LogMgrRespDto
	 * @throws DataNotFoundException
	 */
	public LogMgrRespDto getLogReport(String userId, String startDate, String emndDate, String mdn, String model,
			String fileName, String imei, Integer offset, Integer limit, String sortby, Integer currUser,
			String sortCol) throws DataNotFoundException;

	/**
	 * Saves the log manager user preferences
	 * 
	 * @param logMgrUserPrefDto
	 * @return ResponseDto
	 * @throws LogMgrException
	 */
	public Boolean saveUserPref(LogMgrPrefDto mgrUserPrefDto) throws LogMgrException;

	/**
	 * Deletes the selected/passed log records
	 * 
	 * @param deleteFiles
	 * @return ResponseDto
	 * @throws InvalidRequestPayloadException
	 * @throws LogMgrException
	 */
	public Boolean deleteLogs(List<String> deleteFiles, String startDate, String endDate) throws InvalidRequestPayloadException, LogMgrException;

	/**
	 * Retrieves the saved user preferences for a particular user
	 * 
	 * @param user
	 * @return ResponseDto
	 * @throws DataNotFoundException
	 */
	public List<LogMgrPrefDto> getUserPref(Integer userId);

	/**
	 * Retrieves the log analysis data as percentage of status's.
	 *
	 * @return ResponseDto
	 * @throws DataNotFoundException
	 *             the data not found exception
	 */
	public Map<String, List<LogMgrAnalysisDto>> getLogAnalysisData(String userId, Integer currUser, String startDate,
			String endDate, String dateType);

	/**
	 * Returns search results
	 * 
	 * @param user
	 * @param startDate
	 * @param endDate
	 * @param param
	 * @param sortby
	 * @param offset
	 * @param limit
	 * @return
	 */
	public LogMgrRespDto searchLogs(String user, String startDate, String endDate, String param, String sortby,
			Integer offset, Integer limit, Integer currUser, String sortCol);

	/**
	 * Uploads file to FTP location
	 * 
	 * @param file
	 * @return
	 * @throws IOException
	 */
	public Integer fileUploadHandler(MultipartFile file) throws IOException;

	/**
	 * Reprocesses file in FTP location
	 * 
	 * @param testIds
	 * @return
	 * @throws IOException
	 */
	public Integer reprocessLogFile(List<Integer> testIds) throws IOException;

	/**
	 * Downloads file from FTP location
	 * 
	 * @param file
	 * @return
	 * @throws IOException
	 */
	public File fileDownloadHandler(String file) throws IOException;

	/**
	 * Gets the log six month logs.
	 *
	 * @param userId
	 *            the user id
	 * @param geoPoints
	 *            the geo points
	 * @param mdn
	 *            the mdn
	 * @param imei
	 *            the imei
	 * @param stateCode
	 *            the state code
	 * @param regions
	 *            the regions
	 * @param modelId
	 *            the model id
	 * @param deviceId
	 *            the device id
	 * @param userId2
	 *            the user id 2
	 * @param geoPoints2
	 *            the geo points 2
	 * @param mdn2
	 *            the mdn 2
	 * @param imei2
	 *            the imei 2
	 * @param stateCode2
	 *            the state code 2
	 * @param regions2
	 *            the regions 2
	 * @param modelId2
	 *            the model id 2
	 * @param deviceId2
	 *            the device id 2
	 * @param limit
	 *            the limit
	 * @param offset
	 *            the offset
	 * @return the log six month logs
	 */
	public PolygonLogsDto getLogSixMonthLogs(Integer userId, String geoPoints, String mdn, String imei,
			String stateCode, String regions, String modelId, String deviceId, Integer userId2, String geoPoints2,
			String mdn2, String imei2, String stateCode2, String regions2, String modelId2, String deviceId2,
			Integer limit, Integer offset, String startDate, String endDate, String fileName);

	/**
	 * Fetches log files for a duration & filter parameter
	 * 
	 * @param data
	 * @param from
	 * @param to
	 * @param param
	 * @return
	 */
	public CustomReportsLogDto searchLogFiles(Integer data, String from, String to, String param, Integer offset, Integer limit);

	/**
	 * @param data
	 * @param from`
	 * @param to
	 * @param files
	 * @param kpis
	 * @param states
	 * @param imei
	 * @return
	 */
	public Map<String, List<CustomReportsHistogramDto>> getHistogram(CustomReportsRequestDto customReportsRequestDto);

	/**
	 * Fetches model+imei's from ES
	 * 
	 * @return
	 */
	public List<String> getDevices(String startDate, String endDate) throws DataNotFoundException;

	/**
	 * @param reportsTemplateDto
	 * @return
	 */
	public Integer saveTemplate(CustomReportsTemplateDto reportsTemplateDto);

	/**
	 * @param userId
	 * @return
	 * @throws DataNotFoundException
	 */
	public List<CustomReportsTemplateDto> getAllTemplates(String userId) throws DataNotFoundException;

	/**
	 * @param reportsTemplateDto
	 * @return
	 */
	public Integer deleteTemplate(CustomReportsTemplateDto reportsTemplateDto);

	/**
	 * @param reportsTemplateDto
	 * @return
	 */
	public Integer editTemplate(CustomReportsTemplateDto reportsTemplateDto);

	/**
	 * @param data
	 * @param from
	 * @param to
	 * @param files
	 * @param kpis
	 * @param userIds
	 * @return
	 */
	public Map<String, List<CustomReportsHistogramDto>> getTimeseries(CustomReportsRequestDto customReportsRequestDto);

}
