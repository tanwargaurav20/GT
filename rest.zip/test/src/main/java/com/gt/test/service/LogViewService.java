package com.harman.dmat.service;

import com.harman.dmat.common.dto.EventStatusDto;
import com.harman.dmat.common.dto.LogViewDto;
import com.harman.dmat.common.dto.ResponseDto;

import java.util.List;
import java.util.Map;

public interface LogViewService {
    ResponseDto getFileId(LogViewDto logViewDto);
    ResponseDto updateEvtStatus(List<LogViewDto> statusList);
    List<LogViewDto> getEventsList();
    EventStatusDto getStatusReportCount(String startDate, String endDate);
    ResponseDto getAutoTestReport(String filename);
}
