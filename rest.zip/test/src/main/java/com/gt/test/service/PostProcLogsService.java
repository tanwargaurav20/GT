package com.harman.dmat.service;

import com.harman.dmat.common.dto.PostProcLogsDto;
import com.harman.dmat.common.dto.ResponseDto;

import java.util.List;

public interface PostProcLogsService {
    ResponseDto addPostProcLogs(List<PostProcLogsDto> postProcLogs);
}
