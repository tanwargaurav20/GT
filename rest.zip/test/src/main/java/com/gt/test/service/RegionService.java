package com.harman.dmat.service;

import com.harman.dmat.common.dto.Result;
import com.harman.dmat.common.dto.USRegionDto;

public interface RegionService {
	public Result getRegionData(USRegionDto usRegionDto);
}
