package com.harman.dmat.service;

import java.util.List;
import java.util.Map;

import com.harman.dmat.common.dto.*;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.web.multipart.MultipartFile;
import com.harman.dmat.common.exception.DataAccessException;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.InvalidRequestPayloadException;
import com.harman.dmat.common.exception.SystemException;
import com.harman.dmat.common.exception.UserException;

/**
 * The Interface UserService.
 *
 * @author prakash.bisht@harman.com
 */

public interface UserService {

	/**
	 * Validate user.
	 *
	 * @param username
	 *            the username
	 * @param userPass
	 *            the user pass
	 * @param accesCode
	 *            the acces code
	 * @return the user dto
	 * @throws UserException
	 *             the user exception
	 */
	public UserDto validateUser(String username, String userPass, String accesCode) throws UserException;

	/**
	 * Change password.
	 *
	 * @param userId
	 *            the user id
	 * @param oldPassword
	 *            the old password
	 * @param newPassword
	 *            the new password
	 * @throws UserException
	 *             the user exception
	 */
	public void changePassword(Integer userId, String oldPassword, String newPassword) throws UserException;

	/**
	 * Forget password.
	 *
	 * @param userName
	 *            the user name
	 * @throws UserException
	 *             the user exception
	 */
	public void forgetPassword(String userName) throws UserException;

	/**
	 * Records feedback from the user.
	 *
	 * @param feedBack
	 * @throws Exception
	 */
	public ResponseDto userFeedback(FeedBackDto feedBack) throws UserException;

	/**
	 * Delete the users on the basis of Ids.
	 *
	 * @param userIds
	 *            the user ids
	 * @return the boolean
	 * @throws InvalidRequestPayloadException
	 *             the invalid request payload exception
	 */
	public Boolean deleteUserData(List<Integer> userIds) throws InvalidRequestPayloadException;

	/**
	 * get the active and inactive users on the basis of status.
	 *
	 * @param offset
	 *            the offset
	 * @param limit
	 *            the limit
	 * @param status
	 *            the status
	 * @param userType
	 *            the user type
	 * @param token
	 *            the token
	 * @return the user details status
	 */
	public List<UserDto> getUserDetailsStatus(Integer offset, Integer limit, Integer status, String userType,
			String token, String sortBy);

	/**
	 * Adds the user.
	 *
	 * @param userDto
	 *            the user dto
	 * @throws UserException
	 *             the user exception
	 */
	public void addUser(UserDto userDto) throws UserException;

	/**
	 * update user data for my account.
	 *
	 * @param userInfo
	 *            the user info
	 * @return the int
	 * @throws InvalidRequestPayloadException
	 *             the invalid request payload exception
	 * @throws DataAccessException
	 *             the data access exception
	 */
	public int updateUserData(Map<String, String> userInfo) throws InvalidRequestPayloadException, DataAccessException;

	/**
	 * get the users data on the basis of search param.
	 *
	 * @param searchparam
	 *            the searchparam
	 * @return the list
	 * @throws InvalidRequestPayloadException
	 *             the invalid request payload exception
	 * @throws DataAccessException
	 *             the data access exception
	 */
	public List<UserDto> searchUser(String searchparam) throws InvalidRequestPayloadException, DataAccessException;

	/**
	 * Get user preference on the basis of userId.
	 *
	 * @param userId
	 *            the user id
	 * @return the user preference
	 * @throws UserException
	 *             the user exception
	 * @throws DataNotFoundException
	 *             the data not found exception
	 */
	public UserPreferenceDto getUserPreference(Integer userId) throws UserException;

	/**
	 * get the user preference on the basis of userId.
	 *
	 * @param String
	 *            the states
	 * @return the area dto
	 * @throws UserException
	 *             the user exception
	 */
	public AreaDto getUserPreferredArea(String states) throws UserException;

	/**
	 * Send email notification to inactive users.
	 */
	public void sendEmailNotificationToInactiveUsers();

	/**
	 * Edit the role for user.
	 *
	 * @param editRoleDto
	 *            the edit role dto
	 * @return the int
	 * @throws DataNotFoundException
	 *             the data not found exception
	 */
	public int editRoleforUser(EditRoleDto editRoleDto) throws DataNotFoundException;

	/**
	 * Activate users.
	 *
	 * @param userIds
	 *            the user ids
	 * @throws UserException
	 *             the user exception
	 */
	public void activateUsers(List<Integer> userIds) throws UserException;

	/**
	 * edit the user preference and state record for user.
	 *
	 * @param userPreferenceDto
	 *            the user preference dto
	 * @return the boolean
	 * @throws UserException
	 *             the user exception
	 */
	public Boolean saveUserPreferences(UserPreferenceDto userPreferenceDto) throws UserException;

	/**
	 * edit the user preference and state record for user.
	 *
	 * @param userPreferenceDto
	 *            the user preference dto
	 * @return the boolean
	 * @throws UserException
	 *             the user exception
	 */
	public Boolean saveUserPreferenceExtent(UserPreferenceDto userPreferenceDto) throws UserException;

	/**
	 * Fetch user detail on the basis of email.
	 *
	 * @param userId
	 *            the user id
	 * @return the user detail
	 * @throws UserException
	 *             the user exception
	 * @throws DataNotFoundException
	 *             the data not found exception
	 */
	public UserDto getUserDetail(Integer userId) throws UserException;

	/**
	 * Edit the user status Active or inactive.
	 *
	 * @param editUserStatusDto
	 *            the edit user status dto
	 * @return the int
	 * @throws DataNotFoundException
	 *             the data not found exception
	 */
	public int editUserStatus(EditUserStatusDto editUserStatusDto) throws DataNotFoundException;

	/**
	 * Get all role.
	 *
	 * @return the roles
	 * @throws UserException
	 *             the user exception
	 */
	public List<RoleDto> getRoles() throws UserException;

	/**
	 * get list of the preferences.
	 *
	 * @return the listofpreferences
	 * @throws UserException
	 *             the user exception
	 */
	public List<PreferenceDto> getListofpreferences() throws UserException;

	/**
	 * Update by admin data.
	 *
	 * @param userInfo
	 *            the user info
	 * @return the int
	 * @throws UserException
	 */
	public int updateByAdminData(Map<String, String> userInfo) throws UserException;

	/**
	 * Admin user.
	 *
	 * @param userDto
	 *            the user dto
	 * @throws UserException
	 *             the user exception
	 */
	public void adminUser(UserDto userDto) throws UserException;

	/**
	 * get all the companies.
	 *
	 * @return the companies
	 * @throws SystemException
	 *             the system exception
	 */
	public List<CompanyDto> getCompanies() throws SystemException;

	/**
	 * get all the states.
	 *
	 * @return the states
	 * @throws SystemException
	 *             the system exception
	 */
	public List<StateDto> getStates() throws SystemException;

	/**
	 * get all the regions.
	 *
	 * @return the regions
	 * @throws SystemException
	 *             the system exception
	 */
	public List<RegionDto> getRegions() throws SystemException;

	/**
	 * get the state name on the basis of region.
	 *
	 * @param region
	 *            the region
	 * @return the state name
	 * @throws SystemException
	 *             the system exception
	 */
	public List<String> getStateName(String region) throws SystemException;

	/**
	 * get all the events.
	 *
	 * @return the events
	 * @throws SystemException
	 *             the system exception
	 */
	public List<EventDto> getEvents() throws SystemException;

	/**
	 * get all the users count.
	 *
	 * @return the user count
	 * @throws UserException
	 *             the user exception
	 */
	public Integer getUserCount() throws UserException;

	/**
	 * Gets the accordion info.
	 *
	 * @param token
	 *            the token
	 * @return the accordion info
	 * @throws UserException
	 *             the user exception
	 */
	public AccordionInfo getAccordionInfo(String token) throws UserException;

	/**
	 * Change status.
	 *
	 * @param statusInfoDto
	 *            the status info dto
	 * @throws UserException
	 *             the user exception
	 */
	public void changeStatus(StatusInfoDto statusInfoDto) throws UserException;

	/**
	 * Delete users.
	 *
	 * @param statusInfoDto
	 *            the status info dto
	 * @throws UserException
	 *             the user exception
	 */
	public void deleteUsers(StatusInfoDto statusInfoDto) throws UserException;

	/**
	 * Send notification.
	 *
	 * @param file
	 *            the file
	 * @param subject
	 *            the subject
	 * @param body
	 *            the body
	 * @param statusInfoDto
	 *            the status info dto
	 * @throws UserException
	 *             the user exception
	 */
	public void sendNotification(MultipartFile file, String subject, String body, StatusInfoDto statusInfoDto)
			throws UserException;

	/**
	 * Gets the contact.
	 *
	 * @return the contact
	 * @throws UserException
	 *             the user exception
	 */
	public ContactDto getContact() throws UserException;

	/**
	 * Upload file.
	 *
	 * @param file
	 *            the file
	 * @param fileUploadDto
	 *            the file upload dto
	 * @return the long
	 */
	public Long UploadFile(MultipartFile file, FileUploadDto fileUploadDto);

	/**
	 * File download handler.
	 *
	 * @param file
	 *            the file
	 * @return the byte array resource
	 */
	public ByteArrayResource fileDownloadHandler(String file);

	/**
	 * Gets the list of dowload metadata.
	 *
	 * @param type
	 *            the type
	 * @return the list of dowload metadata
	 */
	public List<FileUploadDto> getListOfDowloadMetadata(String type);

	/**
	 * Save last activity.
	 *
	 * @param userDto
	 *            the user dto
	 * @throws UserException
	 *             the user exception
	 */
	public void saveLastActivity(LastActivitiyDto userDto) throws UserException;

	/**
	 * Save sim card request.
	 *
	 * @param simRequestDto
	 *            the sim request dto
	 * @throws UserException
	 *             the user exception
	 */
	public void saveSimCardRequest(SimRequestDto simRequestDto) throws UserException;

	/**
	 * Gets the device.
	 *
	 * @return the device
	 * @throws UserException
	 *             the user exception
	 */
	public List<DeviceDto> getDevice() throws UserException;

	/**
	 * Edits the device.
	 *
	 * @param deviceDto
	 *            the device dto
	 * @throws UserException
	 *             the user exception
	 */
	public void editDevice(DeviceDto deviceDto) throws UserException;

	/**
	 * Removes the device.
	 *
	 * @param deviceIds
	 *            the device ids
	 * @throws UserException
	 *             the user exception
	 */
	public void removeDevice(List<Integer> deviceIds) throws UserException;

	/**
	 * Adds the device.
	 *
	 * @param deviceDto
	 *            the device dto
	 * @throws UserException
	 *             the user exception
	 */
	public void addDevice(DeviceDto deviceDto) throws UserException;

	/**
	 * Import excel file.
	 *
	 * @param file
	 *            the file
	 * @throws UserException
	 *             the user exception
	 */
	public void importExcelFile(MultipartFile file) throws UserException;

	/**
	 * Gets the sim info.
	 *
	 * @param iccid
	 *            the iccid
	 * @return the sim info
	 * @throws UserException
	 *             the user exception
	 */
	public List<SimInfoDto> getSimInfo(String iccid) throws UserException;

	/**
	 * Adds the os.
	 *
	 * @param osDto
	 *            the os dto
	 * @throws UserException
	 *             the user exception
	 */
	public void addOs(OsDto osDto) throws UserException;

	/**
	 * Gets the os.
	 *
	 * @return the os
	 * @throws UserException
	 *             the user exception
	 */
	public List<OsDto> getOs() throws UserException;

	/**
	 * Creates the group.
	 *
	 * @param groupDto
	 *            the group dto
	 * @throws UserException
	 *             the user exception
	 */
	public void createGroup(GroupDto groupDto) throws UserException;

	/**
	 * Update group.
	 *
	 * @param groupDto
	 *            the group dto
	 * @throws UserException
	 *             the user exception
	 */
	public void updateGroup(GroupDto groupDto) throws UserException;

	/**
	 * Delete group.
	 *
	 * @param groupIds
	 *            the group id
	 * @throws UserException
	 *             the user exception
	 */
	public void deleteGroup(Integer[] groupIds) throws UserException;

	/**
	 * Gets the groups.
	 *
	 * @return the groups
	 * @throws UserException
	 *             the user exception
	 */
	public List<GroupDto> getGroups() throws UserException;

	/**
	 * Sets the group request status.
	 *
	 * @param groupRequestDto
	 *            the new group request status
	 * @throws UserException
	 *             the user exception
	 */
	public void setGroupRequestStatus(GroupRequestDto groupRequestDto) throws UserException;

	/**
	 * Gets the user brief info.
	 *
	 * @param offset
	 *            the offset
	 * @param limit
	 *            the limit
	 * @return the user brief info
	 * @throws UserException
	 *             the user exception
	 */
	public List<UserDto> getUserBriefInfo(Integer offset, Integer limit) throws UserException;

	/**
	 * Gets the sim info.
	 *
	 * @param offset
	 *            the offset
	 * @param limit
	 *            the limit
	 * @return the sim info
	 * @throws UserException
	 *             the user exception
	 */
	public SimRequestData getSimInfo(Integer offset, Integer limit) throws UserException;

	/**
	 * Gets the user groups.
	 *
	 * @return the user groups
	 * @throws UserException
	 *             the user exception
	 */
	public List<GroupDto> getMyGroups() throws UserException;

	/**
	 * Gets the group requests.
	 *
	 * @return the group requests
	 * @throws UserException
	 *             the user exception
	 */
	public List<GroupRequestDto> getGroupRequests() throws UserException;

	public void deleteUserGuide(Integer fileId) throws UserException;

	public Boolean checkIFTheGroupNameAvailable(String groupName);

	public List<SoftwareVersionDto> getSoftwareList();

	public Boolean deleteSoftware(int softwareId);

	public Boolean setLatestSoftware(int softwareId, int osId, boolean latest);

	public ResponseDto registerSoftware(SoftwareVersionDto softwareVersionDto);

	public EventDtos getEventsLegends(EventsBodyDto eventsBodyDto) throws SystemException;

	List<EventsCountDto> getEventsCount(EventsBodyDto eventsBodyDto) throws SystemException;
}
