package com.harman.dmat.service;

import com.harman.dmat.common.dto.*;

public interface WifiService {

	WifiDto getWifiInfo(String latitude, String longitude, String scale, String startDate, String endDate);
	WifiClusterResponseDto getWifiDataClusters(WifiClusterRequestDto wifiClusterRequestDto);
	WifiClusterInfoResponseDto getWifiDataClusterInfoData(WifiClusterInfoRequestDto requestDto);
}