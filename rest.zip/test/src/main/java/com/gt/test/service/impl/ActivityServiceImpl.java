/**
 * 
 */
package com.harman.dmat.service.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.harman.dmat.common.dto.ActivitiesDetailsDto;
import com.harman.dmat.common.dto.ActivityCommentDto;
import com.harman.dmat.common.dto.ActivityDTO;
import com.harman.dmat.common.dto.ActivityShareDto;
import com.harman.dmat.common.dto.EmailDto;
import com.harman.dmat.common.dto.UserDto;
import com.harman.dmat.common.exception.ActivityException;
import com.harman.dmat.common.exception.InvalidActivityExcption;
import com.harman.dmat.common.exception.UserException;
import com.harman.dmat.common.security.User;
import com.harman.dmat.dao.ActivityDAO;
import com.harman.dmat.dao.UserDao;
import com.harman.dmat.enums.ErrorCode;
import com.harman.dmat.service.ActivityService;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class ActivityServiceImpl.
 *
 * @author insgupta06
 */
@Component

/** The Constant log. */
@Slf4j
public class ActivityServiceImpl implements ActivityService {

	/** The user dao. */
	@Inject
	ActivityDAO activityDao;

	/** The user dao. */
	@Inject
	UserDao userDao;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.ActivityService#saveActivity(com.harman.dmat.
	 * common.dto. ActivityDTO)
	 */
	@Override
	public void saveActivity(ActivityDTO activityDto) throws ActivityException {
		try {
			final Integer loginUserId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
					.getUserId();
			if (!activityDao.getActivity(loginUserId, activityDto.getActivityName()))
				activityDao.saveActivity(activityDto);
			else
				throw new InvalidActivityExcption(
						String.format("Activity : %s already exist plesae change the name to save this activity",
								activityDto.getActivityName()));

		} catch (final Exception  e) {
			log.error("An error occred during saving activity" + e);
			if(e instanceof InvalidActivityExcption )
				throw new  InvalidActivityExcption(e.getMessage());
			else
			throw new ActivityException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.ActivityService#getCreatedActivities()
	 */
	@Override
	public List<ActivitiesDetailsDto> getCreatedActivities() throws ActivityException {
		try {
			final List<ActivitiesDetailsDto> createdActivities = activityDao.getCreatedActivities();
			return createdActivities;
		} catch (final Exception e) {
			log.error("An error occured while fetching created activity list" + e);
			throw new ActivityException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.ActivityService#getAssignedActivities()
	 */
	@Override
	public List<ActivitiesDetailsDto> getAssignedActivities() throws ActivityException {
		try {
			final List<ActivitiesDetailsDto> assignedActivities = activityDao.getAssignedActivities();
			return assignedActivities;
		} catch (final Exception e) {
			log.error("An error occured while fetching assigned activity list" + e);
			throw new ActivityException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.ActivityService#deleteActivity(java.lang.Integer)
	 */
	@Override
	public void deleteActivity(Integer activityId) throws ActivityException {
		try {
			activityDao.deleteActivity(activityId);
		} catch (final Exception e) {
			log.error("An error occred during deleting activity" + e);
			throw new ActivityException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.ActivityService#createActivityStatus(java.lang.
	 * Integer, java.lang.String)
	 */
	@Override
	public void createActivityStatus(Integer activityId, String status) throws ActivityException {
		try {
			activityDao.createActivityStatus(activityId, status);
		} catch (final Exception e) {
			log.error("An error occred during updating share activity status" + e);
			throw new ActivityException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.ActivityService#shareActivity(com.harman.dmat.
	 * common.dto.ActivityShareDto)
	 */
	@Override
	public void shareActivity(ActivityShareDto activityShareDto) throws ActivityException {
		UserDto userDto = null;
		UserDto loggedInUserDto = null;
		final Integer userId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();
		try {
			loggedInUserDto = userDao.getUser(userId);
		} catch (final UserException e) {
			log.error("An error occred during updating sharing activity with users" + e);
			throw new ActivityException(e);
		}

		try {
			userDto = userDao.getUserByEmail(activityShareDto.getEmail());
		} catch (final UserException e) {
			log.error("Error occured during validateuser agains userid {}." + activityShareDto.getEmail() + e);
			throw new ActivityException(ErrorCode.INVALID_USER.getErrorMessage(),
					ErrorCode.INVALID_USER.getErrorCode());
		}
		if (userDto == null) {
			throw new ActivityException(ErrorCode.NOT_EXIST_USER.getErrorMessage(),
					ErrorCode.NOT_EXIST_USER.getErrorCode());
		}
		if (userDto.getEmail().trim().equalsIgnoreCase(loggedInUserDto.getEmail().trim())) {
			throw new ActivityException(ErrorCode.ACTIVITY_ITSELF.getErrorMessage(),
					ErrorCode.ACTIVITY_ITSELF.getErrorCode());
		}
		try {
			activityDao.shareActivity(activityShareDto, userDto.getUserId());

			final String userName = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
					.getUserName();

			final String msg = "Hi " + userDto.getFirstName() + "\n\n " + userName
					+ " has shared a activity with you.\n Kindly login to the portal and review the activity.\n\nRegards,Team DMAT";
			final EmailDto emailDto = new EmailDto(userDto.getFirstName(), userDto.getEmail(), msg, "Logs Activity");
			// emailService.sendEmail(emailDto);

		} catch (final Exception e) {
			log.error("An error occred during updating sharing activity with users" + e);
			throw new ActivityException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.ActivityService#createComment(com.harman.dmat.
	 * common.dto.ActivityCommentDto)
	 */
	@Override
	public void createComment(ActivityCommentDto activityCommentDto) throws ActivityException {
		try {
			activityDao.createComment(activityCommentDto);
		} catch (final Exception e) {
			log.error("An error occred during creating comment on shared activity" + e);
			throw new ActivityException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.ActivityService#getComments(java.lang.Integer)
	 */
	@Override
	public List<ActivityCommentDto> getComments(Integer activityId) throws ActivityException {
		try {
			return activityDao.getComments(activityId);
		} catch (final Exception e) {
			log.error("An error occred during getting comments on shared activity" + e);
			throw new ActivityException(e);
		}
	}

	@Override
	public List<ActivitiesDetailsDto> getShareActivity() throws ActivityException {
		try {
			return activityDao.getShareActivity();

		} catch (final Exception e) {
			log.error("An error occured while fetching shared activity list" + e);
			throw new ActivityException(e);
		}
	}
}
