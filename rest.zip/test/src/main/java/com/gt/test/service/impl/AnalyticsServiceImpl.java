package com.harman.dmat.service.impl;

import com.harman.dmat.common.dto.AnalyticsRequestDto;
import com.harman.dmat.common.dto.AnalyticsResponseDto;
import com.harman.dmat.common.dto.DeviceStatsRequestDto;
import com.harman.dmat.common.dto.DeviceStatsResponseDto;
import com.harman.dmat.dao.AnalyticsDao;
import com.harman.dmat.service.AnalyticsService;
import com.harman.dmat.utils.Utill;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@Transactional
public class AnalyticsServiceImpl implements AnalyticsService {
    @Inject
    AnalyticsDao analyticsDao;

    @Inject
    Environment environment;

    /**
     * Returns the unique models for the given search request
     * @param analyticsRequestDto
     * @return
     */
    @Override
    public AnalyticsResponseDto getModels(AnalyticsRequestDto analyticsRequestDto) {
        String indices = Utill.getIndex(analyticsRequestDto.getFromDate(), analyticsRequestDto.getToDate());
        String query = getUniqueModelsQuery(analyticsRequestDto);
        if (log.isDebugEnabled()) {
            log.debug("GetModels Query formed: " + query);
            log.debug("Indices: " + indices);
        }
        return analyticsDao.getModels(query, indices);
    }

    /**
     * Returns the device stats for the given search request.
     * @param deviceStatsRequestDto
     * @return
     */
    @Override
    public List<DeviceStatsResponseDto> getDeviceStats(DeviceStatsRequestDto deviceStatsRequestDto) {
        String indices = Utill.getIndex(deviceStatsRequestDto.getFromDate(), deviceStatsRequestDto.getToDate());
        String query = getDeviceStatsQuery(deviceStatsRequestDto);

        if (log.isDebugEnabled()) {
            log.debug("getDeviceStats Query formed: " + query);
            log.debug("Indices: " + indices);
        }
        return analyticsDao.getDeviceStats(query, indices, deviceStatsRequestDto.getLocCode());
    }

    /**
     * Creates a query to retrieve the unique models.
     * @param analyticsRequestDto
     * @return
     */
    private String getUniqueModelsQuery(AnalyticsRequestDto analyticsRequestDto) {
        return "{" +
                "  \"size\": 0," +
                "  \"query\": {" +
                "    \"bool\": {" +
                "      \"must\": [" +
                "        {" +
                "          \"range\": {" +
                "            \"TimeStamp\": {" +
                "              \"from\": \"" + analyticsRequestDto.getFromDate() +
                "\"," +
                "              \"to\": \"" + analyticsRequestDto.getToDate() +
                "\"," +
                "              \"include_lower\": true," +
                "              \"include_upper\": true," +
                "              \"boost\": 1" +
                "            }" +
                "          }" +
                "        }" + getDomainESQuery(analyticsRequestDto.getDomain()) + getUserQuery(analyticsRequestDto.getUserId()) +
                "      ]," +
                "      \"must_not\": [" +
                "        {" +
                "          \"exists\": {" +
                "            \"field\": \"InbuildinguserMark\"" +
                "          }" +
                "        }" +
                "      ]," +
                "      \"filter\": {" +
                "        \"geo_bounding_box\": {" +
                "          \"loc\": {" +
                "            \"top_left\": {" +
                "              \"lat\": " + analyticsRequestDto.getTlLat() +
                "," +
                "              \"lon\": " + analyticsRequestDto.getTlLon() +
                "" +
                "            }," +
                "            \"bottom_right\": {" +
                "              \"lat\": " + analyticsRequestDto.getBrLat() +
                "," +
                "              \"lon\": " + analyticsRequestDto.getBrLon() +
                "" +
                "            }" +
                "          }" +
                "        }" +
                "      }" +
                "    }" +
                "  }," +
                "  \"aggs\": {" +
                "    \"unique_model\": {" +
                "      \"terms\": {" +
                "        \"field\": \"ModelName\"," +
                "        \"size\": 10000" +
                "      }" +
                "    }" +
                "  }" +
                "}";
    }

    /**
     * Creates the domain SQL query
     *
     * @param userDomain
     * @return
     */
    private String getDomainESQuery(String userDomain) {
        String domainQuery = "";
        userDomain = userDomain == null ? "null" : userDomain;
        StringBuffer sb = new StringBuffer();
        try {
            List<String> listVzDomains = Arrays.asList(environment.getRequiredProperty("verizon.domains").split(","));

            if (listVzDomains.contains(userDomain)) {
                for (String domain : listVzDomains) {
                    sb = sb.append("{ \"query_string\": { \"query\": \"EmailId:*").append(domain).append("\"} },");
                }
                sb.deleteCharAt(sb.length() - 1);
                domainQuery = ", { \"bool\": { \"should\": [" + sb.toString() + "] } }";
            } else {
                sb = sb.append("{ \"query_string\": { \"query\": \"EmailId:*").append(userDomain.toLowerCase())
                        .append("\"} }");
                domainQuery = ", { \"bool\": { \"must\": [" + sb.toString() + "] } }";
            }
        } catch (Exception e) {
            log.error("Error Getting Vz domains");
        }

        return domainQuery;
    }

    /**
     * Gets the events range query.
     *
     * @param eventsField
     * @return
     */
    private String getEventsRange(String eventsField) {
        return "{" + "\"range\": {" + "\"" + eventsField + "\": {" + "\"gt\": 0" + "}" + "}" + "}";
    }

    /**
     * Returns userQuery for a given userId, returns nothing if the userId is ALL.
     * @param userId
     * @return
     */
    private String getUserQuery(String userId) {
        String userQuery = "";
        if (!userId.equalsIgnoreCase("ALL")) {
            userQuery = ",{" + "\"terms\": {" + "\"DmUser\": [\"" + userId + "\"]" + "}" + "}";
        }

        return userQuery;
    }

    /**
     * Creates query to retrieve the device stats for the given requestDto.
     * @param deviceStatsRequestDto
     * @return
     */
    private String getDeviceStatsQuery(DeviceStatsRequestDto deviceStatsRequestDto) {
        String query =  "{" +
                "  \"size\": 0," +
                "  \"query\": {" +
                "    \"bool\": {" +
                "      \"must\": [" ;
                if(!deviceStatsRequestDto.getKpi().trim().equalsIgnoreCase("")) {
                    query = query + "        {" +
                            "          \"query_string\": {" +
                            "            \"query\": \"_exists_:" + deviceStatsRequestDto.getKpi() +
                            "\"" +
                            "          }" +
                            "        },";
                }

                query = query + " {" +
                "          \"range\": {" +
                "            \"TimeStamp\": {" +
                "              \"from\": \"" + deviceStatsRequestDto.getFromDate() +
                "\"," +
                "              \"to\": \"" + deviceStatsRequestDto.getToDate() +
                "\"," +
                "              \"include_lower\": true," +
                "              \"include_upper\": true," +
                "              \"boost\": 1" +
                "            }" +
                "          }" +
                "        }"
                 ;

            query = query + ((deviceStatsRequestDto.getTimeFrame().size() > 0) ? " ,{ \"bool\": {" +
                "            \"should\": [" + getTimeFrameQuery(deviceStatsRequestDto).substring(0, getTimeFrameQuery(deviceStatsRequestDto).length() - 1) +
                "]}}" : "");

            query = query + ((deviceStatsRequestDto.getTimeFrame().size() > 0) ? " ,{ \"bool\": {" +
                "            \"should\": [" + getKpiRangeQuery(deviceStatsRequestDto).substring(0, getKpiRangeQuery(deviceStatsRequestDto).length() - 1) +
                "]}}" : "");

            query = query + getDeviceQuery(deviceStatsRequestDto) + getUserQuery(deviceStatsRequestDto.getUserId()) ;

            query = query + ((deviceStatsRequestDto.getEvents().size() > 0) ? ", { \"bool\": {" +
                "            \"should\": [" + getEventsRangeQuery(deviceStatsRequestDto) +
                "]}}" : "");

            query = query + getDomainESQuery(deviceStatsRequestDto.getDomain()) +
                "      ]," +
                "      \"must_not\": [" +
                "        {" +
                "          \"exists\": {" +
                "            \"field\": \"InbuildinguserMark\"" +
                "          }" +
                "        }" +
                "      ]," +
                "      \"filter\": {" +
                "        \"geo_bounding_box\": {" +
                "          \"loc\": {" +
                "            \"top_left\": {" +
                "              \"lat\": " + deviceStatsRequestDto.getTlLat() +
                        "," +
                "              \"lon\": " + deviceStatsRequestDto.getTlLon() +
                        "" +
                "            }," +
                "            \"bottom_right\": {" +
                "              \"lat\": " + deviceStatsRequestDto.getBrLat() +
                        "," +
                "              \"lon\": " + deviceStatsRequestDto.getBrLon() +
                        "" +
                "            }" +
                "          }" +
                "        }" +
                "      }" +
                "    }" +
                "  }" +
                "," +
                "\"aggs\": {" +
                    "    \"aggTestIds\": {" +
                    "      \"terms\": {" +
                    "        \"field\": \"FileName\"" +"," +
                    "            \"size\": 50000" +
                    "      }," +
                    "      \"aggs\": {" +
                    "        \"" + deviceStatsRequestDto.getLocCode() +
                    "\": {" +
                    "          \"terms\": {" +
                    "            \"field\": \"" + deviceStatsRequestDto.getLocCode() +
                    "\"," +
                    "            \"size\": 1" +
                    "          }" +
                    "        }" +
                    "      }" +
                    "    }" +
                    "  }" +
                "}";

        return query;
    }

    private String getEventsRangeQuery(DeviceStatsRequestDto deviceStatsRequestDto) {
        String eventsRangeQuery = "";
        int i = 0;
        for (String eventName : deviceStatsRequestDto.getEvents()) {
            eventsRangeQuery = (i == (deviceStatsRequestDto.getEvents().size() - 1)) ? eventsRangeQuery + getEventsRange(eventName)
                    : eventsRangeQuery + getEventsRange(eventName) + ",";
            i++;
        }

        return eventsRangeQuery;
    }

    /**
     * Returns device query with devices as comma separated String.
     * @param deviceStatsRequestDto
     * @return
     */
    private String getDeviceQuery(DeviceStatsRequestDto deviceStatsRequestDto) {
        String deviceStr = "";
        String deviceQuery = "";

        for(int i = 0; i < deviceStatsRequestDto.getDevices().size(); i++) {
            deviceStr = deviceStr + "\"" + deviceStatsRequestDto.getDevices().get(i) + ((i == (deviceStatsRequestDto.getDevices().size() - 1)) ? "\"" : "\",");
        }

        if(!deviceStr.trim().equalsIgnoreCase("")) {
            deviceQuery = "," +
                    "        {" +
                    "          \"terms\": {" +
                    "            \"ModelName\": [" + deviceStr +
                    "            ]" +
                    "          }" +
                    "        }";
        }

        return deviceQuery;
    }

    /**
     * Returns kpiRange Query.
     * @param deviceStatsRequestDto
     * @return
     */
    private String getKpiRangeQuery(DeviceStatsRequestDto deviceStatsRequestDto) {
        StringBuilder kpiRangeQuery = new StringBuilder("");

        if(deviceStatsRequestDto.getKpiRanges().size() > 0 && deviceStatsRequestDto.getKpiRanges().get(0).contains("<=X<")) {
            deviceStatsRequestDto.getKpiRanges().forEach(x -> {
            List<Integer> kpiRange = Arrays.asList(x.split("<=X<")).stream().map(Integer :: valueOf).collect(Collectors.toList());
            kpiRangeQuery.append(" {" +
                    "\"range\": {" +
                    "\"" + deviceStatsRequestDto.getKpi() +
                    "\": {" +
                    "\"from\": " + Collections.min(kpiRange) +
                    "," +
                    "\"to\": " + Collections.max(kpiRange) +
                    "" +
                    "}" +
                    "}" +
                    "},");
            } );
        } else {
            String kpiRangesStr = "";

            for(int i = 0; i < deviceStatsRequestDto.getKpiRanges().size(); i++) {
                kpiRangesStr = kpiRangesStr + "\"" + deviceStatsRequestDto.getKpiRanges().get(i) + ((i == (deviceStatsRequestDto.getKpiRanges().size() - 1)) ? "\"" : "\",");
            }

            kpiRangeQuery.append("{" +
                    "          \"terms\": {" +
                    "            \"" + deviceStatsRequestDto.getKpi() +
                    "\": [" + kpiRangesStr + "]" +
                    "          }" +
                    "        },");
        }

        return kpiRangeQuery.toString();
    }

    /**
     * Returns timeFrame query.
     * @param deviceStatsRequestDto
     * @return
     */
    private String getTimeFrameQuery(DeviceStatsRequestDto deviceStatsRequestDto) {
        StringBuilder timeFrameQuery = new StringBuilder("");

        deviceStatsRequestDto.getTimeFrame().forEach(x -> {
            List<Integer> hourRange = Arrays.asList(x.split("-")).stream().map(Integer :: valueOf).collect(Collectors.toList());
            timeFrameQuery.append(" {" +
                    "\"script\": {" +
                    "\"script\": {" +
                    "\"inline\": \"def hour = Instant.ofEpochMilli(doc.TimeStamp.value).atZone(ZoneId.of('Z')).toLocalTime().getHour(); return hour >= params.min && hour < params.max;\"," +
                    "\"lang\": \"painless\"," +
                    "\"params\": {" +
                    "\"min\": " + Collections.min(hourRange) +
                    "," +
                    "\"max\": " + Collections.max(hourRange) +
                    "" +
                    "}" +
                    "}" +
                    "}" +
                    "},");
        } );

        return timeFrameQuery.toString();
    }

}
