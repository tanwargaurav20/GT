package com.harman.dmat.service.impl;

import com.harman.dmat.common.dto.BaselineCountyReqDto;
import com.harman.dmat.common.dto.BaselineCountyResDto;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.dao.BaselineCountyDao;
import com.harman.dmat.service.BaselineCountyService;
import com.harman.dmat.utils.Utill;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.Arrays;
import java.util.List;

@Component
@Slf4j
public class BaselineCountyServiceImpl implements BaselineCountyService {
    @Inject
    BaselineCountyDao baselineCountyDao;

    @Inject
    Environment environment;

    @Override
    public BaselineCountyResDto getBaselineCounty(BaselineCountyReqDto baselineCountyReqDto, String userId){
        try {
            String query = getBaseLineESQuery(baselineCountyReqDto, userId);
            String indices = Utill.getIndex(baselineCountyReqDto.getStartDate(), baselineCountyReqDto.getEndDate());

            if (log.isDebugEnabled()) {
                log.debug("BaselineCounty query formed: " + query);
                log.debug("Indices: " + indices);
            }
            BaselineCountyResDto baselineCountyResDto = baselineCountyDao.getBaselineCounty(query, indices);
            return baselineCountyResDto;
        } catch (final Exception e) {
            log.error("Error getting BaselineCounty data from elastic search." + e);
            throw new DataNotFoundException(e);
        }
    }

    private String getBaseLineESQuery(BaselineCountyReqDto baselineCountyReqDto, String userId) {
        String query = "";
        String domainQuery = getDomainESQuery(baselineCountyReqDto.getDomain());
        String searchTerm = "";
        String searchTarget = "";
        String searchSource = "";

        if(StringUtils.isNotBlank(baselineCountyReqDto.getImeiS()) && StringUtils.isNotBlank(baselineCountyReqDto.getImeiT())) {
            searchTerm = "Imei";
            searchTarget = baselineCountyReqDto.getImeiT();
            searchSource = baselineCountyReqDto.getImeiS();
        } else if (StringUtils.isNotBlank(baselineCountyReqDto.getMdnS()) && StringUtils.isNotBlank(baselineCountyReqDto.getMdnT())) {
            searchTerm = "MDN";
            searchTarget = baselineCountyReqDto.getMdnT();
            searchSource = baselineCountyReqDto.getMdnS();
        } else if (StringUtils.isNotBlank(baselineCountyReqDto.getModelS()) && StringUtils.isNotBlank(baselineCountyReqDto.getModelT())) {
            searchTerm = "ModelName";
            searchTarget = baselineCountyReqDto.getModelT();
            searchSource = baselineCountyReqDto.getModelS();
        }

        query = query + "{" +
                "  \"size\": 0," +
                "  \"query\": {" +
                "    \"bool\": {" +
                "      \"must\": [" +
                "        {" +
                "          \"query_string\": {" +
                "            \"query\": \"_exists_:" + baselineCountyReqDto.getKpiName() +
                "\"" +
                "          }" +
                "        }," +
                "        {" +
                "          \"range\": {" +
                "            \"TimeStamp\": {" +
                "              \"from\": \"" + baselineCountyReqDto.getStartDate() +
                "\"," +
                "              \"to\": \"" + baselineCountyReqDto.getEndDate() +
                "\"," +
                "              \"include_lower\": true," +
                "              \"include_upper\": true," +
                "              \"boost\": 1" +
                "            }" +
                "          }" +
                "        }," +
                "        {" +
                "          \"bool\": {" +
                "            \"must_not\": [" +
                "              {" +
                "                \"bool\": {" +
                "                  \"must_not\": [" +
                "                    {" +
                "                      \"exists\": {" +
                "                        \"field\": \"" + baselineCountyReqDto.getKpiName() +
                "\"," +
                "                        \"boost\": 1" +
                "                      }" +
                "                    }" +
                "                  ]" +
                "                }" +
                "              }" +
                "            ]" +
                "          }" +
                "        }" + ((userId != null && userId.equalsIgnoreCase("ALL")) ? "" : getUserQuery(userId)) + domainQuery +
                "        ,{" +
                "          \"bool\": {" +
                "            \"should\": [" +
                "              {" +
                "                \"match\": {" +
                "                  \"" + searchTerm +
                "\": {" +
                "                    \"query\": \"" + searchSource +
                "\"," +
                "                    \"boost\": 1" +
                "                  }" +
                "                }" +
                "              }," +
                "              {" +
                "                \"match\": {" +
                "                  \"" + searchTerm +
                "\": {" +
                "                    \"query\": \"" + searchTarget +
                "\"," +
                "                    \"boost\": 1" +
                "                  }" +
                "                }" +
                "              }" +
                "            ]" +
                "          }" +
                "        }" +
                "      ]," +
                "      \"filter\": [" +
                "        {" +
                "          \"geo_bounding_box\": {" +
                "            \"loc\": {" +
                "              \"top_left\": {" +
                "                \"lat\": " + baselineCountyReqDto.getTlLat() +
                "," +
                "                \"lon\": " + baselineCountyReqDto.getTlLon() +
                "" +
                "              }," +
                "              \"bottom_right\": {" +
                "                \"lat\": " + baselineCountyReqDto.getBrLat() +
                "," +
                "                \"lon\": " + baselineCountyReqDto.getBrLon() +
                "" +
                "              }" +
                "            }" +
                "          }" +
                "        }" +
                "      ]" +
                "    }" +
                "  }," +
                "  \"aggs\": {" +
                "    \"County\": {" +
                "      \"terms\": {" +
                "        \"field\": \"County\"," +
                "        \"size\": 50000" +
                "      }," +
                "      \"aggs\": {" +
                "        \"" + baselineCountyReqDto.getMagnitude() +
                "\": {" +
                "          \"terms\": {" +
                "            \"field\": \"" + baselineCountyReqDto.getMagnitude() +
                "\"," +
                "            \"size\": 50000" +
                "          }" +
                "        }" +
                "      }" +
                "    }" +
                "," +
                "    \"StateCode\": {" +
                "      \"terms\": {" +
                "        \"field\": \"StateCode\"," +
                "        \"size\": 50000" +
                "      }," +
                "      \"aggs\": {" +
                "        \"" + baselineCountyReqDto.getMagnitude() +
                "\": {" +
                "          \"terms\": {" +
                "            \"field\": \"" + baselineCountyReqDto.getMagnitude() +
                "\"," +
                "            \"size\": 50000" +
                "          }" +
                "        }" +
                "      }" +
                "    }," +
                "    \"VzwRegions\": {" +
                "      \"terms\": {" +
                "        \"field\": \"VzwRegions\"," +
                "        \"size\": 50000" +
                "      }," +
                "      \"aggs\": {" +
                "        \"" + baselineCountyReqDto.getMagnitude() +
                "\": {" +
                "          \"terms\": {" +
                "            \"field\": \"" + baselineCountyReqDto.getMagnitude() +
                "\"," +
                "            \"size\": 50000" +
                "          }" +
                "        }" +
                "      }" +
                "    }" +
                "  }," +
                "  \"_source\": false" +
                "}";

        return query;
    }

    private String getUserQuery(String userId) {
        String userQuery = "";
        if (!userId.equalsIgnoreCase("ALL")) {
            userQuery = ",{" + "\"terms\": {" + "\"DmUser\": [\"" + userId + "\"]" + "}" + "}";
        }

        return userQuery;
    }

    /**
     * Creates the domain SQL query
     *
     * @param userDomain
     * @return
     */
    private String getDomainESQuery(String userDomain) {
        String domainQuery = "";
        userDomain = userDomain == null ? "null" : userDomain;
        StringBuffer sb = new StringBuffer();
        try {
            List<String> listVzDomains = Arrays.asList(environment.getRequiredProperty("verizon.domains").split(","));

            if (listVzDomains.contains(userDomain)) {
                for (String domain : listVzDomains) {
                    sb = sb.append("{ \"query_string\": { \"query\": \"EmailId:*").append(domain).append("\"} },");
                }
                sb.deleteCharAt(sb.length() - 1);
                domainQuery = ", { \"bool\": { \"should\": [" + sb.toString() + "] } }";
            } else {
                sb = sb.append("{ \"query_string\": { \"query\": \"EmailId:*").append(userDomain.toLowerCase())
                        .append("\"} }");
                domainQuery = ", { \"bool\": { \"must\": [" + sb.toString() + "] } }";
            }
        } catch (Exception e) {
            log.error("Error Getting Vz domains");
        }

        return domainQuery;
    }

}
