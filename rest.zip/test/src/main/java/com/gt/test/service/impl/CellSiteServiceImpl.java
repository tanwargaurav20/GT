package com.harman.dmat.service.impl;

import javax.inject.Inject;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.harman.dmat.common.dto.CellSiteClusterRequestDto;
import com.harman.dmat.common.dto.CellSiteClusterResponseDto;
import com.harman.dmat.dao.CellSiteDao;
import com.harman.dmat.service.CellSiteService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional

public class CellSiteServiceImpl implements CellSiteService {
	@Inject
	Environment environment;

	@Inject
	CellSiteDao cellSiteDao;

	@Override
	public CellSiteClusterResponseDto getCellSiteDataClusters(CellSiteClusterRequestDto cellSiteClusterRequestDto) {

		String cellSiteDataClusterQuery = getCellSiteDataClustersQuery(cellSiteClusterRequestDto);

		String indices = environment.getRequiredProperty("esCellsiteIndex");

		if (log.isDebugEnabled()) {
			log.debug("WifiDataCluster Query formed: " + cellSiteDataClusterQuery);
			log.debug("Indices: " + indices);
		}

		return cellSiteDao.getCellSiteDataClusters(cellSiteDataClusterQuery, indices,
				cellSiteClusterRequestDto.getLocCode());

	}

	private String getCellSiteDataClustersQuery(CellSiteClusterRequestDto cellSiteClusterRequestDto) {
		return "{" +
				"  \"from\": 0," +
				"  \"size\": 0," +
				"  \"query\": {" +
				"  \"bool\": {" +
				"  \"must\":[{\"exists\":{\"field\": \"lte_cell_type\"}}],"+
				//This field will be needed for date range calculation
				/*"      \"must\": [" +"        
				"        {" +
				"          \"range\": {" +
				"            \"createddate\": {" +
				"              \"from\": \"" + cellSiteClusterRequestDto.getTimeStampFrom() +
				"\"," +
				"              \"to\": \"" + cellSiteClusterRequestDto.getTimeStampTo() +
				"\"," +
				"              \"include_lower\": true," +
				"              \"include_upper\": true" +
				"            }" +
				"          }" +
				"        }" +
				"      ]," +*/
				"      \"filter\": {" +
				"        \"geo_bounding_box\": {" +
				"          \"loc\": {" +
				"            \"top_left\": {" +
				"              \"lat\": " + cellSiteClusterRequestDto.getTlLat() +
				"," +
				"              \"lon\": " + cellSiteClusterRequestDto.getTlLon() +
				"" +
				"            }," +
				"            \"bottom_right\": {" +
				"              \"lat\": " + cellSiteClusterRequestDto.getBrLat() +
				"," +
				"              \"lon\": " + cellSiteClusterRequestDto.getBrLon() +
				"" +
				"            }" +
				"          }" +
				"        }" +
				"      }" +
				"    }" +
				"  } "+
				"," +
				"  \"aggregations\": {" +
				"    \"Location\": {" +
				"      \"terms\": {" +
				"        \"field\": \""+ cellSiteClusterRequestDto.getLocCode() + "\"," +
				"     \"size\": 50000" +
				"      }," +
				"          \"aggs\": {" +
				"            \"top_loc\": {" +
				"              \"top_hits\": {" +				
				"                \"_source\": {" +
				"                  \"includes\": [" +
				"                    \"loc_mx\"," +
				"                    \"loc_my\"" +
				"                  ]" +
				"                }," +
				"                \"size\": 1" +
				"              }" +
				"            }" +
				"          }" +
				"        }" +
				"  }" +
				"}";
	}
}