package com.harman.dmat.service.impl;

import com.google.gson.*;
import com.harman.dmat.common.dto.*;
import com.harman.dmat.common.email.EmailService;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.dao.ClientAPIDao;
import com.harman.dmat.service.ClientAPIService;
import com.harman.dmat.service.ConfigurationService;
import lombok.extern.slf4j.Slf4j;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.inject.Inject;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Module that has all the services required for Client API call.
 */
@Component
@Slf4j
public class ClientAPIServiceImpl implements ClientAPIService {
    @Inject
    EmailService emailService;

    @Inject
    ConfigurationService config;

    @Inject
    ClientAPIDao clientAPIDao;

    @Inject
    private transient Environment environment;

    @Inject
    private RestTemplate restTemplate;

    /**
     * Writes the crash Report in the log file.
     *
     * @param crashExceptionString
     */
    @Override
    public ResponseDto createCrashReport(String crashExceptionString, UserFiltersDto userFiltersDto){
        final ResponseDto responseDto = new ResponseDto();
        try {
            // Disabling userauthentication for crashreport now, since it is not mandatory for the user
            // to provide imei and imsi for this api request from Mukesh on 2017/09/27
            if(userFiltersDto.getImei() != null && userFiltersDto.getImei() != null) {
                int userId = authenticateUser(userFiltersDto);
            }

            writeToFile(environment.getRequiredProperty("crashReportPath"), crashExceptionString);

//            if(userId > 0) {
                String adminEmailsString = environment.getRequiredProperty("adminEmailList");
                log.debug("Sending crash report email notification to Dmat Admin user "+ adminEmailsString);

                emailService.sendEmailList(Arrays.asList(adminEmailsString.split(",")),
                        config.getAllConfiguration().get("crash_report_subject"),
                        crashExceptionString, "Admin", true);

                responseDto.setStatusCode(0);
                responseDto.setMessage("Successfully created crash report");
                responseDto.setData("Successfully created crash report");

                log.debug("Successfully created crash report");
            /*} else {
                responseDto.setErrorCode(1);
                responseDto.setMessage("User Authentication Failed");
                responseDto.setDeveloperMessage("User is not available");
            }*/
        } catch (JSONException ex) {
            log.error("Failed in creating crash report "+ ex.getMessage());
            responseDto.setErrorCode(1);
            responseDto.setMessage("User Authentication Failed in JSONException");
            responseDto.setDeveloperMessage("User Authentication Failed in JSONException");
        } catch(Exception e) {
            log.error("Failed in creating crash report "+ e.getMessage());
            responseDto.setErrorCode(1);
            responseDto.setMessage("Failed in creating crash report");
            responseDto.setDeveloperMessage("Failed in creating crash report "+ e.getMessage());
        }

        return responseDto;
    }

    // Writes the input payload into the directory
    private void writeToFile(String strFilePath, String message) {
        try {
            Path file_path = Paths.get(strFilePath);

            // if file doesn't exists, then create it
            if (!Files.exists(file_path)) {
                Files.createFile(file_path);
            }

            Files.write(file_path, ("\n\r"+message).getBytes(), StandardOpenOption.APPEND);
        } catch(IOException ex) {
            log.error("Failed in writing message into a file "+ ex.getMessage());
            ex.printStackTrace();
        }
    }

    /**
     * Receives the sim pin from the request string, encrypts it and adds it into Encrypt_Decrypt_Master_tbl
     * @param strICCID
     * @param strPIN
     * @return responseStatus
     */
    @Override
    public ResponseDto updatePin(String strICCID, String strPIN, UserFiltersDto userFiltersDto) {
        final ResponseDto responseDto = new ResponseDto();
        try {
            int userId = authenticateUser(userFiltersDto);

            if(userId > 0) {
                String strResult = clientAPIDao.updatePin(strICCID, strPIN);

                if (strResult != "" && !strResult.equalsIgnoreCase("Fail")) {
                    log.debug("Pin updated successfully and response sent. Result= " + strResult);
                    responseDto.setStatusCode(0);
                    responseDto.setMessage("Pin updated successfully and response sent");
                    responseDto.setData(strResult);
                } else {
                    log.debug("Unable to Update the PIN.");
                    strResult = "NoPin - Unable to Update the PIN.";
                    responseDto.setErrorCode(1);
                    responseDto.setMessage(strResult);
                    responseDto.setDeveloperMessage(strResult);
                }
            } else {
                responseDto.setErrorCode(1);
                responseDto.setMessage("User Authentication Failed");
                responseDto.setDeveloperMessage("User is not available");
            }
        } catch (JSONException ex) {
            log.error("Failed in updating Sim pin "+ ex.getMessage());
            responseDto.setErrorCode(1);
            responseDto.setMessage("User Authentication Failed in JSONException");
            responseDto.setDeveloperMessage("User Authentication Failed in JSONException");
        }

        return responseDto;
    }

    /**
     * Receives the sim pin from the table Encrypt_Decrypt_Master_tbl
     * @param strICCID
     * @return responseStatus
     */
    @Override
    public ResponseDto getPin(String strICCID, UserFiltersDto userFiltersDto) {
        final ResponseDto responseDto = new ResponseDto();
        try {
            int userId = authenticateUser(userFiltersDto);

            if(userId > 0) {
                String strPinValue = clientAPIDao.getPin(strICCID);

                if (strPinValue != "" && !strPinValue.equalsIgnoreCase("")) {
                    log.debug("Pin successfully retrieved and response sent. Result= " + strPinValue);
                    responseDto.setStatusCode(0);
                    responseDto.setMessage("SIM Pin successfully retrieved");
                    SimPinResponseDto simPinResponseDto = new SimPinResponseDto();
                    simPinResponseDto.setPin(strPinValue);
                    responseDto.setData(simPinResponseDto);
                } else {
                    log.debug("No Pin for given i/p");
                    responseDto.setErrorCode(1);
                    responseDto.setMessage("Failed to retrieve SIM PIN.");
                    responseDto.setDeveloperMessage("Invalid ICCID");
                }
            } else {
                responseDto.setErrorCode(1);
                responseDto.setMessage("User Authentication Failed");
                responseDto.setDeveloperMessage("User is not available");
            }
        } catch (JSONException ex) {
            log.error("Failed in retrieving Sim pin "+ ex.getMessage());
            responseDto.setErrorCode(1);
            responseDto.setMessage("User Authentication Failed in JSONException");
            responseDto.setDeveloperMessage("User Authentication Failed in JSONException");
        }

        return responseDto;
    }

    /**
     * Adds the datapoints from request into Data_Points_Live table
     * @param points - List of Live Data points
     * @return responseStatus
     */
    @Override
    public ResponseDto addDmatLiveDatapoints(String dmatLiveStr, List<DataPointsLiveDto> points, UserFiltersDto userFiltersDto) {
        final ResponseDto responseDto = new ResponseDto();
        try {
            int userId = authenticateUser(userFiltersDto);

            if(userId > 0) {
                String status = clientAPIDao.addDmatLive(points);

                if(status == "Success") {
                    log.debug("Succefully added dmat live datapoints");
                    responseDto.setStatusCode(0);
                    responseDto.setMessage("Succefully added dmat live datapoints");
                    responseDto.setData("Succefully added dmat live datapoints");
                } else {
                    log.error("Failed to add dmat live datapoints");
                    responseDto.setErrorCode(1);
                    responseDto.setMessage("Failed to add dmat live datapoints");
                    responseDto.setDeveloperMessage("Failed to add dmat live datapoints");
                }
            } else {
                writeToFile(environment.getRequiredProperty("dmatLiveExceptionDir"), dmatLiveStr);
                responseDto.setErrorCode(1);
                responseDto.setMessage("User Authentication Failed");
                responseDto.setDeveloperMessage("User is not available");
            }

        } catch (JSONException ex) {
            writeToFile(environment.getRequiredProperty("dmatLiveExceptionDir"), dmatLiveStr);
            log.error("Failed to add dmat live datapoints "+ ex.getMessage());
            responseDto.setErrorCode(1);
            responseDto.setMessage("User Authentication Failed in JSONException");
            responseDto.setDeveloperMessage("User Authentication Failed in JSONException");
        }

        return responseDto;
    }

    @Override
    public ResponseDto getFilteredData(InBuildingFiltersDto inBuildingFiltersDto) {
        final ResponseDto responseDto = new ResponseDto();
        try {
            int userId = authenticateUser(inBuildingFiltersDto.getUserFiltersDto());
            Gson gson = new GsonBuilder().serializeNulls().create();

            if (userId > 0) {
                List<InBuildingClientImageDto> inBuildingImageList = clientAPIDao.getFilteredDataForUser(userId, inBuildingFiltersDto);
                String inbuildingJson = gson.toJson(inBuildingImageList);

                if (inBuildingImageList.size() > 0) {
                    JSONArray jsonArray = new JSONArray(inbuildingJson);

                    for(int i=0; i < jsonArray.length(); i++) {
                        JSONObject jsonObj = jsonArray.getJSONObject(i);
                        jsonObj.remove("buildingimage");
                        log.debug("Succefully got the Inbuilding Filtered data "+jsonObj);
                    }

                    responseDto.setStatusCode(0);
                    responseDto.setMessage("Succefully got the Inbuilding data");
                    responseDto.setData(inBuildingImageList);
                } else {
                    responseDto.setErrorCode(1);
                    responseDto.setMessage("No Inbuilding data is available");
                    responseDto.setDeveloperMessage("No Inbuilding data is available");
                }
            } else {
                responseDto.setErrorCode(1);
                responseDto.setMessage("User Authentication Failed");
                responseDto.setDeveloperMessage("User is not available");
            }
        } catch (JSONException ex) {
            log.error("Failed to retrieve Inbuilding Filtered Images Data "+ ex.getMessage());
            responseDto.setErrorCode(1);
            responseDto.setMessage("User Authentication Failed in JSONException");
            responseDto.setDeveloperMessage("User Authentication Failed in JSONException");
        }

        return responseDto;
    }

    @Override
    public byte[] getInbuildingImage(int id) {
        return clientAPIDao.getInbuildingImage(id);
    }

    @Override
    public ResponseDto getInbuildingLocations(UserFiltersDto userFiltersDto) {
        final ResponseDto responseDto = new ResponseDto();
        try {
            int userId = authenticateUser(userFiltersDto);

            if (userId > 0) {
                List<InBuildingLocationDto> inBuildingLocations = clientAPIDao.getInbuildingLocations(userId);
                if (inBuildingLocations.size() > 0) {
                    log.debug("Succefully got the Inbuilding Locations data "+new Gson().toJson(inBuildingLocations));
                    responseDto.setStatusCode(0);
                    responseDto.setMessage("Succefully got the Inbuilding Locations data");
                    responseDto.setData(inBuildingLocations);
                } else {
                    responseDto.setErrorCode(1);
                    responseDto.setMessage("No Inbuilding locations data is available");
                    responseDto.setDeveloperMessage("No Inbuilding locations data is available");
                }
            } else {
                responseDto.setErrorCode(1);
                responseDto.setMessage("User Authentication Failed");
                responseDto.setDeveloperMessage("User is not available");
            }
        } catch (JSONException ex) {
            log.error("Failed to retrieve Inbuilding Locations Data "+ ex.getMessage());
            responseDto.setErrorCode(1);
            responseDto.setMessage("User Authentication Failed in JSONException");
            responseDto.setDeveloperMessage("User Authentication Failed in JSONException");
        }

        return responseDto;
    }

    @Override
    public ResponseDto getSoftwareVersion(SoftwareDto softwareDto) {
        final ResponseDto responseDto = new ResponseDto();
        try {
            int userId = authenticateUser(softwareDto.getUserFiltersDto());

            if(userId > 0){
                log.debug("User is authenticated: Pass.");
                log.debug("current version: " + softwareDto.getVersionCode());
                String strTest = "";

                String currentVersion = softwareDto.getVersionCode();
                // This code needs more research since we will not have secure_access in Postgres dmat database.
                /*strTest = clientAPIDao.updateVersionNumber(userId, softwareDto.getImei(), softwareDto.getImsi(), currentVersion);

                if (strTest == "Success") {*/
                    String latestVersion = currentVersion;
                    boolean currentIsLatest = false;

                    // cdmaless version code is 3 and if the releaseType is 3 it is cdmalessversion
                    if (softwareDto.getReleaseType().equals("3")) {
                        currentIsLatest = checkLatestForCDMALess(currentVersion);
                    } else {
                        currentIsLatest = checkLatest(softwareDto);
                    }

                    if (!currentIsLatest) {
                        SoftwareVersionDto softwareVersionDto = clientAPIDao.getSoftwareVersion(softwareDto);
                        log.debug("Got the Software Latest Version, Updated Version: " + softwareVersionDto.getVersionCode());
                        responseDto.setStatusCode(0);
                        responseDto.setMessage("Got the Software Latest Version");
                        responseDto.setData(softwareVersionDto);
                    } else {
                        responseDto.setErrorCode(1);
                        responseDto.setMessage("You have the latest software version");
                        responseDto.setDeveloperMessage("You have the latest software version");
                    }
                /*} else {
                    log.debug("Update to secure_access Failed.");
                    responseDto.setErrorCode(1);
                    responseDto.setMessage("Update to secure_access Failed.");
                    responseDto.setDeveloperMessage("Update to secure_access Failed.");
                }*/
            } else {
                responseDto.setErrorCode(1);
                responseDto.setMessage("User Authentication Failed");
                responseDto.setDeveloperMessage("User is not available");
            }
        } catch (JSONException ex) {
            log.error("Failed to retrieve Software version Information "+ ex.getMessage());
            responseDto.setErrorCode(1);
            responseDto.setMessage("User Authentication Failed in JSONException");
            responseDto.setDeveloperMessage("User Authentication Failed in JSONException");
        }

        return responseDto;
    }

    @Override
    public byte[] getApkData(String version) {
        return clientAPIDao.getApkData(version);
    }

    @Override
    public ResponseDto addDeviceTestSummary(TestResultsWrapper testResultsWrapper, UserFiltersDto userFiltersDto) {
        ResponseDto responseDto = new ResponseDto();
        try {
            int userId = authenticateUser(userFiltersDto);

            if(userId > 0) {
                String status  = clientAPIDao.addDeviceTestSummary(userId, testResultsWrapper);
                if(status == "Success") {
                    log.debug("Succefully added Device Test Summary");
                    responseDto.setStatusCode(0);
                    responseDto.setMessage("Succefully added Device Test Summary");
                    responseDto.setData("Succefully added Device Test Summary");
                } else {
                    log.error("Failed to add Device Test Summary");
                    responseDto.setErrorCode(1);
                    responseDto.setMessage("Failed to add Device Test Summary");
                    responseDto.setDeveloperMessage("Failed to add Device Test Summary");
                }
            } else {
                writeToFile(environment.getRequiredProperty("dmatLiveExceptionDir"), new Gson().toJson(testResultsWrapper));
                log.debug("User data not found in secure_access.");
                responseDto.setErrorCode(1);
                responseDto.setMessage("Failed to add the device test summary");
                responseDto.setDeveloperMessage("User data not found in secure_access.");
            }
        } catch (JSONException ex) {
            writeToFile(environment.getRequiredProperty("dmatLiveExceptionDir"), new Gson().toJson(testResultsWrapper));
            log.error("Failed to retrieve Software version Information "+ ex.getMessage());
            responseDto.setErrorCode(1);
            responseDto.setMessage("User Authentication Failed in JSONException");
            responseDto.setDeveloperMessage("User Authentication Failed in JSONException");
            ex.printStackTrace();
        }

        return responseDto;
    }

    @Override
    public ResponseDto addInbuildingImage(InbuildingUploadImageDto imageDto, UserFiltersDto userFiltersDto) {
        final ResponseDto responseDto = new ResponseDto();

        try {
            int userId = authenticateUser(userFiltersDto);

            if(userId > 0) {
                String status = clientAPIDao.addInbuildingImage(userId, imageDto);
                if(status == "Success") {
                    log.debug("Succefully added Inbuilding Image");
                    responseDto.setStatusCode(0);
                    responseDto.setMessage("Succefully added Inbuilding Image");
                    responseDto.setData("Succefully added Inbuilding Image");
                } else {
                    log.error("Failed to add dmat Inbuilding Image");
                    responseDto.setErrorCode(1);
                    responseDto.setMessage("Failed to add Inbuilding Image");
                    responseDto.setDeveloperMessage("Failed to add Inbuilding Image");
                }
            } else {
                log.debug("User data not found in users table.");
                responseDto.setErrorCode(1);
                responseDto.setMessage("Failed to add the Inbuilding image data");
                responseDto.setDeveloperMessage("User data not found in users.");
            }
        } catch (JSONException ex) {
            log.error("Failed to add InbuildingImage "+ ex.getMessage());
            responseDto.setErrorCode(1);
            responseDto.setMessage("User Authentication Failed in JSONException");
            responseDto.setDeveloperMessage("User Authentication Failed in JSONException");
            ex.printStackTrace();
        }

        return responseDto;
    }

    /**
     * Adds Wifi Data into Wifi_data_details table.
     * @param wifiDataDto
     * @param userFiltersDto
     * @return
     */
    @Override
    public ResponseDto addWifiData(WifiDataDto wifiDataDto, UserFiltersDto userFiltersDto, WifiDataLocDto wifiDataLocDto) {
        final ResponseDto responseDto = new ResponseDto();
        try {
            int userId = authenticateUser(userFiltersDto);

            if(userId > 0) {
                String status = clientAPIDao.addWifiData(wifiDataDto, userId, wifiDataLocDto);
                if(status == "Success") {
                    log.debug("Succefully added Wifi Data");
                    responseDto.setStatusCode(0);
                    responseDto.setMessage("Succefully added Wifi Data");
                    responseDto.setData("Succefully added Wifi Data");
                } else {
                    log.error("Failed to add dmat Wifi Data");
                    responseDto.setErrorCode(1);
                    responseDto.setMessage("Failed to add Wifi Data due to exception in inserting data into Elastic Search");
                    responseDto.setDeveloperMessage("Failed to add Wifi Data due to exception in inserting data into Elastic Search");
                }
            } else {
                writeToFile(environment.getRequiredProperty("wifiDataExceptionDir"), new Gson().toJson(wifiDataDto)+userId+new Gson().toJson(wifiDataLocDto));
                log.error("Failed to add dmat Wifi Data");
                responseDto.setErrorCode(1);
                responseDto.setMessage("User Authentication Failed");
                responseDto.setDeveloperMessage("User Authentication Failed while adding Wifi Data");
            }
        } catch (JSONException ex) {
            writeToFile(environment.getRequiredProperty("wifiDataExceptionDir"), new Gson().toJson(wifiDataDto)+new Gson().toJson(wifiDataLocDto));
            log.error("Failed to add WifiData "+ ex.getMessage());
            responseDto.setErrorCode(1);
            responseDto.setMessage("User Authentication Failed in JSONException");
            responseDto.setDeveloperMessage("User Authentication Failed in JSONException");
            ex.printStackTrace();
        } catch(Exception e) {
            writeToFile(environment.getRequiredProperty("wifiDataExceptionDir"), new Gson().toJson(wifiDataDto)+new Gson().toJson(wifiDataLocDto));
            log.error("Failed to add WifiData "+ e.getMessage());
            responseDto.setErrorCode(1);
            responseDto.setMessage("Exception in processing data");
            responseDto.setDeveloperMessage("Exception in processing data");
            e.printStackTrace();
        }

        return responseDto;
    }

    public boolean checkLatestForCDMALess(String currentVersion) {
        boolean currentIsLatest = true;
        String latestCDMALessVersion = "";

        latestCDMALessVersion = clientAPIDao.getOlderVersion(currentVersion);

        if(latestCDMALessVersion != null){
            if (Integer.parseInt(latestCDMALessVersion) > Integer.parseInt(currentVersion)) {
                currentIsLatest = false;
            } else {
                currentIsLatest = true;
            }
        }

        return currentIsLatest;
    }

    public boolean checkLatest(SoftwareDto softwareDto) {
        boolean currentIsLatest = true;

        String latestVersionCode = clientAPIDao.getLatest();

        if(latestVersionCode != null && !latestVersionCode.trim().equals("")) {
            if (Integer.parseInt(latestVersionCode) > Integer.parseInt(softwareDto.getVersionCode()) ) {
                currentIsLatest = false;
            }
        } else {
            log.error("latest version code is null in software table");
            throw new DataNotFoundException("latest version code is null in software table");
        }

        return currentIsLatest;
    }

    /**
     * Authenticates user using License Manager.
     * @param userFiltersDto
     * @return
     * @throws JSONException
     */
    private int authenticateUser(UserFiltersDto userFiltersDto) throws JSONException {
        int userId = 0;
        boolean status = false;
        Gson gson = new Gson();
        String element = gson.toJson(userFiltersDto);
        JSONObject request = new JSONObject(element);

        // set headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        // send request and parse result
        ResponseEntity<String> authResp = restTemplate.exchange(environment.getRequiredProperty("lmUrl"), HttpMethod.POST, entity, String.class);

        if (authResp != null && authResp.getStatusCode() == HttpStatus.OK) {
            JSONObject userJson = new JSONObject(authResp.getBody());
            status = userJson.getString("statusCode").equals("0") ? true : false;

            if(status) {
                userId = Integer.parseInt(userJson.getString("userID"));
            }
        }

        return userId;
    }

    /**
     * Sends EventsSummaryEmail for the given request.
     * @param requestDto
     * @return
     */
    @Override
    public ResponseDto sendEventsSummaryEmail(EventsSummaryRequestDto requestDto) {
        final ResponseDto responseDto = new ResponseDto();

        log.debug("Sending Event Summary email notification to the users "+ requestDto.getRecipientEmail());

        String message = "<!DOCTYPE html>" +
                "<html>" +
                "<head>" +
                "<title>EVent Summary Email Api</title>" +
                "<link rel=\"stylesheet\" type=\"text/css\" href=\"main.css\">" +
                "<style>" +
                "table, th, td {" +
                "    border: 1px solid #ccc;" +
                "    border-collapse: collapse;" +
                "}" +
                "th, td {" +
                "    padding: 10px;" +
                "}" +
                "" +
                "" +
                "table tbody tr td:first-child," +
                "table thead tr td:first-child," +
                "table thead tr th:first-child {" +
                "border-right: 0;" +
                "}" +
                "" +
                "table tbody tr td:nth-child(2)," +
                "table thead tr td:nth-child(2)," +
                "table thead tr th:nth-child(2) {" +
                "border-left: 0;" +
                "}" +
                "" +
                "table thead tr th  {" +
                "background: #fff;" +
                "color: #999;" +
                "}" +
                "" +
                "table tbody tr th  {" +
                "color: #999;" +
                "}" +
                "" +
                "table tbody tr td," +
                "table thead tr td," +
                "table thead tr th {" +
                "background: #f4f4f4;" +
                "}" +
                "" +
                ".event-summary-table {" +
                "    width: 30%;" +
                "    margin: auto;" +
                "    border: 10px solid #ccc;" +
                "}" +
                "</style>"+
                "</head>" +
                "<body>" +
                "" +
                "<table class=\"event-summary-table\">" +
                "<thead>" +
                "    <tr>" +
                "        <th colspan=\"5\" style=\"background:#fff;\">" +
                "            Event Stats since: " + requestDto.getEventSummary().getEventStartDate() +
                "        </th>" +
                "    </tr>" +
                "    <tr>" +
                "        <th colspan=\"3\" style=\"width:50%;\">Event Name</th>" +
                "        <th colspan=\"2\">Occurance</th>" +
                "    </tr>" ;
                for(Map.Entry<String,String> pair : requestDto.getEventSummary().getEventOccurrence().entrySet()) {
                    message = message + "    <tr>" +
                            "        <td colspan=\"3\">"+pair.getKey()+"</td>" +
                            "        <td colspan=\"2\">"+pair.getValue()+"</td>" +
                            "    </tr>" ;
                }

        message = message + "</thead>" +
                "<tbody>" +
                "    <tr style=\"border-top: 10px solid #ccc;border-bottom: 10px solid #ccc;\">" +
                "        <th colspan=\"5\">Event Summary</th>" +
                "    </tr>" ;
        for(EventsDto eventsDto : requestDto.getEventSummary().getEvents()) {
            message = message + "    <tr>" +
                    "        <th colspan=\"5\">" + eventsDto.getName() + " : " + eventsDto.getTime() + "</th>" +
                    "    </tr>";
            for(Map.Entry<String,String> pair : eventsDto.getData().getEventCause().entrySet()) {
            message = message + "    <tr>" +
                    "        <td colspan=\"3\" style=\"width:50%;\">"+pair.getKey()+"</td>" +
                    "        <td colspan=\"2\">"+pair.getValue()+"</td>" +
                    "    </tr>";
             }
        }
         message = message +  "</tbody>" +
                "" +
                "</table>" +
                "" +
                "</body>" +
                "</html>";

        String response = emailService.sendEventSummaryEmailList(requestDto.getRecipientEmail(),
                config.getAllConfiguration().get("event_summary_email_subject"),
                message, "Admin", true);

        if(response.equalsIgnoreCase("success")) {
            responseDto.setStatusCode(0);
            responseDto.setMessage("Successfully emailed Event summary");
            responseDto.setData("Successfully emailed Event summary ");
            log.debug("Successfully emailed Event summary ");
        } else {
            responseDto.setErrorCode(1);
            responseDto.setMessage("Failed to email Event summary, Invalid email id ");
            responseDto.setDeveloperMessage("Invalid email id");
            log.debug("Failed to send EventsSummary Email");
        }

        return responseDto;
    }

}
