package com.harman.dmat.service.impl;

import java.util.Map;
import javax.inject.Inject;
import javax.inject.Singleton;
import org.springframework.stereotype.Service;
import com.harman.dmat.dao.ConfigurationDao;
import com.harman.dmat.service.ConfigurationService;

/**
 * The Class ConfigurationServiceImpl.
 */
@Service
@Singleton
public class ConfigurationServiceImpl implements ConfigurationService {

	/** The Configuration dao. */
	@Inject
	private transient ConfigurationDao configurationDao;

	/** The config. */
	private transient Map<String, String> config;

	/*
	 * Getting configuration from database.
	 *
	 * @see com.harman.dmat.service.ConfigurationService#getAllConfiguration()
	 */
	@Override
	public Map<String, String> getAllConfiguration() {
		if (config == null) {
			config = configurationDao.getAllConfigurations();
		}
		return config;
	}
}
