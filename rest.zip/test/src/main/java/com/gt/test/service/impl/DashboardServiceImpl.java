package com.harman.dmat.service.impl;

import com.harman.dmat.common.dto.*;
import com.harman.dmat.dao.DashboardDao;
import com.harman.dmat.service.DashboardService;
import com.harman.dmat.utils.FileProcessingUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.io.File;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Slf4j
@Service
@Transactional
public class DashboardServiceImpl implements DashboardService {

    private static final DateTimeFormatter dtFmtyyyyMMdd = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter dtFmtMMddyyyy = DateTimeFormatter.ofPattern("MMddyyyy");
    static SimpleDateFormat simpleDateFmtMMddyyyy = new SimpleDateFormat("MMddyyyy");
    private static final String failedDirectory = "/failed";
    private static final String processedDirectory = "/processed";

    @Inject
    DashboardDao dashboardDao;

    @Inject
    private Environment environment;

    /**
     * @return
     */
    @Override
    public UserCountDto getUserCount() {
        UserCountDto userCountDto = dashboardDao.getUserCount();
        return userCountDto;
    }

    /**
     * @param userType
     * @param offset
     * @param limit
     * @return
     */
    @Override
    public List<UserDto> getUserList(String userType, int offset, int limit) {
        List<UserDto> userDtoList = dashboardDao.getUserList(userType, offset, limit);
        return userDtoList;
    }

    /**
     * @param offset
     * @param limit
     * @return
     */
    @Override
    public ApkDetailsDto getApkVersionDetails(int offset, int limit) {
        ApkDetailsDto apkDetailsDto = dashboardDao.getApkVersionDetails(offset, limit);
        return apkDetailsDto;
    }

    @Override
    public FilePreProcessResponseDto getFilePreProcessList(String startDate, String endDate, Integer offset, Integer limit) {
        FilePreProcessResponseDto filePreProcessResponseDto = new FilePreProcessResponseDto();
        List<FilePreProcessDto> fileProcessDtoList = dashboardDao.getFilePreProcessingList(startDate, endDate);
        filePreProcessResponseDto.setCount(fileProcessDtoList.size());
        filePreProcessResponseDto.setFilePreProcessDtoList((List<FilePreProcessDto>) getSubList(fileProcessDtoList, offset, limit));
        return filePreProcessResponseDto;
    }

    @Override
    public FilePostProcessResponseDto getFilePostProcessList(String startDate, String endDate, Integer offset, Integer limit) {
        FilePostProcessResponseDto filePostProcessResponseDto = new FilePostProcessResponseDto();
        List<FilePostProcessDto> fileProcessDtoList = dashboardDao.getFilePostProcessingList(startDate, endDate);
        filePostProcessResponseDto.setCount(fileProcessDtoList.size());
        filePostProcessResponseDto.setFilePostProcessDtoList((List<FilePostProcessDto>) getSubList(fileProcessDtoList, offset, limit));
        return filePostProcessResponseDto;
    }

    @Override
    public FileProcessStatusResponseDto getFileProcessStatusReport(String startDate, String endDate, Integer offset, Integer limit) {
        FileProcessStatusResponseDto fileProcessStatusResponseDto = new FileProcessStatusResponseDto();
        List<FileProcessStatusDto> fileProcessDtoList;
        fileProcessDtoList = dashboardDao.getFileProcessStatusList(startDate, endDate);
        fileProcessStatusResponseDto.setCount(fileProcessDtoList.size());
        List<FileProcessStatusDto> fileProcessStatusDtos = (List<FileProcessStatusDto>) getSubList(fileProcessDtoList, offset, limit);
        if (fileProcessStatusDtos.size() > 0) {
            FileProcessStatusDto lastDto = fileProcessStatusDtos.get(0);
            FileProcessStatusDto firstDto = fileProcessStatusDtos.get(fileProcessStatusDtos.size() - 1);
            Map<String, Long[]> esFileRecordCount = dashboardDao.getFileCountRecordCount(firstDto.getFormattedProcessDate(), lastDto.getFormattedProcessDate());
            Map<String, Long> esEventsCount = dashboardDao.getEsEventsCount(firstDto.getFormattedProcessDate(), lastDto.getFormattedProcessDate());

            Calendar reportDay = new GregorianCalendar();
            String[] sStartDate = lastDto.getFormattedProcessDate().split("-");
            reportDay.set(Calendar.DAY_OF_MONTH, Integer.parseInt(sStartDate[2]));
            reportDay.set(Calendar.MONTH, Integer.parseInt(sStartDate[1]) - 1);
            reportDay.set(Calendar.YEAR, Integer.parseInt(sStartDate[0]));

            if (DateUtils.isSameDay(reportDay, Calendar.getInstance())) {
                String stagingDir = environment.getProperty("sftp.stagingdir");
                String sourceDir = environment.getProperty("sftp.sourcedir");
                String spamFileDir = environment.getProperty("sftp.spam");
                lastDto.setFtpFiles(getTotalFilesOnSFTP(stagingDir, sourceDir, spamFileDir, reportDay));
            }

            fileProcessStatusDtos.forEach(fileProcessStatusDto -> {
                Long[] fileDetailsInES = esFileRecordCount.containsKey(fileProcessStatusDto.getFormattedProcessDate()) ? esFileRecordCount.get(fileProcessStatusDto.getFormattedProcessDate()) : null;
                long esEvents = esEventsCount.containsKey(fileProcessStatusDto.getFormattedProcessDate()) ? esEventsCount.get(fileProcessStatusDto.getFormattedProcessDate()) : 0;
                if (fileDetailsInES != null) {
                    fileProcessStatusDto.setEsFiles(fileDetailsInES[0]);
                    fileProcessStatusDto.setEsRecords(fileDetailsInES[1]);
                    fileProcessStatusDto.setEsEvents(esEvents);
                }
            });
        }
        fileProcessStatusResponseDto.setFileProcessStatusDtoList(fileProcessStatusDtos);
        return fileProcessStatusResponseDto;
    }

    @Override
    public FileProcessDirComparisonResponseDto getPhysicalDirComparisonReport(String startDate, String endDate, Integer offset, Integer limit) {
        FileProcessDirComparisonResponseDto fileDirComparisonDtos = new FileProcessDirComparisonResponseDto();
        try {
            List<FileProcessDirComparisonDto> dirComparisonList = dashboardDao.getPhysicalDirComparisonList(startDate, endDate);
            if (endDate != null) {
                String[] endDateInd = endDate.split("-");
                LocalDate localEndDate = LocalDate.of(Integer.parseInt(endDateInd[0]), Integer.parseInt(endDateInd[1]), Integer.parseInt(endDateInd[2]));
                LocalDate localToday = LocalDate.now();
                if (localEndDate.isEqual(localToday)) {
                    String stagingDir = environment.getProperty("sftp.stagingdir");
                    FileProcessDirComparisonDto dirComparisonDto = getDirectoryStats(localEndDate, stagingDir);
                    dirComparisonList.removeIf(dto -> dto.getFormattedProcessDate().equals(endDate));
                    dirComparisonList.add(0, dirComparisonDto);
                }
            }
            fileDirComparisonDtos.setCount(dirComparisonList.size());
            fileDirComparisonDtos.setFileProcessDirComparisonDtoList((List<FileProcessDirComparisonDto>) getSubList(dirComparisonList, offset, limit));
        } catch (Exception e) {
            log.error("Exception in getPhysicalDirComparisonReport: {}, {}", e.getMessage(), e);
        }
        return fileDirComparisonDtos;
    }

    private static long getTotalFilesOnSFTP(String stagingDir, String sourceDir, String spamFileDir, Calendar reportDay) {
        Calendar dayBefore = Calendar.getInstance();
        dayBefore.set(reportDay.get(Calendar.YEAR), reportDay.get(Calendar.MONTH), (reportDay.get(Calendar.DAY_OF_MONTH) - 1), reportDay.get(Calendar.HOUR_OF_DAY), reportDay.get(Calendar.MINUTE), reportDay.get(Calendar.SECOND));
        String currentDir = stagingDir + "/" + simpleDateFmtMMddyyyy.format(reportDay.getTime());
        long fileInFTP = 0;
        try {
            int notPicked;
            int inProcInd;
            long inProcPart;
            int spamFileCount = 0;
            long failed;
            long indFiles;
            long partFiles;

            File[] newFiles = FileProcessingUtil.listCompleteFiles(new File(sourceDir));//Total Files Still Not Picked up by process
            notPicked = (newFiles != null) ? newFiles.length : 0;

            File[] inProcessFilesInd = FileProcessingUtil.listCompleteFiles(new File(stagingDir));//Total IN-PROCESS Individual Files
            inProcInd = (inProcessFilesInd != null) ? inProcessFilesInd.length : 0;

            Set<String> totalProcDir = FileProcessingUtil.listDir(stagingDir + "/multiPart");
            inProcPart = totalProcDir.stream().mapToLong(FileProcessingUtil::listFiles).sum();

            File[] spamFiles = FileProcessingUtil.listFiles(new File(spamFileDir));//Total SPAM/JUNK/UNKNOWN Files
            if (spamFiles != null && spamFiles.length > 0) {
                for (File sf : spamFiles) {
                    if (sf.lastModified() <= reportDay.getTimeInMillis() && sf.lastModified() >= dayBefore.getTimeInMillis()) {
                        spamFileCount++;
                    }
                }
            }

            failed = FileProcessingUtil.listFiles(currentDir + failedDirectory);
            indFiles = FileProcessingUtil.listFiles(currentDir + processedDirectory);

            Set<String> totalprocessedDir = FileProcessingUtil.listDir(stagingDir + processedDirectory);
            partFiles = totalprocessedDir.stream().mapToLong(FileProcessingUtil::listFiles).sum();

            fileInFTP = notPicked + inProcInd + inProcPart + spamFileCount + indFiles + partFiles + failed;

        } catch (Exception e) {
            log.error("ERROR getting directory stats for " + currentDir + ": " + e.getMessage(), e);
        }
        return fileInFTP;
    }

    private static FileProcessDirComparisonDto getDirectoryStats(LocalDate dateTime, String stageDir) {
        FileProcessDirComparisonDto dirModel = new FileProcessDirComparisonDto();
        String currentDir = stageDir + "/" + dateTime.format(dtFmtMMddyyyy);
        try {
            String repDate = dateTime.format(dtFmtyyyyMMdd);
            dirModel.setProcessDate(repDate);

            dirModel.setFilesFailed(FileProcessingUtil.listFiles(currentDir + failedDirectory));
            dirModel.setIndividualFiles(FileProcessingUtil.listFiles(currentDir + processedDirectory));

            Set<String> totalProcDir = FileProcessingUtil.listDir(currentDir + processedDirectory);
            dirModel.setPartDirCount((long) totalProcDir.size());

            long partFileTot = totalProcDir.stream().mapToLong(FileProcessingUtil::listFiles).sum();
            dirModel.setTotalPartFiles(partFileTot);
        } catch (Exception e) {
            log.error("ERROR getting directory stats for {} : {}", currentDir, e);
        }
        return dirModel;
    }

    private List<? extends Object> getSubList(List<? extends Object> fileProcessDtoList, Integer offset, Integer limit) {
        int size = fileProcessDtoList.size();
        int fromIndex = offset != null ? offset - 1 : 0;
        int toIndex = limit != null ? fromIndex + limit : size;
        if (fromIndex <= size && size > 0) {
            return fileProcessDtoList.subList(fromIndex, toIndex <= size ? toIndex : size);
        } else {
            return Collections.emptyList();
        }
    }
}
