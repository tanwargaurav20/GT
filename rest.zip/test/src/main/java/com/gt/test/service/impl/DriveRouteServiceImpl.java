
package com.harman.dmat.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.dao.DriveRouteDao;
import com.harman.dmat.service.DriveRouteService;
import com.harman.dmat.utils.Utill;
import lombok.extern.slf4j.Slf4j;

/**
 * @author GTanwar Interacts with the Elastic Search DAO layer
 *
 */
@Slf4j
@Service
@Transactional
public class DriveRouteServiceImpl implements DriveRouteService {

	@Autowired
	DriveRouteDao driveRouteDao;

	@Override
	public List<String> getLatLon(String fileName, String startDate, String endDate) throws DataNotFoundException {

		String query = null;
		StringBuffer sb = new StringBuffer();
		sb.append("[");

		for (String testId : fileName.split(",")) {
			sb.append("\"").append(testId).append("\"").append(",");
		}

		String s = sb.substring(0, sb.length() - 1) + "]";

		query = "{ \"size\": 10, \"_source\": { \"includes\": [ \"lat\", \"lon\"], \"excludes\": [] },\"query\": { \"bool\": { \"must\": [ { \"query_string\": { \"query\": \"_exists_:LTEPccRsrp\" } },"
				+ " { \"match_phrase\": { \"Outlier\": { \"query\": 0, \"slop\": 0, \"boost\": 1 } } }, { \"terms\": { \"FileName\":"
				+ s + " } },"
				+ " { \"bool\": { \"must_not\": [ { \"bool\": { \"must_not\": [ { \"exists\": { \"field\": \"LTEPccRsrp\", \"boost\": 1 } } ]"
				+ " } } ] } } ] } } }";

		String indices = Utill.getIndex(startDate, endDate);

		if (log.isDebugEnabled()){
			log.debug("Drive route Query formed: " + query);
			log.debug("Drive route Indices: " + indices);
		}
		return driveRouteDao.getLatLon(query, indices);
	}

}