package com.harman.dmat.service.impl;

import com.harman.dmat.common.dto.ENodeBidRequestDto;
import com.harman.dmat.dao.ENodeBidDao;
import com.harman.dmat.service.ENodeBidService;
import com.harman.dmat.utils.Utill;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.Arrays;
import java.util.List;

@Service
@Slf4j
public class ENodeBidServiceImpl implements ENodeBidService {
    @Inject
    ENodeBidDao eNodeBidDao;

    @Inject
    Environment environment;

    @Override
    public List<String> getENodeBids(ENodeBidRequestDto requestDto) {
        String indices = Utill.getIndex(requestDto.getFromDate(), requestDto.getToDate());
        String query = getENodeBidQuery(requestDto);

        if (log.isDebugEnabled()) {
            log.debug("getDeviceStats Query formed: " + query);
            log.debug("Indices: " + indices);
        }
        return eNodeBidDao.getENodeBids(query, indices);
    }

    /**
     * Returns ENodeBidQuery for the given request.
     * @param requestDto
     * @return
     */
    private String getENodeBidQuery(ENodeBidRequestDto requestDto) {
        return "{" +
                "  \"size\": 0," +
                "  \"query\": {" +
                "    \"bool\": {" +
                "      \"must\": [" +
                "        {" +
                "          \"query_string\": {" +
                "            \"query\": \"_exists_:LTEeNBId\"" +
                "          }" +
                "        }," +
                "        {" +
                "          \"range\": {" +
                "            \"TimeStamp\": {" +
                "              \"from\": \"" + requestDto.getFromDate() +
                "\"," +
                "              \"to\": \"" + requestDto.getToDate() +
                "\"," +
                "              \"include_lower\": true," +
                "              \"include_upper\": true," +
                "              \"boost\": 1" +
                "            }" +
                "          }" +
                "        } "+ getDomainESQuery(requestDto.getDomain()) + getUserQuery(requestDto.getUserId()) +
                "      ]," +
                "      \"must_not\": [" +
                "        {" +
                "          \"exists\": {" +
                "            \"field\": \"InbuildinguserMark\"" +
                "          }" +
                "        }" +
                "      ]," +
                "      \"filter\": {" +
                "        \"geo_bounding_box\": {" +
                "          \"loc\": {" +
                "            \"top_left\": {" +
                "              \"lat\": " + requestDto.getTlLat() +
                "," +
                "              \"lon\": " + requestDto.getTlLon() +
                "" +
                "            }," +
                "            \"bottom_right\": {" +
                "              \"lat\": " + requestDto.getBrLat() +
                "," +
                "              \"lon\": " + requestDto.getBrLon() +
                "" +
                "            }" +
                "          }" +
                "        }" +
                "      }" +
                "    }" +
                "  }," +
                "  \"aggs\": {" +
                "    \"LTEeNBId\": {" +
                "      \"terms\": {" +
                "        \"field\": \"LTEeNBId\"," +
                "        \"size\": 50000" +
                "      }" +
                "    }" +
                "  }" +
                "}";
    }

    /**
     * Returns userQuery for a given userId, returns nothing if the userId is ALL.
     * @param userId
     * @return
     */
    private String getUserQuery(String userId) {
        String userQuery = "";
        if (!userId.equalsIgnoreCase("ALL")) {
            userQuery = ",{" + "\"terms\": {" + "\"DmUser\": [\"" + userId + "\"]" + "}" + "}";
        }

        return userQuery;
    }

    /**
     * Creates the domain SQL query
     *
     * @param userDomain
     * @return
     */
    private String getDomainESQuery(String userDomain) {
        String domainQuery = "";
        userDomain = userDomain == null ? "null" : userDomain;
        StringBuffer sb = new StringBuffer();
        try {
            List<String> listVzDomains = Arrays.asList(environment.getRequiredProperty("verizon.domains").split(","));

            if (listVzDomains.contains(userDomain)) {
                for (String domain : listVzDomains) {
                    sb = sb.append("{ \"query_string\": { \"query\": \"EmailId:*").append(domain).append("\"} },");
                }
                sb.deleteCharAt(sb.length() - 1);
                domainQuery = ", { \"bool\": { \"should\": [" + sb.toString() + "] } }";
            } else {
                sb = sb.append("{ \"query_string\": { \"query\": \"EmailId:*").append(userDomain.toLowerCase())
                        .append("\"} }");
                domainQuery = ", { \"bool\": { \"must\": [" + sb.toString() + "] } }";
            }
        } catch (Exception e) {
            log.error("Error Getting Vz domains");
        }

        return domainQuery;
    }

}
