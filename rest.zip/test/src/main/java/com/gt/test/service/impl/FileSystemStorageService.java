package com.harman.dmat.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

import javax.inject.Inject;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;

import com.harman.dmat.common.exception.StorageException;
import com.harman.dmat.common.exception.StorageFileNotFoundException;
import com.harman.dmat.service.StorageService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author insnayak20
 *
 */
@Slf4j
@Service
public class FileSystemStorageService implements StorageService {

	/**
	 * Path
	 * FileSystemStorageService.java
	 */
	private final Path rootLocation;

	/**
	 * insnayak20
	 * @param properties
	 */
	@Inject
	public FileSystemStorageService(StorageProperties properties) {
		this.rootLocation = Paths.get(properties.getLocation());
		deleteAll();
		init();
	}

	@Override
	public Path getRootLocation() {
		return this.rootLocation;
	}

	/**
	 * insnayak20
	 * store
	 * void
	 * @param file
	 */
	@Override
	public void store(MultipartFile file) {
		try {
			if (file.isEmpty()) {
				log.error("empty multipart request ");
				throw new StorageException("Failed to store empty file " + file.getOriginalFilename());
			}
			log.info("inside  the method uploadLegends with the file {}", file.getOriginalFilename());
			Files.copy(file.getInputStream(), this.rootLocation.resolve(file.getOriginalFilename()));
		} catch (final IOException ioException) {	
			if(!(ioException instanceof FileAlreadyExistsException)){
			log.error("error in storing the file  ",ioException);
			throw new StorageException("Failed to store file " + file.getOriginalFilename(), ioException);
			}
		}
	}

	/**
	 * insnayak20
	 * store
	 * void
	 * @param file
	 */
	@Override
	public void store(File file) {
		try {
			if (!file.exists()) {
				log.error("falied to store the file because the file already exist in the dir");
				throw new StorageException("Failed to store empty file ");
			}
			log.info("saving the file {}",file.getName());
			Files.copy(this.rootLocation.resolve(file.getName()), new FileOutputStream(file));
		} catch (final IOException ioException) {
			log.error("error in storing the file ",ioException);
			throw new StorageException("Failed to store file ");
		}
	}

	/**
	 * insnayak20
	 * loadAll
	 * Stream<Path>
	 * @return
	 */
	@Override
	public Stream<Path> loadAll() {
		try {
			return Files.walk(this.rootLocation, 1).filter(path -> !path.equals(this.rootLocation))
					.map(path -> this.rootLocation.relativize(path));
		} catch (final IOException ioException) {
			log.error("error in loading all files ",ioException);
			throw new StorageException("Failed to read stored files", ioException);
		}

	}

	/**
	 * insnayak20
	 * load
	 * Path
	 * @param filename
	 * @return
	 */
	@Override
	public Path load(String filename) {
		return rootLocation.resolve(filename);
	}

	/**
	 * insnayak20
	 * loadAsResource
	 * Resource
	 * @param filename
	 * @return
	 */
	@Override
	public Resource loadAsResource(String filename) {
		try {
			final Path file = load(filename);
			final Resource resource = new UrlResource(file.toUri());
			if (resource.exists() || resource.isReadable()) {
				return resource;
			} else {
				log.error("file not found in the location with the name {}",filename);
				throw new StorageFileNotFoundException("Could not read file: " + filename);

			}
		} catch (final MalformedURLException e) {
			log.error("url for the resource not correct file: {}",filename,e);
			throw new StorageFileNotFoundException("Could not read file: " + filename, e);
		}
	}

	/**
	 * insnayak20
	 * deleteAll
	 * void
	 */
	@Override
	public void deleteAll() {
		log.info("deleting all the files in path {}", rootLocation);
		FileSystemUtils.deleteRecursively(rootLocation.toFile());
	}

	
	
	/**
	 * insnayak20
	 * init
	 * void
	 */
	@Override
	public void init() {
		try {
			Files.createDirectory(rootLocation);
		} catch (final IOException e) {
			log.error("unable to create the dir in the root location",e);
			throw new StorageException("Could not initialize storage", e);
		}
	}

	/**
	 * insnayak20
	 * deleteFile
	 * boolean
	 * @param path
	 * @return
	 */
	@Override
	public boolean deleteFile(Path path) {
		try {
			log.info("deleteing the file :{}", path.toString());
			return Files.deleteIfExists(path);
		} catch (final IOException exception) {
			log.error("IOException in deleting the file ", exception);
			throw new StorageException("unable to delete the file ", exception);
		}
	}
}
