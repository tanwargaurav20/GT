package com.harman.dmat.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;

import com.harman.dmat.common.dto.*;
import com.harman.dmat.utils.Utill;
import org.springframework.core.env.Environment;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.harman.dmat.common.exception.DataAccessException;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.GlobalFilterException;
import com.harman.dmat.common.exception.InActiveStatusException;
import com.harman.dmat.common.exception.InvalidRequestPayloadException;
import com.harman.dmat.common.security.User;
import com.harman.dmat.dao.GlobalFilterDao;
import com.harman.dmat.dao.UserDao;
import com.harman.dmat.service.GlobalFilterService;
import lombok.extern.slf4j.Slf4j;

/** The Constant log. */
@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
public class GlobalFilterServiceImpl implements GlobalFilterService {
    @Inject
    Environment environment;

	/** The global filter dao. */
	@Inject
	GlobalFilterDao globalFilterDao;

	/** The user dao. */
	@Inject
	UserDao userDao;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.GlobalFilterService#getModelData(java.lang.
	 * Integer)
	 */
	@Override
	public List<ModelDto> getModelData(Integer userId) throws DataNotFoundException, DataAccessException {
		final List<ModelDto> models = new ArrayList<ModelDto>();
		final StatusDto statusDto = globalFilterDao.getStatus(userId);
		if (statusDto == null) {
			log.error("Global Filter: data not found for user.");
			throw new DataNotFoundException();
		} else {
			if (statusDto.getIsActive() > 0 && statusDto.getUserId() > 0) {
				try {
					final List<Integer> modelsId = globalFilterDao.getModelId(userId);
					for (final Integer modelId : modelsId) {
						final ModelDto model = globalFilterDao.getUserModelData(modelId);
						models.add(model);
					}
				} catch (final Exception e) {
					log.error("Global Filter: Error getting model data for user.");
					throw new DataAccessException();
				}
			} else {
				log.error("Global Filter: Either user is inactive or not exist.");
				throw new InActiveStatusException();

			}
		}
		return models;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.GlobalFilterService#getAllModels(java.lang.
	 * Integer, java.lang.Integer)
	 */
	@Override
	public List<ModelDto> getAllModels(Integer offset, Integer limit) throws DataAccessException {
		List<ModelDto> models = null;
		try {
			models = globalFilterDao.getAllModelData(offset, limit);
		} catch (final Exception e) {
			throw new DataAccessException(e);
		}

		return models;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.GlobalFilterService#getImeiData(java.lang.
	 * Integer)
	 */
	@Override
	public List<ImeiDto> getImeiData(Integer value) throws DataNotFoundException, DataAccessException {
		List<ImeiDto> imeis = null;
		StatusDto statusDto = null;
		try {
			statusDto = globalFilterDao.getStatus(value);
		} catch (final Exception e) {
			log.error("Global Filter: Error getting status data for user.");
			throw new DataNotFoundException();
		}
		if (statusDto.getIsActive() > 0 && statusDto.getUserId() > 0) {
			try {
				imeis = globalFilterDao.getUserImeiData(statusDto.getUserId());
			} catch (final Exception e) {
				log.error("Global Filter: Error getting Imei data for user.");
				throw new DataAccessException();
			}
		} else {
			log.error("Global Filter: Either user is inactive or not exist.");
			throw new InActiveStatusException();
		}
		return imeis;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.GlobalFilterService#getUserMdnData(java.lang.
	 * Integer)
	 */
	@Override
	public List<ImeiDto> getUserMdnData(Integer value) throws DataNotFoundException, DataAccessException {
		List<ImeiDto> mdns = null;
		StatusDto statusDto = null;
		try {
			statusDto = globalFilterDao.getStatus(value);
		} catch (final Exception e) {
			log.error("Global Filter: Error getting status data for user.");
			throw new DataNotFoundException();
		}
		if (statusDto.getIsActive() > 0 && statusDto.getUserId() > 0) {
			try {
				mdns = globalFilterDao.getUserMdnData(statusDto.getUserId());
			} catch (final Exception e) {
				log.error("Global Filter: Error getting Mdn data for user.");
				throw new DataAccessException();
			}
		} else {
			log.error("Global Filter: Either user is inactive or not exist.");
			throw new InActiveStatusException();
		}
		return mdns;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.GlobalFilterService#getAllImeiData(java.lang.
	 * Integer, java.lang.Integer)
	 */
	@Override
	public List<ImeiDto> getAllImeiData(Integer offset, Integer limit) throws DataAccessException {
		try {
			return globalFilterDao.getAllImeiData(offset, limit);
		} catch (final Exception e) {
			throw new DataAccessException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.GlobalFilterService#getAllMdnData(java.lang.
	 * Integer, java.lang.Integer)
	 */
	@Override
	public List<ImeiDto> getAllMdnData(Integer offset, Integer limit) throws DataAccessException {
		try {
			return globalFilterDao.getAllMdnData(offset, limit);
		} catch (final Exception e) {
			throw new DataAccessException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.GlobalFilterService#getUserLogData(java.lang.
	 * Integer, java.lang.Integer, java.lang.Integer)
	 */
	@Override
	public List<LogMgrDto> getUserLogData(Integer userId, Integer offset, Integer limit)
			throws DataNotFoundException, DataAccessException {
		List<LogMgrDto> loglist = null;
		StatusDto statusDto = null;
		try {
			statusDto = globalFilterDao.getStatus(userId);
		} catch (final Exception e) {
			log.error("Global Filter: Error getting status data for user");
			throw new DataNotFoundException();
		}
		if (statusDto.getIsActive() > 0 && statusDto.getUserId() > 0) {
			try {
				loglist = globalFilterDao.getUserLogData(userId, offset, limit);
			} catch (final Exception e) {
				log.error("Global Filter: Error getting log data for user.");
				throw new DataAccessException();
			}
		} else {
			log.error("Global Filter: Either user is inactive or not exist.");
			throw new InActiveStatusException();
		}

		return loglist;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.GlobalFilterService#getAllLogData(java.lang.
	 * Integer, java.lang.Integer)
	 */
	@Override
	public List<LogMgrDto> getAllLogData(Integer offset, Integer limit) throws DataAccessException {
		try {
			return globalFilterDao.getAllLogs(offset, limit);
		} catch (final Exception e) {
			log.error("Error occured during getting all states." + e);
			throw new DataAccessException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.GlobalFilterService#getUserStateData(java.lang.
	 * Integer)
	 */
	@Override
	public List<StateDto> getUserStateData(Integer userId) throws DataNotFoundException, DataAccessException {
		List<StateDto> loglist = null;
		StatusDto statusDto = null;
		try {
			statusDto = globalFilterDao.getStatus(userId);
		} catch (final Exception e) {
			log.error("Global Filter: Error getting status data for user.");
			throw new DataNotFoundException();
		}
		if (statusDto.getIsActive() > 0 && statusDto.getUserId() > 0) {
			try {
				loglist = globalFilterDao.getUserStateData(userId);
			} catch (final Exception e) {
				log.error("Global Filter: Error getting state data for user.");
				throw new DataAccessException();
			}
		} else {
			log.error("Global Filter: Either user is inactive or not exist.");
			throw new InActiveStatusException();
		}
		return loglist;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.GlobalFilterService#getFilterData(java.lang.
	 * String, java.lang.String, java.lang.Integer, java.lang.Integer,
	 * java.lang.String, java.lang.String, java.lang.Integer, java.lang.String,
	 * java.lang.String, java.lang.String)
	 */
	@Override
	public List<GlobalFilterDto> getFilterData(String user, String startDate, String endDate, String mdn, Integer model,
			String fileName, String imei) throws GlobalFilterException {
		List<GlobalFilterDto> globalFilResDto;
		try {
			globalFilResDto = globalFilterDao.getFilterResults(user, startDate, endDate, mdn, model, fileName, imei);
			Integer userId = null;
			if (user != null && !user.equalsIgnoreCase("ALL")) {
				userId = Integer.parseInt(user);
			}
			final List<UserLogFileDto> userLogFiles = getUserLogFiles(userId, startDate, endDate, null, 10, 10, 0, mdn,
					model, imei);
			globalFilResDto.get(0).setUserLogFiles(userLogFiles);
			if (globalFilResDto != null && !globalFilResDto.isEmpty()) {
				final Integer loinUserId = ((User) SecurityContextHolder.getContext().getAuthentication()
						.getPrincipal()).getUserId();
				final List<GroupDto> groups = userDao.getUserGroups(loinUserId);
				final Map<Integer, List<UserDto>> groupUsers = userDao.getGroupUsers(loinUserId);
				for (final GroupDto groupDto : groups) {
					groupDto.setUsers(groupUsers.get(groupDto.getGroupId()));
					globalFilResDto.get(0).setGroupDtos(groups);
				}

			}

		} catch (final InvalidRequestPayloadException e) {
			log.error("Global Filter: Error getting Data." + e);
			throw new InvalidRequestPayloadException(e);
		} catch (final Exception e) {
			log.error("Global Filter: Error getting Data." + e);
			throw new GlobalFilterException(e);
		}

		return globalFilResDto;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.GlobalFilterService#getAllStateData(java.lang.
	 * Integer, java.lang.Integer)
	 */
	@Override
	public List<StateDto> getAllStateData(Integer offset, Integer limit) throws DataAccessException {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.GlobalFilterService#getUserLogFiles(java.lang.
	 * Integer, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.Integer, java.lang.Integer)
	 */
	@Override
	public List<UserLogFileDto> getUserLogFiles(Integer userId, String startDate, String endDate, String token,
			Integer userLimit, Integer fileLimit, Integer offset, String mdn, Integer model, String imei)
			throws GlobalFilterException {
		try {
			return globalFilterDao.getUserLogFiles(userId, startDate, endDate, token, userLimit, fileLimit, offset, mdn,
					model, imei);

		} catch (final InvalidRequestPayloadException e) {
			log.error("User Log Files: Error getting Data." + e);
			throw new InvalidRequestPayloadException(e);
		} catch (final Exception e) {
			if (!(e instanceof EmptyResultDataAccessException)) {
				log.error("User Log Files: Error getting Data." + e);
				throw new GlobalFilterException(e);
			}
			return new ArrayList<>();
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.GlobalFilterService#getMdns(java.lang.Integer,
	 * java.lang.String, java.lang.String,
	 * com.harman.dmat.common.dto.GlobalFilterRequestDto)
	 */
	@Override
	public List<String> getMdns(Integer userId, String startDate, String endDate,
			GlobalFilterRequestDto globalFilterDtos) throws GlobalFilterException {
		try {
			return globalFilterDao.getMdns(userId, startDate, endDate, globalFilterDtos);
		} catch (final Exception e) {
			log.error("User Log Files: Error getting Data." + e);
			throw new GlobalFilterException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.GlobalFilterService#getImeis(java.lang.Integer,
	 * java.lang.String, java.lang.String,
	 * com.harman.dmat.common.dto.GlobalFilterRequestDto)
	 */
	@Override
	public List<String> getImeis(Integer userId, String startDate, String endDate,
			GlobalFilterRequestDto globalFilterDtos) throws GlobalFilterException {
		try {
			List<String> list = globalFilterDao.getImeis(userId, startDate, endDate, globalFilterDtos);
			list.replaceAll(x -> new BigDecimal(Double.valueOf(x)).toString());
			return list;
		} catch (final Exception e) {
			log.error("Imeis: Error getting Data." + e);
			throw new GlobalFilterException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.GlobalFilterService#getModels(java.lang.Integer,
	 * java.lang.String, java.lang.String,
	 * com.harman.dmat.common.dto.GlobalFilterRequestDto)
	 */
	@Override
	public List<String> getModels(Integer userId, String startDate, String endDate,
			GlobalFilterRequestDto globalFilterDtos) throws GlobalFilterException {
		try {
			return globalFilterDao.getModels(userId, startDate, endDate, globalFilterDtos);
		} catch (final Exception e) {
			log.error("Models: Error getting Data." + e);
			throw new GlobalFilterException(e);
		}
	}

	@Override
	public GlobalFilterDataDto getFilterDataFromES(String userId, String startDate, String endDate, String domain, String tl_lat, String tl_lon, String br_lat, String br_lon, int fileOffset, int userOffset) throws GlobalFilterException {
		try {
			String query = getFilterDataQuery(startDate, endDate, userId, domain, tl_lat, tl_lon, br_lat, br_lon, fileOffset, userOffset);
			String indices = Utill.getIndex(startDate, endDate);

			if (log.isDebugEnabled()) {
				log.debug("Global Filter Data Query formed: " + query);
				log.debug("Indices: " + indices);
			}
            GlobalFilterDataDto globalFilterDataDto = globalFilterDao.getFilterDataFromES(query, indices);
            if(userId.equals("All")) {
            	Map<String, List<UserDto>> userGroups = globalFilterDao.getUserGroups();
            	globalFilterDataDto.setUserGroups(userGroups);
            }
			return globalFilterDataDto;
		} catch (final Exception e) {
			log.error("FilteredData: Error getting Filtered Data." + e);
			throw new GlobalFilterException(e);
		}
	}

	private String getFilterDataQuery(String startDate, String endDate, String userId, String domain, String tl_lat,
									  String tl_lon, String br_lat, String br_lon, int fileOffset, int userOffset) {
		String query = "";
		String domainQuery = getDomainESQuery(domain);

		if(userOffset == 0) {
			userOffset = 10;
		}

		query = query + "{" +
                "  \"size\": 0," +
                "  \"query\": {" +
                "    \"bool\": {" +
                "      \"must\": [" + ((userId != null && userId.equalsIgnoreCase("ALL")) ? "" : getUserQuery(userId)) +
                "        {" +
                "          \"range\": {" +
                "            \"TimeStamp\": {" +
                "              \"from\": \"" + startDate +
                "\"," +
                "              \"to\": \"" + endDate +
                "\"," +
                "              \"include_lower\": true," +
                "              \"include_upper\": true," +
                "              \"boost\": 1" +
                "            }" +
                "          }" +
                "        }" +
                domainQuery +
                "      ], \"must_not\": [ { \"exists\": { \"field\": \"InbuildinguserMark\" } } ]," +
                "      \"filter\": [" +
                "        {" +
                "          \"geo_bounding_box\": {" +
                "            \"loc\": {" +
                "              \"top_left\": {" +
                "                \"lat\": " + tl_lat +
                "," +
                "                \"lon\": " + tl_lon +
                "" +
                "              }," +
                "              \"bottom_right\": {" +
                "                \"lat\": " + br_lat +
                "," +
                "                \"lon\": " + br_lon +
                "" +
                "              }" +
                "            }" +
                "          }" +
                "        }" +
                "      ]" +
                "    }" +
                "  }," +
                "  \"aggs\": {" +
                "    \"ModelName\": {" +
                "      \"terms\": {" +
                "        \"field\": \"ModelName\"," +
                "        \"size\": 1000" +
                "      }" +
                "    }," +
                "    \"Imei\": {" +
                "      \"terms\": {" +
                "        \"field\": \"Imei\"," +
                "        \"size\": 1000" +
                "      }" +
                "    }," +
                "    \"MDN\": {" +
                "      \"terms\": {" +
                "        \"field\": \"MDN\"," +
                "        \"size\": 1000" +
                "      }" +
                "    }," +
                "    \"StateCode\": {" +
                "      \"terms\": {" +
                "        \"field\": \"StateCode\"," +
                "        \"size\": 1000" +
                "      }" +
                "    }," +
				"	\"DmUser\": {" +
				"      \"terms\": {" +
				"        \"field\": \"DmUser\"," +
				"        \"size\": " + userOffset +
				"" +
				"      }," +
				"      \"aggs\": {" +
				"        \"FileName\": {" +
				"          \"terms\": {" +
				"            \"field\": \"FileName\"," +
				"            \"size\": " + fileOffset +
				"" +
				"          }" +
				"        }," +
				"        \"FirstName\": {" +
				"          \"terms\": {" +
				"            \"field\": \"FirstName\"," +
				"            \"size\": 1000" +
				"          }" +
				"        }," +
				"        \"LastName\": {" +
				"          \"terms\": {" +
				"            \"field\": \"LastName\"," +
				"            \"size\": 1000" +
				"          }" +
				"        }" +
				"      }" +
				"    }"+
                "  }," +
                "  \"_source\": false" +
                "}";

		return query;
	}

    private String getUserQuery(String userId) {
        String userQuery = "";
        if (!userId.equalsIgnoreCase("ALL")) {
            userQuery = "{" + "\"terms\": {" + "\"DmUser\": [\"" + userId + "\"]" + "}" + "},";
        }

        return userQuery;
    }

    /**
     * Creates the domain SQL query
     *
     * @param userDomain
     * @return
     */
    private String getDomainESQuery(String userDomain) {
        String domainQuery = "";
        userDomain = userDomain == null ? "null" : userDomain;
        StringBuffer sb = new StringBuffer();
        try {
            List<String> listVzDomains = Arrays.asList(environment.getRequiredProperty("verizon.domains").split(","));

            if (listVzDomains.contains(userDomain)) {
                for (String domain : listVzDomains) {
                    sb = sb.append("{ \"query_string\": { \"query\": \"EmailId:*").append(domain).append("\"} },");
                }
                sb.deleteCharAt(sb.length() - 1);
                domainQuery = ", { \"bool\": { \"should\": [" + sb.toString() + "] } }";
            } else {
                sb = sb.append("{ \"query_string\": { \"query\": \"EmailId:*").append(userDomain.toLowerCase())
                        .append("\"} }");
                domainQuery = ", { \"bool\": { \"must\": [" + sb.toString() + "] } }";
            }
        } catch (Exception e) {
            log.error("Error Getting Vz domains");
        }

        return domainQuery;
    }

}