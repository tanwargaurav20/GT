package com.harman.dmat.service.impl;

import com.harman.dmat.common.dto.HeatMapRequestDto;
import com.harman.dmat.common.dto.HeatMapResponseDto;
import com.harman.dmat.dao.HeatMapDao;
import com.harman.dmat.service.HeatMapService;
import com.harman.dmat.utils.Utill;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import javax.inject.Inject;

/**
 * HeatMap API calls are handled by this service.
 */
@Slf4j
@Service
public class HeatMapServiceImpl implements HeatMapService {
    @Inject
    Environment environment;

    @Autowired
    HeatMapDao heatMapDao;

    @Override
    public HeatMapResponseDto getHeatMapLocations(HeatMapRequestDto heatMapRequestDto) {
        String cdmaLessFalseQuery = getHeatMapQueryForCdmalessFalse(heatMapRequestDto);
        String cdmaLessTrueQuery = getHeatMapQueryForCdmalessTrue(heatMapRequestDto);

        String indices = Utill.getIndex(heatMapRequestDto.getTimeStampFrm(), heatMapRequestDto.getTimeStampTo());

        if (log.isDebugEnabled()) {
            log.debug("HeatMap List Query formed: " + cdmaLessFalseQuery);
            log.debug("Indices: " + indices);
        }

        HeatMapResponseDto heatMapResponseDto = new HeatMapResponseDto();

        if(heatMapRequestDto.isCdmaless()) {
            heatMapResponseDto = heatMapDao.getHeatMapLocations(cdmaLessTrueQuery, indices, heatMapRequestDto.getLocCode());
        } else {
            heatMapResponseDto = heatMapDao.getHeatMapLocations(cdmaLessFalseQuery, indices, heatMapRequestDto.getLocCode());
        }

        return heatMapResponseDto;
    }

    private String getHeatMapQueryForCdmalessFalse(HeatMapRequestDto heatMapRequestDto) {
        String query = "{" +
                "  \"from\": 0," +
                "  \"size\": 0," +
                "  \"query\": {" +
                "    \"bool\": {" +
                "      \"must\": {" +
                "        \"range\": {" +
                "          \"TimeStamp\": {" +
                "            \"from\": \"" + heatMapRequestDto.getTimeStampFrm() +"\"," +
                "            \"to\": \"" + heatMapRequestDto.getTimeStampTo() +"\"," +
                "            \"include_lower\": true," +
                "            \"include_upper\": true" +
                "          }" +
                "        }" +
                "      }," +
                "      \"filter\": {" +
                "        \"geo_bounding_box\": {" +
                "          \"loc\": {" +
                "            \"top_left\": {" +
                "              \"lat\": " + heatMapRequestDto.getTlLat() +
                "," +
                "              \"lon\": " + heatMapRequestDto.getTlLon() +
                "" +
                "            }," +
                "            \"bottom_right\": {" +
                "              \"lat\": " + heatMapRequestDto.getBrLat() +
                "," +
                "              \"lon\": " + heatMapRequestDto.getBrLon() +
                "" +
                "            }" +
                "          }" +
                "        }" +
                "      }" +
                "    }" +
                "  }," +
                "  \"aggregations\": {" +
                "    \"" + heatMapRequestDto.getLocCode() +
                "\": {" +
                "      \"terms\": {" +
                "        \"field\": \"" + heatMapRequestDto.getLocCode() +
                "\"," +
                "        \"size\": 200" +
                "      }" +
                "    }" +
                "  }" +
                "}";


        return query;
    }

    private String getHeatMapQueryForCdmalessTrue(HeatMapRequestDto heatMapRequestDto) {
        String query = "{" +
                "\"size\": 0," +
                "\"query\": {" +
                "\"bool\": {" +
                "\"must\": [{" +
                "\"match_phrase\": {" +
                "\"Outlier\": {" +
                "\"query\": 0," +
                "\"slop\": 0," +
                "\"boost\": 1" +
                "}" +
                "}" +
                "}, {" +
                "\"range\": {" +
                "\"TimeStamp\": {" +
                "\"from\": \"" + heatMapRequestDto.getTimeStampFrm() +
                "\"," +
                "\"to\": \"" + heatMapRequestDto.getTimeStampTo() +
                "\"," +
                "\"include_lower\": true," +
                "\"include_upper\": true," +
                "\"boost\": 1" +
                "}" +
                "}" +
                "}, {" +
                "\"wildcard\": {" +
                "\"FileName\": \"*CDMALESS*\"" +
                "}" +
                "}" +
                "]," +
                "\"filter\": {" +
                "\"geo_bounding_box\": {" +
                "\"loc\": {" +
                "\"top_left\": {" +
                "\"lat\": " + heatMapRequestDto.getTlLat() +
                "," +
                "\"lon\": " + heatMapRequestDto.getTlLon() +
                "" +
                "}," +
                "\"bottom_right\": {" +
                "\"lat\": " + heatMapRequestDto.getBrLat() +
                "," +
                "\"lon\": " + heatMapRequestDto.getBrLon() +
                "" +
                "}" +
                "}" +
                "}" +
                "}" +
                "}" +
                "}," +
                "\"aggs\": {" +
                "\"" + heatMapRequestDto.getLocCode() +
                "\": {" +
                "\"terms\": {" +
                "\"field\": \"" + heatMapRequestDto.getLocCode() +
                "\"," +
                "\"size\": 50000" +
                "}," +
                "\"aggs\": {" +
                "\"average\": {" +
                "\"value_count\": {" +
                "\"field\": \"_index\"" +
                "}" +
                "}" +
                "}" +
                "}" +
                "}" +
                "}";

        return query;
    }
}
