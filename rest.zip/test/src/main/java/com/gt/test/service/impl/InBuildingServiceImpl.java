package com.harman.dmat.service.impl;

import com.harman.dmat.common.dto.InBuildingImageDto;
import com.harman.dmat.common.dto.InBuildingImageListDto;
import com.harman.dmat.common.dto.InBuildingLogViewDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.dao.InBuildingDao;
import com.harman.dmat.service.InBuildingService;
import com.harman.dmat.utils.Utill;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@Transactional
public class InBuildingServiceImpl implements InBuildingService {

    @Inject
    InBuildingDao inBuildingDao;

    @Override
    public Map<String, Object> getInbuildingImage(int imageId) {
        return inBuildingDao.getInbuildingImage(imageId);
    }

    @Override
    public List<InBuildingLogViewDto> getLogsByDate(String startDate, String endDate, Integer userId, Integer userType) {
        //String indices =  Utill.getIndex(startDate, endDate);
        String indices = calculateInBuildingIndices(startDate, endDate);

        Integer userIdForEsQuery = userType != null && userType == 0 ? userId : 0;
        List<InBuildingLogViewDto> inBuildingLogViewDtos = inBuildingDao.getLogsByDate(startDate, endDate, userIdForEsQuery, indices);

        if (inBuildingLogViewDtos.size() > 0 && userType == 1) {
            List<Integer> imageIds = inBuildingLogViewDtos.stream().map(InBuildingLogViewDto::getImageIds).collect(Collectors.toList());
            List<Integer> userIdsToRemove = inBuildingDao.getImageIdsToRemoveForLogFiles(imageIds, userId);
            inBuildingLogViewDtos.removeIf(logDto -> userIdsToRemove.contains(logDto.getImageIds()));
        }
        return inBuildingLogViewDtos;
    }

    @Override
    public Map<String, String> getInfoPoints(double xCoordinate, double yCoordinate, String fileName, String startDate, String endDate) throws DataNotFoundException {

        //String indices =  Utill.getIndex(startDate, endDate);
        String indices = calculateInBuildingIndices(startDate, endDate);

        return inBuildingDao.getInfoPoints(xCoordinate, yCoordinate, fileName, indices);
    }

    //TODO: this method is workaround for getting old data from dmat-2017-inbuilding index
    //method should be removed since it is invalid from next year(2018)
    //use Utill.getIndex(startDate, endDate) instead of this method from next year(2018)
    private String calculateInBuildingIndices(String startDate, String endDate) {
        String indices = "";
        String oldInBuildingIndices = "dmat-2017-inbuilding";
        int startDateMonth = Integer.parseInt(startDate.split("-")[1]);
        int startDateYear = Integer.parseInt(startDate.split("-")[0]);
        int endDateMonth = Integer.parseInt(endDate.split("-")[1]);
        if (startDateYear == 2017) {
            if (startDateMonth >= 9) {
                indices = Utill.getIndex(startDate, endDate);
            } else if (endDateMonth >= 9) {
                indices = Utill.getIndex("2017-09-01", endDate);
            }
            indices = indices.length() > 0 ? indices + "," + oldInBuildingIndices : oldInBuildingIndices;
        } else {
            indices = Utill.getIndex(startDate, endDate);
        }
        return indices;
    }

    @Override
    public ResponseDto responseDto(Map<String, Object> inBuildingParameter) {

        final boolean saveStatus = inBuildingDao.registerInBuilding(inBuildingParameter);
        final ResponseDto responseDto = new ResponseDto();

        if (saveStatus) {
            log.debug("Succefully registered Inbuilding");
            responseDto.setStatusCode(0);
            responseDto.setMessage("Succefully registered Inbuilding");
            responseDto.setData("Succefully registered Inbuilding");
        } else {
            log.error("Failed to add dmat Inbuilding Image");
            responseDto.setErrorCode(1);
            responseDto.setMessage("Failed to register Inbuilding");
            responseDto.setDeveloperMessage("Failed to registered Inbuilding");
        }

        return responseDto;
    }

    public InBuildingImageListDto getInBuildingList(Integer offset, Integer limit, Integer userId, Integer access) {
        InBuildingImageListDto inBuildingImageListDto = new InBuildingImageListDto();

        inBuildingImageListDto.setInBuildingImageDtoList(inBuildingDao.getInBuildingList(offset, limit, userId, access));
        inBuildingImageListDto.setCount(inBuildingDao.getInBuildingCount(userId, access));

        return inBuildingImageListDto;
    }

    public ResponseDto removeInBuilding(String id) {
        final boolean saveStatus = inBuildingDao.removeInBuilding(id);
        final ResponseDto responseDto = new ResponseDto();

        if (saveStatus) {
            log.debug("Succefully removed Inbuilding");
            responseDto.setStatusCode(0);
            responseDto.setMessage("Succefully removed Inbuilding");
            responseDto.setData("Succefully removed Inbuilding");
        } else {
            log.error("Failed to add dmat Inbuilding Image");
            responseDto.setErrorCode(1);
            responseDto.setMessage("Failed to remove Inbuilding");
            responseDto.setDeveloperMessage("Failed to remove Inbuilding");
        }

        return responseDto;
    }

    public ResponseDto updateInBuildingImage(Integer imageId, byte[] image, int width, int height) {
        final boolean saveStatus = inBuildingDao.updateInBuildingImage(imageId, image, width, height);
        final ResponseDto responseDto = new ResponseDto();

        if (saveStatus) {
            log.debug("Succefully updated Inbuilding Image");
            responseDto.setStatusCode(0);
            responseDto.setMessage("Succefully updated Inbuilding Image");
            responseDto.setData("Succefully updated Inbuilding Image");
        } else {
            log.error("Failed to updated Inbuilding Image");
            responseDto.setErrorCode(1);
            responseDto.setMessage("Failed to updated Inbuilding Image");
            responseDto.setDeveloperMessage("Failed to updated Inbuilding Image");
        }

        return responseDto;
    }

    @Override
    public ResponseDto registerInBuildingWithoutImage(InBuildingImageDto inBuildingImageDto) {
        final long recentId = inBuildingDao.registerInBuildingWithoutImage(inBuildingImageDto);
        final ResponseDto responseDto = new ResponseDto();

        if (recentId > 0) {
            log.debug("Succefully registered Inbuilding");
            responseDto.setStatusCode(0);
            responseDto.setMessage("Succefully registered Inbuilding");
            responseDto.setData(recentId);
        } else {
            log.error("Failed to add dmat Inbuilding Image");
            responseDto.setErrorCode(1);
            responseDto.setMessage("Failed to register Inbuilding");
            responseDto.setDeveloperMessage("Failed to registered Inbuilding");
        }

        return responseDto;
    }

    @Override
    public ResponseDto updateInBuildingInfo(InBuildingImageDto inBuildingImageDto) {
        final long status = inBuildingDao.updateInBuildingInfo(inBuildingImageDto);
        final ResponseDto responseDto = new ResponseDto();

        if (status > 0) {
            log.debug("Succefully updated Inbuilding Information");
            responseDto.setStatusCode(0);
            responseDto.setMessage("Succefully updated Inbuilding Information");
            responseDto.setData("Succefully updated Inbuilding Information");
        } else {
            log.error("Failed to updated Inbuilding Information");
            responseDto.setErrorCode(1);
            responseDto.setMessage("Failed to updated Inbuilding Information");
            responseDto.setDeveloperMessage("Failed to updated Inbuilding Information");
        }

        return responseDto;
    }
}
