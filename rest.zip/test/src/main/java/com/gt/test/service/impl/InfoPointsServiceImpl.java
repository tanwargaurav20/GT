package com.harman.dmat.service.impl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.harman.dmat.common.dto.EventsInfoDto;
import com.harman.dmat.common.dto.LiveInfoPointsDto;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.security.User;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.dao.InfoPointsDao;
import com.harman.dmat.enums.LegendsEnum;
import com.harman.dmat.service.InfoPointsService;
import com.harman.dmat.utils.Utill;
import lombok.extern.slf4j.Slf4j;

/**
 * @author GTanwar Interacts with the Elastic Search DAO layer
 *
 */
@Slf4j
@Service
@Transactional
public class InfoPointsServiceImpl implements InfoPointsService {

	@Inject
	Environment environment;
	@Autowired
	InfoPointsDao infoPointsDao;

	private static final Map<String, String> eventNameMap = new HashMap<>();

	static {
		eventNameMap.put("LTEAttRej", "LTE Attach Reject");
		eventNameMap.put("LTEReselToGsmUmtsFail", "LTE Resel To GSM UMTS Fail");
		eventNameMap.put("LTEAuthRej", "LTE Auth Reject");
		eventNameMap.put("LTEReselFromGsmUmtsFail", "LTE Resel From GSM UMTS Fail");
		eventNameMap.put("LTEIntraReselFail", "LTE Intra Resel Fail");
		eventNameMap.put("LTEIntraHoFail", "LTE Intra Ho Fail");
		eventNameMap.put("LTEMobilityFromEutraFail", "LTE Mobility From Eutra Fail");
		eventNameMap.put("LTEOos", "LTE Out Of Service");
		eventNameMap.put("LTEPdnRej", "LTE PDN Reject");
		eventNameMap.put("LTERlf", "LTE Rlf");
		eventNameMap.put("LTERrcConRestRej", "LTE RRC Connection Rest Reject");
		eventNameMap.put("LTERrcConRej", "LTE RRC Connection Reject");
		eventNameMap.put("LTEServiceRej", "LTE Service Reject");
		eventNameMap.put("LTESibReadFailure", "LTE Sib Read Failure");
		eventNameMap.put("LTETaRej", "LTE TA Reject");
		eventNameMap.put("LTEVoLTEDrop", "LTE VoLTE Drop");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.InfoPointsService#getInfoPoints(java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public List<String> getInfoPoints(String lat, String lng, String userId, String fileName, String scale,
			String kpiName, String startDate, String endDate, String mdn, String kpiType, String showEvent,
			String events, int[] bandFilter, String voiceratFilterArr, String earfcnFilterArr, String rsrpFilter,
			String sinrFilter, String rsrqFilter, String rssiFilter, String enbIdFilter) throws DataNotFoundException {
		List<String> list = null;
		String query = null;
		String distance = calculateDistance(scale);
		String indices = Utill.getIndex(startDate, endDate);

		if (Constant.TRUE.equalsIgnoreCase(showEvent) && Integer.parseInt(scale) > 12) {
			query = getInfoPointsQuery(lat, lng, userId, fileName, scale, distance, kpiName, startDate, endDate, mdn,
					kpiType, showEvent, events, bandFilter, voiceratFilterArr, earfcnFilterArr, rsrpFilter, sinrFilter,
					rsrqFilter, rssiFilter, enbIdFilter);

			if (log.isDebugEnabled()) {
				log.debug("Info Points Events Query formed: " + query);
				log.debug("Indices: " + indices);
			}
			list = infoPointsDao.getInfoPoints(query, indices);
		}
		if (list == null || list.size() == 0) {
			query = getInfoPointsQuery(lat, lng, userId, fileName, scale, distance, kpiName, startDate, endDate, mdn,
					kpiType, Constant.FALSE, null, bandFilter, voiceratFilterArr, earfcnFilterArr, rsrpFilter,
					sinrFilter, rsrqFilter, rssiFilter, enbIdFilter);
			if (log.isDebugEnabled()) {
				log.debug("Info Points Hex Query formed: " + query);
				log.debug("Indices: " + indices);
			}
			list = infoPointsDao.getInfoPoints(query, indices);
		}
		return list;

	}

	/**
	 * This method gets the list of events for a given parameters listed below
	 * 
	 * @param startDate
	 * @param endDate
	 * @param userId
	 * @param domain
	 * @param tl_lat
	 * @param tl_lon
	 * @param br_lat
	 * @param br_lon
	 * @param eventNames
	 * @return List<EventsInfoDto>
	 */
	@Override
	public List<EventsInfoDto> getEventsList(String startDate, String endDate, String userId, String domain,
			String tl_lat, String tl_lon, String br_lat, String br_lon, String[] eventNames, String[] fileNames) {
		String query = getEventsListQuery(startDate, endDate, userId, domain, tl_lat, tl_lon, br_lat, br_lon,
				eventNames, fileNames);
		String indices = Utill.getIndex(startDate, endDate);

		if (log.isDebugEnabled()) {
			log.debug("Events List Query formed: " + query);
			log.debug("Indices: " + indices);
		}
		List<EventsInfoDto> list = infoPointsDao.getEventsList(query, indices);
		return list;
	}

	/**
	 * Returns the ElasticSearch Query for the given listed parameters
	 * 
	 * @param startDate
	 * @param endDate
	 * @param userId
	 * @param domain
	 * @param tl_lat
	 * @param tl_lon
	 * @param br_lat
	 * @param br_lon
	 * @param eventsName
	 * @return
	 */
	private String getEventsListQuery(String startDate, String endDate, String userId, String domain, String tl_lat,
			String tl_lon, String br_lat, String br_lon, String[] eventsName, String[] fileName) {
		List<String> eventNames = Arrays.asList(eventsName);
		List<String> fileNames = Arrays.asList(fileName);
		String query = "";

		query = query + "{" + "\"size\": 10000," + "\"_source\": {"
				+ "\"includes\": [\"lat\", \"lon\", \"loc_mx\", \"loc_my\", ";

		for (String eventName : eventNames) {
			query = query + " \"" + eventName + "\",";
		}

		query = query
				+ " \"FileName\", \"TimeStamp\", \"ObjectId\", \"FirstName\", \"LastName\", \"EmailId\", \"DmUser\"],"
				+ "\"excludes\": []" + "}," + "\"query\": {" + "\"bool\": {" + "\"must\": [{" + "\"bool\": {"
				+ "\"should\": [";

		int i = 0;
		for (String eventName : eventNames) {
			query = (i == (eventNames.size() - 1)) ? query + getEventsRange(eventName)
					: query + getEventsRange(eventName) + ",";
			i++;
		}

		query = query + "]" + "}" + "}, {" + "\"range\": {" + "\"TimeStamp\": {" + "\"from\": \"" + startDate + "\","
				+ "\"to\": \"" + endDate + "\"," + "\"include_lower\": true," + "\"include_upper\": true,"
				+ "\"boost\": 1" + "}" + "}" + "} " + getUserQuery(userId) + getDomainESQuery(domain)
				+ getFileNameQuery(fileNames) + "]," + "\"filter\": {" + "\"geo_bounding_box\": {" + "\"loc\": {"
				+ "\"top_left\": {" + "\"lat\": " + tl_lat + "," + "\"lon\": " + tl_lon + "" + "},"
				+ "\"bottom_right\": {" + "\"lat\": " + br_lat + "," + "\"lon\": " + br_lon + "" + "}" + "}" + "}" + "}"
				+ "}" + "}" + "}";

		return query;
	}

	private String getUserQuery(String userId) {
		String userQuery = "";
		if (!userId.equalsIgnoreCase("ALL")) {
			userQuery = ",{" + "\"terms\": {" + "\"DmUser\": [\"" + userId + "\"]" + "}" + "}";
		}

		return userQuery;
	}

	private String getFileNameQuery(List<String> fileNames) {
		String fileNameQuery = "";

		if (fileNames.size() > 0) {
			fileNameQuery = ", {" + "\"terms\": {" + "\"FileName\": [";

			int i = 0;
			for (String fileName : fileNames) {
				fileNameQuery = (i == (fileNames.size() - 1)) ? fileNameQuery + "\"" + fileName + "\""
						: fileNameQuery + "\"" + fileName + "\",";
				i++;
			}

			fileNameQuery = fileNameQuery + "]}}";
		}

		return fileNameQuery;
	}

	/**
	 * Gets the events range query.
	 * 
	 * @param eventsField
	 * @return
	 */
	private String getEventsRange(String eventsField) {
		return "{" + "\"range\": {" + "\"" + eventsField + "\": {" + "\"gt\": 0" + "}" + "}" + "}";
	}

	/**
	 * Forms the ES query to fetch the Info Points
	 * 
	 * @param lat
	 * @param lng
	 * @param userId
	 * @param fileName
	 * @param scale
	 * @param distance
	 * @return String
	 */
	private String getInfoPointsQuery(String lat, String lng, String userId, String fileName, String scale,
			String distance, String kpiName, String startDate, String endDate, String mdn, String kpiType,
			String showEvent, String event, int[] bandFilter, String voiceratFilterArr, String earfcnFilterArr,
			String rsrpFilter, String sinrFilter, String rsrqFilter, String rssiFilter, String enbIdFilter) {
		String userQuery = "";
		String fileQuery = "";
		String mdnQuery = "";
		String geoPointFltr = "";
		String query = null;
		String kpiAgg = "";
		String domainQuery = "";
		String dateRangeQuery = "";
		String voiceRatQuery = "";
		String earfcnQuery = "";
		String rsrpFilterQuery = "";
		String rsrqFilterQuery = "";
		String rssiFilterQuery = "";
		String sinrFilterQuery = "";
		String enbIdFilterQuery = "";

		String bandFilterStr = "";
		if (bandFilter != null && bandFilter.length > 0) {
			bandFilterStr = bandFilterStr + ", {" + "\"terms\": {" + "\"LTEPccBandInd\": " + Arrays.toString(bandFilter)
					+ "}" + "}";
		}

		final String userDomain = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserDomain();

		domainQuery = getDomainESQuery(userDomain);

		if (kpiName != null && (!"LTEPccRsrp".equalsIgnoreCase(kpiName) && !"LTEPccRsrq".equalsIgnoreCase(kpiName)
				&& !"LTEPccSinr".equalsIgnoreCase(kpiName) && !"LTEPccRssi".equalsIgnoreCase(kpiName)
				&& !"LTEPuschTxPwr".equalsIgnoreCase(kpiName) && !"servingcell".equalsIgnoreCase(kpiName)
				&& !"LTEPccBandInd".equalsIgnoreCase(kpiName) && !"VoiceRAT".equalsIgnoreCase(kpiName)
				&& !"LTEPccPci".equalsIgnoreCase(kpiName) && !"LTEPccPuschTxPwr".equalsIgnoreCase(kpiName))) {
			if (kpiType.equalsIgnoreCase(LegendsEnum.TYPE_FIXED_RANGE.value))
				kpiAgg = " \"" + kpiName.trim() + "\": { \"terms\": { \"field\":" + "\"" + kpiName.trim() + "\""
						+ " } }, \"kpicount\": { \"value_count\": { \"field\":" + "\"" + kpiName.trim() + "\" } }";
			else
				kpiAgg = " \"" + kpiName.trim() + "\": { \"avg\": { \"field\":" + "\"" + kpiName.trim() + "\""
						+ " } }, \"kpicount\": { \"value_count\": { \"field\":" + "\"" + kpiName.trim() + "\" } }";

		} else {
			kpiAgg = "\"kpicount\": { \"value_count\": { \"field\":" + "\"" + kpiName.trim() + "\" } }";
		}
		if (startDate != null && endDate != null) {
			dateRangeQuery = ",{ \"range\": { \"TimeStamp\": { \"from\": \"" + startDate + "\", \"to\": \"" + endDate
					+ "\", " + "\"include_lower\": true, \"include_upper\": true, \"boost\": 1 } } }";
		}
		if (fileName != null) {

			fileQuery = ",{ \"terms\": { \"FileName\": " + getTermsData(fileName) + " } }";
		}
		if (voiceratFilterArr != null) {

			voiceRatQuery = ",{ \"terms\": { \"VoiceRAT\": " + getTermsData(voiceratFilterArr) + " } }";
		}
		if (earfcnFilterArr != null) {

			earfcnQuery = ",{ \"terms\": { \"LTEPccEarfcnDL\": " + getTermsData(earfcnFilterArr) + " } }";
		}

		if (enbIdFilter != null) {

			enbIdFilterQuery = ",{ \"terms\": { \"LTEeNBId\": " + getTermsData(enbIdFilter) + " } }";
		}

		if (rsrpFilter != null) {

			rsrpFilterQuery = getRangeFilterQuery(rsrpFilter, "LTEPccRsrp");
		}
		if (rsrqFilter != null) {

			rsrqFilterQuery = getRangeFilterQuery(rsrqFilter, "LTEPccRsrq");
		}

		if (rssiFilter != null) {

			rssiFilterQuery = getRangeFilterQuery(rssiFilter, "LTEPccRssi");
		}

		if (sinrFilter != null) {

			sinrFilterQuery = getRangeFilterQuery(sinrFilter, "LTEPccSinr");
		}

		if (mdn != null) {
			mdnQuery = ",{ \"terms\": { \"MDN\": " + getTermsData(mdn) + " } }";
		}
		geoPointFltr = ", \"filter\": { \"geo_distance\": { \"distance\":" + distance + ", \"loc\": { \"lat\":" + lat
				+ ", \"lon\":" + lng + "} } }";

		query = getESQuery(userId, showEvent, userQuery, fileQuery, mdnQuery, geoPointFltr, kpiAgg, domainQuery,
				dateRangeQuery, event, bandFilterStr, voiceRatQuery, earfcnQuery, rsrpFilterQuery, rssiFilterQuery,
				rsrqFilterQuery, sinrFilterQuery, enbIdFilterQuery);
		return query;
	}

	@Override
	public Map<String, Object> getEventInfoPoints(String lat, String lon, String userId, String scale, String fileName,
			String scaleLoc) throws DataNotFoundException {

		String userQuery = "";
		String fileQuery = "";
		String scaleLocQuery = "";
		String geoPointFltr = "";
		String distance = calculateDistance(scale);
		String query = null;
		if (userId != null) {
			userQuery = ", { \"match\": { \"dm_user\": { \"query\":" + userId + "} } }";
		}
		if (fileName != null) {
			fileQuery = ", { \"match\": { \"file_name\": { \"query\": \"" + fileName + "} } }";
		}
		if (scaleLoc != null) {
			scaleLocQuery = "{  \"query_string\": {  \"query\": \"_exists_:" + scaleLoc + "\" } },";
		}
		geoPointFltr = ", \"filter\": { \"geo_distance\": { \"distance\":" + distance + ", \"loc\": { \"lat\":" + lat
				+ ", \"lon\":" + lon + "} } }";
		query = "{ \"size\": 1, \"_source\": { \"includes\": [ \"lat\", \"lng\", \"loc_mx\", \"loc_my\", \"loc_1000\","
				+ " \"file_name\", \"dm_user\", \"eventid\" ], \"excludes\": [] }, \"query\": { \"bool\": { \"must\": [ {"
				+ " \"match_phrase\": { \"outlier\": { \"query\": 0 } } }," + scaleLocQuery
				+ "{  \"bool\": {  \"must_not\": [   {  \"bool\": {   \"must_not\": [  {\"exists\": {\"field\": \"eventid\",   \"boost\": 1 } } ]  }}] }}"
				+ "" + userQuery + fileQuery + "]" + geoPointFltr + "} } }";

		if (scale == null || Integer.parseInt(scale) < 16) {
			query = query.substring(0, query.length() - 1);
			query = query + ",\"aggs\": { \"event\": { \"terms\": { \"size\": 1,"
					+ " \"order\": [ { \"_count\": \"desc\" }], \"field\": \"eventid\"}},"
					+ " \"average\": { \"max_bucket\": { \"buckets_path\": \"event>_count\"}}}}";
		}
		if (log.isDebugEnabled()) {
			log.debug("Event info Points Query formed: " + query);
		}
		Map<String, Object> dataMap = infoPointsDao.getEventInfoPoints(query);
		return dataMap;
	}

	private String calculateDistance(String scale) {
		String distance = null;
		if (scale == null) {
			distance = "\"50m\"";
		} else {
			switch (scale) {
			case "20":
				distance = "\"5m\"";
				break;
			case "19":
				distance = "\"8m\"";
				break;
			case "18":
				distance = "\"10m\"";
				break;
			case "17":
				distance = "\"15m\"";
				break;
			case "16":
			case "15":
			case "14":
				distance = "\"100m\"";
				break;

			case "13":
			case "12":
				distance = "\"700m\"";
				break;
			case "11":
				distance = "\"800m\"";
				break;
			case "10":
			case "9":
				distance = "\"1000m\"";
				break;

			default:
				distance = "\"15m\"";

			}
		}
		return distance;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.InfoPointsService#getLiveInfoPoints(java.lang.
	 * String, java.lang.String, java.lang.String)
	 */
	@Override
	public LiveInfoPointsDto getLiveInfoPoints(String lat, String lng, String imei) throws DataNotFoundException {
		String query = getLiveInfoPointsQuery(lat, lng, imei);
		if (log.isDebugEnabled()) {
			log.debug("Live Info Points Query formed: " + query);
		}
		LiveInfoPointsDto liveInfoPointsDto = infoPointsDao.getLiveInfoPoints(query, lat, lng);
		return liveInfoPointsDto;
	}

	/**
	 * Forms the RDBMS query to fetch the Live Info Points
	 * 
	 * @param lat
	 * @param lng
	 * @param imei
	 * @return String
	 */
	private String getLiveInfoPointsQuery(String lat, String lng, String imei) {
		String imeiQuery = "";
		String query = null;

		if (imei != null) {
			imeiQuery = " and imei='" + imei + "'";
		}

		query = " select rsrp, rsrq, rssi,sinr,puschTx, servingCell, pucchActualTx, file_name, dm_user, imei, mdn, dm_timestamp"
				+ " as dmtimestamp, BandIndicator, Rat, pdschThroughput, puschThroughput, macUlTx, macDlTx, RLCUL,RLCDL,"
				+ "PDCPUL,PDCPDL from data_points_live_wm where lat=? and lng=?" + imeiQuery;
		return query;
	}

	/**
	 * Creates the domain SQL query
	 * 
	 * @param userDomain
	 * @return
	 */
	private String getDomainESQuery(String userDomain) {
		String domainQuery = "";
		userDomain = userDomain == null ? "null" : userDomain;
		StringBuffer sb = new StringBuffer();
		try {
			List<String> listVzDomains = Arrays.asList(environment.getRequiredProperty("verizon.domains").split(","));

			if (listVzDomains.contains(userDomain)) {
				for (String domain : listVzDomains) {
					sb = sb.append("{ \"query_string\": { \"query\": \"EmailId:*").append(domain).append("\"} },");
				}
				sb.deleteCharAt(sb.length() - 1);
				domainQuery = ", { \"bool\": { \"should\": [" + sb.toString() + "] } }";
			} else {
				sb = sb.append("{ \"query_string\": { \"query\": \"EmailId:*").append(userDomain.toLowerCase())
						.append("\"} }");
				domainQuery = ", { \"bool\": { \"must\": [" + sb.toString() + "] } }";
			}
		} catch (Exception e) {
			log.error("Error Getting Vz domains");
		}

		return domainQuery;
	}

	/**
	 * @param userId
	 * @param showEvent
	 * @param userQuery
	 * @param fileQuery
	 * @param mdnQuery
	 * @param geoPointFltr
	 * @param kpiAgg
	 * @param domainQuery
	 * @param dateRangeQuery
	 * @return
	 */
	private String getESQuery(String userId, String showEvent, String userQuery, String fileQuery, String mdnQuery,
			String geoPointFltr, String kpiAgg, String domainQuery, String dateRangeQuery, String event,
			String bandFilterStr, String voiceRatQuery, String earfcnQuery, String rsrpFilterQuery,
			String rssiFilterQuery, String rsrqFilterQuery, String sinrFilterQuery, String enbIdQuery) {
		String query = "";
		String lteKpis = "";
		if (voiceRatQuery == null || "".equals(voiceRatQuery) || voiceRatQuery.contains("LTE")) {
			lteKpis = "\"rsrp\":"
					+ " { \"avg\": { \"field\": \"LTEPccRsrp\" } }, \"rsrq\": { \"avg\": { \"field\": \"LTEPccRsrq\" } }, \"sinr\": { \"avg\""
					+ ": { \"field\": \"LTEPccSinr\" } },\"rssi\":" + " { \"avg\": { \"field\": \"LTEPccRssi\" } },"
					+ " \"puschtx\": { \"avg\": { \"field\": \"LTEPuschTxPwr\" } },"
					+ "\"PCI\": { \"terms\": { \"field\": \"LTEPccPci\" } },"
					+ "\"bandindicator\": { \"terms\": { \"field\": \"LTEPccBandInd\" } },"
					+ "\"ENBID\": { \"terms\": { \"field\": \"LTEeNBId\" } },";
		}
		if (userId != null && !userId.equalsIgnoreCase(Constant.ALL) && Constant.TRUE.equalsIgnoreCase(showEvent)) {
			userQuery = ", { \"match\": { \"DmUser\": { \"query\":" + userId + "} } }";
			String eventsQuery = eventQuery(event);
			String eventsAgg = eventsAggregation(event);
			// log.debug("BandFilterStr : "+bandFilterStr);
			query = "{ \"size\": 0, \"_source\": { \"includes\": [], \"excludes\": [] }, \"query\": { \"bool\": { \"must\": [ {"
					+ " \"match_phrase\": { \"Outlier\": { \"query\": 0 } } }" + bandFilterStr + userQuery
					+ dateRangeQuery + fileQuery + voiceRatQuery + earfcnQuery + enbIdQuery + rsrpFilterQuery
					+ rsrqFilterQuery + rssiFilterQuery + sinrFilterQuery + mdnQuery + eventsQuery + domainQuery + "]"
					+ geoPointFltr + "} },  \"aggs\": { " + lteKpis + " \"rat\": { \"terms\": {"
					+ " \"field\": \"VoiceRAT\" } }, \"servingcell\": { \"terms\": { \"field\": \"servingcell\" } },"
					+ eventsAgg
					+ " \"filename\": { \"terms\": { \"field\": \"FileName\" } }, \"TestId\": { \"terms\": { \"field\": \"TestId\" } },"
					+ " \"mdn\": { \"terms\": { \"field\": \"MDN\" } },"
					+ " \"imei\": { \"terms\": { \"field\": \"Imei\" } }, \"timestamp\": { \"terms\": { \"field\": \"TimeStamp\" } }, "
					+ kpiAgg
					+ ",\"mcc\": { \"terms\": { \"field\": \"LTEMccMncId\" } },\"ObjectId\": { \"terms\": { \"field\": \"ObjectId\" } } } }";

		} else if (userId != null && !userId.equalsIgnoreCase(Constant.ALL)
				&& Constant.FALSE.equalsIgnoreCase(showEvent)) {
			userQuery = ", { \"match\": { \"DmUser\": { \"query\":" + userId + "} } }";
			query = "{ \"size\": 0, \"_source\": { \"includes\": [], \"excludes\": [] }, \"query\": { \"bool\": { \"must\": [ {"
					+ " \"match_phrase\": { \"Outlier\": { \"query\": 0 } } }" + bandFilterStr + userQuery
					+ dateRangeQuery + fileQuery + voiceRatQuery + earfcnQuery + enbIdQuery + rsrpFilterQuery
					+ rsrqFilterQuery + rssiFilterQuery + sinrFilterQuery + mdnQuery + domainQuery + "]" + geoPointFltr
					+ "} },  \"aggs\": { " + lteKpis + "\"rat\": { \"terms\": {"
					+ " \"field\": \"VoiceRAT\" } }, \"servingcell\": { \"terms\": { \"field\": \"servingcell\" } },"
					+ " \"filename\": { \"terms\": { \"field\": \"FileName\" } }, \"TestId\": { \"terms\": { \"field\": \"TestId\" } }, \"mdn\": { \"terms\": { \"field\": \"MDN\" } },"
					+ " \"imei\": { \"terms\": { \"field\": \"Imei\" } }, \"timestamp\": { \"terms\": { \"field\": \"TimeStamp\" } }, "
					+ kpiAgg
					+ ",\"mcc\": { \"terms\": { \"field\": \"LTEMccMncId\" } }, \"ObjectId\": { \"terms\": { \"field\": \"ObjectId\" } }} }";

		} else if ((userId == null || userId.equalsIgnoreCase(Constant.ALL))
				&& Constant.FALSE.equalsIgnoreCase(showEvent)) {

			query = "{ \"size\": 0, \"_source\": { \"includes\": [], \"excludes\": [] }, \"query\": { \"bool\": { \"must\": [ {"
					+ " \"match_phrase\": { \"Outlier\": { \"query\": 0 } } }" + bandFilterStr + dateRangeQuery
					+ fileQuery + voiceRatQuery + earfcnQuery + enbIdQuery + rsrpFilterQuery + rsrqFilterQuery
					+ rssiFilterQuery + sinrFilterQuery + mdnQuery + domainQuery + "]" + geoPointFltr
					+ "} },  \"aggs\": { " + lteKpis + "\"rat\": { \"terms\": {"
					+ " \"field\": \"VoiceRAT\" } }, \"servingcell\": { \"terms\": { \"field\": \"servingcell\" } },"
					+ "\"mcc\": { \"terms\": { \"field\": \"LTEMccMncId\" } },"
					+ "\"ObjectId\": { \"terms\": { \"field\": \"ObjectId\" } }," + kpiAgg + " } }";

		} else if ((userId == null || userId.equalsIgnoreCase(Constant.ALL))
				&& Constant.TRUE.equalsIgnoreCase(showEvent)) {
			String eventsQuery = eventQuery(event);
			String eventsAgg = eventsAggregation(event);
			query = "{ \"size\": 0, \"_source\": { \"includes\": [], \"excludes\": [] }, \"query\": { \"bool\": { \"must\": [ {"
					+ " \"match_phrase\": { \"Outlier\": { \"query\": 0 } } }" + bandFilterStr + dateRangeQuery
					+ fileQuery + voiceRatQuery + earfcnQuery + enbIdQuery + rsrpFilterQuery + rsrqFilterQuery
					+ rssiFilterQuery + sinrFilterQuery + mdnQuery + eventsQuery + domainQuery + "]" + geoPointFltr
					+ "} },  \"aggs\": {" + lteKpis + "\"rat\": { \"terms\": {"
					+ " \"field\": \"VoiceRAT\" } }, \"servingcell\": { \"terms\": { \"field\": \"servingcell\" } },"
					+ eventsAgg
					+ "\"mcc\": { \"terms\": { \"field\": \"LTEMccMncId\" } },\"ObjectId\": { \"terms\": { \"field\": \"ObjectId\" } },"
					+ kpiAgg + " } }";
		}
		return query;
	}

	/**
	 * @param data
	 * @return
	 */
	private String getTermsData(String data) {
		if (data == null) {
			return null;
		}
		StringBuffer sb = new StringBuffer();
		sb.append("[");
		for (String value : data.split(",")) {
			sb = sb.append("\"").append(value).append("\"").append(",");
		}

		return sb.substring(0, sb.length() - 1) + "]";

	}

	/**
	 * @param events
	 * @return
	 */
	private String eventQuery(String events) {
		String eventsQuery = "";
		if (events == null || events.isEmpty()) {
			eventsQuery = ",{ \"bool\": { \"should\": [ { \"range\": { \"LTEPdnRej\": { \"gt\": 0 } } }, { \"range\": {"
					+ " \"LTERlf\": { \"gt\": 0 } } }, { \"range\": { \"LTERrcConRestRej\": { \"gt\": 0 } } }, { \"range\": {"
					+ " \"LTERrcConRej\": { \"gt\": 0 } } }, { \"range\": { \"LTEServiceRej\": { \"gt\": 0 } } }, { \"range\":"
					+ " { \"LTESibReadFailure\": { \"gt\": 0 } } }, { \"range\": { \"LTETaRej\": { \"gt\": 0 } } }, { \"range\": {"
					+ " \"LTEVoLTEDrop\": { \"gt\": 0 } } }, { \"range\": { \"LTEReselFromGsmUmtsFail\": { \"gt\": 0 } } }, { \"range\": "
					+ "{ \"LTEIntraReselFail\": { \"gt\": 0 } } }, { \"range\": { \"LTEIntraHoFail\": { \"gt\": 0 } } } ] } }";
		} else {
			String[] eventsArr = events.split(",");
			StringBuffer sRange = new StringBuffer();

			for (String event : eventsArr) {
				sRange.append("{ \"range\": { \"" + event + "\": { \"gt\": 0 } } },");
			}
			eventsQuery = ",{ \"bool\": { \"should\": [" + sRange.substring(0, sRange.length() - 1) + "] } }";
		}
		return eventsQuery;
	}

	private String eventsAggregation(String events) {
		String eventsQuery = "";
		if (events == null || events.isEmpty()) {
			eventsQuery = " \"LTE PDN Reject\": { \"terms\": { \"field\": \"LTEPdnRej\" } }, \"LTE Rlf\": { \"terms\": { \"field\": \"LTERlf\" } },"
					+ " \"LTE RRC Connection Rest Reject\": { \"terms\": { \"field\": \"LTERrcConRestRej\" } }, \"LTE RRC Connection Reject\": { "
					+ "\"terms\": { \"field\": \"LTERrcConRej\" } }, \"LTE Service Reject\": { \"terms\": { \"field\": \"LTEServiceRej\" } }, \"LTE Sib Read Failure\": "
					+ "{ \"terms\": { \"field\": \"LTESibReadFailure\" } }, \"LTE TA Reject\": { \"terms\": { \"field\": \"LTETaRej\" } }, \"LTE VoLTE Drop\":"
					+ " { \"terms\": { \"field\": \"LTEVoLTEDrop\" } }, \"LTE Resel From GSM UMTS Fail\": { \"terms\": { \"field\": \"LTEReselFromGsmUmtsFail\" } },"
					+ " \"LTE Intra Resel Fail\": { \"terms\": { \"field\": \"LTEIntraReselFail\" } }, \"LTE Intra Ho Fail\": { \"terms\": { \"field\": \"LTEIntraHoFail\" } },";
		} else {
			String[] eventsArr = events.split(",");
			StringBuffer eventsAgg = new StringBuffer();

			for (String event : eventsArr) {
				if (eventNameMap.keySet().contains(event)) {
					eventsAgg.append("\"" + eventNameMap.get(event).toString() + "\": { \"terms\": { \"field\": \""
							+ event + "\" } },");
				}
			}
			eventsQuery = "" + eventsAgg;
		}
		return eventsQuery;
	}

	/**
	 * @param values
	 * @param key
	 * @return
	 */
	private String getRangeFilterQuery(String values, String key) {
		String query = "";
		String rangeFrom = null;
		String rangeTo = null;
		try {
			rangeFrom = values.split("/")[0];
			rangeTo = values.split("/")[1];
			query = ",{ \"range\": { \"" + key + "\": { \"from\": \"" + rangeFrom + "\", \"to\": \"" + rangeTo
					+ "\", \"include_lower\": true, \"include_upper\": true, \"boost\": 1 } } }";
		} catch (ArrayIndexOutOfBoundsException ex) {
			log.debug("Range not in correct format");
			query = "";
		}
		return query;
	}

}