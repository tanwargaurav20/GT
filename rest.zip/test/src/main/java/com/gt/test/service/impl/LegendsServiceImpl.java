package com.harman.dmat.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.harman.dmat.common.dto.Buckets;
import com.harman.dmat.common.dto.DynamicKpiDto;
import com.harman.dmat.common.dto.ResetTeplate;
import com.harman.dmat.common.dto.Result;
import com.harman.dmat.common.dto.UniqueKpiDto;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.EsException;
import com.harman.dmat.common.exception.InvalidFileFormatException;
import com.harman.dmat.common.exception.InvalidRequestPayloadException;
import com.harman.dmat.dao.LegendsDao;
import com.harman.dmat.legends.dto.ColoredFixedRangeLegends;
import com.harman.dmat.legends.dto.FixedValueColorDto;
import com.harman.dmat.legends.dto.Kpi;
import com.harman.dmat.legends.dto.NewFixedValueColorDto;
import com.harman.dmat.legends.dto.NewVariableRangeColorDto;
import com.harman.dmat.legends.dto.RangeDto;
import com.harman.dmat.legends.dto.Template;
import com.harman.dmat.legends.dto.VariableRangeColorDto;
import com.harman.dmat.legends.exception.InvalidPayloadException;
import com.harman.dmat.service.LegendsService;
import com.harman.dmat.utils.EsClient;
import com.harman.dmat.utils.Utill;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class LegendsServiceImpl implements LegendsService {
	@Inject
	LegendsDao legendsDao;

	private List<VariableRangeColorDto> removeRedundentValues(List<VariableRangeColorDto> list) {
		log.info("removing duplicates from the parsed list  ");
		HashMap<String, List<VariableRangeColorDto>> map = new HashMap<>();
		for (Iterator<VariableRangeColorDto> iterator = list.iterator(); iterator.hasNext();) {
			VariableRangeColorDto veriableRangeColorDto = iterator.next();
			List<VariableRangeColorDto> personList;
			if (map.containsKey(veriableRangeColorDto.getGroupName() + veriableRangeColorDto.getKpiName())) {
				personList = map.get(veriableRangeColorDto.getGroupName() + veriableRangeColorDto.getKpiName());
				personList.add(veriableRangeColorDto);
			} else {
				personList = new ArrayList<>();
				personList.add(veriableRangeColorDto);
			}
			map.put(veriableRangeColorDto.getGroupName() + veriableRangeColorDto.getKpiName(), personList);
		}
		List<VariableRangeColorDto> finalList = new ArrayList<>();
		map.forEach((key, value) -> {
			List<RangeDto> rangeDtoList = new ArrayList<>();
			value.forEach(v1 -> rangeDtoList.addAll(v1.getList()));
			VariableRangeColorDto per = value.get(0);
			per.setList(rangeDtoList);
			finalList.add(per);
		});
		if (log.isDebugEnabled())
			log.debug("list without duplicates {} ", finalList);
		return finalList;
	}

	private List<ColoredFixedRangeLegends> parseFileGetLegendsList(Path path) {
		List<ColoredFixedRangeLegends> list = new ArrayList<>();
		try (FileInputStream inputStream = new FileInputStream(new File(path.toString()));
				Workbook workbook = new XSSFWorkbook(inputStream);) {

			final Sheet firstSheet = workbook.getSheetAt(2);
			final Iterator<Row> iterator = firstSheet.iterator();
			while (iterator.hasNext()) {
				int cloumn = 1;
				final ColoredFixedRangeLegends colFixedRangeLeg = new ColoredFixedRangeLegends();
				Row nextRow = iterator.next();
				Iterator<Cell> cellIterator = nextRow.cellIterator();
				FixedValueColorDto fixedValueColorDto = new FixedValueColorDto();
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_STRING:
						switch (cloumn) {
						case 1:
							colFixedRangeLeg.setGroupName(cell.getStringCellValue());
							break;
						case 2:
							colFixedRangeLeg.setKpiName(cell.getStringCellValue());
							break;
						case 4:
							colFixedRangeLeg.setKpiLegendsType(cell.getStringCellValue());
							break;
						case 5:
							fixedValueColorDto.setColor(cell.getStringCellValue());
							break;
						case 7:
							fixedValueColorDto.setUnit(cell.getStringCellValue());
							break;
						case 8:
							colFixedRangeLeg.setKey(cell.getStringCellValue());
							break;
						default:
							break;

						}
						break;
					case Cell.CELL_TYPE_BOOLEAN:
						colFixedRangeLeg.setKpiEditable(cell.getBooleanCellValue());
						break;
					case Cell.CELL_TYPE_NUMERIC:
						fixedValueColorDto.setValue(String.format("%s", cell.getNumericCellValue()));
					}
					cloumn++;
				}
				List<FixedValueColorDto> listOfFixedValueColor = new ArrayList<>();
				listOfFixedValueColor.add(fixedValueColorDto);
				colFixedRangeLeg.setList(listOfFixedValueColor);
				list.add(colFixedRangeLeg);
			}
		} catch (IOException ioException) {
			log.error("IOException in parsing the file for fixed value color legend kpis", ioException);
		}
		log.info("removing the heading and redusing the list");
		return getUniqueList(list.subList(1, list.size()));

	}

	private List<ColoredFixedRangeLegends> getUniqueList(List<ColoredFixedRangeLegends> list) {
		if (log.isDebugEnabled())
			log.debug("the list get from the excel file is {}", list);
		final HashMap<String, List<ColoredFixedRangeLegends>> map = new HashMap<>();
		for (final Iterator<ColoredFixedRangeLegends> iterator = list.iterator(); iterator.hasNext();) {
			ColoredFixedRangeLegends colredFixedRangeLegends = iterator.next();
			List<ColoredFixedRangeLegends> colFixedValueKpis;
			if (map.containsKey(colredFixedRangeLegends.getGroupName() + colredFixedRangeLegends.getKpiName())) {
				colFixedValueKpis = map
						.get(colredFixedRangeLegends.getGroupName() + colredFixedRangeLegends.getKpiName());
				colFixedValueKpis.add(colredFixedRangeLegends);
			} else {
				colFixedValueKpis = new ArrayList<>();
				colFixedValueKpis.add(colredFixedRangeLegends);
			}
			map.put(colredFixedRangeLegends.getGroupName() + colredFixedRangeLegends.getKpiName(), colFixedValueKpis);
		}
		List<ColoredFixedRangeLegends> listColoredFixedRangeKpis = new ArrayList<>();
		map.forEach((key, value) -> {
			List<FixedValueColorDto> coloredValueList = new ArrayList<>();
			value.forEach(v1 -> coloredValueList.addAll(v1.getList()));
			final ColoredFixedRangeLegends kpi = value.get(0);
			kpi.setList(coloredValueList);
			listColoredFixedRangeKpis.add(kpi);
		});
		if (log.isDebugEnabled())
			log.debug("unique list of kpis of type fixed value legends  {}", listColoredFixedRangeKpis);
		return listColoredFixedRangeKpis;
	}

	@Override
	public List<Kpi> getUserLegends(final Long userId, int groupId) {
		log.info("getting the userid :{} groupid :{}", userId, groupId);
		return legendsDao.getUserLegends(userId, groupId);
	}

	@Override
	public Kpi getLegendForKpi(Long userId, Long kpiId) {
		log.info("getting the kpi {} for the user {} ", kpiId, userId);
		return legendsDao.getLegendForKpi(userId, kpiId);
	}

	public boolean checkContinuity(List<Double> list, Double min, Double max) {
		Collections.sort(list);
		return ((Double.compare(list.get(0), min) == 0) && Double.compare(list.get(list.size() - 1), max) == 0);
	}

	@SuppressWarnings("deprecation")
	@Override
	public List<NewVariableRangeColorDto> parseFileForUsersVariableLegendsKpis(Path path) {
		List<NewVariableRangeColorDto> list = new ArrayList<>();
		try (FileInputStream inputStream = new FileInputStream(new File(path.toString()));
				Workbook workbook = new XSSFWorkbook(inputStream);) {
			Sheet firstSheet = workbook.getSheetAt(0);
			Iterator<Row> iterator = firstSheet.iterator();
			while (iterator.hasNext()) {
				int i = 1;
				NewVariableRangeColorDto newVariableRangeColorDto = new NewVariableRangeColorDto();
				Row nextRow = iterator.next();
				Iterator<Cell> cellIterator = nextRow.cellIterator();
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
						if (i == 5) {
							newVariableRangeColorDto.setColor(cell.getStringCellValue());
						} else if (i == 6) {
							newVariableRangeColorDto.setUnit(cell.getStringCellValue());
						}
					} else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
						switch (i) {
						case 1:
							newVariableRangeColorDto.setTemplateId(Math.round(cell.getNumericCellValue()));
							break;
						case 2:
							newVariableRangeColorDto.setKpiId(Math.round(cell.getNumericCellValue()));
							break;
						case 3:
							newVariableRangeColorDto.setMin(cell.getNumericCellValue());
							break;
						case 4:
							newVariableRangeColorDto.setMax(cell.getNumericCellValue());
							break;
						}
					}
					i++;
				}
				list.add(newVariableRangeColorDto);
			}
		} catch (IOException e) {
			log.error("exception in parsing the file ", e);
			throw new InvalidFileFormatException("file format is wrong ");
		}
		log.info("removing the heading ");
		if (list.size() > 1)
			return list.subList(1, list.size());
		else
			throw new InvalidFileFormatException("Invalid file format to import legends ");
	}

	@Override
	public List<NewFixedValueColorDto> parseFileForUserFixedLegendsKpis(Path path) {
		List<NewFixedValueColorDto> list = new ArrayList<>();
		try (FileInputStream inputStream = new FileInputStream(new File(path.toString()));
				Workbook workbook = new XSSFWorkbook(inputStream);) {
			Sheet firstSheet = workbook.getSheetAt(1);
			Iterator<Row> iterator = firstSheet.iterator();
			while (iterator.hasNext()) {
				int cloumn = 1;
				NewFixedValueColorDto newFixedValueColorDto = new NewFixedValueColorDto();
				Row nextRow = iterator.next();
				Iterator<Cell> cellIterator = nextRow.cellIterator();
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
						if (cloumn == 3) {
							newFixedValueColorDto.setColor(cell.getStringCellValue());
						} else if (cloumn == 5) {
							newFixedValueColorDto.setUnit(cell.getStringCellValue());
						} else if (cloumn == 4) {
							newFixedValueColorDto.setValue(String.format("%s", cell.getStringCellValue()));
						}
					} else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
						switch (cloumn) {
						case 2:
							newFixedValueColorDto.setKpiId(Math.round(cell.getNumericCellValue()));
							break;
						case 1:
							newFixedValueColorDto.setId(Math.round(cell.getNumericCellValue()));
							break;
						case 4:
							newFixedValueColorDto.setValue(cell.getNumericCellValue() + "");
							break;
						}

					}
					cloumn++;

				}
				list.add(newFixedValueColorDto);

			}
		} catch (IOException e) {
			log.error("file format is not correct ", e);
			throw new InvalidFileFormatException("file format provided is not correct ", e);
		}
		log.info("removing the heading from files ");
		if (list.size() > 1)
			return list.subList(1, list.size());
		else
			throw new InvalidFileFormatException("Invalid file format to import legends ");
	}

	@Override
	public Template createNewTemplate(Template template) {
		if (template.getUserId() == null && template.getTemplateName() == null)
			throw new InvalidRequestPayloadException("user information can not be null");
		else {
			Optional<Long> id = legendsDao.getTemplateName(template.getUserId(), template.getTemplateName());
			if (id.isPresent()) {
				template.setTemplateId(id.get());
				return legendsDao.updateTeplate(template);
			}
			return legendsDao.createNewTemplate(template);
		}
	}

	@Override
	public Object getDefaultKpiLegends(Long templateId, Long kpiId) {
		return legendsDao.getDefaultKpiLegends(templateId, kpiId);
	}

	@Override
	public String deleteTemplate(Long userId, Long teplateId) {
		int col = 0;
		log.debug("deleteing the template {}  the user {}", teplateId, userId);
		if (userId == null || teplateId == null)
			throw new InvalidPayloadException("userId or teplate id can not be null");
		else if (legendsDao.getTemplateForUser(userId, teplateId).getTemplateId() == 1) {
			throw new InvalidPayloadException("can not delete the default ");
		} else if (legendsDao.deleteTemplate(userId, teplateId) <= 0) {
			throw new DataNotFoundException("can not delete the default ");
		} else {
			return String.format("teplate with id %s  deleted success  ", teplateId);
		}

	}

	@Override
	public Template getTemplate(Long userId, Long templateid) {
		return legendsDao.getTemplateForUser(userId, templateid);
	}

	@Override
	public List<Template> getUserTemplates(Long userId) {
		return legendsDao.getUserTemplates(userId);
	}

	@Override
	public Template updateTeplate(Template teplate) {
		log.info("updating the template {} for user {}", teplate.getTemplateName(), teplate.getUserId());
		return legendsDao.updateTeplate(teplate);
	}

	@Override
	public Template applyTeplate(Template teplate) {
		log.info("applying the template {} for user {}", teplate.getTemplateName(), teplate.getUserId());
		return legendsDao.applyTeplate(teplate);
	}

	@Override
	public Template resetTeplate(ResetTeplate resetTeplate) {
		Template source = legendsDao.getTemplateForUser(resetTeplate.getUserId(), resetTeplate.getSourceTeplateId());
		Template destination = legendsDao.getTemplateForUser(resetTeplate.getUserId(),
				resetTeplate.getDetinationTeplateId());
		legendsDao.deleteOnlylegends(destination);
		legendsDao.saveNewVeriableLegends(source.getVariableRangeKpiLegendsList(), destination.getTemplateId());
		legendsDao.saveNewFixedLegends(source.getFixedValueKpiLegendsList(), destination.getTemplateId());
		return legendsDao.getTemplateForUser(destination.getUserId(), destination.getTemplateId());
	}

	@Override
	public Map<String, List<Integer>> getKpiValuesFromEs(UniqueKpiDto uniqueKpiDto) {
		Client client = EsClient.client;
		BoolQueryBuilder bqBuilder = new BoolQueryBuilder();
		if (uniqueKpiDto.getUserId() != null) {
			bqBuilder
					.must(QueryBuilders.rangeQuery("TimeStamp").from(uniqueKpiDto.getTimeFrom())
							.to(uniqueKpiDto.getTimeTo()).includeLower(true).includeUpper(true))
					.must(QueryBuilders.matchQuery("DmUser", uniqueKpiDto.getUserId()));
		} else {
			bqBuilder.must(QueryBuilders.rangeQuery("TimeStamp").from(uniqueKpiDto.getTimeFrom())
					.to(uniqueKpiDto.getTimeTo()).includeLower(true).includeUpper(true));
		}
		if (uniqueKpiDto.getFilter() != null || !uniqueKpiDto.getFilter().isEmpty()) {
			uniqueKpiDto.getFilter().forEach((key, value) -> {
				bqBuilder.must(QueryBuilders.termsQuery(key, uniqueKpiDto.getFilter().get(key)));
			});
		}
		bqBuilder.must(QueryBuilders.geoBoundingBoxQuery("loc").setCorners(uniqueKpiDto.getMapExtent().getCorner1(),
				uniqueKpiDto.getMapExtent().getCorner2(), uniqueKpiDto.getMapExtent().getCorner3(),
				uniqueKpiDto.getMapExtent().getCorner4()));
		bqBuilder.filter(QueryBuilders.existsQuery(uniqueKpiDto.getKpiName()));
		log.info("formed query  {}", bqBuilder.toString());
		String indices = Utill.getIndex(uniqueKpiDto.getTimeFrom(), uniqueKpiDto.getTimeTo());
		final String[] sIndices = indices.split(",");
		log.debug("querying from the index {}", Arrays.asList(sIndices));
		SearchRequestBuilder srb = client.prepareSearch(sIndices).setTypes("geo").setSize(0).setQuery(bqBuilder)
				.setSearchType(SearchType.DEFAULT);
		srb = srb.addAggregation(AggregationBuilders.terms("agg").field(uniqueKpiDto.getKpiName()).size(1500000));
		SearchResponse resp;
		try {
			resp = srb.execute().get();
			Result result = new ObjectMapper().readValue(resp.toString(), Result.class);
			List<Buckets> list = Arrays.asList(result.getAggregations().getAgg().getBuckets());
			Map<Integer, String> reminderColorMap = uniqueKpiDto.getValueColorMap();
			List<Integer> allUniqueList = list.stream().map(value -> Integer.parseInt(value.getKey()))
					.collect(Collectors.toList());
			Map<Integer, List<Integer>> auxiliaryMap = new HashMap<>();
			for (int i = 0; i < uniqueKpiDto.getDivisor(); i++) {
				final int reminder = i;
				log.info(String.format("list of all %s :", uniqueKpiDto.getKpiName()) + allUniqueList);
				auxiliaryMap.put(reminder, allUniqueList.parallelStream()
						.filter(value -> value % uniqueKpiDto.getDivisor() == reminder).collect(Collectors.toList()));
			}
			Map<String, List<Integer>> returnVal = new HashMap<>();
			reminderColorMap.forEach((key, value) -> {
				if (auxiliaryMap.get(key) != null && !auxiliaryMap.get(key).isEmpty())
					returnVal.put(reminderColorMap.get(key), auxiliaryMap.get(key));
			});
			log.debug("" + auxiliaryMap);
			log.debug(resp.toString());
			return returnVal;
		} catch (InterruptedException e) {
			log.error("error in connecting the es ", e);
			throw new EsException("error in getting the data from elasticserch ");
		} catch (Exception e) {
			log.error("error in connecting the es ", e);
			throw new EsException("error in getting the data from elasticserch ");
		}

	}

	@Override
	public Map<String, String> getDynamicKpiLegendsOnMapExtent(DynamicKpiDto dynamicKpiDto) {

		Client client = EsClient.client;
		BoolQueryBuilder bqBuilder = new BoolQueryBuilder();
		if (dynamicKpiDto.getUserId() != null) {
			bqBuilder
					.must(QueryBuilders.rangeQuery("TimeStamp").from(dynamicKpiDto.getTimeFrom())
							.to(dynamicKpiDto.getTimeTo()).includeLower(true).includeUpper(true))
					.must(QueryBuilders.matchQuery("DmUser", dynamicKpiDto.getUserId()));
		} else {
			bqBuilder.must(QueryBuilders.rangeQuery("TimeStamp").from(dynamicKpiDto.getTimeFrom())
					.to(dynamicKpiDto.getTimeTo()).includeLower(true).includeUpper(true));
		}

		if (dynamicKpiDto.getFilter() != null || !dynamicKpiDto.getFilter().isEmpty()) {
			dynamicKpiDto.getFilter().forEach((key, value) -> {
				bqBuilder.must(QueryBuilders.termsQuery(key, dynamicKpiDto.getFilter().get(key)));
			});
		}

		bqBuilder.must(QueryBuilders.geoBoundingBoxQuery("loc").setCorners(dynamicKpiDto.getMapExtent().getCorner1(),
				dynamicKpiDto.getMapExtent().getCorner2(), dynamicKpiDto.getMapExtent().getCorner3(),
				dynamicKpiDto.getMapExtent().getCorner4()));
		bqBuilder.filter(QueryBuilders.existsQuery(dynamicKpiDto.getKpiName()));
		log.info("formed query  {}", bqBuilder.toString());
		String indices = Utill.getIndex(dynamicKpiDto.getTimeFrom(), dynamicKpiDto.getTimeTo());
		final String[] sIndices = indices.split(",");
		log.debug("querying from the index {}", Arrays.asList(sIndices));
		SearchRequestBuilder srb = client.prepareSearch(sIndices).setTypes("geo").setSize(0).setQuery(bqBuilder)
				.setSearchType(SearchType.DEFAULT);
		srb = srb.addAggregation(AggregationBuilders.terms("agg").field(dynamicKpiDto.getKpiName()).size(1500000));
		SearchResponse resp;
		try {
			resp = srb.execute().get();
			Result result = new ObjectMapper().readValue(resp.toString(), Result.class);
			List<Buckets> list = Arrays.asList(result.getAggregations().getAgg().getBuckets());
			log.debug("" + list);
			Map<String, String> valueColorMap = dynamicKpiDto.getValueColorMap();
			List<String> allUniqueList = list.stream().map(value -> value.getKey()).collect(Collectors.toList());
			Map<String, String> returnVal = new HashMap<>();
			valueColorMap.forEach((key, value) -> {
				if (allUniqueList.contains(key)) {
					returnVal.put(valueColorMap.get(key), key);
				}
			});

			return returnVal;
		} catch (InterruptedException e) {
			log.error("error in connecting the es ", e);
			throw new EsException("error in getting the data from elasticserch ");
		} catch (Exception e) {
			log.error("error in connecting the es ", e);
			throw new EsException("error in getting the data from elasticserch ");
		}

	}

}
