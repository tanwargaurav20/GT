package com.harman.dmat.service.impl;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.harman.dmat.common.dto.LiveAPIDto;
import com.harman.dmat.common.dto.LivePciDto;
import com.harman.dmat.common.dto.LiveTrendingDto;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.dao.LiveAPIDao;
import com.harman.dmat.service.LiveAPIService;
import com.harman.dmat.utils.Utill;

/**
 * @author GTanwar Interacts with the DAO layer
 *
 */

@Service
@Transactional
public class LiveAPIServiceImpl implements LiveAPIService {

	@Autowired
	LiveAPIDao liveAPIDao;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.LiveAPIService#getLiveImei()
	 */
	@Override
	public LiveAPIDto getLiveImei() throws DataNotFoundException {
		String query = "select distinct imei from data_points_live_wm";
		LiveAPIDto liveAPIDto = liveAPIDao.getLiveImei(query);
		return liveAPIDto;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.LiveAPIService#getLiveTrend(java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public List<LiveTrendingDto> getLiveTrend(String imei, String timestamp) throws DataNotFoundException {
		String query = null;
		List<LiveTrendingDto> liveTrendingDtos = null;
		if (StringUtils.isBlank(timestamp)) {
			query = "SELECT rsrp,rsrq, rssi, sinr, CAST(pdschthroughput AS DECIMAL) / 1000 as pdsch, CAST(puschthroughput AS DECIMAL) / 1000 as pusch, dm_timestamp as dmtimestamp,dm_timestamp::time as time"
					+ "  FROM data_points_live_wm WHERE (dm_timestamp <= CURRENT_TIMESTAMP - INTERVAL '10 seconds') and imei='"
					+ imei + "' order by dmtimestamp desc limit 10";
		} else {
			query = "SELECT rsrp,rsrq, rssi, sinr, CAST(pdschthroughput AS DECIMAL) / 1000 as pdsch, CAST(puschthroughput AS DECIMAL) / 1000 as pusch, dm_timestamp as dmtimestamp,dm_timestamp::time  as time"
					+ " FROM data_points_live_wm WHERE (dm_timestamp <= '" + timestamp
					+ "' - INTERVAL '10 seconds') and imei='" + imei + "' order by dmtimestamp desc limit 10";
		}

		liveTrendingDtos = liveAPIDao.getLiveTrend(query);
		if (!liveTrendingDtos.isEmpty()) {
			for (LiveTrendingDto dto : liveTrendingDtos) {
				dto.setDmtimestamp(Utill.splitString(dto.getDmtimestamp(), Constant.DOT));
				dto.setTime(Utill.splitString(dto.getTime(), Constant.DOT));
			}
		}
		Collections.reverse(liveTrendingDtos);
		return liveTrendingDtos;
	}

	@Override
	public Map<String, List<Integer>> getKpiValuesFromPs(LivePciDto livePciDto) {
		List<Integer> lisOfPci = liveAPIDao.getKpiValuesFromPs(livePciDto.getImei());
		Map<Integer, String> reminderColorMap = livePciDto.getValueColorMap();
		Map<Integer, List<Integer>> auxiliaryMap = new HashMap<>();
		for (int i = 0; i < livePciDto.getDivisor(); i++) {
			final int reminder = i;
			auxiliaryMap.put(reminder, lisOfPci.parallelStream()
					.filter(value -> value % livePciDto.getDivisor() == reminder).collect(Collectors.toList()));
		}
		Map<String, List<Integer>> returnVal = new HashMap<>();
		reminderColorMap.forEach((key, value) -> {
			if (auxiliaryMap.get(key) != null && !auxiliaryMap.get(key).isEmpty())
				returnVal.put(reminderColorMap.get(key), auxiliaryMap.get(key));
		});
		return returnVal;
	}

}