package com.harman.dmat.service.impl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.harman.dmat.common.dto.CustomReportsDto;
import com.harman.dmat.common.dto.CustomReportsHistogramDto;
import com.harman.dmat.common.dto.CustomReportsLogDto;
import com.harman.dmat.common.dto.CustomReportsRequestDto;
import com.harman.dmat.common.dto.CustomReportsTemplateDto;
import com.harman.dmat.common.dto.LogMgrAnalysisDto;
import com.harman.dmat.common.dto.LogMgrPrefDto;
import com.harman.dmat.common.dto.LogMgrRespDto;
import com.harman.dmat.common.dto.PolygonLogsDto;
import com.harman.dmat.common.exception.AuthorizationException;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.InvalidRequestPayloadException;
import com.harman.dmat.common.exception.LogMgrException;
import com.harman.dmat.common.security.User;
import com.harman.dmat.common.sftp.SftpService;
import com.harman.dmat.dao.LogMgrDao;
import com.harman.dmat.enums.ErrorCode;
import com.harman.dmat.enums.Roles;
import com.harman.dmat.service.LogMgrService;
import com.harman.dmat.service.StorageService;
import com.harman.dmat.utils.Utill;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.SftpException;

import lombok.extern.slf4j.Slf4j;

/**
 * @author GTanwar Interacts with the DAO layer
 *
 */
@Slf4j
@Service
@Transactional
public class LogMgrServiceImpl implements LogMgrService {

	@Autowired
	LogMgrDao logMgrDao;

	@Inject
	SftpService sftpService;

	@Inject
	Environment environment;

	@Inject
	StorageService storageService;

	/*
	 * (non-Javadoc)
	 *
	 * @see com.harman.dmat.service.LogMgrService#getLogReport(java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.Integer, java.lang.Integer)
	 */
	@Override
	public LogMgrRespDto getLogReport(final String userId, final String startDate, final String endDate,
			final String mdn, final String model, final String fileName, final String imei, final Integer offset,
			final Integer limit, final String sortby, final Integer currUser, final String sortCol)
			throws DataNotFoundException {
		LogMgrRespDto logMgrRespDto;
		try {
			if (offset == null || limit == null) {
				log.error("Log Manager: Limit & offset not set");
				throw new InvalidRequestPayloadException();
			}

			logMgrRespDto = logMgrDao.getLogResults(userId, startDate, endDate, mdn, model, fileName, imei, offset,
					limit, sortby, currUser, sortCol);

			File dir = new File(storageService.getRootLocation().toString());
			FilenameFilter filter = new FilenameFilter() {

				@Override
				public boolean accept(File dir, String name) {
					return (name.endsWith(".dlf") || name.endsWith(".DLF"));
				}
			};

			File[] list = dir.listFiles(filter);
			long purgeTime = System.currentTimeMillis() - (1 * 24 * 60 * 60 * 1000);
			File fileDelete;
			boolean isdeleted = false;
			for (File file : list) {
				String temp = new StringBuffer(storageService.getRootLocation().toString()).append(File.separator)
						.append(file).toString();
				fileDelete = new File(temp);
				if (file.lastModified() < purgeTime)
					isdeleted = fileDelete.delete();
				log.debug("file : " + temp + " is deleted : " + isdeleted);
			}

		} catch (final InvalidRequestPayloadException e) {
			log.error("Log Manager: Error getting Logs." + e);
			throw new InvalidRequestPayloadException(e);
		} catch (final Exception e) {
			log.error("Log Manager: Error getting Logs." + e);
			throw new DataNotFoundException(e);
		}

		return logMgrRespDto;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.harman.dmat.service.LogMgrService#saveUserPref(com.harman.dmat.common
	 * .dto.LogMgrPrefDto)
	 */
	@Override
	public Boolean saveUserPref(final LogMgrPrefDto logMgrUserPrefDto) throws LogMgrException {
		Boolean result = false;
		try {
			result = logMgrDao.saveUserPref(logMgrUserPrefDto);
		} catch (final Exception e) {
			log.error("Log Manager: Error Saving user Preference." + e);
			throw new LogMgrException(e);
		}
		return result;

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.harman.dmat.service.LogMgrService#deleteLogs(java.lang.String)
	 */
	@Override
	public Boolean deleteLogs(final List<String> deleteFiles, String startDate, String endDate)
			throws InvalidRequestPayloadException, LogMgrException {
		Boolean result;
		try {
			result = logMgrDao.deleteLogs(deleteFiles, startDate, endDate);
		} catch (final LogMgrException e) {
			throw e;
		} catch (final Exception e) {
			log.error("Log Manager: Error deleting logs." + e.getMessage());
			throw new InvalidRequestPayloadException(e);
		}

		return result;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.harman.dmat.service.LogMgrService#getUserPref(java.lang.String)
	 */
	@Override
	public List<LogMgrPrefDto> getUserPref(final Integer userId) {
		List<LogMgrPrefDto> logMgrPrefDto;
		try {
			logMgrPrefDto = logMgrDao.getUserPref(userId);

		} catch (final Exception e) {
			log.error("Log Manager: Error getting user prefs." + e);
			throw new DataNotFoundException(e);
		}

		return logMgrPrefDto;

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.harman.dmat.service.LogMgrService#getLogAnalysisData()
	 */
	@Override
	public Map<String, List<LogMgrAnalysisDto>> getLogAnalysisData(String userId, Integer currUser, String startDate,
			String endDate, String dateType) {
		try {
			return logMgrDao.getLogAnalysisData(userId, currUser, startDate, endDate, dateType);
		} catch (final Exception e) {
			log.error("Log Manager: Error getting Analysis data" + e);
			throw new DataNotFoundException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.LogMgrService#searchLogs(java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.Integer, java.lang.Integer)
	 */
	@Override
	public LogMgrRespDto searchLogs(String user, String startDate, String endDate, String param, String sortby,
			Integer offset, Integer limit, final Integer currUser, final String sortCol) {
		LogMgrRespDto logMgrRespDto;
		try {
			if (offset == null || limit == null || param == null) {
				log.error("Log Manager: Limit & offset not set ");
				throw new InvalidRequestPayloadException();
			}
			logMgrRespDto = logMgrDao.searchLogs(user, startDate, endDate, param.toLowerCase().split("\\s+")[0], sortby,
					offset, limit, currUser, sortCol);

		} catch (final InvalidRequestPayloadException e) {
			log.error("Log Manager: Error getting Logs." + e);
			throw new InvalidRequestPayloadException(e);
		} catch (final Exception e) {
			log.error("Log Manager: Error getting Logs." + e);
			throw new DataNotFoundException(e);
		}

		return logMgrRespDto;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.LogMgrService#fileUploadHandler(org.
	 * springframework.web.multipart.MultipartFile)
	 */
	@Override
	public Integer fileUploadHandler(MultipartFile file) throws IOException {
		Integer uploaded = 0;
		ChannelSftp channelSftp = null;

		log.debug("fileUploadHandler: preparing the host information for sftp.");
		try {
			channelSftp = sftpService.connectChannel();
			try {
				channelSftp.ls(file.getOriginalFilename());
				uploaded = 1;
				log.debug("fileUploadHandler: file already esists.");
			} catch (SftpException sftpException) {
				log.debug("fileUploadHandler: uploading file.");
			}
			if (uploaded == 0) {
				channelSftp.put(file.getInputStream(), file.getOriginalFilename());
			}

		} catch (final SftpException e) {
			uploaded = 2;
		}

		return uploaded;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.LogMgrService#fileDownloadHandler(java.lang.
	 * String)
	 */
	@Override
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public File fileDownloadHandler(String file) throws IOException {
		String filePath = "";
		File f = null;
		final Integer userId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();
		String userDomain = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserDomain();
		List<String> verizonDomains = Arrays.asList(environment.getProperty("verizon.domains").split(","));
		try {
			filePath = logMgrDao.getFilePath(file);
		} catch (final Exception e) {
			log.error("Log Manager: Error getting logs data against file" + e);
			throw new DataNotFoundException(e);
		}
		if (verizonDomains.parallelStream().anyMatch(domain -> domain.trim().equalsIgnoreCase(userDomain))
				|| userId == Integer.parseInt(logMgrDao.getUserFromFile(file))) {
			f = downloadFileFromFtp(filePath, file);
		} else {
			throw new AuthorizationException(ErrorCode.ACCESS_DENIED.getErrorMessage(),
					ErrorCode.ACCESS_DENIED.getErrorCode());
		}
		return f;
	}

	private File downloadFileFromFtp(String filePath, String file) throws IOException {
		log.debug("fileDownloadHandler: preparing the host information for sftp.");
		ChannelSftp channelSftp = null;
		File f  = new File(storageService.getRootLocation() + File.separator + file);
		channelSftp = sftpService.connectChannel();
		try (OutputStream out = new FileOutputStream(f);
				InputStream inputStream = channelSftp.get(filePath + "/" + file);) {
			byte buf[] = new byte[1024];
			int bytesread = 0, bytesBuffered = 0;
			while ((bytesread = inputStream.read(buf)) > -1) {
				out.write(buf, 0, bytesread);
				bytesBuffered += bytesread;
				if (bytesBuffered > 1024 * 1024) { // flush after 1MB
					bytesBuffered = 0;
					out.flush();
				}
			}
		} catch (SftpException | FileNotFoundException ex) {
			if (log.isDebugEnabled())
				log.debug(ex.getMessage());
		}
		return f;
	}

	@Override
	public PolygonLogsDto getLogSixMonthLogs(Integer userId, String geoPoints, String mdn, String imei,
			String stateCode, String regions, String modelId, String deviceId, Integer userId2, String geoPoints2,
			String mdn2, String imei2, String stateCode2, String regions2, String modelId2, String deviceId2,
			Integer limit, Integer offset, String startDate, String endDate, String fileName) {
		try {
			return logMgrDao.getLogSixMonthLogs(null, geoPoints, mdn, imei, stateCode, regions, modelId, deviceId,
					limit, offset, startDate, endDate, fileName);
		} catch (final Exception e) {
			log.error("Log Manager: Error getting logs data against polygon" + e);
			throw new DataNotFoundException(e);
		}
	}

	@Override
	public CustomReportsLogDto searchLogFiles(Integer data, String from, String to, String param, Integer offset,
			Integer limit) {
		CustomReportsLogDto list = null;
		try {

			list = logMgrDao.searchLogFiles(data, from, to, param, offset, limit);

		} catch (final InvalidRequestPayloadException e) {
			log.error("Log Manager searchLogFiles: Error getting files." + e);
			throw new InvalidRequestPayloadException(e);
		} catch (final Exception e) {
			log.error("Log Manager searchLogFiles: Error getting files." + e);
			throw new DataNotFoundException(e);
		}

		return list;

	}

	@Override
	public Map<String, List<CustomReportsHistogramDto>> getHistogram(CustomReportsRequestDto customReportsRequestDto) {
		Map<String, List<CustomReportsHistogramDto>> map = null;

		try {
			map = logMgrDao.getHistogram(customReportsRequestDto);

		} catch (final InvalidRequestPayloadException e) {
			log.error("Log Manager searchLogFiles: Error getting files." + e);
			throw new InvalidRequestPayloadException(e);
		} catch (final Exception e) {
			log.error("Log Manager searchLogFiles: Error getting files." + e);
			throw new DataNotFoundException(e);
		}

		return map;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.LogMgrService#getDevices()
	 */
	@Override
	public List<String> getDevices(String startDate, String endDate) throws DataNotFoundException {
		final String userDomain = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserDomain();
		String domainQuery = "";
		if (!isVzDomain(userDomain)) {
			domainQuery = "{ \"bool\" : { \"must\" : [ { \"query_string\" : {\"query\" : \"EmailId:*" + userDomain
					+ "\", \"analyzer\": \"standard\" } } ] } },";
		}

		String query = "{ \"size\": 0," + domainQuery
				+ "\"aggs\": { \"unique_set_1\": { \"terms\": { \"field\": \"ModelName\" },"
				+ " \"aggregations\": { \"unique_set_2\": { \"terms\": { \"field\": \"Imei\" } } } } } }";
		String index = Utill.getIndex(startDate, endDate);
		if (log.isDebugEnabled())
			log.debug("Index to query: " + index);
		return logMgrDao.getDevices(query, index);
	}

	@Override
	public Integer saveTemplate(CustomReportsTemplateDto reportsTemplateDto) {
		return logMgrDao.saveTemplate(reportsTemplateDto);
	}

	@Override
	public List<CustomReportsTemplateDto> getAllTemplates(String userId) throws DataNotFoundException {
		return logMgrDao.getAllTemplates(userId);

	}

	@Override
	public Integer deleteTemplate(CustomReportsTemplateDto reportsTemplateDto) {
		return logMgrDao.deleteTemplate(reportsTemplateDto);
	}

	@Override
	public Integer editTemplate(CustomReportsTemplateDto reportsTemplateDto) {
		return logMgrDao.editTemplate(reportsTemplateDto);
	}

	@Override
	public Map<String, List<CustomReportsHistogramDto>> getTimeseries(CustomReportsRequestDto customReportsRequestDto) {
		Map<String, List<CustomReportsHistogramDto>> map = null;

		try {
			map = logMgrDao.getTimeseries(customReportsRequestDto);

		} catch (final InvalidRequestPayloadException e) {
			log.error("Log Manager searchLogFiles: Error getting files." + e);
			throw new InvalidRequestPayloadException(e);
		} catch (final Exception e) {
			log.error("Log Manager searchLogFiles: Error getting files." + e);
			throw new DataNotFoundException(e);
		}

		return map;

	}

	/**
	 * Checks user's domain
	 * 
	 * @param userDomain
	 * @return
	 */
	private Boolean isVzDomain(String userDomain) {
		Boolean isVzDomain = false;
		try {
			List<String> listVzDomains = Arrays
					.asList(environment.getRequiredProperty("verizon.domains").toLowerCase().split(","));
			if (listVzDomains.contains(userDomain.toLowerCase())) {
				isVzDomain = true;
			}
		} catch (Exception e) {
			log.error("Error Getting Vz domains");
		}

		return isVzDomain;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.LogMgrService#reprocessLogFile(java.lang.String)
	 */
	@Override
	public Integer reprocessLogFile(List<Integer> testIds) throws IOException {
		Integer uploaded = 0;
		ChannelSftp sftpChannel = null;
		for (int testId : testIds) {
			List<CustomReportsDto> customReportDtoList = logMgrDao.getPathFromFileName(""); //TODO
			if (customReportDtoList == null) {
				uploaded = 2;
				return uploaded;
			}
			log.debug("reprocessLogFile: preparing the host information for sftp.");
			try {
				String source = customReportDtoList.get(0).getFileLocation() + "/"
						+ customReportDtoList.get(0).getFileName();
				String destination = environment.getRequiredProperty("sftp.wrkngdir") + "/"
						+ customReportDtoList.get(0).getFileName();
				sftpChannel = sftpService.connectChannel();

				if (uploaded == 0) {
					sftpChannel.rename(source, destination);
				}

			} catch (SftpException e) {
				uploaded = 2;
			}
		}
		return uploaded;
	}

}