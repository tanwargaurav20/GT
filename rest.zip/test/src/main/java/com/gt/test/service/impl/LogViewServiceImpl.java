package com.harman.dmat.service.impl;

import com.harman.dmat.common.dto.*;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.dao.LogViewDao;
import com.harman.dmat.service.LogViewService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
@Slf4j
public class LogViewServiceImpl implements LogViewService {
    @Inject
    LogViewDao logViewDao;
    @Inject
    private Environment environment;

    public ResponseDto getFileId(LogViewDto logViewDto) {
        final ResponseDto responseDto = new ResponseDto();
        String fileId = logViewDao.getFileId(logViewDto);

        if (fileId != null && !fileId.equals("")) {
            log.debug("Fileid for the given testId " + fileId);
            responseDto.setStatus(Constant.OK);
            responseDto.setMessage("Fileid for the given testId " + fileId);
            responseDto.setData(fileId);
        } else {
            log.debug("Unable to get the fileId for the given testId "+ logViewDto.getTestId());
            responseDto.setStatus(Constant.NOT_FOUND);
            responseDto.setMessage("Unable to get the fileId for the given testId "+ logViewDto.getTestId());
            responseDto.setData("Unable to get the fileId for the given testId "+ logViewDto.getTestId());
        }

        return responseDto;
    }

    @Override
    public ResponseDto updateEvtStatus(List<LogViewDto> statusList){
        final ResponseDto responseDto = new ResponseDto();
        String result = logViewDao.updateEvtStatus(statusList,false);

        if (result != null && !result.equals("failure") && !result.equals("")) {
            log.debug("result for the given event status " + result);
            responseDto.setStatus(Constant.OK);
            responseDto.setMessage("Events updated with Status Successfully for "+statusList.toString());
            responseDto.setData(result);
        } else {
            log.debug("Unable to update the event status");
            responseDto.setStatus(Constant.OK);
            responseDto.setMessage("Unable to update the event status");
            responseDto.setData("Unable to update the event status");
        }

        return responseDto;
    }
    @Override
    public List<LogViewDto> getEventsList(){
        List<LogViewDto> lvdList = logViewDao.getEventsList();
        if(!lvdList.isEmpty()){
            log.debug("Polling Results to LVAB : "+lvdList.toString());
            //logViewDao.updateEvtStatus(lvdList,true);
            for(LogViewDto lvd : lvdList){
                lvd.setDuration(new Integer(environment.getRequiredProperty("lv.duration")).intValue());
//                lvd.setDuration(30);
            }
        }
        return lvdList;
    }

    @Override
    public EventStatusDto getStatusReportCount(String startDate, String endDate){
        return logViewDao.getStatusReportCount(startDate,endDate);
    }

    @Override
    public ResponseDto getAutoTestReport(String fileName){
        final ResponseDto responseDto = new ResponseDto();
        List<AutoTestReportDto> autoTestReports = logViewDao.getAutoTestReport(fileName);

        if (autoTestReports != null && !autoTestReports.isEmpty()) {
            responseDto.setStatus(Constant.OK);
            responseDto.setMessage("Successfully retrieved auto test report for " + fileName);
            responseDto.setData(autoTestReports);
        } else {
            log.debug("Unable to get the test report for the given filename "+ fileName);
            responseDto.setStatus(Constant.NOT_FOUND);
            responseDto.setMessage("Unable to get the test report for the given filename "+ fileName);
            responseDto.setData("Unable to get the test report for the given filename "+ fileName);
        }

        return responseDto;
    }
}
