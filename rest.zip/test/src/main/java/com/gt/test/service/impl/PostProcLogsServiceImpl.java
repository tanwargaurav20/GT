package com.harman.dmat.service.impl;

import com.harman.dmat.common.dto.PostProcLogsDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.dao.PostProcLogsDao;
import com.harman.dmat.service.PostProcLogsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.List;

@Component
@Slf4j
public class PostProcLogsServiceImpl implements PostProcLogsService {
    @Inject
    PostProcLogsDao postProcLogsDao;

    @Override
    public ResponseDto addPostProcLogs(List<PostProcLogsDto> postProcLogs) {
        ResponseDto responseDto = new ResponseDto();
        String status = postProcLogsDao.addPostProcLogs(postProcLogs);

        if(status == "Success") {
            log.debug("Succefully added Post Proc Logs");
            responseDto.setStatusCode(0);
            responseDto.setMessage("Succefully added Post Proc Logs");
            responseDto.setData("Succefully added Post Proc Logs");
        } else {
            log.error("Failed to add Post Proc Logs");
            responseDto.setErrorCode(1);
            responseDto.setMessage("Failed to add Post Proc Logs");
            responseDto.setDeveloperMessage("Failed to add Post Proc Logs");
        }

        return responseDto;
    }
}
