package com.harman.dmat.service.impl;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;

import javax.inject.Inject;

import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.transport.RemoteTransportException;
import org.springframework.core.env.Environment;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.harman.dmat.common.dto.FilterKpi;
import com.harman.dmat.common.dto.Result;
import com.harman.dmat.common.dto.USRegionDto;
import com.harman.dmat.common.security.User;
import com.harman.dmat.legends.exception.RegionException;
import com.harman.dmat.service.RegionService;
import com.harman.dmat.utils.EsClient;
import com.harman.dmat.utils.Utill;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class RegionServiceImpl implements RegionService {

	@Inject
	Environment environment;

	@Override
	public Result getRegionData(USRegionDto usRegionDto) {
		Result result = null;
		try {
			Client client = EsClient.client;
			final String userDomain = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
					.getUserDomain();
			BoolQueryBuilder bqBuilder = new BoolQueryBuilder();
			if (usRegionDto.getUserId() != null && !usRegionDto.getUserId().isEmpty()) {
				bqBuilder
						.must(QueryBuilders.rangeQuery("TimeStamp").from(usRegionDto.getDm_timestampFrom())
								.to(usRegionDto.getDm_timestampTo()).includeLower(true).includeUpper(true))
						.must(QueryBuilders.matchQuery("DmUser", usRegionDto.getUserId()));

				if (Utill.checkCollectionIsNotNullOrEmpty.test(usRegionDto.getStateCode())) {
					bqBuilder.must(QueryBuilders.termsQuery("StateCode", usRegionDto.getStateCode()));
				}

			} else {
				bqBuilder.must(QueryBuilders.rangeQuery("TimeStamp").from(usRegionDto.getDm_timestampFrom())
						.to(usRegionDto.getDm_timestampTo()).includeLower(true).includeUpper(true));
				if (Utill.checkCollectionIsNotNullOrEmpty.test(usRegionDto.getStateCode())) {
					bqBuilder.must(QueryBuilders.termsQuery("StateCode", usRegionDto.getStateCode()));
				}
			}
			if (usRegionDto.getMapExtent() != null) {
				bqBuilder.must(QueryBuilders.geoBoundingBoxQuery("loc").setCorners(
						usRegionDto.getMapExtent().getCorner1(), usRegionDto.getMapExtent().getCorner2(),
						usRegionDto.getMapExtent().getCorner3(), usRegionDto.getMapExtent().getCorner4()));
			}
			if (usRegionDto.getKpiFilterDto() != null && usRegionDto.getKpiFilterDto().isKpisEnable()
					&& usRegionDto.getKpiFilterDto() != null && usRegionDto.getKpiFilterDto().getFilterKpiList() != null
					&& !usRegionDto.getKpiFilterDto().getFilterKpiList().isEmpty()) {
				List<FilterKpi> list = usRegionDto.getKpiFilterDto().getFilterKpiList();
				list.forEach(value -> bqBuilder
						.must(QueryBuilders.rangeQuery(value.getEskey()).from(value.getMin()).to(value.getMax())));
			} else if (usRegionDto.getKpiFilterDto() != null && usRegionDto.getKpiFilterDto().getRatValues() != null
					&& !usRegionDto.getKpiFilterDto().getRatValues().isEmpty()) {
				usRegionDto.getKpiFilterDto().getRatValues().forEach((key, value) -> {
					bqBuilder.must(QueryBuilders.termsQuery(key, value));
				});

			}

			if (usRegionDto.getSubFilterDto() != null && usRegionDto.getSubFilterDto().getTestId() != null
					&& !usRegionDto.getSubFilterDto().getTestId().isEmpty()) {
				usRegionDto.getSubFilterDto().getTestId().forEach((key, value) -> {
					bqBuilder.must(QueryBuilders.termsQuery(key, value));
				});

			}
			if (usRegionDto.getSubFilterDto() != null && usRegionDto.getSubFilterDto().getFiles() != null
					&& !usRegionDto.getSubFilterDto().getFiles().isEmpty()) {
				usRegionDto.getSubFilterDto().getFiles().forEach((key, value) -> {
					bqBuilder.must(QueryBuilders.termsQuery(key, value));
				});

			}
			if (usRegionDto.getSubFilterDto() != null && usRegionDto.getSubFilterDto().getImei() != null
					&& !usRegionDto.getSubFilterDto().getImei().isEmpty()) {
				usRegionDto.getSubFilterDto().getImei().forEach((key, value) -> {
					bqBuilder.must(QueryBuilders.termsQuery(key, value));
				});

			}
			if (usRegionDto.getSubFilterDto() != null && usRegionDto.getSubFilterDto().getMdn() != null
					&& !usRegionDto.getSubFilterDto().getMdn().isEmpty()) {
				usRegionDto.getSubFilterDto().getMdn().forEach((key, value) -> {
					bqBuilder.must(QueryBuilders.termsQuery(key, value));
				});

			}
			if (usRegionDto.getSubFilterDto() != null && usRegionDto.getSubFilterDto().getModel() != null
					&& !usRegionDto.getSubFilterDto().getModel().isEmpty()) {
				usRegionDto.getSubFilterDto().getModel().forEach((key, value) -> {
					bqBuilder.must(QueryBuilders.termsQuery(key, value));
				});

			}

			if (usRegionDto.getSelectedKpisDto() != null && usRegionDto.getSelectedKpisDto().getBandValues() != null
					&& !usRegionDto.getSelectedKpisDto().getBandValues().isEmpty()) {
				usRegionDto.getSelectedKpisDto().getBandValues().forEach((key, value) -> {
					bqBuilder.must(QueryBuilders.termsQuery(key, value));
				});

			}
			if (usRegionDto.getSelectedKpisDto() != null && usRegionDto.getSelectedKpisDto().getEarfcnValues() != null
					&& !usRegionDto.getSelectedKpisDto().getEarfcnValues().isEmpty()) {
				usRegionDto.getSelectedKpisDto().getEarfcnValues().forEach((key, value) -> {
					bqBuilder.must(QueryBuilders.termsQuery(key, value));
				});

			}
			if (usRegionDto.getSelectedKpisDto() != null && usRegionDto.getSelectedKpisDto().getSelectedKpis() != null
					&& !usRegionDto.getSelectedKpisDto().getSelectedKpis().isEmpty()) {
				usRegionDto.getSelectedKpisDto().getSelectedKpis().forEach((key) -> {
					bqBuilder.should(QueryBuilders.existsQuery(key));
				});

			}

			try {
				List<String> listVzDomains = Arrays
						.asList(environment.getRequiredProperty("verizon.domains").split(","));

				if (listVzDomains.contains(userDomain)) {
					listVzDomains.forEach((key) -> {
						bqBuilder.should(QueryBuilders.wildcardQuery("EmailId", "*" + key));
					});
				} else {
					bqBuilder.must(QueryBuilders.wildcardQuery("EmailId", "*" + userDomain.toLowerCase()));
				}
			} catch (Exception e) {
				log.error("Error Getting Vz domains");
			}

			bqBuilder.filter(QueryBuilders.existsQuery("County"));

			String indices = Utill.getIndex(usRegionDto.getDm_timestampFrom(), usRegionDto.getDm_timestampTo());
			final String[] sIndices = indices.split(",");
			log.debug("querying from the index {}", Arrays.asList(sIndices));
			SearchRequestBuilder srb = client.prepareSearch(sIndices).setTypes(usRegionDto.getType()).setSize(0)
					.setQuery(bqBuilder).setSearchType(SearchType.DEFAULT);
			srb = srb.addAggregation(AggregationBuilders.terms("agg").field(usRegionDto.getField()).size(150000));
			SearchResponse resp = srb.execute().get();
			if (log.isDebugEnabled()) {
				log.debug("Query: {}", bqBuilder.toString());
				// log.debug(resp.toString()); commenting response logging

			}
			result = new ObjectMapper().readValue(resp.toString(), Result.class);
		} catch (IOException | InterruptedException | ExecutionException |

				RemoteTransportException exception) {
			log.error("error in fatching the data from ES  {}", exception);
			throw new RegionException(
					String.format("No data Found for this range from date %s to date %s please change the data range ",
							usRegionDto.getDm_timestampFrom(), usRegionDto.getDm_timestampTo()));
		}
		return result;
	}
	/*
	 * RegionServiceImpl.java insnayak20
	 **/
}
