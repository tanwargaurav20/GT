package com.harman.dmat.service.impl;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.ClientProtocolException;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.harman.dmat.common.dto.AccordionInfo;
import com.harman.dmat.common.dto.AreaDto;
import com.harman.dmat.common.dto.CompanyDto;
import com.harman.dmat.common.dto.ContactDto;
import com.harman.dmat.common.dto.DeviceDto;
import com.harman.dmat.common.dto.EditRoleDto;
import com.harman.dmat.common.dto.EditUserStatusDto;
import com.harman.dmat.common.dto.EmailDto;
import com.harman.dmat.common.dto.EventDto;
import com.harman.dmat.common.dto.EventDtos;
import com.harman.dmat.common.dto.EventsBodyDto;
import com.harman.dmat.common.dto.EventsCountDto;
import com.harman.dmat.common.dto.FeedBackDto;
import com.harman.dmat.common.dto.FileUploadDto;
import com.harman.dmat.common.dto.GroupDto;
import com.harman.dmat.common.dto.GroupRequestDto;
import com.harman.dmat.common.dto.LastActivitiyDto;
import com.harman.dmat.common.dto.OsDto;
import com.harman.dmat.common.dto.PreferenceDto;
import com.harman.dmat.common.dto.PrivilegeDto;
import com.harman.dmat.common.dto.RegionDto;
import com.harman.dmat.common.dto.ResponseDto;
import com.harman.dmat.common.dto.RoleDto;
import com.harman.dmat.common.dto.SimInfoDto;
import com.harman.dmat.common.dto.SimRequestData;
import com.harman.dmat.common.dto.SimRequestDto;
import com.harman.dmat.common.dto.SoftwareVersionDto;
import com.harman.dmat.common.dto.StateDto;
import com.harman.dmat.common.dto.StatusInfoDto;
import com.harman.dmat.common.dto.UserDto;
import com.harman.dmat.common.dto.UserPreferenceDto;
import com.harman.dmat.common.email.EmailService;
import com.harman.dmat.common.exception.DataAccessException;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.FTPException;
import com.harman.dmat.common.exception.InvalidRequestPayloadException;
import com.harman.dmat.common.exception.SystemException;
import com.harman.dmat.common.exception.UserEmailException;
import com.harman.dmat.common.exception.UserException;
import com.harman.dmat.common.security.User;
import com.harman.dmat.common.sftp.SftpService;
import com.harman.dmat.constant.Constant;
import com.harman.dmat.dao.UserDao;
import com.harman.dmat.enums.ErrorCode;
import com.harman.dmat.enums.FileTypeEnum;
import com.harman.dmat.enums.Roles;
import com.harman.dmat.enums.Status;
import com.harman.dmat.service.ConfigurationService;
import com.harman.dmat.service.LegendsService;
import com.harman.dmat.service.StorageService;
import com.harman.dmat.service.UserService;
import com.harman.dmat.utils.SecuirtyUtils;
import com.harman.dmat.utils.UserManagerStringUtil;
import com.harman.dmat.utils.Utill;
import com.jcraft.jsch.ChannelSftp;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class UserServiceImpl.
 *
 * @author prakash.bisht@harman.com
 */

@Component

/** The Constant log. */

/** The Constant log. */

/** The Constant log. */
@Slf4j
public class UserServiceImpl implements UserService {

	/**
	 * Injected UserDao implementation.
	 */
	@Inject
	LegendsService legendsService;

	/** The user dao. */
	@Inject
	UserDao userDao;
	/**
	 * Injected EmailService implementation.
	 */
	@Inject
	EmailService emailService;

	/** The storage service. */
	@Inject
	StorageService storageService;

	/** Injected ConfigurationService implementation. */
	@Inject
	ConfigurationService config;

	/** The environment. */
	@Inject
	private Environment environment;

	/**
	 * SftpService UserServiceImpl.java
	 */
	@Inject
	SftpService sftpService;

	@Inject
	private RestTemplate restTemplate;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#validateUser(java.lang.String,
	 * java.lang.String, java.lang.String)
	 */
	@Override
	public UserDto validateUser(final String username, final String userPass, final String accessCode)
			throws UserException {
		UserDto userDto = null;
		String statusCode = "";
		boolean resetPassword = false;
		Boolean isLMAuthenticated = false;
		try {
			statusCode = authenticateUserinLM(username, userPass);
			String[] lmResp = statusCode.split(Pattern.quote("||"));
			if(lmResp.length>0){
				statusCode = lmResp[0];
				resetPassword = StringUtils.equalsIgnoreCase(lmResp[1],"true")?true:false;
			}
			if (statusCode.equals(Constant.LM_SUCCESS)) {
				isLMAuthenticated = true;
			}
			if (statusCode.equals(Constant.LM_INVALID_CREDENTIALS)) {
				throw new UserException(ErrorCode.INVALID_USER.getErrorMessage(),
						ErrorCode.INVALID_USER.getErrorCode());
			}
			if (statusCode.equals(Constant.LM_INACTIVE_USER)) {
				throw new UserException(ErrorCode.INACTIVE_USER.getErrorMessage(),
						ErrorCode.INACTIVE_USER.getErrorCode());
			}
			if (statusCode.equals(Constant.LM_LICENSE_EXPIRED)) {
				throw new UserException(ErrorCode.LICENSE_EXPIRED.getErrorMessage(),
						ErrorCode.LICENSE_EXPIRED.getErrorCode());
			}
			if (statusCode.equals(Constant.LM_UNAUTHORIZED_USER)) {
				log.error("Error occured during validateuser agains userid {}." + username);
				throw new UserException(ErrorCode.INVALID_USER.getErrorMessage(),
						ErrorCode.INVALID_USER.getErrorCode());
			}
		} catch (final UserException e) {
			throw e;
		} catch (final Exception e) {
			isLMAuthenticated = false;
			log.error("License Manager server failed to respond. Switching to local postgres authorization.");
		}
		try {
			userDto = userDao.getUserByEmail(username);
		} catch (final Exception e) {
			log.error("Error occured during validateuser agains userid {}." + username + e);
			throw new UserException(ErrorCode.INVALID_USER.getErrorMessage(), ErrorCode.INVALID_USER.getErrorCode());
		}
		if (userDto != null) {
			final int userStatus = userDto.getStatus();
			if (userStatus == Status.INACTIVE.getValue() || userStatus == Status.PENDING.getValue()) {
				throw new UserException(ErrorCode.INACTIVE_USER.getErrorMessage(),
						ErrorCode.INACTIVE_USER.getErrorCode());
			}
			final String userStoredPasswordHash = userDto.getPassword();
			final boolean accessCodeMatch = true;
			if (userStatus == Status.SUSPENDED.getValue()) {
				if (!userDto.getAccessCode().equals(accessCode)) {
					throw new UserException(ErrorCode.ACCESSCODE_NOT_MATCH.getErrorMessage(),
							ErrorCode.ACCESSCODE_NOT_MATCH.getErrorCode());
				}
			}
			if (isLMAuthenticated
					|| (SecuirtyUtils.matchPassword(userPass, userStoredPasswordHash) && accessCodeMatch)) {

				if (StringUtils.isNotBlank(userDto.getAccessCode())) {
					userDao.upadateAccessCode(userDto.getUserId(), null, Status.ACTIVE.getValue());
				}

				final Date lastLogin = userDto.getLastLogin();
				if (lastLogin != null && userDto.getStatus() != Status.SUSPENDED.getValue()) {
					final Integer day = Integer.parseInt(config.getAllConfiguration().get("suspend_day"));
					final LocalDate revisedlocal = LocalDate.now().minusDays(day);
					final Date revisedDate = Date.from(revisedlocal.atStartOfDay(ZoneId.systemDefault()).toInstant());
					if (revisedDate.after(lastLogin) && userDto.getStatus() != Status.SUSPENDED.getValue()) {
						final String generatedAccessCode = Utill.randomAlphaNumeric(8);
						final EmailDto emailDto = new EmailDto(userDto.getFirstName(), userDto.getEmail(),
								generatedAccessCode, config.getAllConfiguration().get("access_code_subject"));
						emailService.sendEmail(emailDto);
						userDao.upadateAccessCode(userDto.getUserId(), generatedAccessCode,
								Status.SUSPENDED.getValue());
						throw new UserException(ErrorCode.LAST_LOGIN.getErrorMessage(),
								ErrorCode.LAST_LOGIN.getErrorCode());
					}
				}
				userDto.setPassword(null);
				userDto.setStatus(Status.ACTIVE.getValue());
				userDto.setIsResetPassword(resetPassword?1:0);
				userDao.updateLastLoginTime(userDto.getUserId());
				return userDto;
			}
		} else {
			throw new UserException(ErrorCode.NOT_EXIST_USER.getErrorMessage(),
					ErrorCode.NOT_EXIST_USER.getErrorCode());
		}
		throw new UserException(ErrorCode.INVALID_USER.getErrorMessage(), ErrorCode.INVALID_USER.getErrorCode());

	}

	/**
	 * @param username
	 * @param userPass
	 * @return
	 * @throws IOException
	 * @throws JSONException
	 * @throws ClientProtocolException
	 */
	private String authenticateUserinLM(String username, String userPass) throws JSONException {
		String statusCode = "";
		String tempPassword = "false";
		String element = ("[{ \"signinauth\": { \"user\": \"" + username + "\", \"password\": \"" + userPass
				+ "\", \"productID\": 2 } }]");
		// JSONObject request = new JSONObject(element);

		// set headers
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<String>(element, headers);

		// send request and parse result
		ResponseEntity<String> authResp = restTemplate.exchange(environment.getRequiredProperty("lmLoginUrl"),
				HttpMethod.POST, entity, String.class);

		if (authResp.getStatusCode() == HttpStatus.OK) {
			JSONObject userJson = new JSONObject(authResp.getBody());
			if(StringUtils.isNotBlank(userJson.getString("tempPassword"))){
				tempPassword = userJson.getString("tempPassword");
			}
			if(StringUtils.isNotBlank(userJson.getString("licenseExpired")) && StringUtils.equalsIgnoreCase(userJson.getString("licenseExpired"),"true")){
				boolean allowUser = validateLMExpiry(userJson.getString("endDateTime"));
				statusCode = (allowUser)?Constant.LM_SUCCESS:Constant.LM_LICENSE_EXPIRED;
			}
			else {
				statusCode = userJson.getString("statusCode");
			}
		}
		return statusCode.concat("||").concat(tempPassword);
	}
	private boolean validateLMExpiry(String date){
		boolean isValid = false;
		if(StringUtils.isNotBlank(date)){
			String[] dateSplit = date.split(Pattern.quote(" "));
			try {
				Date formattedDate = new SimpleDateFormat("MM/dd/yyyy").parse(dateSplit[0]);
				Date todayDate = new Date();
				DateFormat outputFormatter = new SimpleDateFormat("MM/dd/yyyy");
				isValid = (StringUtils.equalsIgnoreCase(outputFormatter.format(formattedDate),outputFormatter.format(todayDate)))?true:false;
			}
			catch(ParseException pe){
				log.error("Error parsing the date");
			}
		}
		return isValid;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#forgetPassword(java.lang.String)
	 */
	@Override
	public void forgetPassword(final String userName) throws UserException {
		final UserDto userDto = userDao.getUserByEmail(userName);
		if (userDto != null) {
			final String tempPassword = Utill.randomAlphaNumeric(8);
			final String emailBody = "<p>Dear <strong>" + userDto.getFirstName() + " " + userDto.getLastName()
					+ ",</strong></p>\r\n<p>We receive a request to reset your DMAT password<br />You can log in at <a href=\"https://vzwdt.com/DMATBD/#/login\">DMATLogin </a>using <span style=\"text-decoration: underline;\">"
					+ userDto.getEmail() + "</span> as username and <br /><strong>" + tempPassword
					+ "</strong><br />as temporary <strong>password</strong>. Then, please make sure to keep your information secure by updating your password.</p>\r\n<p><br />Thank you<br />Regards,<br />TEAM DMAT</p>";
			final EmailDto emailDto = new EmailDto(userDto.getFirstName(), userDto.getEmail(), emailBody,
					"Your password has been reset");
			emailService.sendEmail(emailDto);
			userDao.updateUserPassword(userDto.getUserId(), SecuirtyUtils.hashPassword(tempPassword), false);
			return;
		}
		throw new UserException(ErrorCode.INVALID_PASSWORD.getErrorMessage(),
				ErrorCode.INVALID_PASSWORD.getErrorCode());
	}

	@Override
	public ResponseDto userFeedback(FeedBackDto feedBack) throws UserException {
		final ResponseDto responseDto = new ResponseDto();
		final EmailDto emailDto = new EmailDto(environment.getRequiredProperty("email.from"), environment.getRequiredProperty("adminEmailList"),
				feedBack.getFeedback(), "Feedback");
		try {
			emailService.sendFeedbackEmail(emailDto);
			boolean isFdbkInserted = userDao.storeUserFeedback(feedBack);
			if(isFdbkInserted) {
				responseDto.setMessage(Constant.FEEDBACK);
				responseDto.setStatus(Constant.OK);
			}
			else{
				responseDto.setMessage(Constant.FEEDBACK_ERROR);
				responseDto.setStatus(Constant.FAILED);
			}
		} catch (Exception e) {
			log.error("Error while sending email "+e.getMessage());
			responseDto.setMessage(Constant.FEEDBACK_ERROR);
			responseDto.setStatus(Constant.FAILED);
		}

		return responseDto;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#changePassword(java.lang.String,
	 * java.lang.String, java.lang.String)
	 */
	@Override
	public void changePassword(final Integer userId, final String oldPassword, final String newPassword)
			throws UserException {
		final UserDto userDto = userDao.getUser(userId);
		if (userDto != null) {
			final String userStoredPasswordHash = userDto.getPassword();
			final String usernewPasswordHash = SecuirtyUtils.hashPassword(newPassword);
			if (SecuirtyUtils.matchPassword(oldPassword, userStoredPasswordHash)) {
				try {
					userDao.updateUserPassword(userDto.getUserId(), usernewPasswordHash, true);
				} catch (final Exception e) {
					log.error("Error ocurred during update password against:" + userId + e);
					throw new UserException(e);
				}
			} else {
				throw new UserException(ErrorCode.PASSWORD_NOT_MATCH.getErrorMessage(),
						ErrorCode.PASSWORD_NOT_MATCH.getErrorCode());
			}
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#addUser(com.harman.dmat.common.dto
	 * .UserDto)
	 */
	@Override
	public void addUser(final UserDto userDto) throws UserException {
		userDto.setPassword(SecuirtyUtils.hashPassword(userDto.getPassword()));
		if (!userDao.isUniqueEmail(userDto.getEmail())) {
			throw new UserException(ErrorCode.DUPLICATE_EMAIL.getErrorMessage(),
					ErrorCode.DUPLICATE_EMAIL.getErrorCode());
		}
		try {
			userDao.registerUser(userDto);
			final String accountCreationAck = "<p>Dear " + userDto.getFirstName() + " " + userDto.getLastName()
					+ ",<br /> <br /> Thank you for registering on DMAT server.</p> <p>You will receive a confirmation email once your account is activated by an Admin. <br /> <br /> <em>This is an auto generated email from DMAT</em><br /> <br /> ----------------------------------------------<br /> Thank you<br /> Regards,<br /> <em>TEAM DMAT</em><br /> ----------------------------------------------</p>";
			sendEmail(userDto.getFirstName(), userDto.getEmail(), "DMAT Account Creation Acknowledgement ",
					accountCreationAck);
			final List<String> adminEmails = userDao.getAdminEmail();
			final String body = "<p style=\"border: none; padding: 0in;\">Dear Admin,<br /> <br /> A new user <strong>"
					+ userDto.getFirstName() + " " + userDto.getLastName()
					+ "</strong> wants to access DMAT Server. <br /> Please sign in to <a href=\"https://vzwdt.com/DMATBD/#/login\">DMAT Website </a>and activate the user.<br /> <br /> <em>This is an auto generated email from DMAT</em><br /> <br /> <br /> ----------------------------------------------<br /> Thank you<br /> Regards,<br /> <em>TEAM DMAT</em><br /> ----------------------------------------------</p>";
			/*
			 * emailService.sendEmailList(adminEmails,
			 * "DMAT Account activation request from " + userDto.getFirstName()
			 * + " " + userDto.getLastName(), body, userDto.getFirstName(),
			 * false);
			 */

		} catch (final Exception e) {
			log.error("Error occured during registering user." + e);
			throw new UserException(HttpStatus.INTERNAL_SERVER_ERROR.toString(),
					HttpStatus.INTERNAL_SERVER_ERROR.value());

		}

	}

	private void sendEmail(String toName, String toEmail, String subject, String body) {
		final EmailDto emailDto = new EmailDto(toName, toEmail, body, subject);
		emailService.sendEmail(emailDto);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#deleteUserData(java.util.List)
	 */
	@Override
	public Boolean deleteUserData(final List<Integer> userIds) throws InvalidRequestPayloadException {
		Boolean result = false;
		try {
			result = userDao.deleteUserData(userIds);
		} catch (final DataAccessException e) {
			log.error("User Manager: Error deleting User." + e);
			throw new InvalidRequestPayloadException(e);
		}

		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#updateUserData(com.harman.dmat.common
	 * .dto.UserDto)
	 */
	@Override
	public int updateUserData(final Map<String, String> userInfo)
			throws InvalidRequestPayloadException, DataAccessException {
		if (UserManagerStringUtil.isNullOrEmpty(userInfo.get(Constant.FIRST_NAME))
				&& UserManagerStringUtil.isNullOrEmpty(userInfo.get(Constant.LAST_NAME))
				&& UserManagerStringUtil.isNullOrEmpty(userInfo.get(Constant.IS_GROUP_ADMIN))
				|| UserManagerStringUtil.isNullOrEmpty(userInfo.get(Constant.USER_ID))) {
			log.error("Pay load given is not  right");
			throw new InvalidRequestPayloadException(Constant.PAYLOAD_REQUEST_ERROR);
		}
		try {
			return userDao.updateUserdata(userInfo);
		} catch (final DataAccessException e) {
			log.error("Error occured during editing user details." + e);
			throw new DataAccessException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#searchUser(java.lang.String)
	 */
	@Override
	public List<UserDto> searchUser(final String email) throws InvalidRequestPayloadException, DataAccessException {
		List<UserDto> userdata = null;
		if (UserManagerStringUtil.isNullOrEmpty(email)) {
			throw new InvalidRequestPayloadException(Constant.PAYLOAD_REQUEST_ERROR);
		}
		try {
			userdata = userDao.getSearchUserData(email);
		} catch (final DataAccessException e) {
			log.error("Error occured during searching the input string");
			throw new DataAccessException();
		}
		return userdata;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#editUserStatus(com.harman.dmat.common
	 * .dto.EditUserStatusDto)
	 */
	@Override
	public int editUserStatus(final EditUserStatusDto editUserStatusDto) throws DataNotFoundException {
		int status;
		final Integer count = userDao.checkEmailExist(editUserStatusDto.getEmail());
		if (count.intValue() == Constant.VALUE_CHECK.intValue()) {
			throw new DataNotFoundException(Constant.EMAIL_DOES_NOT_EXIST);
		}
		try {
			status = userDao.editUserStatus(editUserStatusDto.getEmail(), editUserStatusDto.getRoleId(),
					editUserStatusDto.getStatus());
		} catch (final DataNotFoundException e) {
			log.error("Data not found for this user." + e);
			throw new DataNotFoundException(e);
		} catch (final DataAccessException e) {
			log.error("Error occured during edit user status." + e);
			throw new DataAccessException(e);
		}
		return status;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#getUserPreference(java.lang.Integer)
	 */
	@Override
	public UserPreferenceDto getUserPreference(final Integer userId) throws UserException {
		final int preference;
		UserPreferenceDto userPreferenceDto;
		final Integer count = userDao.checkValueExist(userId);
		if (count.intValue() == Constant.VALUE_CHECK.intValue()) {
			throw new DataNotFoundException(Constant.EMAIL_DOES_NOT_EXIST);
		}
		try {
			userPreferenceDto = userDao.getUserPreference(userId);
		} catch (final DataNotFoundException e) {
			log.error("Data not found for this user." + e);
			throw new DataNotFoundException(e);
		} catch (final DataAccessException e) {
			log.error("User Manager: Error getting preference for user." + e);
			throw new DataAccessException(e);
		}
		return userPreferenceDto;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.harman.dmat.service.UserService#getUserPreference(java.lang.Integer)
	 */
	@Override
	public AreaDto getUserPreferredArea(final String states) throws UserException {
		AreaDto areaDto;
		try {
			areaDto = userDao.getUserPreferredArea(states);
		} catch (final DataNotFoundException e) {
			log.error("Data not found for this user." + e);
			throw new DataNotFoundException(e);
		} catch (final DataAccessException e) {
			log.error("User Manager: Error getting Area preference for user." + e);
			throw new DataAccessException(e);
		}
		return areaDto;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#sendEmailNotificationToInactiveUsers(
	 * )
	 */
	@Override
	public void sendEmailNotificationToInactiveUsers() {
		final Integer day = Integer.parseInt(config.getAllConfiguration().get("inactive_day"));
		final List<UserDto> users = userDao.getInactiveUsers(day);
		if (users != null) {
			for (final UserDto userDto : users) {
				log.debug("Sending email notification to inactive user who was not login last 60 days");
				final EmailDto emailDto = new EmailDto(userDto.getFirstName() + " " + userDto.getLastName(),
						userDto.getEmail(), config.getAllConfiguration().get("login_notification_text"),
						config.getAllConfiguration().get("login_notification_subject"));
				// emailService.sendEmail(emailDto);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#editRoleforUser(com.harman.dmat.
	 * common .dto.EditRoleDto)
	 */
	@Override
	public int editRoleforUser(final EditRoleDto editRoleDto) throws DataNotFoundException {
		int roleupdated;
		final Integer count = userDao.checkEmailExist(editRoleDto.getEmail());
		if (count.intValue() == Constant.VALUE_CHECK.intValue()) {
			throw new DataNotFoundException(Constant.EMAIL_DOES_NOT_EXIST);
		}
		try {
			roleupdated = userDao.editRoleforUser(editRoleDto.getEmail(), editRoleDto.getNewRole());
		} catch (final DataNotFoundException e) {
			log.error("Data not found for this user." + e);
			throw new DataNotFoundException(e);
		} catch (final DataAccessException e) {
			log.error("Error occured during changing the role for user." + e);
			throw new DataAccessException(e);
		}
		return roleupdated;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#activateUsers(java.util.List)
	 */
	@Override
	public void activateUsers(final List<Integer> userIds) throws UserException {
		try {
			userDao.activateUsers(userIds);
			for (final Integer userId : userIds) {
				final UserDto user = userDao.getUserDetail(userId);
				final String body = "<p style=\"margin-bottom: 12.0pt;\">Hi " + user.getFirstName() + " "
						+ user.getLastName()
						+ ", <br /> Your account has been activated successfully. Please login with your email ID. <br /> <br /><a href=\"https://vzwdt.com/DMATBD/#/login\">https://vzwdt.com</a><br /> <br /> ----------------------------------------------<br /> Thank you<br /> Regards,<br /> <em>TEAM DMAT</em><br /> ----------------------------------------------</p>";
				sendEmail(user.getFirstName(), user.getEmail(), "DMAT Account Activation Notification", body);
			}

		} catch (final Exception e) {
			log.error("Either role is not admin or admin is inactive" + e);
			throw new UserException("Error ocured during activating users", e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#saveUserPreferences(com.harman.dmat.
	 * common.dto.UserPreferenceDto)
	 */
	@Override
	public Boolean saveUserPreferences(final UserPreferenceDto userPreferenceDto) throws UserException {
		Boolean result = false;
		final Integer count = userDao.checkValueExist(userPreferenceDto.getUserId());
		if (userPreferenceDto.getPreferenceId() != Constant.PREFERENCE_VALUE_CHECK_DEEP
				&& userPreferenceDto.getPreferenceId() != Constant.PREFERENCE_VALUE_CHECK_HIGH) {
			log.error("Pay load given is not  right");
			throw new InvalidRequestPayloadException(Constant.PAYLOAD_REQUEST_ERROR);
		}
		if (userPreferenceDto.getPreferenceId() == Constant.PREFERENCE_VALUE_CHECK_DEEP) {
			userPreferenceDto.setStateCode(null);
		}

		if (count.intValue() == Constant.VALUE_CHECK.intValue()) {
			throw new DataNotFoundException(Constant.EMAIL_DOES_NOT_EXIST);
		}
		final List<String> statecodeList = userPreferenceDto.getStateCode();
		if (UserManagerStringUtil.isNullOrEmptyListCheck(statecodeList)) {
			try {
				result = userDao.saveUserPreferenceData(userPreferenceDto);
			} catch (final DataNotFoundException e) {
				log.error("Data not found for this user." + e);
				throw new DataNotFoundException(e);
			} catch (final DataAccessException e) {
				log.error("Error occured during saving preference." + e);
				throw new DataAccessException(e);
			}

		} else {
			final StringBuilder states = new StringBuilder();
			int i = 0;
			for (final String state : statecodeList) {
				if (i > 0) {
					states.append("|");
				} else {
					i++;
				}
				states.append(state);
			}
			try {
				result = userDao.saveUserPreferenceData(userPreferenceDto, states);
			} catch (final DataAccessException e) {
				log.error("Error occured during saving preference." + e);
				throw new DataAccessException(e);
			}
		}

		return result;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.harman.dmat.service.UserService#saveUserPreferences(com.harman.dmat.
	 * common.dto.UserPreferenceDto)
	 */
	@Override
	public Boolean saveUserPreferenceExtent(final UserPreferenceDto userPreferenceDto) throws UserException {
		Boolean result = false;
		final Integer count = userDao.checkValueExist(userPreferenceDto.getUserId());
		if (userPreferenceDto.getPreferenceId() != Constant.PREFERENCE_VALUE_CHECK_DEEP
				&& userPreferenceDto.getPreferenceId() != Constant.PREFERENCE_VALUE_CHECK_HIGH) {
			log.error("Pay load given is not  right");
			throw new InvalidRequestPayloadException(Constant.PAYLOAD_REQUEST_ERROR);
		}
		if (count.intValue() == Constant.VALUE_CHECK.intValue()) {
			throw new DataNotFoundException(Constant.EMAIL_DOES_NOT_EXIST);
		}
		try {
			result = userDao.saveUserPreferenceExtentData(userPreferenceDto);
		} catch (final DataNotFoundException e) {
			log.error("Data not found for this user." + e);
			throw new DataNotFoundException(e);
		} catch (final DataAccessException e) {
			log.error("Error occured during saving preference." + e);
			throw new DataAccessException(e);
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#getUserDetail(java.lang.String)
	 */
	@Override
	public UserDto getUserDetail(final Integer userId) throws UserException {
		UserDto userdata = null;
		try {
			userdata = userDao.getUserDetail(userId);
			if (userdata != null) {
				try {
					userdata.setLastActivityJson(userDao.getLastActivity(userId));
				} catch (final EmptyResultDataAccessException e) {

				}
			}
		} catch (final DataNotFoundException e) {
			log.error("Data not found for this user." + e);
			throw new DataNotFoundException(Constant.EMAIL_DOES_NOT_EXIST);
		} catch (final DataAccessException e) {
			log.error("Error occured during getting user data." + e);
			throw new DataAccessException(e);
		}

		final Integer roleId = userdata.getRoleId();
		List<PrivilegeDto> privilegesDto = null;
		try {
			privilegesDto = userDao.getprivilegeData(roleId);
		} catch (final DataAccessException e) {
			log.error("Error occured during getting preference for the user." + e);
			throw new DataAccessException(e);
		}
		try {
			userdata.setIsGroupRequest(userDao.getGroupRequestCount(userId));
		} catch (final DataAccessException e) {
			log.error("Error occured during getting grouprequest status for the user." + e);
			throw new DataAccessException(e);
		}
		try {
			userdata.setIsActivityShared(userDao.isActivityShared(userId));
		} catch (final DataAccessException e) {
			log.error("Error occured during getting activity shared status for the user." + e);
			throw new DataAccessException(e);
		}
		if (userdata.getIsFirstLogin() == 1) {
			userDao.updateIsFirstLogin(userId, 0);
			/*
			 * final Long usrId = new Long(userId);
			 * legendsService.createLegendsForUser(usrId);
			 */
		}
		userdata.setPrivilegesDto(privilegesDto);
		userdata.setPassword(null);
		return userdata;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * 
	 * @see com.harman.dmat.service.UserService#getRoles()
	 */
	@Override
	public List<RoleDto> getRoles() throws UserException {
		try {
			return userDao.getRoles();
		} catch (final Exception e) {
			log.error("Error occured during getting system role." + e);
			throw new UserException(e);

		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#getListofpreferences()
	 */
	@Override
	public List<PreferenceDto> getListofpreferences() throws UserException {
		List<PreferenceDto> preferences = null;
		try {
			preferences = userDao.getListofpreferences();
		} catch (final Exception e) {
			log.error("Error occured during getting list of preferences." + e);
			throw new UserException(e);
		}
		return preferences;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#getUserDetailsStatus(java.lang.
	 * Integer , java.lang.Integer, java.lang.Integer)
	 */
	@Override
	public List<UserDto> getUserDetailsStatus(final Integer offset, final Integer limit, final Integer status,
			String userType, String token, String sortBy) {
		if (offset == null || limit == null) {
			log.error("Pay load given is not right ");
			throw new InvalidRequestPayloadException(Constant.PAYLOAD_REQUEST_ERROR);
		}
		try {
			return userDao.getUserDetails(offset, limit, userType, token, sortBy);
		} catch (final DataAccessException e) {
			log.error("Error occured during getting user details with status." + e);
			throw new DataAccessException(Constant.UNABLE_TO_GET_USERS_DATA);

		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#updateByAdminData(java.util.Map)
	 */
	@Override
	public int updateByAdminData(Map<String, String> userInfo) throws UserException {

		if (UserManagerStringUtil.isNullOrEmpty(userInfo.get(Constant.FIRST_NAME))
				&& UserManagerStringUtil.isNullOrEmpty(userInfo.get(Constant.STATUS))
				&& UserManagerStringUtil.isNullOrEmpty(userInfo.get(Constant.IS_GROUP_ADMIN))
				&& UserManagerStringUtil.isNullOrEmpty(userInfo.get(Constant.COMPANY_ID))
				&& UserManagerStringUtil.isNullOrEmpty(userInfo.get(Constant.ROLE_ID))
				&& UserManagerStringUtil.isNullOrEmpty(userInfo.get(Constant.LAST_NAME))
				|| UserManagerStringUtil.isNullOrEmpty(userInfo.get(Constant.USER_ID))) {
			log.error("Pay load given is not  right");
			throw new InvalidRequestPayloadException(Constant.PAYLOAD_REQUEST_ERROR);

		}
		final Integer currentLogInRoleId = ((User) SecurityContextHolder.getContext().getAuthentication()
				.getPrincipal()).getScope();
		final String usrRoleId = userInfo.get(Constant.ROLE_ID);
		if (usrRoleId != null) {
			if (currentLogInRoleId == Roles.SUPER_ADMIN.getValue()
					&& Integer.parseInt(usrRoleId) == Roles.SUPER_ADMIN.getValue()) {
				throw new UserException(Constant.ROLE_CHANGED, HttpStatus.UNAUTHORIZED.value());
			} else if (currentLogInRoleId == Roles.ADMIN.getValue()
					&& (Integer.parseInt(usrRoleId) == Roles.SUPER_ADMIN.getValue()
							|| Integer.parseInt(usrRoleId) == Roles.ADMIN.getValue())) {
				throw new UserException(Constant.ROLE_CHANGED, HttpStatus.UNAUTHORIZED.value());
			}
		}
		int count;
		if (userInfo.containsKey(Constant.STATUS)) {
			try {
				count = userDao.updateUserdata(userInfo);
			} catch (final DataAccessException e) {
				log.error("Error occured during editing user details." + e);
				throw new DataAccessException(e);
			}
			if (count > 0 && Integer.parseInt(userInfo.get(Constant.STATUS)) == Status.ACTIVE.getValue()) {
				final UserDto user = userDao.getUserDetail(Integer.parseInt(userInfo.get(Constant.USER_ID)));

				final String body = "<p style=\"margin-bottom: 12.0pt;\">Hi " + user.getFirstName() + " "
						+ user.getLastName()
						+ ", <br /> Your account has been activated successfully. Please login with your email ID. <br /> <br /><a href=\"https://vzwdt.com/DMATBD/#/login\">https://vzwdt.com</a><br /> <br /> ----------------------------------------------<br /> Thank you<br /> Regards,<br /> <em>TEAM DMAT</em><br /> ----------------------------------------------</p>";
				sendEmail(user.getFirstName(), user.getEmail(), "DMAT Account Activation Notification", body);

			} else if (count > 0 && Integer.parseInt(userInfo.get(Constant.STATUS)) == Status.INACTIVE.getValue()) {
				final UserDto user = userDao.getUserDetail(Integer.parseInt(userInfo.get(Constant.USER_ID)));
				final String body = "<p style=\"margin-bottom: 12.0pt;\">Hi " + user.getFirstName() + " "
						+ user.getLastName()
						+ ", <br /> Your account has been inactivated successfully. Please login with your email ID. <br /> <br /><a href=\"https://vzwdt.com/DMATBD/#/login\">https://vzwdt.com</a><br /> <br /> ----------------------------------------------<br /> Thank you<br /> Regards,<br /> <em>TEAM DMAT</em><br /> ----------------------------------------------</p>";
				sendEmail(user.getFirstName(), user.getEmail(), "DMAT Account inactivation Notification", body);
			}
			return count;
		} else {
			try {
				return userDao.updateUserdata(userInfo);
			} catch (final DataAccessException e) {
				log.error("Error occured during editing user details." + e);
				throw new DataAccessException(e);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#adminUser(com.harman.dmat.common.dto.
	 * UserDto)
	 */
	@Override
	public void adminUser(UserDto userDto) throws UserException {
		final String tPassword = userDto.getPassword();
		userDto.setPassword(SecuirtyUtils.hashPassword(userDto.getPassword()));
		try {
			userDao.registerUser(userDto);
			final String body = "<p>&nbsp;</p>\r\n<p>Dear <strong>" + userDto.getFirstName() + " "
					+ userDto.getLastName()
					+ "</strong>,<br /> <br /> We have created user account for you.<br /> <br /> You can log in at <a href=\"https://vzwdt.com/DMATBD/#/login\">DMAT Login</a> using <a href=\"mailto:"
					+ userDto.getEmail() + "\"><strong>" + userDto.getEmail()
					+ "</strong></a> as username and <br /> <br /> <strong>" + tPassword
					+ "</strong><br /> <br /> as temporary password. Then, please make sure to keep your information secure by updating your password.<br /> <br /> ----------------------------------------------<br /> Thank you<br /> Regards,<br /> <em>TEAM DMAT</em><br /> ----------------------------------------------</p>";
			sendEmail(userDto.getFirstName(), userDto.getEmail(), "DMAT Account Creation ", body);
		} catch (final Exception e) {
			log.error("Error occured during registering user." + e);
			if (e instanceof org.springframework.dao.DuplicateKeyException) {
				throw new UserException(e.getCause().getMessage(), HttpStatus.ALREADY_REPORTED.value());
			} else {
				throw new UserException(HttpStatus.INTERNAL_SERVER_ERROR.toString(),
						HttpStatus.INTERNAL_SERVER_ERROR.value());
			}
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.SystemService#getCompanies()
	 */
	@Override
	public List<CompanyDto> getCompanies() throws SystemException {
		try {
			return userDao.getCompanies();
		} catch (final Exception e) {
			log.error("Error occured during getting all companies." + e);
			throw new SystemException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.HomeService#getRegions()
	 */
	@Override
	public List<RegionDto> getRegions() throws SystemException {
		try {
			return userDao.getRegions();
		} catch (final Exception e) {
			log.error("Error occured during getting all regions." + e);
			throw new SystemException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.HomeService#getStates()
	 */
	@Override
	public List<StateDto> getStates() throws SystemException {
		try {
			return userDao.getStates();
		} catch (final Exception e) {
			log.error("Error occured during getting all states." + e);
			throw new SystemException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.HomeService#getStateName(java.lang.String)
	 */
	@Override
	public List<String> getStateName(final String region) throws SystemException {
		if (UserManagerStringUtil.isNullOrEmpty(region)) {
			throw new InvalidRequestPayloadException(Constant.PAYLOAD_REQUEST_ERROR);
		}
		List<String> states = null;
		try {
			states = userDao.getStateName(region);
		} catch (final Exception e) {
			log.error("Error occured during getting list of states on basis of region." + e);
			throw new SystemException(e);

		}
		return states;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#getEvents()
	 */
	@Override
	public List<EventDto> getEvents() throws SystemException {
		try {
			return userDao.getEvents();
		} catch (final Exception e) {
			log.error("Error occured during getting all Events." + e);
			throw new SystemException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#getUserCount()
	 */
	@Override
	public Integer getUserCount() throws UserException {
		try {
			return userDao.getUserCount();
		} catch (final Exception e) {
			log.error("Error occured during getting all user count." + e);
			throw new UserException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#getAccordionInfo()
	 */
	@Override
	public AccordionInfo getAccordionInfo(String token) throws UserException {
		try {
			if (token != null && !token.isEmpty()) {
				return userDao.getAccordionInfo(token);
			} else {
				return userDao.getAccordionInfo();
			}
		} catch (final EmptyResultDataAccessException e) {
			log.error("There are no data avilable." + e);
		} catch (final Exception e) {
			log.error("Error occured during getting all accordioninfo." + e);
			throw new UserException(e);
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#changeStatus(com.harman.dmat.common.
	 * dto.StatusInfoDto)
	 */
	@Override
	public void changeStatus(StatusInfoDto statusInfoDto) throws UserException {
		checkPrivelage(statusInfoDto);
		try {
			if (statusInfoDto.getToken() == null) {
				userDao.changeUserStatus(statusInfoDto);
			} else {
				userDao.changeUserStatus(statusInfoDto.getToken(), statusInfoDto);
			}
		} catch (final Exception e) {
			log.error("Error occured during changing the status of users." + e);
			throw new UserException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#deleteUsers(com.harman.dmat.common.
	 * dto.StatusInfoDto)
	 */
	@Override
	public void deleteUsers(StatusInfoDto statusInfoDto) throws UserException {
		checkPrivelage(statusInfoDto);
		try {
			if (statusInfoDto.getToken() == null) {
				userDao.deleteUsers(statusInfoDto);
			} else {
				userDao.deleteUsers(statusInfoDto.getToken(), statusInfoDto);
			}
		} catch (final Exception e) {
			log.error("Error occured during deleting the users." + e);
			throw new UserException(e);
		}
	}

	private void checkPrivelage(StatusInfoDto statusInfoDto) throws UserException {
		final List<Integer> users = new ArrayList<>();
		if (statusInfoDto.getAdmin() != null && statusInfoDto.getAdmin().getIncludedUserIds() != null) {
			users.addAll(statusInfoDto.getAdmin().getIncludedUserIds());
		}
		if (statusInfoDto.getSme() != null && statusInfoDto.getSme().getIncludedUserIds() != null) {
			users.addAll(statusInfoDto.getSme().getIncludedUserIds());
		}
		if (statusInfoDto.getUser() != null && statusInfoDto.getUser().getIncludedUserIds() != null) {
			users.addAll(statusInfoDto.getUser().getIncludedUserIds());
		}
		if (statusInfoDto.getSuperAdmin() != null && statusInfoDto.getSuperAdmin().getIncludedUserIds() != null) {
			users.addAll(statusInfoDto.getSuperAdmin().getIncludedUserIds());
		}
		if (statusInfoDto.getOem() != null && statusInfoDto.getOem().getIncludedUserIds() != null) {
			users.addAll(statusInfoDto.getOem().getIncludedUserIds());
		}
		if (statusInfoDto.getAdmin() != null && statusInfoDto.getAdmin().isAll()
				|| !users.isEmpty() && userDao.isConatinAdminSuperAdmin(users)) {
			throw new UserException(Constant.USER_SELECTION, HttpStatus.EXPECTATION_FAILED.value());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#sendNotification(com.harman.dmat.
	 * common.dto.StatusInfoDto)
	 */
	@Override
	public void sendNotification(MultipartFile file, String subject, String body, StatusInfoDto statusInfoDto)
			throws UserException {
		try {
			if (statusInfoDto.getToken() == null) {
				final List<UserDto> userDtos = userDao.sendNotification(statusInfoDto);
				log.debug("users:" + userDtos.toString());
				sendNotification(file, subject, body, userDtos);
			} else {
				final List<UserDto> userDtos = userDao.sendNotification(statusInfoDto.getToken(), statusInfoDto);
				log.debug("users:" + userDtos.toString());
				sendNotification(file, subject, body, userDtos);

			}
		} catch (final Exception e) {
			log.error("Error occured during sending notification to the users." + e);
			throw new UserException(e);
		}
	}

	/**
	 * Send notification.
	 *
	 * @param file
	 *            the file
	 * @param subject
	 *            the subject
	 * @param body
	 *            the body
	 * @param userDtos
	 *            the user dtos
	 */
	private void sendNotification(MultipartFile file, String subject, String body, List<UserDto> userDtos) {
		File filePath = null;
		if (file != null) {
			storageService.store(file);
			final Path path = storageService.load(file.getOriginalFilename());
			filePath = new File(path.toString());
		}
		if (userDtos != null) {
			for (final UserDto userDto : userDtos) {
				final EmailDto emailDto = new EmailDto(userDto.getFirstName() + " " + userDto.getLastName(),
						userDto.getEmail(), body, subject);
				emailDto.setFile(filePath);
				emailService.sendEmail(emailDto);

			}
			// storageService.deleteFile(path);
		}
	}

	/**
	 * Gets the contact.
	 *
	 * @return the contact
	 * @throws UserException
	 *             the user exception
	 */
	@Override
	public ContactDto getContact() throws UserException {
		final String contactDetails = config.getAllConfiguration().get("contact_us");
		final ContactDto contactDto = new ContactDto(contactDetails);
		return contactDto;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#UploadFile(org.springframework.web.
	 * multipart.MultipartFile, com.harman.dmat.common.dto.FileUploadDto)
	 */
	@Override
	public Long UploadFile(MultipartFile file, FileUploadDto fileUploadDto) {
		if (uploadFile(file, fileUploadDto.getType(), fileUploadDto.getLocation())) {
			log.debug("fileUploadDto is {}", fileUploadDto.toString());
			fileUploadDto.setLocation(Optional
					.of(getFilePath(fileUploadDto.getType(), file.getOriginalFilename(), fileUploadDto.getLocation())));
			final Optional<Long> record = userDao.getRecord(fileUploadDto.getFileName(), fileUploadDto.getType());
			if (record.isPresent()) {
				final int val = userDao.updateRecord(record.get(), fileUploadDto);
				log.info("no of record updated {}", val);
				return record.get();
			} else {
				return userDao.createRecord(fileUploadDto);
			}
		} else {
			throw new FTPException("Unable to upload the file on ftp ");
		}
	}

	/**
	 * Upload file.
	 *
	 * @param file
	 *            the file
	 * @param type
	 *            the type
	 * @param location
	 *            the location
	 * @return true, if successful
	 */
	private boolean uploadFile(MultipartFile file, String type, Optional<String> location) {
		boolean result = false;
		final ChannelSftp channelSftp = sftpService.connectChannel();
		try {
			if (type.equalsIgnoreCase("apk")) {
				String path = environment.getProperty("sftp.apkdir");
				channelSftp.cd(path);
				if (location.isPresent()) {
					path = location.get();
					channelSftp.mkdir(path);
					channelSftp.cd(path);
				}
				channelSftp.put(file.getInputStream(), file.getOriginalFilename(), ChannelSftp.OVERWRITE);
				result = true;
			} else if (type.equalsIgnoreCase("userGuide")) {
				String path = environment.getProperty("sftp.userguidedir");
				channelSftp.cd(path);
				if (location.isPresent()) {
					path = location.get();
					channelSftp.mkdir(path);
					channelSftp.cd(path);
				}
				channelSftp.put(file.getInputStream(), file.getOriginalFilename(), ChannelSftp.OVERWRITE);
				result = true;
			}
		} catch (final Exception ex) {
			log.error("unable to uplaod the file on sftp {}", ex);
			result = false;
		}
		return result;
	}

	/**
	 * Gets the file path.
	 *
	 * @param type
	 *            the type
	 * @param fileName
	 *            the file name
	 * @param location
	 *            the location
	 * @return the file path
	 */
	private String getFilePath(String type, String fileName, Optional<String> location) {
		String path = null;
		if (type.equalsIgnoreCase("apk")) {
			path = environment.getProperty("sftp.apkdir");
			if (location.isPresent()) {
				path = path + "/" + location.get();
			}
		}

		else if (type.equalsIgnoreCase("userGuide")) {
			path = environment.getProperty("sftp.userguidedir");
			if (location.isPresent()) {
				path = path + "/" + location.get();
			}

		}
		return path = path + "/" + fileName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#fileDownloadHandler(java.lang.String)
	 */
	@Override
	public ByteArrayResource fileDownloadHandler(String file) {
		final String dir = file.substring(0, file.lastIndexOf('/') + 1);
		final String fileName = file.substring(file.lastIndexOf('/') + 1);
		ByteArrayOutputStream baos = null;
		ByteArrayResource resource = null;
		log.debug("fileDownloadHandler: preparing the host information for sftp.");
		try {
			final ChannelSftp channelSftp = sftpService.connectChannel();
			log.info(channelSftp.getHome());
			channelSftp.cd(dir);
			final InputStream inputStream = channelSftp.get(fileName);
			baos = new ByteArrayOutputStream();
			try {
				final byte[] buf = new byte[1024];
				int bytesread = 0, bytesBuffered = 0;
				while ((bytesread = inputStream.read(buf)) > -1) {
					baos.write(buf, 0, bytesread);
					bytesBuffered += bytesread;
					if (bytesBuffered > 1024 * 1024) { // flush after 1MB
						bytesBuffered = 0;
						baos.flush();
					}
				}
			} finally {
				if (baos != null) {
					baos.flush();
				}
			}
			resource = new ByteArrayResource(baos.toByteArray());
		} catch (final Exception e) {
			log.error(
					"unable to download file either the file is delete or the connection of the sftp client is closed  ");
			new FTPException("unable to download file from FTP ");
		}

		return resource;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#getListOfDowloadMetadata(java.lang.
	 * String)
	 */
	@Override
	public List<FileUploadDto> getListOfDowloadMetadata(String type) {
		List<FileUploadDto> list = new ArrayList<>();
		if (type.equalsIgnoreCase("apk")) {
			list = userDao.getListOfDowloadMetadata(FileTypeEnum.TYPE_APK.getValue());
		} else {
			list = userDao.getListOfDowloadMetadata(FileTypeEnum.TYPE_USER_GUIDE.getValue());
		}
		return list;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#saveLastActivity(com.harman.dmat.
	 * common.dto.LastActivitiyDto)
	 */
	@Override
	public void saveLastActivity(LastActivitiyDto lastActivitiyDto) throws UserException {
		try {
			userDao.saveLastActivity(lastActivitiyDto);
		} catch (final Exception e) {
			log.error("An error occred during save the last activity of user." + e);
			throw new UserException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#saveSimCardRequest()
	 */
	@Override
	public void saveSimCardRequest(SimRequestDto simRequestDto) throws UserException {
		try {
			userDao.saveSimCardRequest(simRequestDto);
		} catch (final Exception e) {
			log.error("An error occred during save the sim card request" + e);
			throw new UserException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#getDevice()
	 */
	@Override
	public List<DeviceDto> getDevice() throws UserException {
		try {
			return userDao.getDevice();
		} catch (final Exception e) {
			log.error("An error occred during getting devices" + e);
			throw new UserException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#editDevice(com.harman.dmat.common.dto
	 * .DeviceDto)
	 */
	@Override
	public void editDevice(DeviceDto deviceDto) throws UserException {
		try {
			userDao.editDevice(deviceDto);
		} catch (final Exception e) {
			log.error("An error occred during editing devices" + e);
			throw new UserException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#removeDevice(java.util.List)
	 */
	@Override
	public void removeDevice(List<Integer> deviceIds) throws UserException {
		try {
			userDao.removeDevice(deviceIds);
		} catch (final Exception e) {
			log.error("An error occred during removing devices" + e);
			throw new UserException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#addDevice(com.harman.dmat.common.dto.
	 * DeviceDto)
	 */
	@Override
	public void addDevice(DeviceDto deviceDto) throws UserException {
		if (!userDao.isUniqueDevice(deviceDto.getDeviceName(), deviceDto.getDeviceModel())) {
			throw new UserException(ErrorCode.INVALID_DEVICE.getErrorMessage(),
					ErrorCode.INVALID_DEVICE.getErrorCode());
		}
		try {
			userDao.addDevice(deviceDto);
		} catch (final Exception e) {
			log.error("An error occred during adding devices" + e);
			throw new UserException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#importExcelFile(org.springframework.
	 * web.multipart.MultipartFile)
	 */
	@Override
	public void importExcelFile(MultipartFile file) throws UserException {
		storageService.store(file);
		final Path path = storageService.load(file.getOriginalFilename());
		List<String[]> lines;
		try {
			lines = Utill.readExcelFile(file.getInputStream());
		} catch (final IOException e) {
			log.error("An error occred during adding parsing csv file." + e);
			throw new UserException(e);
		}
		try {
			userDao.addExcelInfo(lines);
		} catch (final Exception e) {
			log.error("An error occred during adding excel info to database." + e);
			throw new UserException(e);
		} finally {
			storageService.deleteFile(path);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#getSimInfo(java.lang.String)
	 */
	@Override
	public List<SimInfoDto> getSimInfo(String iccid) throws UserException {
		try {
			return userDao.getSimInfo(iccid);
		} catch (final Exception e) {
			log.error("An error occred during getting sim info against:" + iccid + e);
			throw new UserException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#addOs(com.harman.dmat.common.dto.
	 * OsDto)
	 */
	@Override
	public void addOs(OsDto osDto) throws UserException {
		try {
			userDao.addOs(osDto);
		} catch (final Exception e) {
			log.error("An error occred during adding os info" + e);
			throw new UserException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#getOs()
	 */
	@Override
	public List<OsDto> getOs() throws UserException {
		try {
			return userDao.getOs();
		} catch (final Exception e) {
			log.error("An error occred during getting os info" + e);
			throw new UserException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#createGroup(com.harman.dmat.common.
	 * dto.GroupDto)
	 */
	@Override
	public void createGroup(GroupDto groupDto) throws UserException {
		try {
			// userDao.createGroup(groupDto);
			List<UserDto> user = userDao.createGroup(groupDto);
			final String firstName = user.get(0).getFirstName();
			final String lastName = user.get(0).getLastName();
			user.stream().forEach(usr -> {
				if (usr.getEmail().equalsIgnoreCase(user.get(0).getEmail())) {
					// skiping the admin
				} else {
					log.info("sending the email notification to the added uses");
					String msg = "<html><body><h5>Hi %s,</h5><p> You are invited to the group %s by %s %s. Please login to the portal and accept or reject the invitation.</p><br/>Regards,<br/>Team DMAT</body></html>";
					msg = String.format(msg, usr.getFirstName(), groupDto.getGroupName(), firstName, lastName);
					log.info("html message {}", msg);
					final EmailDto emailDto = new EmailDto(usr.getFirstName(), usr.getEmail(), msg, "Group Request");
					emailService.sendEmail(emailDto);
				}
			});

		} catch (UserEmailException ex) {
			throw new UserEmailException("Group created but uanble to notify the users using email");
		} catch (org.springframework.dao.DuplicateKeyException ex) {
			throw new UserException(ErrorCode.DUPLICATE_GROUP.getErrorMessage(),
					ErrorCode.DUPLICATE_GROUP.getErrorCode());
		}

		/*
		 * catch (final Exception e) { if (e instanceof
		 * org.springframework.dao.DuplicateKeyException) { throw new
		 * UserException(ErrorCode.DUPLICATE_GROUP.getErrorMessage(),
		 * ErrorCode.DUPLICATE_GROUP.getErrorCode()); } log.error(
		 * "An error occred during creating group" + e); throw new
		 * UserException(e); }
		 */
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#updateGroup(com.harman.dmat.common.
	 * dto.GroupDto)
	 */
	@Override
	public void updateGroup(GroupDto groupDto) throws UserException {
		try {
			userDao.updateGroup(groupDto);
		} catch (final Exception e) {
			log.error("An error occred during update group" + e);
			throw new UserException(e);
		}
		final UserDto groupAdmin = userDao.getGroupAdmin(groupDto.getGroupId());
		final List<Integer> userIds = groupDto.getAddUserIds();
		if (userIds != null && !userIds.isEmpty()) {
			final List<UserDto> userDtos = userDao.getUserDetail(userIds);
			for (final UserDto userDto : userDtos) {
				String msg = "<html><body><h5>Hi %s,</h5><p> You are invited to the group %s by %s %s. Please login to the portal and accept or reject the invitation.</p><br/>Regards,<br/>Team DMAT</body></html>";
				msg = String.format(msg, userDto.getFirstName(), groupDto.getGroupName(), groupAdmin.getFirstName(),
						groupAdmin.getLastName());
				final EmailDto emailDto = new EmailDto(userDto.getFirstName(), userDto.getEmail(), msg,
						"Group Request");
				emailService.sendEmail(emailDto);
			}
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#deleteGroup(java.lang.Integer)
	 */
	@Override
	public void deleteGroup(Integer[] groupIds) throws UserException {
		try {
			userDao.deleteGroup(groupIds);
		} catch (final Exception e) {
			log.error("An error occred during delete group" + e);
			throw new UserException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#getGroups()
	 */
	@Override
	public List<GroupDto> getGroups() throws UserException {
		try {
			final List<GroupDto> groups = userDao.getGroups();
			final Map<Integer, List<UserDto>> groupUsers = userDao.getGroupUsers();
			for (final GroupDto groupDto : groups) {
				groupDto.setUsers(groupUsers.get(groupDto.getGroupId()));
			}
			return groups;
		} catch (final Exception e) {
			log.error("An error occred during getting group" + e);
			throw new UserException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#setGroupRequestStatus(com.harman.dmat
	 * .common.dto.GroupRequestDto)
	 */
	@Override
	public void setGroupRequestStatus(GroupRequestDto groupRequestDto) throws UserException {
		try {
			userDao.setGroupRequestStatus(groupRequestDto);
		} catch (final Exception e) {
			log.error("An error occred during changing the status of group request" + e);
			throw new UserException(e);
		}
		final String userName = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserName();
		final UserDto userDto = userDao.getGroupAdmin(groupRequestDto.getGroupId());
		final String emailBody = userName + " " + (groupRequestDto.getStatus() == 1 ? "Accept" : "Reject")
				+ " the group request for group:" + groupRequestDto.getGroupName();
		final EmailDto emailDto = new EmailDto(userDto.getFirstName(), userDto.getEmail(), emailBody, "Group Request");
		// emailService.sendEmail(emailDto);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.harman.dmat.service.UserService#getUserBriefInfo(java.lang.Integer,
	 * java.lang.Integer)
	 */
	@Override
	public List<UserDto> getUserBriefInfo(Integer offset, Integer limit) throws UserException {
		try {
			return userDao.getUserBriefInfo(offset, limit);
		} catch (final Exception e) {
			log.error("An error occred during getting user brief info" + e);
			throw new UserException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#getSimInfo(java.lang.Integer,
	 * java.lang.Integer)
	 */
	@Override
	public SimRequestData getSimInfo(Integer offset, Integer limit) throws UserException {
		try {
			return userDao.getSimInfo(offset, limit);
		} catch (final Exception e) {
			log.error("An error occred during getting sim info" + e);
			throw new UserException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#getUserGroups()
	 */
	@Override
	public List<GroupDto> getMyGroups() throws UserException {
		final Integer loinUserId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUserId();
		try {
			final List<GroupDto> groups = userDao.getUserGroups(loinUserId);
			final Map<Integer, List<UserDto>> groupUsers = userDao.getGroupUsers(loinUserId);
			for (final GroupDto groupDto : groups) {
				groupDto.setUsers(groupUsers.get(groupDto.getGroupId()));
			}
			return groups;
		} catch (final Exception e) {
			log.error("An error occred during getting group" + e);
			throw new UserException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.harman.dmat.service.UserService#getGroupRequests()
	 */
	@Override
	public List<GroupRequestDto> getGroupRequests() throws UserException {
		try {
			final Integer loinUserId = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
					.getUserId();
			return userDao.getGroupRequest(loinUserId);
		} catch (final Exception e) {
			if (!(e instanceof EmptyResultDataAccessException)) {
				log.error("Error occured during getting user group requests for the user." + e);
				throw new UserException(e);
			}

		}
		return null;
	}

	@Override
	public void deleteUserGuide(Integer fileId) throws UserException {
		log.debug("fileDownloadHandler: preparing the host information for sftp.");
		String filePath = null;
		try {
			filePath = userDao.getFileUploadDto(fileId);
		} catch (final Exception e) {
			throw new UserException(ErrorCode.RECORD_NOT_EXIST.getErrorMessage(),
					ErrorCode.RECORD_NOT_EXIST.getErrorCode());
		}
		try {
			userDao.deletFileUploadDto(fileId);
			final ChannelSftp channelSftp = sftpService.connectChannel();
			log.info(channelSftp.getHome());
			channelSftp.rm(filePath);
			channelSftp.disconnect();
		} catch (final Exception e) {
			log.error("unable to delete file either the file is delete or the connection of the sftp client is closed  "
					+ e);
			throw new UserException(ErrorCode.UNABLE_TO_DELETE_FILE.getErrorMessage(),
					ErrorCode.UNABLE_TO_DELETE_FILE.getErrorCode());

		}

	}

	@Override
	public Boolean checkIFTheGroupNameAvailable(String groupName) {
		return userDao.checkIFTheGroupNameAvailable(groupName);
	}

	@Override
	public List<SoftwareVersionDto> getSoftwareList(){
		return userDao.getSoftwareList();
	}
	@Override
	public Boolean deleteSoftware(int softwareId){
		return userDao.deleteSoftware(softwareId);
	}

	@Override
	public Boolean setLatestSoftware(int softwareId, int osId, boolean latest){
		return userDao.setLatestSoftware(softwareId,osId,latest);
	}

	@Override
	public ResponseDto registerSoftware(SoftwareVersionDto softwareVersionDto){
		final String status = userDao.registerSoftware(softwareVersionDto);
		final ResponseDto responseDto = new ResponseDto();
		if (StringUtils.equalsIgnoreCase("success",status)) {
			log.debug("Software Registered succesffully");
			responseDto.setStatusCode(0);
			responseDto.setMessage("Software Registered successfully");
			responseDto.setData(status);
		} else {
			log.error("Failed to register New Software");
			responseDto.setErrorCode(1);
			responseDto.setMessage("Failed to register New Software");
			responseDto.setDeveloperMessage("Failed to register New Software");
		}

		return responseDto;
	}

	@Override
	public EventDtos getEventsLegends(EventsBodyDto eventsBodyDto) throws SystemException {
		try {
			return userDao.getEventsLegends(eventsBodyDto);
		} catch (final Exception e) {
			log.error("Error occured during getting all Events." + e);
			throw new SystemException(e);
		}
	}

	@Override
	public List<EventsCountDto> getEventsCount(EventsBodyDto eventsBodyDto) throws SystemException {
		try {
			return userDao.getEventsCount(eventsBodyDto);
		} catch (final Exception e) {
			log.error("Error occured during getting all Events." + e);
			throw new SystemException(e);
		}
	}
}
