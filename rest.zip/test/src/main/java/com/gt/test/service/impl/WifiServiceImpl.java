package com.harman.dmat.service.impl;

import com.harman.dmat.common.dto.*;
import com.harman.dmat.dao.WifiDao;
import com.harman.dmat.service.WifiService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Slf4j
@Service
@Transactional

public class WifiServiceImpl implements WifiService {
	@Inject
	Environment environment;

	@Inject
    WifiDao wifiDao;

	@Override
	public WifiDto getWifiInfo(String latitude, String longitude, String scale, String startDate, String endDate) {
		log.debug("getWifiInfo in...");
		String distance = calculateDistance(scale);
		String query = "{\"size\": 10000,"
				+ "\"query\": {\"bool\": {\"must\": {\"range\":" + " {\"createddate\": {\"from\": \"" + startDate + "\" ,\"to\": \"" + endDate + "\","
				+ "\"include_lower\": true,\"include_upper\": true}}},"
				+ "\"filter\": {\"geo_distance\": {\"distance\": "+ distance + ", \"loc\": {\"lat\": " + latitude + ",\"lon\": " + longitude + "}}}}},"
				+ "\"aggs\": {"
				+ "\"RSSI\": {\"avg\": {\"field\": \"rssi\" }}," 
				+ "\"SSID\": { \"terms\": { \"field\": \"ssid\"}},"
				+ "\"BSSID\": {\"terms\": {\"field\":\"bssid\"}},"
				+ "\"ipaddress\": {\"terms\": {\"field\": \"ipaddress\"}},"
				+ "\"hiddenssid\": {\"terms\": { \"field\": \"hiddenssid\"}},"
				+ "\"networkid\": {\"terms\": { \"field\": \"networkid\"}},"
				+ "\"macaddress\": {\"terms\": {\"field\": \"macaddress\"}},"
				+ "\"linkspeed\": { \"terms\": {\"field\": \"linkspeed\"} },"
				+ "\"gateway\": { \"terms\": {\"field\": \"gateway\"}},"
				+ "\"netmask\": {\"terms\": {\"field\": \"netmask\"}},"
				+ "\"wifitype\": {\"terms\": {\"field\": \"wifitype\"}},"
				+ "\"encryption\": {\"terms\": {\"field\": \"encryption\"}},"
				+ "\"createddate\": { \"terms\": {\"field\": \"createddate\"}},"
				+ "\"secondarydns\": {\"terms\": {\"field\": \"secondarydns\"}},"
				+ "\"dhcpserver\": {\"terms\": {\"field\": \"dhcpserver\"}},"
				+ "\"channel\": { \"terms\": {\"field\": \"channel\"}}"
				+ "}}";

		WifiDto wifiDto = wifiDao.getWifiInfo(query);
		log.debug("getWifiInfo out.");
		return wifiDto;
	}

	private String calculateDistance(String scale) {
		String distance = null;
		if (scale == null) {
			distance = "\"50m\"";
		} else {
			switch (scale) {
			case "20":
				distance = "\"5m\"";
				break;
			case "19":
				distance = "\"8m\"";
				break;
			case "18":
				distance = "\"10m\"";
				break;
			case "17":
				distance = "\"15m\"";
				break;
			case "16":
			case "15":
			case "14":
				distance = "\"100m\"";
				break;

			case "13":
			case "12":
				distance = "\"700m\"";
				break;
			case "11":
				distance = "\"800m\"";
				break;
			case "10":
			case "9":
				distance = "\"1000m\"";
				break;

			default:
				distance = "\"15m\"";

			}
		}
		return distance;
	}

	/**
	 * Gets the feature response for the given search request.
	 * @param wifiClusterRequestDto
	 * @return
	 */
	@Override
	public WifiClusterResponseDto getWifiDataClusters(WifiClusterRequestDto wifiClusterRequestDto) {
		WifiClusterResponseDto wifiClusterResponseDto = new WifiClusterResponseDto();

		if(wifiClusterRequestDto.isWifiRequest() && !wifiClusterRequestDto.isEscherRequest()) {
			String wifiDataClusterQuery = getWifiDataClustersQuery(wifiClusterRequestDto);

			String indices = environment.getRequiredProperty("esIndexEndPoint");

			String dataPointType = environment.getRequiredProperty("esIndexType");

			if (log.isDebugEnabled()) {
				log.debug("WifiDataCluster Query formed: " + wifiDataClusterQuery);
				log.debug("Indices: " + indices);
			}

			wifiClusterResponseDto = wifiDao.getWifiDataClusters("wifi", dataPointType, wifiDataClusterQuery, indices, wifiClusterRequestDto.getLocCode());
		} else if(wifiClusterRequestDto.isEscherRequest() && !wifiClusterRequestDto.isWifiRequest()) {
			String escherDataClustersQuery = getEscherDataClustersQuery(wifiClusterRequestDto);

			String indices = environment.getRequiredProperty("esEscherIndexEndPoint");

			String dataPointType = environment.getRequiredProperty("esEscherIndexType");

			if (log.isDebugEnabled()) {
				log.debug("EscherDataCluster Query formed: " + escherDataClustersQuery);
				log.debug("Indices: " + indices);
			}

			wifiClusterResponseDto = wifiDao.getWifiDataClusters("escher", dataPointType, escherDataClustersQuery, indices, wifiClusterRequestDto.getLocCode());
		} else if(wifiClusterRequestDto.isWifiRequest() && wifiClusterRequestDto.isEscherRequest()) {
			String wifiDataClusterQuery = getWifiDataClustersQuery(wifiClusterRequestDto);

			String indices = environment.getRequiredProperty("esIndexEndPoint");
			String dataPointType = environment.getRequiredProperty("esIndexType");

			if (log.isDebugEnabled()) {
				log.debug("WifiDataCluster Query formed: " + wifiDataClusterQuery);
				log.debug("Indices: " + indices);
			}

			WifiClusterResponseDto wifiResponse = wifiDao.getWifiDataClusters("wifi", dataPointType, wifiDataClusterQuery, indices, wifiClusterRequestDto.getLocCode());

			String escherDataClustersQuery = getEscherDataClustersQuery(wifiClusterRequestDto);

			String escherIndices = environment.getRequiredProperty("esEscherIndexEndPoint");
			String escherDataPointType = environment.getRequiredProperty("esEscherIndexType");

			if (log.isDebugEnabled()) {
				log.debug("EscherDataCluster Query formed: " + escherDataClustersQuery);
				log.debug("Indices: " + escherIndices);
			}

			WifiClusterResponseDto escherResponse = wifiDao.getWifiDataClusters("escher", escherDataPointType, escherDataClustersQuery, escherIndices, wifiClusterRequestDto.getLocCode());
			List<FeaturesDto> wifiFeature = wifiResponse.getFeatures();
			AtomicInteger wifiFeatureCount = new AtomicInteger(wifiResponse.getFeatures().size());

			escherResponse.getFeatures().forEach(x -> {
														x.getAttributes().setID(Integer.toString(wifiFeatureCount.incrementAndGet()));
														wifiFeature.add(x);
												});
			wifiResponse.setFeatures(wifiFeature);

			wifiClusterResponseDto = wifiResponse;
		}

		return wifiClusterResponseDto;
	}

	/**
	 * WifiCluster query for the given escher search request.
	 * @param wifiClusterRequestDto
	 * @return
	 */
	private String getEscherDataClustersQuery(WifiClusterRequestDto wifiClusterRequestDto) {
		return "{" +
				"  \"from\": 0," +
				"  \"size\": 0," +
				"  \"query\": {" +
				"    \"bool\": {" +
				"      \"must\": [" +
				"        {" +
				"          \"range\": {" +
				"            \"currenttime\": {" +
				"              \"from\": \"" + wifiClusterRequestDto.getTimeStampFrm() +
				"\"," +
				"              \"to\": \"" + wifiClusterRequestDto.getTimeStampTo() +
				"\"," +
				"              \"include_lower\": true," +
				"              \"include_upper\": true" +
				"            }" +
				"          }" +
				"        }" +
				"      ]," +
				"      \"filter\": {" +
				"        \"geo_bounding_box\": {" +
				"          \"loc\": {" +
				"            \"top_left\": {" +
				"              \"lat\": " + wifiClusterRequestDto.getTlLat() +
				"," +
				"              \"lon\": " + wifiClusterRequestDto.getTlLon() +
				"" +
				"            }," +
				"            \"bottom_right\": {" +
				"              \"lat\": " + wifiClusterRequestDto.getBrLat() +
				"," +
				"              \"lon\": " + wifiClusterRequestDto.getBrLon() +
				"" +
				"            }" +
				"          }" +
				"        }" +
				"      }" +
				"    }" +
				"  }," +
				"  \"aggregations\": {" +
				"    \"ssid\": {" +
				"      \"terms\": {" +
				"        \"field\": \"ssid\"" +"," +
                "            \"size\": 50000" +
				"      }," +
				"      \"aggs\": {" +
				"        \"" + wifiClusterRequestDto.getLocCode() +
				"\": {" +
				"          \"terms\": {" +
				"            \"field\": \"" + wifiClusterRequestDto.getLocCode() +
				"\"," +
				"            \"size\": 1" +
				"          }," +
				"          \"aggs\": {" +
				"            \"top_loc\": {" +
				"              \"top_hits\": {" +
				"                \"sort\": [" +
				"                  {" +
				"                    \"currenttime\": {" +
				"                      \"order\": \"desc\"" +
				"                    }" +
				"                  }" +
				"                ]," +
				"                \"_source\": {" +
				"                  \"includes\": [" +
				"                    \"loc_mx\"," +
				"                    \"loc_my\"" +
				"                  ]" +
				"                }," +
				"                \"size\": 1" +
				"              }" +
				"            }" +
				"          }" +
				"        }" +
				"      }" +
				"    } " +
				"  }" +
				"}";
	}

	/**
	 * WifiCluster query for the given wifi search request.
	 * @param wifiClusterRequestDto
	 * @return
	 */
	private String getWifiDataClustersQuery(WifiClusterRequestDto wifiClusterRequestDto) {
		return "{" +
				"  \"from\": 0," +
				"  \"size\": 0," +
				"  \"query\": {" +
				"    \"bool\": {" +
				"      \"must\": [" +
				"        {" +
				"          \"term\": {" +
				"            \"wifitype\": \"servingap\"" +
				"          }" +
				"        }," +
				"        {" +
				"          \"range\": {" +
				"            \"createddate\": {" +
				"              \"from\": \"" + wifiClusterRequestDto.getTimeStampFrm() +
				"\"," +
				"              \"to\": \"" + wifiClusterRequestDto.getTimeStampTo() +
				"\"," +
				"              \"include_lower\": true," +
				"              \"include_upper\": true" +
				"            }" +
				"          }" +
				"        }" +
				"      ]," +
				"      \"filter\": {" +
				"        \"geo_bounding_box\": {" +
				"          \"loc\": {" +
				"            \"top_left\": {" +
				"              \"lat\": " + wifiClusterRequestDto.getTlLat() +
				"," +
				"              \"lon\": " + wifiClusterRequestDto.getTlLon() +
				"" +
				"            }," +
				"            \"bottom_right\": {" +
				"              \"lat\": " + wifiClusterRequestDto.getBrLat() +
				"," +
				"              \"lon\": " + wifiClusterRequestDto.getBrLon() +
				"" +
				"            }" +
				"          }" +
				"        }" +
				"      }" +
				"    }" +
				"  } "+
				"," +
				"  \"aggregations\": {" +
				"    \"ssid\": {" +
				"      \"terms\": {" +
				"        \"field\": \"ssid\"" +"," +
				"            \"size\": 50000" +
				"      }," +
				"      \"aggs\": {" +
				"        \"" + wifiClusterRequestDto.getLocCode() +
				"\": {" +
				"          \"terms\": {" +
				"            \"field\": \"" + wifiClusterRequestDto.getLocCode() +
				"\"," +
				"              \"size\": 1" +
				"          }," +
				"          \"aggs\": {" +
				"            \"top_loc\": {" +
				"              \"top_hits\": {" +
				"                \"sort\": [" +
				"                  {" +
				"                    \"createddate\": {" +
				"                      \"order\": \"desc\"" +
				"                    }" +
				"                  }" +
				"                ]," +
				"                \"_source\": {" +
				"                  \"includes\": [" +
				"                    \"loc_mx\"," +
				"                    \"loc_my\"" +
				"                  ]" +
				"                }," +
				"                \"size\": 1" +
				"              }" +
				"            }" +
				"          }" +
				"        }" +
				"      }" +
				"    }" +
				"  }" +
				"}";
	}

	/**
	 * Gets the wifi information for the requested ssid.
	 * @param requestDto
	 * @return
	 */
	@Override
	public WifiClusterInfoResponseDto getWifiDataClusterInfoData(WifiClusterInfoRequestDto requestDto) {
		WifiClusterInfoResponseDto responseDto = new WifiClusterInfoResponseDto();

		if(requestDto.getWifiType().equalsIgnoreCase("wifi")) {
			String wifiClusterInfoQuery = getWifiDataClusterInfoQuery(requestDto);

			String indices = environment.getRequiredProperty("esIndexEndPoint");
			String dataPointType = environment.getRequiredProperty("esIndexType");

			if (log.isDebugEnabled()) {
				log.debug("WifiClusterInfo Query formed for WifiType: " + wifiClusterInfoQuery);
				log.debug("Indices: " + indices);
			}

			responseDto = wifiDao.getWifiDataClusterInfo(dataPointType, wifiClusterInfoQuery, indices, requestDto.getSsid(), "wifi");
		} else if(requestDto.getWifiType().equalsIgnoreCase("escher")) {
			String escherClusterInfoQuery = getEscherClusterInfoQuery(requestDto);

			String indices = environment.getRequiredProperty("esEscherIndexEndPoint");
			String dataPointType = environment.getRequiredProperty("esEscherIndexType");

			if (log.isDebugEnabled()) {
				log.debug("WifiClusterInfo Query formed for EscherType: " + escherClusterInfoQuery);
				log.debug("Indices: " + indices);
			}

			responseDto = wifiDao.getWifiDataClusterInfo(dataPointType, escherClusterInfoQuery, indices, requestDto.getSsid(), "escher");
		}

		return responseDto;
	}

	/**
	 * Gets escher information for the requested ssid.
	 * @param infoRequestDto
	 * @return
	 */
	private String getEscherClusterInfoQuery(WifiClusterInfoRequestDto infoRequestDto) {
		return "{" +
				"  \"size\": 1," +
				"  \"_source\": {" +
				"    \"includes\": [" +
				"      \"ssid\"," +
				"      \"rssi\"," +
				"      \"bssid\"," +
				"      \"imei\"," +
				"      \"mdn\"," +
				"      \"ipass\"," +
				"      \"ipassscore\"," +
				"      \"authenticationused\"," +
				"      \"frequency\"," +
				"      \"linkspeed\"" +
				"    ]" +
				"  }," +
				"  \"query\": {" +
				"    \"bool\": {" +
				"      \"must\": [" +
				"        {" +
				"          \"term\": {" +
				"            \"ssid\": \"" + infoRequestDto.getSsid() +
				"\"" +
				"          }" +
				"        }," +
				"        {" +
				"          \"term\": {" +
				"            \"loc_mx\": \"" + infoRequestDto.getLocMx() +
				"\"" +
				"          }" +
				"        }," +
				"        {" +
				"          \"term\": {" +
				"            \"loc_my\": \"" + infoRequestDto.getLocMy() +
				"\"" +
				"          }" +
				"        }," +
				"        {" +
				"          \"range\": {" +
				"            \"currenttime\": {" +
				"              \"from\": \"" + infoRequestDto.getTimeStampFrm() +
				"\"," +
				"              \"to\": \"" + infoRequestDto.getTimeStampTo() +
				"\"," +
				"              \"include_lower\": true," +
				"              \"include_upper\": true," +
				"              \"boost\": 1" +
				"            }" +
				"          }" +
				"        }" +
				"      ]" +
				"    }" +
				"  }," +
				"  \"sort\": {" +
				"    \"currenttime\": {" +
				"      \"order\": \"desc\"" +
				"    }" +
				"  }" +
				"}";
	}

	/**
	 * Gets the wifi information for the requested ssid.
	 * @param infoRequestDto
	 * @return
	 */
	private String getWifiDataClusterInfoQuery(WifiClusterInfoRequestDto infoRequestDto) {
		return "{" +
				"  \"size\": 1," +
				"  \"_source\": {" +
				"    \"includes\": [" +
				"      \"ssid\"," +
				"      \"rssi\"," +
				"      \"bssid\"," +
				"      \"ipaddress\"," +
				"      \"hiddenssid\"," +
				"      \"networkid\"," +
				"      \"macaddress\"," +
				"      \"linkspeed\"," +
				"      \"gateway\"," +
				"      \"netmask\"," +
				"      \"wifitype\"," +
				"      \"encryption\"," +
				"      \"secondarydns\"," +
				"      \"dhcpserver\"," +
				"      \"channel\"" +
				"    ]" +
				"  }," +
				"  \"query\": {" +
				"    \"bool\": {" +
				"      \"must\": [" +
				"        {" +
				"          \"term\": {" +
				"            \"wifitype\": \"servingap\"" +
				"          }" +
				"        }," +
				"        {" +
				"          \"term\": {" +
				"            \"ssid\": \"\\\"" + infoRequestDto.getSsid() +
				"\\\"\"" +
				"          }" +
				"        }," +
				"        {" +
				"          \"term\": {" +
				"            \"loc_mx\": \"" + infoRequestDto.getLocMx() +
				"\"" +
				"          }" +
				"        }," +
				"        {" +
				"          \"term\": {" +
				"            \"loc_my\": \"" + infoRequestDto.getLocMy() +
				"\"" +
				"          }" +
				"        }," +
				"        {" +
				"          \"range\": {" +
				"            \"createddate\": {" +
				"              \"from\": \"" + infoRequestDto.getTimeStampFrm() +
				"\"," +
				"              \"to\": \"" + infoRequestDto.getTimeStampTo() +
				"\"," +
				"              \"include_lower\": true," +
				"              \"include_upper\": true," +
				"              \"boost\": 1" +
				"            }" +
				"          }" +
				"        }" +
				"      ]" +
				"    }" +
				"  }," +
				"  \"sort\": " +
				"    {" +
				"      \"createddate\": {" +
				"        \"order\": \"desc\"" +
				"      }" +
				"    }" +
				"}";
	}
}