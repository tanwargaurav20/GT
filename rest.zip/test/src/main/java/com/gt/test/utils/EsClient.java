package com.harman.dmat.utils;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.transport.client.PreBuiltTransportClient;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.harman.dmat.common.exception.InfoPointsException;

import lombok.extern.slf4j.Slf4j;

/**
 * @author GTanwar Gives the transport client to communicate with the ES
 */
@Component
@Slf4j
public class EsClient {

	public static TransportClient client;

	public EsClient(Environment environment) {
		String[] nodes;
		String nodeString = environment.getProperty("es.node.id");
		if (nodeString.contains(","))
			nodes = nodeString.split(",");
		else
			nodes = new String[] { nodeString };
		log.info("dmat is using the ES cluster name : {} ", environment.getProperty("es.cluster.name"));
		Settings settings = Settings.builder().put("cluster.name", environment.getProperty("es.cluster.name")).build();
		try {
			client = extracted(settings).addTransportAddresses(getAddress(nodes));
		} catch (UnknownHostException e) {
			log.error("Unable to connect to ES repository");
			throw new InfoPointsException();
		}
	}

	/*
	 * static { Settings settings = Settings.builder().put("cluster.name",
	 * "dmat_es").build(); try { client =
	 * extracted(settings).addTransportAddress( (TransportAddress) new
	 * InetSocketTransportAddress(InetAddress.getByName("10.20.40.183"), 9300));
	 * } catch (UnknownHostException e) { log.error(
	 * "Unable to connect to ES repository"); throw new InfoPointsException(); }
	 * 
	 * }
	 */
	/**
	 * @param settings
	 * @return
	 */
	private static PreBuiltTransportClient extracted(Settings settings) {
		return new PreBuiltTransportClient(settings);
	}

	/**
	 * insnayak20 getAddress InetSocketTransportAddress[]
	 * 
	 * @param hosts
	 * @return
	 * @throws UnknownHostException
	 */
	private static InetSocketTransportAddress[] getAddress(String[] hosts) throws UnknownHostException {
		List<InetSocketTransportAddress> list = new ArrayList<>();
		for (String host : hosts) {
			String[] hostPort = null;
			hostPort = host.split(":");
			list.add(new InetSocketTransportAddress(InetAddress.getByName(hostPort[0]), Integer.parseInt(hostPort[1])));

		}
		;
		list.forEach(value->log.info("added Es  data node id {}",value));
		return list.toArray(new InetSocketTransportAddress[list.size()]);

	}

}
