package com.harman.dmat.utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.harman.dmat.common.dto.FilePostProcessDto;
import com.harman.dmat.common.dto.FilePreProcessDto;
import com.harman.dmat.common.dto.FileProcessDirComparisonDto;
import com.harman.dmat.common.dto.FileProcessStatusDto;
import com.harman.dmat.constant.Constant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FileProcessingUtil {

	public static long listFiles(String directory) {
		Set<String> fileNames = new TreeSet<>();
		try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(Paths.get(directory))) {
			directoryStream.forEach(path -> {
				if (!Files.isDirectory(path)) {
					fileNames.add(path.toString());
				}
			});
		} catch (IOException e) {
			log.error("ERROR getting list of files stats for {}: ", directory, e);
		}
		return fileNames.size();
	}

	public static File[] listFiles(File srcdir){
		File[] files = srcdir.listFiles(file -> !file.isDirectory());
		if(files != null ){
			Arrays.sort(files, Comparator.comparing(f -> f.getName()));
		}
		return files;
	}

	public static Set<String> listDir(String directory) {
		Set<String> fileNames = new TreeSet<>();
		try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(Paths.get(directory))) {
			directoryStream.forEach(path -> {
				if (Files.isDirectory(path)) {
					fileNames.add(path.toString());
				}
			});
		} catch (IOException e) {
			log.error("ERROR getting list of directories stats for {}: ", directory, e);
		}
		return fileNames;
	}

	public static File[] listCompleteFiles(File srcdir){
		File[] files = srcdir.listFiles(file -> {
            String fileExt = getFileExtension(file);
            return !file.isDirectory() && !fileExt.equalsIgnoreCase("temp") ;
        });

		if(files != null ){
			Arrays.sort(files, Comparator.comparing(f -> f.getName()));
		}
		return files;
	}

	private static String getFileExtension(File file) {
		String fileName = file.getName();
		if(fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
			return fileName.substring(fileName.lastIndexOf(".")+1);
		else return "";
	}

	public String createReportFile(final String fileName, final String userId) throws UnsupportedEncodingException {
		String path = this.getClass().getClassLoader().getResource("").getPath();
		log.debug("Context path location:-" + path);
		String fullPath = null;
		fullPath = URLDecoder.decode(path, "UTF-8");
		String pathArr[] = fullPath.split("/WEB-INF/classes/");
		log.debug("Tomcat install path location:-" + pathArr[0]);
		fullPath = pathArr[0];
		File orbitDirectory = new File(fullPath);
		String parentDirectory = orbitDirectory.getParent();
		String excelPath = parentDirectory + "\\" + Constant.DASHBOARDREPORT;
		log.debug("Excel Report folder location:-" + excelPath);
		Path pathWithFileName = Paths.get(excelPath);
		File file = new File(excelPath);
		if (!file.exists()) {
			file.mkdirs();
		}
		String fullFileLocation = pathWithFileName.toString() + "\\" + userId + "_" + fileName;
		log.debug("File absolute path location::-" + fullFileLocation);
		return fullFileLocation;
	}

	public ResponseEntity<Resource> downloadExcelSheet(String fullFileLocation, HSSFWorkbook workbook)
			throws FileNotFoundException, IOException {
		try (FileOutputStream outputStream = new FileOutputStream(fullFileLocation)) {
			workbook.write(outputStream);
		} catch (Exception e) {
		}
		final File downloadFile = new File(fullFileLocation);
		FileInputStream fis = new FileInputStream(fullFileLocation);
		ByteArrayOutputStream bos = new ByteArrayOutputStream();

		byte[] buf = new byte[1024];
		for (int readNum; (readNum = fis.read(buf)) != -1;) {
			bos.write(buf, 0, readNum);
			System.out.println("read " + readNum + " bytes,");
		}
		ByteArrayResource resource = new ByteArrayResource(bos.toByteArray());
		HttpHeaders headers = null;
		headers = new HttpHeaders();
		headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
		headers.add("Pragma", "no-cache");
		headers.add("Expires", "0");
		headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		bos.close();
		fis.close();

		boolean isDeleted = false;
		if (downloadFile.exists()) {
			isDeleted = downloadFile.delete();
		}
		System.out.println("Is file deleted:- " + isDeleted);

		return ResponseEntity.ok().headers(headers).contentLength(resource.contentLength()).body(resource);
	}

	public HSSFWorkbook buildFileProcessingExcel(List<FileProcessStatusDto> fileProcessedList) {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("FileProcessingStatus");

		HSSFCellStyle style = workbook.createCellStyle();
		HSSFFont font = workbook.createFont();
		font.setFontName(HSSFFont.FONT_ARIAL);
		font.setFontHeightInPoints((short) 10);
		font.setBold(true);
		font.setColor(HSSFColor.WHITE.index);
		style.setFont(font);
		style.setFillPattern(FillPatternType.BIG_SPOTS);
		style.setFillForegroundColor(HSSFColor.RED.index);
		style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		style.setAlignment(HorizontalAlignment.CENTER);
		
		style.setBorderLeft(BorderStyle.MEDIUM);
		style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderTop(BorderStyle.MEDIUM);
		style.setTopBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderRight(BorderStyle.MEDIUM);
		style.setRightBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderBottom(BorderStyle.MEDIUM);
		style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		
		Row header = sheet.createRow(0);

		Cell cell = header.createCell((short) 0);
		cell.setCellValue("No.");
		cell.setCellStyle(style);

		cell = header.createCell((short) 1);
		cell.setCellValue("Date");
		cell.setCellStyle(style);

		cell = header.createCell((short) 2);
		cell.setCellValue("FTP Files");
		cell.setCellStyle(style);

		cell = header.createCell((short) 3);
		cell.setCellValue("Pre Processed Files");
		cell.setCellStyle(style);

		cell = header.createCell((short) 4);
		cell.setCellValue("Post Processed");
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 4, 6));
		cell.setCellStyle(style);

		cell = header.createCell((short) 7);
		cell.setCellValue("Elastic Search");
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 7, 9));
		cell.setCellStyle(style);

		cell = header.createCell((short) 10);
		cell.setCellValue("Total Failed Files");
		cell.setCellStyle(style);

		for (int i = 2; i <= 10; i++) {
			sheet.autoSizeColumn(i);
		}
		header = sheet.createRow(1);

		cell = header.createCell((short) 0);
		cell.setCellValue("No.");
		sheet.addMergedRegion(new CellRangeAddress(0, 1, 0, 0));
		cell.setCellStyle(style);

		cell = header.createCell((short) 1);
		cell.setCellValue("Date");
		sheet.addMergedRegion(new CellRangeAddress(0, 1, 1, 1));
		cell.setCellStyle(style);

		cell = header.createCell((short) 2);
		cell.setCellValue("FTP Files");
		sheet.addMergedRegion(new CellRangeAddress(0, 1, 2, 2));
		cell.setCellStyle(style);

		cell = header.createCell((short) 3);
		cell.setCellValue("Pre Processed Files");
		sheet.addMergedRegion(new CellRangeAddress(0, 1, 3, 3));
		cell.setCellStyle(style);

		cell = header.createCell((short) 4);
		cell.setCellValue("Files");
		cell.setCellStyle(style);

		cell = header.createCell((short) 5);
		cell.setCellValue("Records");
		cell.setCellStyle(style);

		cell = header.createCell((short) 6);
		cell.setCellValue("Events");
		cell.setCellStyle(style);

		cell = header.createCell((short) 7);
		cell.setCellValue("Files");
		cell.setCellStyle(style);

		cell = header.createCell((short) 8);
		cell.setCellValue("Records");
		cell.setCellStyle(style);

		cell = header.createCell((short) 9);
		cell.setCellValue("Events");
		cell.setCellStyle(style);

		cell = header.createCell((short) 10);
		cell.setCellValue("Total Failed Files");
		sheet.addMergedRegion(new CellRangeAddress(0, 1, 10, 10));
		cell.setCellStyle(style);

		for (int i = 2; i <= 10; i++) {
			sheet.autoSizeColumn(i);
		}
		int rowCount = 1;
		for (Iterator<FileProcessStatusDto> iterator = fileProcessedList.iterator(); iterator.hasNext();) {
			FileProcessStatusDto fileProcessStatusDto = (FileProcessStatusDto) iterator.next();

			Row row = sheet.createRow(++rowCount);
			int columnCount = 0;

			int slNo = rowCount-1;
			cell = row.createCell(columnCount);
			cell.setCellValue(slNo);

			Object field = fileProcessStatusDto.getProcessDate();
			cell = row.createCell(++columnCount);
			cell.setCellValue((String) field);

			field = fileProcessStatusDto.getFtpFiles();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = fileProcessStatusDto.getPreProcessedFiles();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = fileProcessStatusDto.getPostProcessedFiles();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = fileProcessStatusDto.getPostProcessedRecords();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = fileProcessStatusDto.getPostProcessedEvents();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = fileProcessStatusDto.getEsFiles();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = fileProcessStatusDto.getEsRecords();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = fileProcessStatusDto.getEsEvents();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = fileProcessStatusDto.getFailedFiles();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);
		}
		sheet.autoSizeColumn(1);
		return workbook;
	}

	public HSSFWorkbook buildPreProcessingExcel(List<FilePreProcessDto> fileProcessedList) {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("PreProcessingStatus");
		Row header = sheet.createRow(0);
		HSSFCellStyle style = workbook.createCellStyle();
		HSSFFont font = workbook.createFont();
		font.setFontName(HSSFFont.FONT_ARIAL);
		font.setFontHeightInPoints((short) 10);
		font.setBold(true);
		font.setColor(HSSFColor.WHITE.index);
		style.setFont(font);
		style.setFillPattern(FillPatternType.BIG_SPOTS);
		style.setFillForegroundColor(HSSFColor.RED.index);
		style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		style.setAlignment(HorizontalAlignment.CENTER);
		
		style.setBorderLeft(BorderStyle.MEDIUM);
		style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderTop(BorderStyle.MEDIUM);
		style.setTopBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderRight(BorderStyle.MEDIUM);
		style.setRightBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderBottom(BorderStyle.MEDIUM);
		style.setBottomBorderColor(IndexedColors.BLACK.getIndex());

		Cell headCell = header.createCell((short) 0);
		headCell.setCellValue("No.");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 1);
		headCell.setCellValue("Date");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 2);
		headCell.setCellValue("File Picked");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 3);
		headCell.setCellValue("Zip Files");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 4);
		headCell.setCellValue("DLF Files");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 5);
		headCell.setCellValue("Others");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 6);
		headCell.setCellValue("Staged");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 7);
		headCell.setCellValue("Pre Processed");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 8);
		headCell.setCellValue("Failed");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 9);
		headCell.setCellValue("MV Work Dir");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 10);
		headCell.setCellValue("MV Part Dir");
		headCell.setCellStyle(style);

		int rowCount = 0;

		for (Iterator<FilePreProcessDto> iterator = fileProcessedList.iterator(); iterator.hasNext();) {
			FilePreProcessDto filePreProcessDto = (FilePreProcessDto) iterator.next();

			Row row = sheet.createRow(++rowCount);
			int columnCount = 0;

			Cell cell = row.createCell(columnCount);
			cell.setCellValue((Integer) rowCount);

			Object field = filePreProcessDto.getProcessDate();
			cell = row.createCell(++columnCount);
			cell.setCellValue((String) field);

			field = filePreProcessDto.getFilesPicked();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = filePreProcessDto.getZipFiles();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = filePreProcessDto.getDlfFiles();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = filePreProcessDto.getOthers();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = filePreProcessDto.getStaged();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = filePreProcessDto.getPreProcessed();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = filePreProcessDto.getFailed();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = filePreProcessDto.getMvWorkDir();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = filePreProcessDto.getMvPartDir();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);
		}
		for (int i = 1; i <= 10; i++) {
			sheet.autoSizeColumn(i);
		}
		return workbook;
	}

	public HSSFWorkbook buildPostProcessExcel(List<FilePostProcessDto> fileProcessedList) {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("PostProcessingStatus");
		Row header = sheet.createRow(0);

		HSSFCellStyle style = workbook.createCellStyle();
		HSSFFont font = workbook.createFont();
		font.setFontName(HSSFFont.FONT_ARIAL);
		font.setFontHeightInPoints((short) 10);
		font.setBold(true);
		font.setColor(HSSFColor.WHITE.index);
		style.setFont(font);
		style.setFillPattern(FillPatternType.BIG_SPOTS);
		style.setFillForegroundColor(HSSFColor.RED.index);
		style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		style.setAlignment(HorizontalAlignment.CENTER);
		
		style.setBorderLeft(BorderStyle.MEDIUM);
		style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderTop(BorderStyle.MEDIUM);
		style.setTopBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderRight(BorderStyle.MEDIUM);
		style.setRightBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderBottom(BorderStyle.MEDIUM);
		style.setBottomBorderColor(IndexedColors.BLACK.getIndex());

		Cell headCell = header.createCell((short) 0);
		headCell.setCellValue("No.");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 1);
		headCell.setCellValue("Date");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 2);
		headCell.setCellValue("Total Picked");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 3);
		headCell.setCellValue("Part Dir");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 4);
		headCell.setCellValue("Part Files");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 5);
		headCell.setCellValue("File Processed");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 6);
		headCell.setCellValue("Part Files Processed");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 7);
		headCell.setCellValue("Process Failed");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 8);
		headCell.setCellValue("Total Files Processed");
		headCell.setCellStyle(style);

		int rowCount = 0;

		for (Iterator<FilePostProcessDto> iterator = fileProcessedList.iterator(); iterator.hasNext();) {
			FilePostProcessDto filePostProcessDto = (FilePostProcessDto) iterator.next();

			Row row = sheet.createRow(++rowCount);
			int columnCount = 0;

			Cell cell = row.createCell(columnCount);
			cell.setCellValue((Integer) rowCount);

			Object field = filePostProcessDto.getProcessDate();
			cell = row.createCell(++columnCount);
			cell.setCellValue((String) field);

			field = filePostProcessDto.getFilesPicked();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = filePostProcessDto.getPartDir();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = filePostProcessDto.getPartFiles();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = filePostProcessDto.getFilesProcessed();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = filePostProcessDto.getPartFilesProcessed();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = filePostProcessDto.getProcessFailed();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = filePostProcessDto.getTotalFilesProcessed();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);
		}
		for (int i = 1; i <= 10; i++) {
			sheet.autoSizeColumn(i);
		}
		return workbook;
	}

	public HSSFWorkbook buildPhysicalDirectoryExcel(List<FileProcessDirComparisonDto> fileProcessedList) {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("PhysicalDirectoryStatus");
		Row header = sheet.createRow(0);

		HSSFCellStyle style = workbook.createCellStyle();
		HSSFFont font = workbook.createFont();
		font.setFontName(HSSFFont.FONT_ARIAL);
		font.setFontHeightInPoints((short) 10);
		font.setBold(true);
		font.setColor(HSSFColor.WHITE.index);
		style.setFont(font);
		style.setFillPattern(FillPatternType.BIG_SPOTS);
		style.setFillForegroundColor(HSSFColor.RED.index);
		style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		style.setAlignment(HorizontalAlignment.CENTER);
		
		style.setBorderLeft(BorderStyle.MEDIUM);
		style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderTop(BorderStyle.MEDIUM);
		style.setTopBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderRight(BorderStyle.MEDIUM);
		style.setRightBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderBottom(BorderStyle.MEDIUM);
		style.setBottomBorderColor(IndexedColors.BLACK.getIndex());

		Cell headCell = header.createCell((short) 0);
		headCell.setCellValue("No.");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 1);
		headCell.setCellValue("Date");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 2);
		headCell.setCellValue("Total Individual Files");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 3);
		headCell.setCellValue("Part Directories Count");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 4);
		headCell.setCellValue("Total Part Files");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 5);
		headCell.setCellValue("Failed Files");
		headCell.setCellStyle(style);

		headCell = header.createCell((short) 6);
		headCell.setCellValue("Total");
		headCell.setCellStyle(style);

		int rowCount = 0;

		for (Iterator<FileProcessDirComparisonDto> iterator = fileProcessedList.iterator(); iterator.hasNext();) {
			FileProcessDirComparisonDto fileProcessDirComparisonDto = (FileProcessDirComparisonDto) iterator.next();

			Row row = sheet.createRow(++rowCount);
			int columnCount = 0;

			Cell cell = row.createCell(columnCount);
			cell.setCellValue((Integer) rowCount);

			Object field = fileProcessDirComparisonDto.getProcessDate();
			cell = row.createCell(++columnCount);
			cell.setCellValue((String) field);

			field = fileProcessDirComparisonDto.getIndividualFiles();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = fileProcessDirComparisonDto.getPartDirCount();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = fileProcessDirComparisonDto.getTotalPartFiles();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = fileProcessDirComparisonDto.getFilesFailed();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);

			field = fileProcessDirComparisonDto.getTotal();
			cell = row.createCell(++columnCount);
			cell.setCellValue((Long) field);
		}
		for (int i = 1; i <= 10; i++) {
			sheet.autoSizeColumn(i);
		}
		return workbook;
	}
}