package com.harman.dmat.utils;

import com.harman.dmat.common.dto.CustomReportsHistogramDto;
import lombok.extern.slf4j.Slf4j;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

import java.awt.*;
import java.text.DecimalFormat;
import java.util.List;

@Slf4j
public class JFreeChartUtil {

    public JFreeChartUtil() {

    }

    public CategoryDataset createTimeSeriesDataset(String kpiName, List<CustomReportsHistogramDto> customReportsDtoList) {
        DefaultCategoryDataset dataSet = new DefaultCategoryDataset();
        if (!customReportsDtoList.isEmpty()) {
            customReportsDtoList.forEach(customReportsDto -> {
                String dateTime = customReportsDto.getX();
                String kpiValue = customReportsDto.getY();
                dataSet.addValue(Double.parseDouble(kpiValue), kpiName, dateTime);
            });
        }
        return dataSet;
    }

    public CategoryDataset createHistogramDataset(String kpiName, List<CustomReportsHistogramDto> customReportsDtoList) {
        DefaultCategoryDataset dataSet = new DefaultCategoryDataset();
        if (!customReportsDtoList.isEmpty()) {
            double value = 0;
            for(CustomReportsHistogramDto customReportsHistogramDto: customReportsDtoList) {
                value += Double.parseDouble(customReportsHistogramDto.getY());
            }

            for(CustomReportsHistogramDto customReportsDto: customReportsDtoList) {
                String dateTime = customReportsDto.getX();
                String kpiValue = customReportsDto.getY();
                dataSet.addValue((Double.parseDouble(kpiValue) / value) * 100, kpiName, dateTime);
            }
        }
        return dataSet;
    }


    public JFreeChart createBarChart(String chartHeader, CategoryDataset dateSet, String xAxisLabel, String yAxisLabel) {
        final JFreeChart chart = ChartFactory.createBarChart(
                chartHeader, xAxisLabel, yAxisLabel,
                dateSet, PlotOrientation.VERTICAL, true, false, false);
        CategoryPlot categoryPlot = chart.getCategoryPlot();
        BarRenderer renderer = (BarRenderer) categoryPlot.getRenderer();
        renderer.setBarPainter(new StandardBarPainter());
        renderer.setShadowVisible(false);
        renderer.setDrawBarOutline(false);
        renderer.setMaximumBarWidth(0.1d);
        renderer.setSeriesPaint(0, new Color(255, 153, 153));
        categoryPlot.setRenderer(renderer);

        setRangeAxisProperties(dateSet, (NumberAxis) categoryPlot.getRangeAxis());

        CategoryAxis domainAxis = categoryPlot.getDomainAxis();
        if (dateSet.getColumnCount() > 10) {
            domainAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);
        }
        setPlotGridLineProperties(categoryPlot);
        return chart;
    }

    public JFreeChart createLineChart(String chartHeader, CategoryDataset dateSet, String xAxisLabel, String yAxisLabel) {
        JFreeChart chart = ChartFactory.createLineChart(
                chartHeader, xAxisLabel, yAxisLabel,
                dateSet, PlotOrientation.VERTICAL,
                true, false, false
        );
        CategoryPlot categoryPlot = chart.getCategoryPlot();

        NumberAxis numberAxis = (NumberAxis) categoryPlot.getRangeAxis();
        numberAxis.setAutoRangeIncludesZero(false);
        numberAxis.setStandardTickUnits(NumberAxis.createStandardTickUnits());
        DecimalFormat newFormat = new DecimalFormat("#.#");
        numberAxis.setNumberFormatOverride(newFormat);
        CategoryAxis domainAxis = categoryPlot.getDomainAxis();
        if (dateSet.getColumnCount() > 3 && dateSet.getColumnCount() <= 10) {
            domainAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);
        } else if (dateSet.getColumnCount() > 10) {
            domainAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_90);
        }
        LineAndShapeRenderer renderer = (LineAndShapeRenderer) categoryPlot.getRenderer();
        renderer.setSeriesStroke(0, new BasicStroke(3.5f));
        setPlotGridLineProperties(categoryPlot);
        return chart;
    }

    private void setPlotGridLineProperties(CategoryPlot categoryPlot) {
        float dash[] = {1, 1};
        float f1 = 1f, f2 = 1, f3 = 1;
        BasicStroke gridStroke = new BasicStroke(f1, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, f2, dash, f3);
        categoryPlot.setDomainGridlineStroke(gridStroke);
        categoryPlot.setRangeGridlineStroke(gridStroke);
        categoryPlot.setBackgroundPaint(Color.white);
        categoryPlot.setDomainGridlinesVisible(true);
        categoryPlot.setRangeGridlinesVisible(true);
        categoryPlot.setDomainGridlinePaint(new Color(247, 247, 247));
        categoryPlot.setRangeGridlinePaint(new Color(247, 247, 247));
        categoryPlot.setOutlineVisible(false);
    }

    private void setRangeAxisProperties(CategoryDataset dateSet, NumberAxis rangeAxis) {
        double maxValue = 0;
        for(int column= 0; column < dateSet.getColumnCount(); column++) {
            double columnValue = (double) dateSet.getValue(0, column);
            if(columnValue > maxValue) {
                maxValue = columnValue;
            }
        }
        if((maxValue / 10) > 5) {
            rangeAxis.setRange(0.0, round(maxValue, 10));
            rangeAxis.setTickUnit(new NumberTickUnit(10));
        } else {
            rangeAxis.setRange(0.0, round(maxValue, 5));
            rangeAxis.setTickUnit(new NumberTickUnit(5));
        }
        rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        rangeAxis.setAutoRangeIncludesZero(true);
    }

    private double round(double num, int multipleOf) {
        double roundOffValue =  Math.floor((num + multipleOf / 2) / multipleOf) * multipleOf;
        return (roundOffValue > num || roundOffValue > 90) ? roundOffValue : roundOffValue + multipleOf;
    }
}
