package com.harman.dmat.utils;

import com.harman.dmat.common.dto.CustomReportsDownloadPdfRequestDto;
import com.harman.dmat.constant.Constant;
import com.itextpdf.awt.PdfGraphics2D;
import com.itextpdf.text.*;
import com.itextpdf.text.Font;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.*;
import lombok.extern.slf4j.Slf4j;
import org.jfree.chart.JFreeChart;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@Slf4j
public class PDFWriterUtil {

    private int width;
    private int height;

    public PDFWriterUtil() {

    }

    public PDFWriterUtil(int width, int height) {
        this.width = width;
        this.height = height;
    }

    public void writeChartToPDF(CustomReportsDownloadPdfRequestDto downloadPdfRequestDto, Map<String, JFreeChart> charts, String fileName) {
        PdfWriter writer;
        Document document = new Document(PageSize.A4.rotate());
        try {
            writer = PdfWriter.getInstance(document, new FileOutputStream(fileName));
            writer.setPageEvent(new PageStamper());
            document.open();
            if (downloadPdfRequestDto.getReportType() == 1 || downloadPdfRequestDto.getReportType() == 3) {
                writeChart(document, writer, downloadPdfRequestDto.getTimeseriesRequestDto().getKpis(), charts, Constant.CUSTOM_REPORT_TIME_SERIES_HEADER);
            }
            if (downloadPdfRequestDto.getReportType() == 2 || downloadPdfRequestDto.getReportType() == 3) {
                writeChart(document, writer, downloadPdfRequestDto.getHistogramRequestDto().getKpis(), charts, Constant.CUSTOM_REPORT_HISTOGRAM_HEADER);
            }
        } catch (DocumentException | IOException e) {
            log.error(e.getMessage(), e);
        }
        document.close();
    }

    private void writeChart(Document document, PdfWriter writer, List<String> kpiList, Map<String, JFreeChart> charts, String header) {
        kpiList.forEach(kpi -> {
            String chartHeader = String.join(" ", header, kpi.split(":")[1]);
            if (charts.containsKey(chartHeader)) {
                JFreeChart chart = charts.get(chartHeader);
                PdfContentByte contentByte = writer.getDirectContent();
                PdfTemplate template = contentByte.createTemplate(this.width, this.height);
                contentByte.addTemplate(template, 0, 0);
                Graphics2D graphics2d = new PdfGraphics2D(contentByte, this.width, this.height);
                Rectangle2D rectangle2d = new Rectangle2D.Double(0, 0, this.width, this.height);
                chart.draw(graphics2d, rectangle2d);
                graphics2d.dispose();
                try {
                    com.itextpdf.text.Image image = com.itextpdf.text.Image.getInstance(template);
                    float width = document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin();
                    image.scaleToFit(width, 1000);
                    document.add(image);
                } catch (DocumentException e) {
                    log.error(e.getMessage(), e);
                }
            } else {
                writeDataNotFound(document, chartHeader);
            }
            document.newPage();
        });

    }

    private void writeDataNotFound(Document document, String header) {
        try {
            Font font = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD);
            Paragraph para = new Paragraph(header, font);
            para.setLeading(0, 1);
            PdfPTable table = new PdfPTable(1);
            table.setWidthPercentage(100);
            PdfPCell cell = new PdfPCell(new Phrase(para));
            cell.setBorder(PdfPCell.NO_BORDER);
            cell.setMinimumHeight(50);
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);
            font = new Font(Font.FontFamily.HELVETICA, 18, Font.NORMAL);
            para = new Paragraph("Data Not Found", font);
            cell = new PdfPCell(new Phrase(para));
            cell.setBorder(PdfPCell.NO_BORDER);
            cell.setMinimumHeight(300);
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            para.setLeading(0, 1);
            table.addCell(cell);
            document.add(table);
        } catch (DocumentException e) {
            log.error(e.getMessage(), e);
        }
    }


    class PageStamper extends PdfPageEventHelper {

        @Override
        public void onEndPage(PdfWriter writer, Document document) {
            final int currentPageNumber = writer.getCurrentPageNumber();
            try {
                final Rectangle pageSize = document.getPageSize();
                final PdfContentByte directContent = writer.getDirectContent();

                directContent.setColorFill(BaseColor.GRAY);
                directContent.setFontAndSize(BaseFont.createFont(), 10);

                directContent.setTextMatrix(pageSize.getRight(40), pageSize.getBottom(30));
                directContent.showText("Page " + String.valueOf(currentPageNumber));

            } catch (DocumentException | IOException e) {
                log.error("PDF generation error", e);
            }
        }
    }

}
