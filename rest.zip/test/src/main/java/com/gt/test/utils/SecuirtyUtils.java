package com.harman.dmat.utils;

import java.security.Key;
import java.security.MessageDigest;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import com.harman.dmat.constant.Constant;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * The Class SecuirtyUtils.
 *
 * @author <a href="mailto:Prakash.Bisht@harman.com">Prakash Bisht</a>
 */
public class SecuirtyUtils {

	/** The Constant ALGO. */
	private static final String ALGO = "AES";

	/** The Constant keyValue. */
	private static final byte[] KEY_VALUE = "mybestsecreatkey".getBytes();

	public static void main(final String[] args) {
		System.out.println(hashPassword("Login1-2"));
	}

	/**
	 * Encrypt.
	 *
	 * @param Data
	 *            the data
	 * @return the string
	 * @throws Exception
	 *             the exception
	 */
	public static String encrypt(final String Data) {
		try {
			final Key key = generateKey();
			final Cipher c = Cipher.getInstance(ALGO);
			c.init(Cipher.ENCRYPT_MODE, key);
			final byte[] encVal = c.doFinal(Data.getBytes());
			final String encryptedValue = new BASE64Encoder().encode(encVal);
			return encryptedValue;
		} catch (final Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Decrypt.
	 *
	 * @param encryptedData
	 *            the encrypted data
	 * @return the string
	 * @throws Exception
	 *             the exception
	 */
	public static String decrypt(final String encryptedData) {
		Key key;
		try {
			key = generateKey();
			final Cipher c = Cipher.getInstance(ALGO);
			c.init(Cipher.DECRYPT_MODE, key);
			final byte[] decordedValue = new BASE64Decoder().decodeBuffer(encryptedData);
			final byte[] decValue = c.doFinal(decordedValue);
			final String decryptedValue = new String(decValue);
			return decryptedValue;
		} catch (final Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Generate key.
	 *
	 * @return the key
	 * @throws Exception
	 *             the exception
	 */
	private static Key generateKey() throws Exception {
		final Key key = new SecretKeySpec(KEY_VALUE, ALGO);
		return key;
	}

	public static String hashPassword(final String password) {
		try {
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] hash = digest.digest(password.getBytes("UTF-8"));
			StringBuffer hexString = new StringBuffer();

			for (int i = 0; i < hash.length; i++) {
				String hex = Integer.toHexString(0xff & hash[i]);
				hexString.append(hex);
			}

			return hexString.toString().toUpperCase();
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	public static boolean matchPassword(final String originalPassword, final String generatedSecuredPasswordHash) {
		return originalPassword.equals(generatedSecuredPasswordHash);
		// return
		// hashPassword(originalPassword).equals(generatedSecuredPasswordHash);
		// return BCrypt.checkpw(originalPassword,
		// generatedSecuredPasswordHash);
	}

	public static final String removeCFLRChar(final Object logInput) {
			return logInput.toString().replace(Constant.LOG_SCAPE_CHAR, Constant.EMPTY_STRING);
	}
}
