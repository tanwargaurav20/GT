package com.harman.dmat.utils;

import java.util.List;

import com.harman.dmat.constant.Constant;
import com.harman.dmat.enums.Roles;

public class UserManagerStringUtil {
	public static boolean isNullOrEmpty(String dataStr) {
		boolean isEmpty = false;
		if (dataStr == null
				|| (dataStr != null && (dataStr.length() == 0 || dataStr.trim()
						.length() == 0))) {
			isEmpty = true;
		}
		return isEmpty;
	}

	public static boolean isNullOrEmptyListCheck(List<String> statecodeList) {
		boolean isEmpty = false;
		if (statecodeList == null || statecodeList != null
				&& statecodeList.size() == 0) {
			isEmpty = true;
		}
		return isEmpty;
	}

	public static boolean checkAdminActiveRole(Integer roleId, Integer isActive) {
		return (roleId.intValue() == Roles.ADMIN.getValue()
				&& isActive.intValue() == Constant.ACTIVE_USER);

	}
	public static boolean checkSuperAdminActiveRole(Integer roleId, Integer isActive) {
		return (roleId.intValue() == Roles.SUPER_ADMIN.getValue()
				&& isActive.intValue() == Constant.ACTIVE_USER);

	}
}