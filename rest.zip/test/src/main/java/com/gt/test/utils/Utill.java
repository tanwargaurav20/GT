package com.harman.dmat.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.function.Predicate;
import java.util.regex.Pattern;

import com.esri.hex.HexGrid;
import com.esri.hex.HexRowCol;
import com.esri.hex.HexXY;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * @author prakash.bisht@harman.com
 *
 */
@Slf4j
public class Utill {
	public static final double ORIGINGRIDX = -20000000.0;
	public static final double ORIGINGGRIDY = -20000000.0;

	public static void main(final String[] args) {
		final String s = "default message [userName]]; default message [Please enter valid username.]] ";
		s.substring(s.lastIndexOf("[") + 1, s.lastIndexOf("]]"));
		// System.out.println(randomAlphaNumeric(8));
		usersScript();
	}

	/**
	 * Generate random alpha numeric string
	 * 
	 * @param count
	 * @return
	 */
	public static String randomAlphaNumeric(int count) {
		final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		final StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			final int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
			builder.append(ALPHA_NUMERIC_STRING.charAt(character));
		}
		builder.replace(0, 3, "@a1");
		return builder.toString();
	}

	public static void usersScript() {
		final DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("org.postgresql.Driver");
		dataSource.setUrl("jdbc:postgresql://localhost/dmat");
		dataSource.setUsername("postgres");
		dataSource.setPassword("root");
		dataSource.setSchema("dmat");
		final JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		for (int i = 0; i < 5899; i++) {
			final String email = "'dmatadmin123@vzwdt.com" + i + "'";
			final String sql = "INSERT INTO users (EMAIL, PASSWORD,FIRST_NAME,LAST_NAME, ROLE_ID, BUSINESS_PURPOSE,COMPANY_ID,\r\nREGION,"
					+ " STATE_CODE,IS_ACTIVE, INS_LOGIN )\r\nVALUES (" + email + ",'Login@12', 'fname', 'lname', 2,"
					+ " 'Verizon', 1, 'North', 'NJ', 1,'dmatadmindata123@vzwdt.com');\r\n";

			final int updated = jdbcTemplate.update(sql.toString());
			System.out.println(i);
		}
	}

	/**
	 * Read json.
	 *
	 * @param <T>
	 *            the generic type
	 * @param json
	 *            the json
	 * @param type
	 *            the type
	 * @return the t
	 * @throws IOException
	 * @throws JsonMappingException
	 * @throws JsonParseException
	 */
	public static <T> T readJson(String json, Class<T> type) throws Exception {
		final ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(json, type);
	}

	/**
	 * Checks if is JSON valid.
	 *
	 * @param jsonInString
	 *            the json in string
	 * @return true, if is JSON valid
	 */
	public static boolean isJSONValid(String jsonInString) {
		try {
			final ObjectMapper mapper = new ObjectMapper();
			mapper.readTree(jsonInString);
			return true;
		} catch (final IOException e) {
			return false;
		}
	}

	/**
	 * @param date
	 * @return
	 */
	public static String dateToUsFormat(String date) {
		final DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		final DateFormat outputFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a");
		String convertedDate = null;
		try {
			convertedDate = outputFormat.format(inputFormat.parse(date));
		} catch (final ParseException e) {
			log.error("Error parsing the date");
		}
		return convertedDate;
	}

	public static String esdateToUsFormat(String date) {
		final DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'.000Z'");
		inputFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		final DateFormat outputFormat = new SimpleDateFormat("MMM dd, yyyy, HH:mm:ss, zzzz", Locale.ENGLISH);
		String convertedDate = null;
		try {
			convertedDate = outputFormat.format(inputFormat.parse(date));
		} catch (final ParseException e) {
			log.error("Error parsing the es date");
		}
		return convertedDate;
	}

	public static String liveDbdateToUsFormat(String date) {
		final DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		inputFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		final DateFormat outputFormat = new SimpleDateFormat("MMM dd, yyyy, HH:mm:ss a, zzzz", Locale.ENGLISH);
		String convertedDate = null;
		try {
			convertedDate = outputFormat.format(inputFormat.parse(date));
		} catch (final ParseException e) {
			log.error("Error parsing the es date");
		}
		return convertedDate;
	}

	/**
	 * @param date
	 * @return
	 */
	public static String formatDateToUsDate(String date) {
		String convertedDate = null;
		try {
			convertedDate = new SimpleDateFormat("MM/dd/yyyy").format(new SimpleDateFormat("yyyy-MM-dd").parse(date));
		} catch (final ParseException e) {
			log.error("Error parsing the date");
		}
		return convertedDate;
	}

	public static String esUsDateToDateFormat(String date) {
		final DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'.000Z'");
		final DateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
		String convertedDate = null;
		try {
			convertedDate = outputFormat.format(inputFormat.parse(date));
		} catch (final ParseException e) {
			log.error("Error parsing the es date");
		}
		return convertedDate;
	}

	public static List<String[]> readCsvFile(InputStream fileStream) throws IOException {
		final List<String[]> lins = new ArrayList<>();
		try (BufferedReader br = new BufferedReader(new InputStreamReader(fileStream))) {
			String line = null;
			while ((line = br.readLine()) != null) {
				final String[] country = line.split(",");
				lins.add(country);
			}
		} catch (final IOException e) {
			throw e;
		}
		return lins;
	}

	/**
	 * Read excel file.
	 *
	 * @param fileStream
	 *            the file stream
	 * @return the list
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	@SuppressWarnings("deprecation")
	public static List<String[]> readExcelFile(InputStream fileStream) throws IOException {
		final Workbook workbook = new XSSFWorkbook(fileStream);
		final Sheet sheet = workbook.getSheetAt(0);
		final Iterator<Row> iterator = sheet.iterator();
		final List<String[]> lins = new ArrayList<>();
		while (iterator.hasNext()) {
			final Row nextRow = iterator.next();
			final Iterator<Cell> cellIterator = nextRow.cellIterator();
			final List<String> cells = new ArrayList<>();
			while (cellIterator.hasNext()) {
				final Cell cell = cellIterator.next();
				cell.setCellType(Cell.CELL_TYPE_STRING);
				cells.add(cell.getStringCellValue());
			}
			lins.add(cells.toArray(new String[] {}));
		}
		workbook.close();
		fileStream.close();
		return lins;
	}

	/**
	 * checks if string is a number
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isNumeric(String str) {
		for (char c : str.toCharArray()) {
			if (!Character.isDigit(c))
				return false;
		}
		return true;
	}

	/**
	 * Fetches the ES to fire query on
	 * 
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public static String getIndex(String startDate, String endDate) {
		String indexExpr = "";
		Calendar cal = new GregorianCalendar();
		Calendar calEnd = new GregorianCalendar();
		String[] sStartDate = startDate.split("-");
		cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(sStartDate[2]));
		cal.set(Calendar.MONTH, Integer.parseInt(sStartDate[1]) - 1);
		cal.set(Calendar.YEAR, Integer.parseInt(sStartDate[0]));

		String[] sEndDate = endDate.split("-");
		calEnd.set(Calendar.DAY_OF_MONTH, Integer.parseInt(sEndDate[2]));
		calEnd.set(Calendar.MONTH, Integer.parseInt(sEndDate[1]) - 1);
		calEnd.set(Calendar.YEAR, Integer.parseInt(sEndDate[0]));

		int startWeek = cal.get(Calendar.WEEK_OF_YEAR);
		int endWeek = calEnd.get(Calendar.WEEK_OF_YEAR);
		if (endWeek >= startWeek) {
			for (int i = startWeek; i <= endWeek; i++)
				indexExpr = indexExpr + "dmat-" + cal.get(Calendar.YEAR) + "-" + i + ",";
		} else {
			for (int i = startWeek; i <= 53; i++)
				indexExpr = indexExpr + "dmat-" + cal.get(Calendar.YEAR) + "-" + i + ",";
			for (int i = 1; i <= endWeek; i++)
				indexExpr = indexExpr + "dmat-" + calEnd.get(Calendar.YEAR) + "-" + i + ",";
		}
		return indexExpr.substring(0, indexExpr.length() - 1);
	}
	
	public static String usDateToLiveDbFormat(String date) {
		final DateFormat inputFormat = new SimpleDateFormat("MMM dd, yyyy, HH:mm:ss a, zzzz", Locale.ENGLISH);
		final DateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		inputFormat.setTimeZone(TimeZone.getTimeZone("GMT"));		
		String convertedDate = null;
		try {
			convertedDate = outputFormat.format(inputFormat.parse(date));
		} catch (final ParseException e) {
			log.error("Error parsing the es date");
		}
		return convertedDate;
	}
	
	public static String splitString(String inputStr, String splitBy) {
		String output = "";
		if(!StringUtils.isBlank(inputStr) && !StringUtils.isBlank(splitBy)) {
			String[] tempArr = inputStr.split(Pattern.quote(splitBy));
			output = tempArr[0];
		}		
		return output;
		
	}
	public static final Predicate<Collection<?>> checkCollectionIsNotNullOrEmpty = collection -> collection != null
			&& !collection.isEmpty();

	public static String getMxMyToRowCol(double gridSize, double loc_mx, double loc_my) {
		String rowColValue = null;
		HexGrid hexGrid = null;
		// log.debug("Values received gridSize: "+gridSize+ ", loc_mx: "+loc_mx+",
		// loc_my: "+loc_my);
		if (!Double.isNaN(gridSize) && !Double.isNaN(loc_mx) && !Double.isNaN(loc_mx)) {
			hexGrid = new HexGrid(gridSize, ORIGINGRIDX, ORIGINGGRIDY); // Initialising gridSize Meter
			// Hexgrid, with constant
			// originX & originY
			HexRowCol rowCol = hexGrid.convertXYToRowCol(loc_mx, loc_my); // HexRowCol holds r:c of the Webmarcater x,y
			// values
			rowColValue = (String)rowCol.toText();
			// log.debug("Returning HexGrid r:c: "+rowColValue);
		}
		return rowColValue;
	}

	public static HexXY getRowColToMxMy(double gridSize, long row, long col) {
		HexGrid hexGrid = null;
		HexXY hexXY = null;
		// log.debug("Values received gridSize: "+gridSize+ ", loc_mx: "+loc_mx+",
		// loc_my: "+loc_my);
		if (!Double.isNaN(gridSize)) {
			hexGrid = new HexGrid(gridSize, ORIGINGRIDX, ORIGINGGRIDY); // Initialising gridSize Meter
			// Hexgrid, with constant
			// originX & originY
			hexXY = hexGrid.convertRowColToHexXY(row, col); // HexRowCol holds r:c of the Webmarcater x,y
		}
		return hexXY;
	}

}
