package com.harman.dmat.infoPonts.test;

import java.util.ArrayList;
import java.util.List;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;
import com.harman.dmat.common.config.AppConfig;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.dao.impl.InfoPointsDaoImpl;
import com.harman.dmat.manager.InfoPointsManager;
import com.harman.dmat.manager.impl.InfoPointsManagerImpl;
import com.harman.dmat.service.InfoPointsService;
import com.harman.dmat.service.impl.InfoPointsServiceImpl;

@RunWith(MockitoJUnitRunner.class)
@ContextConfiguration(classes = { AppConfig.class })
public class InfoPointsServiceTest {

	@InjectMocks
	InfoPointsManager infoPointsManager = new InfoPointsManagerImpl();

	@InjectMocks
	@Spy
	InfoPointsService infoPointsService = new InfoPointsServiceImpl();

	@Mock
	InfoPointsDaoImpl infoPointsDaoImpl;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getLogReportsAllUsers() throws DataNotFoundException {
		final List<String> list = new ArrayList<>();

		Mockito.stub(infoPointsDaoImpl.getInfoPoints(new String(), new String())).toReturn(list);
		Assert.assertArrayEquals(infoPointsManager.getInfoPoints("", "", "", "", "", "", "2017-01-01", "2017-01-07", "",
				"", "true", null, null, null, null, null, null, null, null,null).toArray(), list.toArray());
	}

}