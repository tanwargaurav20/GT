package com.harman.dmat.logmgr.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.harman.dmat.common.dto.*;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;

import com.harman.dmat.common.config.AppConfig;
import com.harman.dmat.common.exception.DataNotFoundException;
import com.harman.dmat.common.exception.InvalidRequestPayloadException;
import com.harman.dmat.common.exception.LogMgrException;
import com.harman.dmat.dao.impl.LogMgrDaoImpl;
import com.harman.dmat.manager.LogMgrManager;
import com.harman.dmat.manager.impl.LogMgrManagerImpl;
import com.harman.dmat.service.LogMgrService;
import com.harman.dmat.service.impl.LogMgrServiceImpl;

@RunWith(MockitoJUnitRunner.class)
@ContextConfiguration(classes = { AppConfig.class })
public class LogMgrServiceTest {

	@InjectMocks
	LogMgrManager logMgrManager = new LogMgrManagerImpl();

	@InjectMocks
	@Spy
	LogMgrService logMgrService = new LogMgrServiceImpl();

	@Mock
	LogMgrDaoImpl logMgrDaoImpl;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getLogReportsAllUsers() throws DataNotFoundException {
		final LogMgrRespDto logMgrDtos = new LogMgrRespDto();
		Mockito.stub(logMgrDaoImpl.getLogResults("ALL", "", "", null, null, null, null, 1, 2, null, 1, null))
				.toReturn(logMgrDtos);
		Assert.assertEquals(logMgrManager.getLogReport("ALL", "", "", null, null, null, null, 1, 2, null, 1, null),
				logMgrDtos);
	}

	@Test
	public void getLogReportsSingleUser() throws DataNotFoundException {
		final LogMgrRespDto logMgrDtos = new LogMgrRespDto();
		Mockito.stub(logMgrDaoImpl.getLogResults("Test", "", "", null, null, null, null, 1, 2, null, 1, null))
				.toReturn(logMgrDtos);
		Assert.assertEquals(logMgrManager.getLogReport("Test", "", "", null, null, null, null, 1, 2, null, 1, null),
				logMgrDtos);
	}

	@Test
	public void saveUserPref() throws LogMgrException {
		Mockito.stub(logMgrDaoImpl.saveUserPref(new LogMgrPrefDto())).toReturn(new Boolean(true));
		Assert.assertFalse(logMgrManager.saveUserPref(new LogMgrPrefDto()));
	}

	@Test
	public void deleteLogs() throws InvalidRequestPayloadException, LogMgrException {
		Mockito.stub(logMgrDaoImpl.deleteLogs(new ArrayList<String>(), "2017-10-01", "2017-10-01")).toReturn(new Boolean(true));
		Assert.assertTrue(logMgrManager.deleteLogs(new ArrayList<String>(), "2017-10-01", "2017-10-01"));
	}

	@Test
	public void getUserPrefs() throws DataNotFoundException {
		final List<LogMgrPrefDto> logMgrDtos = new ArrayList<>();
		logMgrDtos.add(new LogMgrPrefDto());
		logMgrDtos.add(new LogMgrPrefDto());
		Mockito.stub(logMgrDaoImpl.getUserPref(1)).toReturn(logMgrDtos);
		Assert.assertArrayEquals(logMgrManager.getUserPref(1).toArray(), logMgrDtos.toArray());
	}

	@Test
	public void getLogAnalysisData() throws DataNotFoundException {
		final Map<String, List<LogMgrAnalysisDto>> dataMap = new HashMap<>();
		final List<LogMgrAnalysisDto> logMgrDtos = new ArrayList<>();
		logMgrDtos.add(new LogMgrAnalysisDto());
		dataMap.put("logStats", logMgrDtos);
		Mockito.stub(logMgrDaoImpl.getLogAnalysisData("All", 1, "", "", "")).toReturn(dataMap);
		Assert.assertArrayEquals(logMgrManager.getLogAnalysisData("All", 1, "", "", "").get("logStats").toArray(),
				logMgrDtos.toArray());
	}

	@Test
	public void searchReportsAllUsers() throws DataNotFoundException {
		final LogMgrRespDto logMgrDtos = new LogMgrRespDto();
		Mockito.stub(logMgrDaoImpl.searchLogs("ALL", "", "", "test", null, 1, 2, 1, null)).toReturn(logMgrDtos);
		Assert.assertEquals(logMgrManager.searchLogs("ALL", "", "", "test", null, 1, 2, 1, null), logMgrDtos);
	}

	@Test
	public void searchReportsSingleUser() throws DataNotFoundException {
		final LogMgrRespDto logMgrDtos = new LogMgrRespDto();
		Mockito.stub(logMgrDaoImpl.searchLogs("1", "", "", "test", null, 1, 2, 1, null)).toReturn(logMgrDtos);
		Assert.assertEquals(logMgrManager.searchLogs("1", "", "", "test", null, 1, 2, 1, null), logMgrDtos);
	}

	@Test
	public void searchCustomReports() throws DataNotFoundException {
		final CustomReportsLogDto customReportsDtos = new CustomReportsLogDto();
		Mockito.stub(logMgrDaoImpl.searchLogFiles(4, "", "", "",2,1 )).toReturn(customReportsDtos);
		Assert.assertEquals(logMgrManager.searchLogFiles(4, "", "", "",2,1), customReportsDtos);
	}

	@Test
	public void getHistogram() throws DataNotFoundException {
		final Map<String, List<CustomReportsHistogramDto>> mapCustomReportsDtos = new HashMap<>();
		CustomReportsRequestDto customReportsRequestDto = new CustomReportsRequestDto();
		customReportsRequestDto.setData(1);
		customReportsRequestDto.setImei(new ArrayList<String>());
		Mockito.stub(logMgrDaoImpl.getHistogram(customReportsRequestDto)).toReturn(mapCustomReportsDtos);
		Assert.assertEquals(logMgrManager.getHistogram(customReportsRequestDto), mapCustomReportsDtos);
	}
}