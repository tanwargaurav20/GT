package com.harman.dmat.test.suit;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import com.harman.dmat.logmgr.test.LogMgrServiceTest;
import com.harman.dmat.user.test.SystemServiceTest;
import com.harman.dmat.user.test.UserServiceTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({ UserServiceTest.class, SystemServiceTest.class, LogMgrServiceTest.class })
public class TestSuit {
}
