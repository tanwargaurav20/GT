package com.harman.dmat.user.test;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;

import com.harman.dmat.common.config.AppConfig;
import com.harman.dmat.common.dto.CompanyDto;
import com.harman.dmat.common.dto.RegionDto;
import com.harman.dmat.common.dto.StateDto;
import com.harman.dmat.common.exception.SystemException;
import com.harman.dmat.dao.impl.UserDaoImpl;
import com.harman.dmat.manager.UserManager;
import com.harman.dmat.manager.impl.UserManagerImpl;
import com.harman.dmat.service.UserService;
import com.harman.dmat.service.impl.UserServiceImpl;

@RunWith(MockitoJUnitRunner.class)
@ContextConfiguration(classes = { AppConfig.class })
@Slf4j
public class SystemServiceTest {

	@InjectMocks
	UserManager userManager = new UserManagerImpl();

	@InjectMocks
	@Spy
	UserService userService = new UserServiceImpl();

	@Mock
	UserDaoImpl userDaoImpl;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getStates() throws SystemException {
		final List<StateDto> stateDtos = new ArrayList<>();
		stateDtos.add(new StateDto());
		stateDtos.add(new StateDto());
		Mockito.stub(userDaoImpl.getStates()).toReturn(stateDtos);
		Assert.assertArrayEquals(userManager.getStates().toArray(),
				stateDtos.toArray());
	}

	@Test
	public void getCompanies() throws SystemException {
		final List<CompanyDto> companyDtos = new ArrayList<>();
		companyDtos.add(new CompanyDto());
		companyDtos.add(new CompanyDto());
		Mockito.stub(userDaoImpl.getCompanies()).toReturn(companyDtos);
		Assert.assertArrayEquals(userManager.getCompanies().toArray(),
				companyDtos.toArray());
	}

	@Test
	public void getRegions() throws SystemException {
		final List<RegionDto> regionDtos = new ArrayList<>();
		regionDtos.add(new RegionDto());
		regionDtos.add(new RegionDto());
		Mockito.stub(userDaoImpl.getRegions()).toReturn(regionDtos);
		Assert.assertArrayEquals(userManager.getRegions().toArray(),
				regionDtos.toArray());
	}

/*	@Test
	public void getRoles() throws SystemException {
		final List<RoleDto> roleDtos = new ArrayList<>();
		roleDtos.add(new RoleDto());
		roleDtos.add(new RoleDto());
		Mockito.stub(systemDaoImpl.getRoles()).toReturn(roleDtos);
		Assert.assertArrayEquals(systemManager.getRoles().toArray(),
				roleDtos.toArray());
	}*/

	@Test
	public void getStateCode() throws SystemException {
		final List<String> data = new ArrayList<String>();
		data.add(new String());
		data.add(new String());
		Mockito.stub(userDaoImpl.getStateName(new String())).toReturn(data);
		Assert.assertArrayEquals(userManager.getStateName(new String())
				.toArray(), data.toArray());
	}

	/*@Test
	public void getPreferences() throws SystemException {
		final List<PreferenceDto> preferenceDto = new ArrayList<PreferenceDto>();
		preferenceDto.add(new PreferenceDto());
		preferenceDto.add(new PreferenceDto());
		Mockito.stub(systemDaoImpl.getListofpreferences()).toReturn(
				preferenceDto);
		Assert.assertArrayEquals(systemManager.getAllpreferences().toArray(),
				preferenceDto.toArray());
	}

	@Test
	public void getUserData() throws SystemException {
		List<FetchUseDto> userlList=new ArrayList<FetchUseDto>();
		userlList.add(new FetchUseDto());
		userlList.add(new FetchUseDto());
		Mockito.stub(systemDaoImpl.getAllUser()).toReturn(userlList);
		Assert.assertArrayEquals(systemManager.getUserDetails(1, 10).toArray(),userlList.toArray());
	}*/
}