package com.harman.dmat.user.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;
import com.harman.dmat.common.config.AppConfig;
import com.harman.dmat.common.dto.AccordionInfo;
import com.harman.dmat.common.dto.AccordionStats;
import com.harman.dmat.common.dto.GroupDto;
import com.harman.dmat.common.dto.StatusInfoDto;
import com.harman.dmat.common.dto.UserDto;
import com.harman.dmat.common.dto.UserPreferenceDto;
import com.harman.dmat.common.email.EmailService;
import com.harman.dmat.common.exception.InvalidRequestPayloadException;
import com.harman.dmat.common.exception.SystemException;
import com.harman.dmat.common.exception.TokenGenerationException;
import com.harman.dmat.common.exception.UserException;
import com.harman.dmat.common.security.TokenAuthentication;
import com.harman.dmat.dao.impl.UserDaoImpl;
import com.harman.dmat.enums.Status;
import com.harman.dmat.manager.UserManager;
import com.harman.dmat.manager.impl.UserManagerImpl;
import com.harman.dmat.service.UserService;
import com.harman.dmat.service.impl.UserServiceImpl;
import lombok.extern.slf4j.Slf4j;

/**
 * The Class UserServiceTest.
 */
@RunWith(MockitoJUnitRunner.class)
@ContextConfiguration(classes = { AppConfig.class })

/** The Constant log. */
@Slf4j
public class UserServiceTest {

	/** The user manager. */
	@InjectMocks
	UserManager userManager = new UserManagerImpl();

	/** The user service. */
	@InjectMocks
	@Spy
	UserService userService = new UserServiceImpl();

	/** The user dao impl. */
	@Mock
	UserDaoImpl userDaoImpl;

	/** The email service. */
	@Mock
	EmailService emailService;

	@Mock
	TokenAuthentication tokenAuthentication;

	/** The user dto. */
	UserDto userDto;

	/** The userval dto. */
	List<UserDto> uservalDto;

	/**
	 * Inits the.
	 */
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Inits the obj.
	 */
	@Before
	public void initObj() {
		userDto = new UserDto();
		userDto.setPassword("prakashsingh");
		userDto.setEmail("prakash.bisht@harman.com");
		userDto.setStatus(Status.ACTIVE.getValue());
		userDto.setFirstName("prakash");
		userDto.setLastName("bisht");
		userDto.setStateCode("NJ");
		userDto.setRegion("North");
		userDto.setUserId(1);

	}

	/**
	 * Rgister user.
	 *
	 * @throws UserException
	 *             the user exception
	 */
	@Test
	public void rgisterUser() throws UserException {
		Mockito.stub(userDaoImpl.registerUser(userDto)).toReturn(1);
		userManager.registerUser(userDto);
	}

	/**
	 * Login user.
	 *
	 * @throws UserException
	 *             the user exception
	 * @throws TokenGenerationException
	 */
	@Test
	public void loginUser() throws UserException, TokenGenerationException {
		userDto.setPassword("$2a$12$A57zzyHC6/hJOn2QL99gWuxdt4qMEJOIXzl6Axl2vFShxQSLPTlga");
		final String token = "ckdkfkdjfsliikdfkciiakfksfkciksdf";
		Mockito.stub(tokenAuthentication.getToken(null).getOrDefault("accessToken", "")).toReturn(token);
		Mockito.stub(userDaoImpl.getUserByEmail("prakash.bisht@harman.com")).toReturn(userDto);
		Assert.assertEquals(userManager.validateUser("prakash.bisht@harman.com", "prakashsingh", "").getToken(), token);
		userDto.setPassword("prakashsingh");
	}

	/**
	 * Change password.
	 *
	 * @throws UserException
	 *             the user exception
	 */
	@Test
	public void changePassword() throws UserException {
		final String newPassword = "prakashbisht";
		Mockito.stub(userDaoImpl.updateUserPassword(userDto.getUserId(), userDto.getPassword(), true)).toReturn(true);
		userManager.changePassword(userDto.getUserId(), userDto.getPassword(), newPassword);

	}

	/**
	 * Forget password.
	 *
	 * @throws UserException
	 *             the user exception
	 */
	@Test
	public void forgetPassword() throws UserException {
		Mockito.stub(userDaoImpl.getUserByEmail("prakash.bisht@harman.com")).toReturn(userDto);
		Mockito.doAnswer(invocation -> {
			return null;
		}).when(emailService).sendEmail(null);
		userManager.forgetPassword(userDto.getEmail());
	}

	/**
	 * Activate users.
	 *
	 * @throws UserException
	 *             the user exception
	 */
	@Test
	public void activateUsers() throws UserException {
		final List<Integer> userIds = new ArrayList<>();
		userIds.add(1);
		userIds.add(2);
		userManager.activateUsers(userIds);
	}

	/**
	 * Save user pref.
	 *
	 * @throws UserException
	 *             the user exception
	 */

	@Test(expected = InvalidRequestPayloadException.class)
	public void saveUserPref() throws UserException {
		Mockito.stub(userDaoImpl.saveUserPreferenceData(new UserPreferenceDto())).toReturn(new Boolean(true));
		Mockito.stub(userDaoImpl.checkValueExist(1)).toReturn(1);
		final UserPreferenceDto userPreferenceDto = new UserPreferenceDto();
		userPreferenceDto.setUserId(1);
		Assert.assertFalse(userManager.saveUserPreferences(new UserPreferenceDto()));
	}

	/*
	 * @Test public void editUserRole() throws UserException {
	 * Mockito.stub(userDaoImpl
	 * .editRoleforUser("prakash.bisht@harman.com",3)).toReturn(1);
	 * Assert.assertEquals
	 * (userManager.editRoleforUser(editRoleDto)("prakash.bisht@harman.com",
	 * 1,3),1); }
	 */

	/**
	 * Gets the user.
	 *
	 * @return the user
	 * @throws SystemException
	 *             the system exception
	 * @throws UserException
	 *             the user exception
	 */
	@Test
	public void getUser() throws SystemException, UserException {
		Mockito.stub(userDaoImpl.getUser(1)).toReturn(userDto);
		Assert.assertEquals(userManager.getUserDetail(1), userDto);
	}

	/**
	 * Gets the search user.
	 *
	 * @return the search user
	 * @throws SystemException
	 *             the system exception
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void getSearchUser() throws SystemException {
		final List<UserDto> userDto = new ArrayList<UserDto>();
		userDto.add(new UserDto());
		userDto.add(new UserDto());
		Mockito.stub(userDaoImpl.getSearchUserData("p")).toReturn(userDto);
		Assert.assertEquals(userManager.getSearchuser("p"), userDto);
	}

	/**
	 * Gets the accordion info.
	 *
	 * @return the accordion info
	 * @throws UserException
	 *             the user exception
	 */
	@Test
	public void getAccordionInfo() throws UserException {
		final AccordionInfo accordionInfo = new AccordionInfo();
		final AccordionStats accordionStats = new AccordionStats();
		accordionStats.setActiveCount(10);
		accordionStats.setInactiveCount(5);
		accordionStats.setTotalCount(15);
		accordionStats.setName("ADMIN");
		final Map<String, AccordionStats> info = new HashMap<>();
		info.put("ADMIN", accordionStats);
		accordionInfo.setAccordionStats(info);
		Mockito.stub(userDaoImpl.getAccordionInfo()).toReturn(accordionInfo);
		Assert.assertEquals(userManager.getAccordionInfo(null).getAccordionStats().get("ADMIN").getActiveCount(),
				accordionStats.getActiveCount());
	}

	/**
	 * Gets the accordion info for search.
	 *
	 * @return the accordion info for search
	 * @throws UserException
	 *             the user exception
	 */
	@Test
	public void getAccordionInfoForSearch() throws UserException {
		final AccordionInfo accordionInfo = new AccordionInfo();
		final AccordionStats accordionStats = new AccordionStats();
		accordionStats.setActiveCount(10);
		accordionStats.setInactiveCount(5);
		accordionStats.setTotalCount(15);
		accordionStats.setName("OEM");
		final Map<String, AccordionStats> info = new HashMap<>();
		info.put("OEM", accordionStats);
		accordionInfo.setAccordionStats(info);
		Mockito.stub(userDaoImpl.getAccordionInfo("name")).toReturn(accordionInfo);
		Assert.assertEquals(userManager.getAccordionInfo("name").getAccordionStats().get("OEM").getActiveCount(),
				accordionStats.getActiveCount());
	}

	/**
	 * Gets the user details.
	 *
	 * @return the user details
	 * @throws UserException
	 *             the user exception
	 */
	@Test
	public void getUserDetails() throws UserException {
		final List<UserDto> userDtos = new ArrayList<UserDto>();
		userDtos.add(new UserDto());
		userDtos.add(new UserDto());
		Mockito.stub(userDaoImpl.getUserDetails(1, 10, "ADMIN")).toReturn(userDtos);
		Assert.assertEquals(userManager.getDetailsWithStatus(1, 10, 1, "ADMIN", null,"FIRST_NAME desc"), userDtos);
	}

	/**
	 * Gets the user details for search.
	 *
	 * @return the user details for search
	 * @throws UserException
	 *             the user exception
	 */
	@Test
	public void getUserDetailsForSearch() throws UserException {
		final List<UserDto> userDtos = new ArrayList<UserDto>();
		userDtos.add(new UserDto());
		userDtos.add(new UserDto());
		Mockito.stub(userDaoImpl.getUserDetails(1, 10, "ADMIN", "pr", "FIRST_NAME desc")).toReturn(userDtos);
		Assert.assertEquals(userManager.getDetailsWithStatus(1, 10, 1, "ADMIN", "pr", "FIRST_NAME desc"), userDtos);
	}

	/**
	 * Change user status.
	 *
	 * @throws UserException
	 *             the user exception
	 */
	@Test
	public void changeUserStatus() throws UserException {
		final StatusInfoDto statusInfoDto = new StatusInfoDto();
		userManager.changeStatus(statusInfoDto);
	}

	/**
	 * Delete users.
	 *
	 * @throws UserException
	 *             the user exception
	 */
	@Test
	public void deleteUsers() throws UserException {
		final StatusInfoDto statusInfoDto = new StatusInfoDto();
		userManager.deleteUsers(statusInfoDto);
	}

	/**
	 * Send notification.
	 *
	 * @throws UserException
	 *             the user exception
	 */
	@Test
	public void sendNotification() throws UserException {
		final List<UserDto> userDtos = new ArrayList<UserDto>();
		userDtos.add(new UserDto());
		userDtos.add(new UserDto());
		final StatusInfoDto statusInfoDto = new StatusInfoDto();
		Mockito.stub(userDaoImpl.sendNotification(statusInfoDto)).toReturn(userDtos);
		Mockito.doAnswer(invocation -> {
			return null;
		}).when(emailService).sendEmail(null);
		userManager.sendNotification(null, "test email", "Hi this is test email", statusInfoDto);
	}

	@Test
	public void getGroups() throws UserException {
		final List<GroupDto> groupDtos = new ArrayList<GroupDto>();
		groupDtos.add(new GroupDto());
		groupDtos.add(new GroupDto());
		Mockito.stub(userDaoImpl.getGroups()).toReturn(groupDtos);
		Assert.assertEquals(userManager.getGroups().size(), groupDtos.size());
	}

	@Test
	public void addGroups() throws UserException {
		final GroupDto groupDto = new GroupDto();
		Mockito.doNothing().when(userDaoImpl).createGroup(groupDto);
		userManager.createGroup(groupDto);
	}

}